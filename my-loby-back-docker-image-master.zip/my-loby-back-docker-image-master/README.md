# My Loby Back Docker image

This is the base image of Node.
