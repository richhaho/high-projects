# MyLoby

## DEV

Migration && seed : https://sequelize.org/master/manual/migrations.html

```
typedoc --out docs src


```
### Prerequisites (Unix)

- Install the latest version of [Docker](https://docs.docker.com/install/) and [Docker Compose](https://docs.docker.com/compose/install/).
- Clone the project using `git clone git@git.thecodingmachine.com:tcm-projects/my-loby.git` inside
your working directory.

### Prerequisites (MacOS)

- Installs [Vagrant](https://www.vagrantup.com/).
- Installs [VirtualBox](https://www.virtualbox.org/).
- Clone the project using `git clone git@git.thecodingmachine.com:tcm-projects/my-loby.git` inside
your working directory.

### First steps

On MacOS, update your `hosts` file:

```bash
sudo nano /ect/hosts
```

With:

```bash
127.0.0.1 api.my-loby.localhost
127.0.0.1 front.my-loby.localhost
127.0.0.1 phpmyadmin.my-loby.localhost
```

Add .env file in root to feed docker-compose.yml variables
```
cp .env.template .env

```
_Set `CATCH_MAIL_ADDRESS` to receive all mails at this adresse and ADMIN_PASSWORD_
_Set `ADMIN_PASSWORD` to log in with as admin@gmail.com_
**On MacOS, run `make vagrant`, then `vagrant up` and finally `vagrant ssh` where you'll be able to run the following commands.**

Next, make sure that there is no application running on port 80, then start all the Docker containers with the following commands:
```
docker-compose up

```

## Vagrant (for macOS only)

* Simply stop the VM using `vagrant halt`.
* You may restart it again with `vagrant up`.
* When you stop working on the project for a while, simply run `vagrant destroy`.

## PWA

See [here](../pwa-my-loby/README.md) for commands and more.

## Server

See [here](../server-my-loby/README.md) for commands and more.

## PREPRODUCTION
add production.env file in root of the project
```
docker-compose -f docker-compose-preprod.yml up

```

## PRODUCTION
add production.env file in root of the project
```
docker-compose -f docker-compose-prod.yml up

```

docker login git.thecodingmachine.com:444