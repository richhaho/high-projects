<template>
    <v-app id="inspire">
        <v-app-bar
            v-if="phone"
            class="hidden-md-and-up"
            app
            dense
            flat
            color="#f4f6f9"
        >
            <img  :src="require('@/assets/img/myloby_logo.svg')" height="30" v-if="currentUser"/>
            <v-spacer></v-spacer>
            <p style="    color: #fe9301;
    font-family: 'Open Sans';
            font-size: 18px;
            font-weight: 700;
            margin: 0;">MyLoby</p>
            <v-spacer></v-spacer>
            <v-btn icon @click.stop="displayProfile = !displayProfile" v-if="currentUser">
                <v-icon>more_vert</v-icon>
            </v-btn>

        </v-app-bar>
        <v-navigation-drawer
            v-if="currentUser"
            v-model="displayProfile"
            fixed
            right
            temporary
            color="#F4F6F9"
        >
            <v-list
                dense
                nav
                class="py-0"
            >
                <router-link :to="{name: 'user',params: {id: currentUser.id}}" replace>
                    <v-list-item two-line class="mt-2">
                        <v-list-item-avatar>
                            <img
                                :src="getSrc(currentUser.picturePath) || defaultUserAvatar"
                                alt="userAvatar"
                                style="object-fit: cover;"
                            />
                        </v-list-item-avatar>

                        <v-list-item-content>
                            <v-list-item-title class="font-weight-bold title-color">{{currentUser.displayName}}
                            </v-list-item-title>
                        </v-list-item-content>
                    </v-list-item>
                </router-link>
                <LocaleSwitcher :mobile="true"/>

                <v-divider></v-divider>

                <v-list-item
                    link
                    v-if="!isDemo && !isB2B"
                >
                    <v-list-item-icon>
                        <v-icon color="#0d0934">insert_drive_file</v-icon>
                    </v-list-item-icon>

                    <v-list-item-content>
                        <v-list-item-title class="title-color subtitle-1">{{$t('link.myPayment')}}</v-list-item-title>
                    </v-list-item-content>
                </v-list-item>
                <router-link :to="{name: 'paymentMethod'}">
                    <v-list-item
                        link
                        v-if="!isB2B"
                    >
                        <v-list-item-icon>
                            <v-icon color="#0d0934" class="icon-picto_credit-card"></v-icon>
                        </v-list-item-icon>

                        <v-list-item-content>
                            <v-list-item-title class="title-color subtitle-1">{{$t('nav.paymentMethod')}}</v-list-item-title>
                        </v-list-item-content>
                    </v-list-item>
                </router-link>
                <v-list-item
                    link
                    href="mailto:info@myloby.fr"
                >
                    <v-list-item-icon>
                        <i class="icon-picto_courrier nav-icon-font-size"></i>
                    </v-list-item-icon>

                    <v-list-item-content>
                        <v-list-item-title class="title-color subtitle-1">{{$t('link.contactUs')}}</v-list-item-title>
                    </v-list-item-content>
                </v-list-item>
                <v-list-item
                    link
                    @click="logout"
                >
                    <v-list-item-icon>
                        <i class="icon-picto_retour back-icon-font-size"></i>
                    </v-list-item-icon>

                    <v-list-item-content>
                        <v-list-item-title class="title-color subtitle-1">{{$t('link.logout')}}</v-list-item-title>
                    </v-list-item-content>
                </v-list-item>
            </v-list>
        </v-navigation-drawer>
        <header-component v-if="!phone" class="hidden-xs-only" :current-user="currentUser"></header-component>

        <v-content class="hidden-md-and-up" v-if="isMobile">
            <v-alert
                text
                color="warning"
                id="refresh-toaster"
                style="display :none"
            >
                <v-row
                    align="center"
                    no-gutters
                >
                    <v-col class="">{{$t('pwaRefresh.text')}}</v-col>
                    <v-col class="shrink">
                        <v-btn
                            color="warning"
                            outlined
                            @click="refresh"
                        >
                            {{$t('pwaRefresh.button')}}
                        </v-btn>
                    </v-col>
                </v-row>
            </v-alert>
            <v-snackbar
                v-model="currentAlert.displayed"
                :color="currentAlert.color"
                :timeout="Number(currentAlert.timeDisplayed)"
                top
                class="snack-notification mobile"
                @click="closeAlert"
            >
                 <span class="content">
                      <span v-if="currentAlert.iconGroup" :class="`${currentAlert.iconGroup} mobile`" >
                        <i class="path1"></i>
                        <i class="path2"></i>
                        <i class="path3"></i>
                     </span>
                    <i v-if="currentAlert.icon" :class="`${currentAlert.icon} default`"></i>
                    {{currentAlert.msg}}
                 </span>
                <v-btn
                    text
                    dark
                    @click="closeAlert"
                >
                    <v-icon>clear</v-icon>
                </v-btn>
            </v-snackbar>
            <router-view name="mobile"/>
        </v-content>

        <div class="content hidden-xs-only" v-else>
            <side-nav v-if="currentUser" :current-user="currentUser"></side-nav>
            <v-content style="padding-top: 20px;">
                <v-snackbar
                    v-model="currentAlert.displayed"
                    :color="currentAlert.color"
                    :timeout="Number(currentAlert.timeDisplayed)"
                    top
                    class="snack-notification desktop"
                    @click="closeAlert"
                >
                    <span class="content">
                         <span v-if="currentAlert.iconGroup" :class="`${currentAlert.iconGroup} mobile`" >
                            <i class="path1"></i>
                            <i class="path2"></i>
                            <i class="path3"></i>
                         </span>
                        <i v-if="currentAlert.icon" :class="`${currentAlert.icon} default`"></i>
                    {{currentAlert.msg}}
                    </span>
                    <v-btn
                        text
                        dark
                        @click="closeAlert"
                    >
                        <v-icon>clear</v-icon>
                    </v-btn>
                </v-snackbar>
                <router-view/>
            </v-content>
        </div>
        <v-footer
            class="hidden-md-and-up"
            color="#f4f6f9"
            app
            v-if="currentUser"
        >
            <v-row no-gutters >
                <v-col class="text-center" v-if="!isDemo">
                    <router-link
                        active-class="active"
                        :to="{name: 'contacts'}">
                        <v-btn icon>
                            <i class="bottomNavIcon icon-picto_mes-contacts"></i>
                        </v-btn>
                    </router-link>
                </v-col>
                <v-col class="text-center">
                    <router-link
                        active-class="active"
                        :to="{name: 'keys', params: {tab: 'myKeys'}}">
                        <v-btn icon>
                            <i class="bottomNavIcon icon-picto_cle-partagees"/>
                        </v-btn>
                    </router-link>
                </v-col>
                <v-col class="text-center" v-if="isAdmin || isAgencyRef">
                    <router-link
                        active-class="active"
                        :to="{name: 'relays'}">
                        <v-btn icon>
                            <i class="bottomNavIcon icon-picto_relais-agence"></i>
                        </v-btn>
                    </router-link>
                </v-col>
                <v-col class="text-center" v-if="currentSubscriptionHasBooking">
                    <router-link
                        active-class="active"
                        :to="{name: 'planning'}">
                        <v-btn icon>
                            <span class="material-icons">
                                event
                            </span>
                        </v-btn>
                    </router-link>
                </v-col>
            </v-row>
        </v-footer>
    </v-app>
</template>

<script lang="ts">
import HeaderComponent from "@/components/HeaderComponent.vue";
import SideNav from "@/components/SideNav.vue";
import LocaleSwitcher from "@/components/LocaleSwitcher.vue";
import {defaultUserAvatar} from "@/utils/constants";
import {getSrc} from "@/utils/misc";
import {Component, Vue, Watch} from "vue-property-decorator";
import {Getter} from "vuex-class";

@Component({
    components: {
        HeaderComponent,
        SideNav,
        LocaleSwitcher,
    },
})
export default class App extends Vue {

    get langList() {
        return this.$store.state.lang.langList;
    }
    get currentAlert() {
        return this.$store.state.alerts.currentAlert;
    }
    get isMobile() {
        if (this.windowWidth > 900) {
            this.phone = false;
        }
        if (this.windowWidth <= 600 || this.phone === true ) {
            this.phone = true;
            return true;
        } else {
            return false;
        }
    }

    get currentSubscriptionHasBooking() {
        return !!this.currentUser.Company?.currentSubscription?.details?.options?.allowBooking?.isActive
            || !this.currentUser.Company?.currentSubscription;
    }

    private phone: boolean = false;
    private displayProfile: boolean = false;
    private getSrc: (string) => string = getSrc;
    private windowWidth: number =  1000;
    private defaultUserAvatar: string = defaultUserAvatar;

    @Getter private isDemo: boolean;
    @Getter private currentUser: any;
    @Getter private isB2B: boolean;
    @Getter private isAgencyRef: boolean;
    @Getter private isAdmin: boolean;

    @Watch("$route", { immediate: true, deep: true })
    public handlerRouter() {
        this.$store.commit("mobileMenu", true);
    }
    private mounted() {
        this.getWindowWidth();
        window.addEventListener("resize", this.getWindowWidth);
    }

    private logout() {
        this.displayProfile = false;
        this.$store.dispatch("auth/logout");
    }

    private getWindowWidth() {
        this.windowWidth = document.documentElement.clientWidth;
        this.$store.commit("dispatchIsMobile", this.isMobile);
    }

    private refresh() {
        window.location.reload();
    }

    private closeAlert() {
        this.$store.commit("alerts/hideAlert");
    }
}
</script>
