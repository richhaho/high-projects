<template>
    <v-row>
        <v-col cols="12" class="py-0">
            <v-autocomplete
                clearable
                no-filter
                v-model="select"
                :loading="loading"
                @change="selectValue"
                :items="items"
                :search-input.sync="search"
                :no-data-text="$t('common.noResult')"
                :hide-no-data="!search || loading"
                v-bind:label="label || $t('form.address')"
                item-text="display_name"
                return-object
                :rules="rules || []"
                :readonly="readonly || false"
                :solo-inverted="mobile"
                :dense="mobile"
                :filled="mobile"
            >
                <template v-slot:append-outer>
                    <v-icon v-if="!relayMap"
                        @click="toggleExtendAddress"
                    >{{split}}
                    </v-icon>
                </template>
                <template v-slot:selection="data">
                    <v-list-item-content v-if="data.item">
                        <p class="mb-0">{{ data.item.display_name }}</p>
                    </v-list-item-content>

                </template>
                <template v-slot:item="data">
                    <template>
                        <v-list-item-content
                            :style="relayMap ? 'max-width: 400px': ''"
                            v-if="data.item && data.item.address && data.item.address.house_number && data.item.address.road && data.item.address.postcode && data.item.address.city">
                            <v-list-item-title
                                v-html="data.item.address.house_number + ' ' + data.item.address.road"></v-list-item-title>
                            <v-list-item-subtitle
                                v-html="data.item.address.postcode + ', ' + data.item.address.city"
                            ></v-list-item-subtitle>
                        </v-list-item-content>
                        <v-list-item-content v-else-if="data.item" :style="relayMap ? 'max-width: 400px': ''">
                            <v-list-item-title v-html="data.item.display_name"></v-list-item-title>
                        </v-list-item-content>
                    </template>
                </template>
            </v-autocomplete>
            <v-col cols="6" class="py-0" v-if="!relayMap && isAddressExtended">
                <v-text-field @change="handleSubAddress('address')" :label="$t('form.fullAddress')"
                              v-model="tmp.address"></v-text-field>
            </v-col>
            <v-col cols="6" class="py-0" v-if="!relayMap && isAddressExtended">
                <v-text-field @change="handleSubAddress" :label="$t('form.latitude')"
                              v-model="tmp.latitude"></v-text-field>
            </v-col>
            <v-col cols="6" class="py-0" v-if="!relayMap && isAddressExtended">
                <v-text-field @change="handleSubAddress" :label="$t('form.longitude')"
                              v-model="tmp.longitude"></v-text-field>
            </v-col>
            <v-col cols="6" class="py-0" v-if="!relayMap && isAddressExtended">
                <v-text-field @change="handleSubAddress" :label="$t('form.city')" v-model="tmp.city"></v-text-field>
            </v-col>
            <v-col cols="6" class="py-0" v-if="!relayMap && isAddressExtended">
                <v-text-field @change="handleSubAddress" :label="$t('form.country')"
                              v-model="tmp.country"></v-text-field>
            </v-col>
            <v-col cols="6" class="py-0" v-if="!relayMap && isAddressExtended">
                <v-text-field @change="handleSubAddress" :label="$t('form.zipCode')"
                              v-model="tmp.postcode"></v-text-field>
            </v-col>
        </v-col>
    </v-row>
</template>

<script lang="ts">
import { Component, Prop, Vue, Watch } from "vue-property-decorator";
import { mdiFormatLineSpacing } from "@mdi/js";
import Timeout = NodeJS.Timeout;

export const DEBOUNCE_TIME_MILLI: number = 800;

@Component({
    components: {},
})
export default class AddressGeo extends Vue {

    @Prop({default: null})
    public addressdisplayname: string;

    @Prop()
    public label: string;

    @Prop()
    public rules: string;

    @Prop()
    public readonly: boolean;

    @Prop({default: null})
    public address: string;

    @Prop({default: null})
    public postcode: string;

    @Prop({default: null})
    public city: string;

    @Prop({default: null})
    public country: string;

    @Prop({default: null})
    public latitude: string;

    @Prop({default: null})
    public longitude: string;

    @Prop({default: false})
    public relayMap: boolean;

    @Prop({default: false})
    public mobile: boolean;

    private split: any = mdiFormatLineSpacing;
    private loading: boolean = false;
    private timerId: Timeout = null;
    private items: any[] = [];
    private search: string = null;
    private select: any = null;
    private tmp: any = {};
    private isAddressExtended: boolean = false;

    @Watch("search")
    public handlerSearch() {
        if (this.search && this.search !== this.select) {
            // cancel pending call
            clearTimeout(this.timerId);
            // delay new call
            this.loading = true;
            this.timerId = setTimeout(() => {
                this.querySelections(this.search);
            }, DEBOUNCE_TIME_MILLI);
        }
    }

    public querySelections(val) {
        this.$store.dispatch("nominatim/searchByAddressName", {search: val}).then((res) => {
            this.items = res;
            this.loading = false;
        }).catch((err) => {
            this.loading = false;
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    public selectValue() {
        if (this.select && this.select.address) {
            this.tmp = {
                address: (this.select.address.house_number || "") + " " + (this.select.address.road || ""),
                latitude: this.select.lat,
                longitude: this.select.lon,
                city: this.select.address.city || this.select.address.municipality,
                country: this.select.address.country,
                postcode: this.select.address.postcode,
                addressdisplayname: this.select.display_name,
            };
            // when address is correctly found
            if (this.select.address.house_number && this.select.address.road) {
                this.emit(this.tmp);
            } else {
                this.isAddressExtended = true;
            }
        }
    }

    public handleSubAddress() {
        this.tmp.addressdisplayname = this.tmp.address;
        this.select = null;
        this.setSelect({display_name: this.tmp.addressdisplayname});
        this.emit(this.tmp);

    }

    public emit(address) {
        this.$emit("update:address", address.address);
        this.$emit("update:addressdisplayname", address.addressdisplayname);
        this.$emit("update:city", address.city);
        this.$emit("update:postcode", address.postcode);
        this.$emit("update:country", address.country);
        this.$emit("update:latitude", address.latitude);
        this.$emit("update:longitude", address.longitude);
    }

    public toggleExtendAddress() {
        this.isAddressExtended = !this.isAddressExtended;
    }

    public setSelect(item) {
        this.items = [item];
        this.select = item;
    }

    private mounted() {
        if (this.addressdisplayname || this.address) {
            this.setSelect({display_name: this.addressdisplayname || this.address});
            this.tmp = {
                address: this.address,
                latitude: this.latitude,
                longitude: this.longitude,
                city: this.city,
                country: this.country,
                postcode: this.postcode,
                addressdisplayname: this.addressdisplayname,
            };
        }
    }
}
</script>
