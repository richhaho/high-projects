<template>
    <v-sheet :height="isMobile && type !== 'month' ? '': '600px'" :class="isMobile ? 'calendar-mobile calendar' : 'calendar'">
        <p v-if="cardItem" class="calendarTitle">{{title}}</p>
        <v-calendar
            class="calendarDisplay"
            ref="calendar"
            v-model="currentFocus"
            color="primary"
            :events="concernedEvents"
            :event-color="getEventColor"
            :type="type"
            :weekdays="[1, 2, 3, 4, 5, 6, 0]"
            @click:event="showEvent"
            @click:more="viewDay"
            @click:date="viewDay"
            @click:day="openAddReservationModal"
            @click:time="openAddReservationModal"
            @change="updateRange"
        ></v-calendar>
        <v-menu
            v-model="selectedOpen"
            :close-on-content-click="false"
            :activator="selectedElement"
            offset-x
        >
            <v-card
                color="grey lighten-4"
                min-width="350px"
                flat
            >
                <v-toolbar
                    :color="selectedEvent.color"
                    dark
                >
                    <v-btn icon>
                        <v-icon>mdi-pencil</v-icon>
                    </v-btn>
                    <v-toolbar-title v-html="selectedEvent.name"></v-toolbar-title>
                    <v-spacer></v-spacer>
                    <v-btn icon>
                        <v-icon>mdi-heart</v-icon>
                    </v-btn>
                    <v-btn icon>
                        <v-icon>mdi-dots-vertical</v-icon>
                    </v-btn>
                </v-toolbar>
                <v-card-text>
                    <span v-html="selectedEvent.details"></span>
                </v-card-text>
                <v-card-actions>
                    <v-btn
                        text
                        color="secondary"
                        @click="selectedOpen = false"
                    >
                        Cancel
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-menu>
    </v-sheet>
</template>

<script lang="ts">
import {Component, Prop, Vue, Watch} from "vue-property-decorator";

@Component
export default class Calendar extends Vue {
    @Prop({default: false})
    public isMobile: boolean;

    @Prop()
    public type: string;

    @Prop()
    public focus: string;

    @Prop({default: null})
    public cardItem: any;

    @Prop({default: []})
    public events: any[];

    public selectedEvent: object = {};
    public selectedElement: object = null;
    public selectedOpen: boolean = false;
    public colors: string[] = ["blue", "indigo", "deep-purple", "cyan", "green", "orange", "grey darken-1"];
    public currentFocus: string = "";
    public loadedRange: boolean = false;

    public $refs!: {
        calendar: HTMLFormElement,
    };

    @Watch("focus")
    public handlerFocus() {
        this.currentFocus = this.focus;
    }

    private mounted() {
        this.$refs.calendar.checkChange();
        this.currentFocus = this.focus;
    }

    get title() {
        return this.cardItem ? this.cardItem.value : "";
    }

    get concernedEvents() {
        if (!this.cardItem) {
            return this.events;
        }
        switch (this.cardItem.type) {
            case "key":
                return this.events.filter((event) => event.key.id === this.cardItem.id);
            case "user":
                return this.events.filter((event) => event.user.id === this.cardItem.id);
            default:
                return this.events;
        }
    }

    private showEvent({ nativeEvent, event }) {
        this.$emit("showEvent", event);
        nativeEvent.stopPropagation();
    }

    private updateRange({ start, end }) {
        if (!this.loadedRange) {
            return this.loadedRange = true;
        }
        this.$emit("updateRange", {
            start,
            end,
        });
    }

    private prev() {
        this.$refs.calendar.prev();
        this.$emit("update-focus", this.currentFocus);
    }

    private next() {
        this.$refs.calendar.next();
        this.$emit("update-focus", this.currentFocus);
    }

    private viewDay({ date }) {
        this.$emit("update-focus", date);
        this.$emit("update-type", "day");
    }

    private getEventColor(event) {
        return event.color;
    }
    private openAddReservationModal(date) {
        this.$emit("addBooking", {date});
    }
}
</script>

<style scoped>

</style>