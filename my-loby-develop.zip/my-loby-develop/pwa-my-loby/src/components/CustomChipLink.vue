<template>
    <v-btn
        :to="route"
        :color="color"
        class="v-btn--active text-none"
        rounded
        text
        x-small
    >
        <v-icon left x-small v-if="icon">{{ icon }}</v-icon>
        {{ text }}
    </v-btn>
</template>

<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";

@Component({})
export default class CustomChipLink extends Vue {
    @Prop({default: null})
    public type: string;

    @Prop({default: null})
    public id: number;

    @Prop({default: null})
    public text: string;

    get route(): any {
        switch (this.type) {
            case "user":
                return {
                    name: "user",
                    params: { id: this.id },
                };
            case "key":
                return {
                    name: "key",
                    params: { id: this.id },
                };
            case "relay":
                return {
                    name: "relay",
                    params: { id: this.id },
                };
            case "userGroup":
                return {
                    name: "contacts",
                    params: {
                        tab: "groups",
                        groupId: this.id,
                    },
                };
            case "keyGroup":
                return {
                    name: "keys",
                    params: {
                        tab: "groups",
                        groupId: this.id,
                    },
                };
            default:
                return {};
        }
    }

    get color(): string {
        switch (this.type) {
            case "user":
                return "warning";
            case "key":
                return "blue";
            case "relay":
                return "green";
            case "userGroup":
                return "red";
            case "keyGroup":
                return "red";
            default:
                return "";
        }
    }

    get icon(): string {
        switch (this.type) {
            case "user":
                return "person";
            case "key":
                return "vpn_key";
            case "relay":
                return "home";
            case "userGroup":
                return "people";
            case "keyGroup":
                return "vpn_key";
            default:
                return "";
        }
    }
}
</script>