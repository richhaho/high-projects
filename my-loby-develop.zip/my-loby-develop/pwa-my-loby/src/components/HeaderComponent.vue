<template>
  <header>
    <div class="content header_row header-component">
        <div class="left_part">
            <div class="logo_brand_wrap">
                <router-link to="/">
                    <div class="image">
                        <img src="../assets/img/myloby_logo.svg" alt/>
                    </div>
                    <p class="brand_name">Myloby</p>
                </router-link>
            </div>
        </div>
      <!-- /.left_part -->
      <div class="flex-grow">
        <div class="middle_part search_bar" v-if="currentUser && displaySearchBar">
            <!--
            <i class="icon-picto_recherche"></i>
            <input
                v-model="searchQuery"
                type="search"
                name="dashboard-search"
                :placeholder="$t('search_placeholder')"
            />
            -->
        </div>
      </div>
      <!-- /.middle_part -->
      <div class="right_part notifs_profil">
        <!--
        <a href="#">
          <i class="icon-header_interrogation"></i>
        </a>
        <a href="#" v-if="currentUser">
          <i class="icon-header_notification pastille_orange"></i>
        </a>
        -->
        <LocaleSwitcher/>
        <a
          href="#"
          @click.prevent="profileDetails = !profileDetails"
          title="Profil"
          class="profil_action"
          v-if="currentUser"
        >
          <span class="image">
            <v-avatar class="ma-0" size="30">
              <img
                :src="getSrc(currentUser.picturePath) || defaultUserAvatar"
                alt="userAvatar"
                style="object-fit: cover;"
              />
            </v-avatar>
          </span>
          <i class="icon-header_triangle little"></i>
        </a>
          <div :class="{'d-block' : profileDetails}" id="profil_details" v-if="currentUser">
              <v-row justify="start">
                  <v-avatar class="ml-3 mr-2" size="30">
                      <img
                          :src="getSrc(currentUser.picturePath) || defaultUserAvatar"
                          alt="userAvatar"
                          style="object-fit: cover;"
                      />
                  </v-avatar>
                  <p>{{currentUser.displayName}}</p>
              </v-row>
              <v-row justify="end">
                  <a class="btn_style" href="#" v-show="false">
                      <i class="icon-picto_ajouter"></i>Ajouter un compte
                  </a>
                  <router-link :to="{name: 'user',params: {id: currentUser.id}}">
                      <button class="btn_style no_picto" @click="profileDetails = false">
                          {{$t('link.myAccount')}}
                      </button>
                  </router-link>
                  <a @click="logout" class="btn_style no_picto mx-3" href="#">
                      {{$t('link.logout')}}
                  </a>
              </v-row>
          </div>
        <!--<v-btn v-if="!currentUser" to="/login">Login</v-btn>-->
      </div>
      <!-- /.right_part -->
    </div>
    <!-- /.header_row -->

    <div class="toggle_menu d-lg-none p-y-2" @click="onMenuClick">
      <a class="" href="#" title="Menu">Menu</a>
    </div>
  </header>
</template>
<script lang="ts">
import {Component, Prop, Vue} from "vue-property-decorator";
import {defaultUserAvatar} from "@/utils/constants";
import {getSrc} from "@/utils/misc";
import LocaleSwitcher from "@/components/LocaleSwitcher.vue";
@Component({
    components: {
        LocaleSwitcher,
    },
})
export default class HeaderComponent extends Vue {

    get displaySearchBar() {
        return this.$store.getters.isDisplayed;
    }

    get searchQuery() {
        return this.$store.getters.getSearchQuery;
    }

    set searchQuery(query) {
        this.$store.commit("updateSearch", query);
    }
    @Prop()
    public currentUser;

    private profileDetails: boolean = false;
    private defaultUserAvatar: string = defaultUserAvatar;
    private getSrc: (string) => string = getSrc;

    public logout() {
        this.profileDetails = false;
        this.$store.dispatch("auth/logout");
    }

    private onMenuClick() {
        this.$store.dispatch("toggleMobileMenu");
    }
}
</script>