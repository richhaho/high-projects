<template>
    <div>
        <img :src="getSrc(picturePath) || defaultKeyPicture" class="img_profil"
            style="object-fit: cover" alt="key picture"/>
    </div>
</template>

<script lang="ts">
    /* tslint:disable */
    import {Component, Prop, Vue} from "vue-property-decorator";
    import {defaultKeyPicture} from "@/utils/constants";
    import { getSrc } from '@/utils/misc';

    @Component({
        components: {},
    })

    export default class ImageKeyRenderer extends Vue {
        @Prop({default: null})
        public picturePath: string;

        private getSrc: (picturePath: string) => string = getSrc;
        private defaultKeyPicture: string = defaultKeyPicture;
    }
</script>

