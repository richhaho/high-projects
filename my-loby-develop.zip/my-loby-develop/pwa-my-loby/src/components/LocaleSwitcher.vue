<template>
    <v-select
        :items="locales"
        v-model="$root.$i18n.locale"
        dense
        flat
        hide-details
        class="locale-switcher mb-1 ml-2"
        :class="mobile ? 'locale-switcher-mobile' : ''"
        :solo-inverted="!mobile"
        :append-icon="!mobile ? '' : '$dropdown'"
    >
        <template slot="selection" slot-scope="data">
            {{ getIconByLocale(data.item) }}
            <span v-if="mobile" class="ml-2">
                {{ $t(`locales.${data.item}.name`) }}
            </span>
        </template>
        <template slot="item" slot-scope="data">
            {{ getIconByLocale(data.item) }}
            {{ $t(`locales.${data.item}.name`) }}
        </template>
    </v-select>
</template>

<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";
import getUnicodeFlagIcon from "country-flag-icons/unicode";

@Component({})
export default class LocaleSwitcher extends Vue {
    @Prop({default: false})
    public mobile: boolean;

    get locales(): string[] {
        // Return all available locales (detected by i18n with locales files found in the locale folder)
        return this.$root.$i18n.availableLocales;
    }

    private getIconByLocale(locale: string): any {
        if (locale === "en") {
            return getUnicodeFlagIcon("GB");
        }
        return getUnicodeFlagIcon(locale.toUpperCase());
    }
}
</script>
<style lang="scss">
    .locale-switcher.v-input{
        width: 40px;
        max-width: 40px;
    }
    .locale-switcher-mobile.v-input{
        width: 150px;
        max-width: 150px;
    }
    .theme--light.locale-switcher.v-text-field--solo-inverted>.v-input__control>.v-input__slot,
    .theme--light.locale-switcher.v-text-field--solo-inverted.v-input--is-focused>.v-input__control>.v-input__slot{
        background: none;
    }
    .locale-switcher.v-select:not(.v-select--is-multi).v-text-field--single-line .v-select__selections{
        flex-direction: row-reverse;
    }
</style>
