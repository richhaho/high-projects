<template>
    <v-dialog max-width="500px" v-model="dialog" persistent>
        <v-card>
            <v-card-title style="word-break: normal;">
                <span class="headline">
                    {{ $t("invitation.smsLimitReached.title") }}
                </span>
            </v-card-title>
            <v-card-text class="pb-1">
                <v-container class="pb-0">
                    <p>{{ $tc("invitation.smsLimitReached.text", {limit}) }}</p>
                    <p v-if="isB2B">{{ $t("invitation.smsLimitReached.overprice", {overprice}) }}</p>
                    <p v-if="isB2B">{{ $t("invitation.smsLimitReached.mail") }}</p>
                    <p v-if="!isB2B">{{ $t("invitation.smsLimitReached.mailB2C") }}</p>
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    @click="$emit('cancel')"
                    color="white"
                    text
                >
                    {{ $t("actions.cancel") }}
                </v-btn>
                <v-btn
                    v-if="isB2B"
                    @click="$emit('accept')"
                    :loading="loading"
                    color="warning"
                >
                    {{ $t("actions.sendSms") }}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";
import {Getter} from "vuex-class";

@Component({})
export default class OverPriceSms extends Vue {
    @Prop({default: false})
    public dialog: boolean;

    @Prop({default: 0})
    public limit: number;

    @Prop({default: 0.07})
    public overprice: number;

    @Prop({default: false})
    public loading: boolean;

    @Getter private isB2B: boolean;
}
</script>