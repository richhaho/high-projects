<template>
    <v-dialog
        persistent
        max-width="910px"
        v-model="displayQrCodeReaderModal"
        :fullscreen="mobile"
        :hide-overlay="mobile"
        :transition="mobile ? 'dialog-bottom-transition': ''"
    >
        <v-card>
            <v-card-title style="word-break: normal;">
                <v-container class="py-0">
                    <v-row justify="center" class="ma-0">
                        <h5 class="ma-0 text-center" v-if="location">
                            {{ $t('key.askSpecificLocation')}}
                            <br/>
                            n°{{ location.codeName }}
                        </h5>
                        <h5 class="ma-0" v-else-if="action === 'DROP'">
                            {{ $t('key.askAnyLocation') }}
                        </h5>
                        <h5 class="ma-0" v-else-if="action === 'HAND_TO_HAND'">
                            {{ $t('key.askUserQrCode') }}
                        </h5>
                        <h5 class="ma-0" v-else-if="action === 'PIN'">
                            {{ $t('key.askReferentPin') }}
                        </h5>
                    </v-row>
                </v-container>
            </v-card-title>
            <v-card-text>
                <v-container class="pa-0 pt-5">
                    <v-alert
                        v-if="readerError === 'StreamApiNotSupportedError'"
                        class="ma-0"
                        color="red"
                        dense
                        outlined
                        text
                    >
                        {{ $t("alerts.error.onlySafariSupported") }}
                    </v-alert>
                    <v-alert
                        v-else-if="error"
                        color="red"
                        dense
                        outlined
                        text
                    >
                        {{ error }}
                    </v-alert>
                    <v-row v-if="hasForceInput">
                        <v-col class="d-flex">
                            <input
                                class="input-group--focused text-center mr-2 form-control"
                                type="text"
                                :placeholder="$t('qrcode.force')"
                                ref="fromUsbScaner"
                                v-model="qrcodeString"
                                @keypress="enterKeyPress"
                            > 
                            <v-btn @click="forceReadQR" color="warning">{{$t('actions.validate')}}</v-btn>
                        </v-col>
                    </v-row>
                    <qrcode-stream
                        v-if="displayScanner && readerError !== 'StreamApiNotSupportedError'"
                        @decode="onDecode"
                        @init="onInit"
                    />
                    <div class="reload-cta"
                         @click="reloadScanner">{{$t('actions.reloadQrCodeStream')}}</div>
                    <!--
                    <v-file-input
                        @change="fileChange"
                        accept="image/png, image/jpeg, image/bmp"
                        prepend-icon="photo"
                        v-model="avatar"
                    ></v-file-input>

                    <label for="files" class="custom-file-upload">
                        <i class="qrcode-scan"></i> SCAN QR-Code
                    </label>
                    <input id="files" type="file" accept="image/jpeg, image/png"  multiple data-
                           role="none" capture="camera"
                    />
                    <textarea id="base64" rows="5"></textarea>
                    -->
                    <v-row justify="center">
                        <v-col align="center" class="px-0">
                            <img
                                :src="getSrc(keyPicture) || defaultKeyPicture"
                                alt="keyPicture"
                                style="object-fit: contain; max-width: 300px;"
                            />
                            <p v-if="keyDescription" class="text-center mb-0 mt-4">{{keyDescription}}</p>
                        </v-col>
                    </v-row>
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn @click="$emit('close')" color="white" text>{{$t('actions.cancel')}}</v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
/* tslint:disable */

import {Component, Prop, Vue} from "vue-property-decorator";
import {QrcodeCapture, QrcodeStream} from "vue-qrcode-reader";
import Jimp from "jimp";
import QrCode from "qrcode-reader";
import {decode} from "base64-arraybuffer";
import {defaultKeyPicture} from "@/utils/constants";
import { getSrc } from '@/utils/misc';

declare const Buffer;

@Component({
    components: {
        QrcodeStream,
        QrcodeCapture,
    },
})
export default class QrCodeReader extends Vue {
    @Prop({default: ""})
    public location: string;

    @Prop({})
    public readQrCode: (token) => void;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: false})
    public displayQrCodeReaderModal: boolean;

    @Prop({default: ""})
    public keyPicture: string;

    @Prop({default: ""})
    public keyDescription: string;

    @Prop({default: ""})
    public qrCodeError: string;

    @Prop({default: ""})
    public action: string;

    @Prop({default: true})
    public hasForceInput: boolean;

    private qrcodeString: any = "";
    private result: any = "";
    private qrCodeImageUpload: any = null;
    private avatar: any = null;
    private pause: boolean = true;
    private getSrc: (string) => string = getSrc;
    private defaultKeyPicture = defaultKeyPicture;
    private readerError: string = null;
    private displayScanner: boolean = true;

    get error() {
       if (this.readerError) {
           return this.$i18n?.t(`alerts.error.${this.readerError}`);
       } else if (this.qrCodeError) {
           return this.qrCodeError;
       }
       return null;
    }

    private beforeDestroy() {
        console.log('beforeDestroy')
        this.pause = true;
    }

    private onDecode(decodedString) {
        console.log('onDecode', decodedString)
        if (decodedString) {
            this.displayScanner = false;
            this.$nextTick().then(() => {
                // Add the component back in
                this.result = decodedString;
                this.readQrCode(decodedString);
            });
        }
    }
    private forceReadQR() {
        if (this.qrcodeString) {
            this.qrcodeString = this.qrcodeString.replaceAll("§", "-");
            this.readQrCode(this.qrcodeString);
        }
    }
    private enterKeyPress(e) {
        if (e.keyCode === 13) {
            this.forceReadQR();
        }
    }
    

    private reloadScanner(decodedString) {
        this.displayScanner = false;
        this.result = ""
        setTimeout(() => this.displayScanner = true, 1000)
    }

    private mounted() {
        if (this.displayQrCodeReaderModal) {
            /*
            // Test for iOS users -> Manual file input
            if (window.File && window.FileReader && window.FileList && window.Blob) {
                document.getElementById("files").addEventListener("change", (evt) => {
                    // tslint:disable-next-line
                    const f = (evt.target as any).files[0]; // FileList object
                    // tslint:disable-next-line
                    const reader = new FileReader();
                    // Closure to capture the file information.
                    reader.onload = ((theFile) => {
                        return (e) => {
                            const binaryData = e.target.result;
                            // Converting Binary Data to base 64
                            const base64String = window.btoa(binaryData);
                            // Test #1 : decode file input front-end
                            // showing file converted to base64
                            // tslint:disable-next-line
                            (document.getElementById("base64") as any).value = base64String;
                            const fileContent: any = decode(base64String);
                            Jimp.read(fileContent, (errJimp, image) => {
                                if (errJimp) {
                                    console.log(errJimp)
                                } else {
                                    const qr = new QrCode();
                                    qr.callback = (errQrCode, value) => {
                                        if (errQrCode) {
                                            console.log(errQrCode)
                                        }
                                        if(value?.result){
                                            console.log(value.result);
                                            this.onDecode(value.result)
                                        }
                                    };
                                    qr.decode(image.bitmap);
                                }
                            });
                            // Test #2 : decode file input back-end
                            this.$store.dispatch("files/getTokenFromQrCode", {base64String: base64String}).then(
                                (data) => this.onDecode(data.result),
                            );
                        };
                    })(f);
                    // Read in the image file as a data URL.
                    reader.readAsBinaryString(f);
                }, false);
            } else {
                alert("The File APIs are not fully supported in this browser.");
            }
             */
        }
    }


    private async onInit(promise) {
        console.log('onInit', promise)
        this.qrcodeString = "";
        try {
            await promise;
            this.pause = true;
        } catch (error) {
            this.readerError = error.name;
        }
        if (this.hasForceInput) {
            (this.$refs.fromUsbScaner as HTMLFormElement).focus();
        }
    }

    private fileChange() {
        const formData = new FormData();
        formData.append("file", this.avatar);
        this.$store.dispatch("files/getTokenFromQrCodeFormData", { formData });
    }



}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
    .error {
        font-weight: bold;
        color: red;
    }
    .custom-file-upload {
        border: 1px solid #ccc;
        display: inline-block;
        padding: 6px 12px;
        cursor: pointer;
    }
    .reload-cta {
        text-align: center;
        margin: 10px;
        text-decoration: underline;
        color: gray;
    }
</style>
