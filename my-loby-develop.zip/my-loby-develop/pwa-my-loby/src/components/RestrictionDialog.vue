<template>
    <v-dialog
        v-if="currentUser && currentUser.company && type"
        max-width="500px"
        persistent
        v-model="dialog"
        :fullscreen="mobile"
        :hide-overlay="mobile"
        :transition="mobile ? 'dialog-bottom-transition' : ''"
    >
        <v-card>
            <v-card-title>
                <v-row justify="center">
                    <span class="headline">{{$t(`restrictions.${type}.title`)}}</span>
                </v-row>
            </v-card-title>
            <v-card-text>
                <v-container>
                    <v-row>
                        <p v-if="restrictions">{{$t(`restrictions.${type}.text`, {planName: planName, maxValue: restrictions[type]})}}</p>
                        <p v-else>{{$t("restrictions.noPlan")}}</p>
                        <i18n v-if="isMaster" path="restrictions.contactMyloby">
                            <a href="mailto:info@myloby.fr">MyLoby</a>
                        </i18n>
                    </v-row>
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    @click="$emit('close')"
                    color="white"
                    text
                >
                    {{$t('actions.close')}}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";
import {Getter} from "vuex-class";

@Component
export default class RestrictionDialog extends Vue {
    @Prop({default: null})
    public type: string;

    @Prop({default: false})
    public mobile: boolean;

    @Getter private isMaster: (type?: string) => boolean;
    @Getter private currentUser: any;
    private dialog: boolean = true;

    get restrictions() {
        return this.currentUser?.company?.currentSubscription?.Plan?.details;
    }

    get planName() {
        return this.$i18n.t(`plan.${this.currentUser?.company?.currentSubscription?.Plan?.name}.name`);
    }
}
</script>
