<template>
    <v-row>
        <div style="width: 100%; max-width: 450px" class="mb-5" v-if="!isLoading">
            <div v-for="(day, i) in week" v-if="companyOpeningHours[day.name]" :key="i" class="row" >
                <div class="col-md-6 first_col schedule" style="padding-bottom: 0">
                    <v-checkbox
                        v-model="companyOpeningHours[day.name].isActive"
                        :label="day.label"
                        :readonly="readonly"
                        color="#0c0733" class="schedule-checkbox" />
                    <v-checkbox
                        v-show="companyOpeningHours[day.name].isActive"
                        v-model="companyOpeningHours[day.name].continuous.isActive"
                        :label="$t('companyOpeningHours.continuous')"
                        :readonly="readonly"
                        color="#0c0733" class="schedule-checkbox" />
                </div>
                <div class="col-md-6 first_col"  v-show="companyOpeningHours[day.name].isActive">
                    <span
                        v-show="companyOpeningHours[day.name].continuous.isActive"
                        class="schedule-wrapper" >
                        <v-text-field
                            :id="`${i}-continuous-start-hour`"
                            @change="mutateValue(day.name, 'continuous', 'fromHours')"
                            @click="select(`${i}-continuous-start-hour`)"
                            v-model="companyHoursCopy[day.name].continuous.fromHours[0]"
                            class="schedule-input"/> :
                        <v-text-field
                            :id="`${i}-continuous-start-minute`"
                            @change="mutateValue(day.name, 'continuous', 'fromHours')"
                            @click="select(`${i}-continuous-start-minute`)"
                            v-model="companyHoursCopy[day.name].continuous.fromHours[1]"
                            class="schedule-input m-r"/> -
                        <v-text-field
                            :id="`${i}-continuous-end-hour`"
                            @change="mutateValue(day.name, 'continuous', 'toHours')"
                            @click="select(`${i}-continuous-end-hour`)"
                            v-model="companyHoursCopy[day.name].continuous.toHours[0]"
                            class="schedule-input m-l"/>:
                        <v-text-field
                            :id="`${i}-continuous-end-minute`"
                            @change="mutateValue(day.name, 'continuous', 'toHours')"
                            @click="select(`${i}-continuous-end-minute`)"
                            v-model="companyHoursCopy[day.name].continuous.toHours[1]"
                            class="schedule-input"/>
                    </span>
                </div>
                <div class="col-md-6 first_col"
                     style="padding-top: 0"
                     v-show="!companyOpeningHours[day.name].continuous.isActive && companyOpeningHours[day.name].isActive">
                    <v-checkbox
                        :label="$t('companyOpeningHours.morning')"
                        v-model="companyOpeningHours[day.name].morning.isActive"
                        :readonly="readonly"
                        color="#0c0733" class="schedule-checkbox"/>
                    <span class="schedule-wrapper"
                          style="padding-top: 5px;"
                          v-show="companyOpeningHours[day.name].morning.isActive">
                        <v-text-field
                            :id="`${i}-morning-start-hour`"
                            @change="mutateValue(day.name, 'morning', 'fromHours')"
                            @click="select(`${i}-morning-start-hour`)"
                            v-model="companyHoursCopy[day.name].morning.fromHours[0]"
                            class="schedule-input"/>:
                        <v-text-field
                            :id="`${i}-morning-start-minute`"
                            @change="mutateValue(day.name, 'morning', 'fromHours')"
                            @click="select(`${i}-morning-start-minute`)"
                            v-model="companyHoursCopy[day.name].morning.fromHours[1]"
                            class="schedule-input m-r"/>-
                        <v-text-field
                            :id="`${i}-morning-end-hour`"
                            @change="mutateValue(day.name, 'morning', 'toHours')"
                            @click="select(`${i}-morning-end-hour`)"
                            v-model="companyHoursCopy[day.name].morning.toHours[0]"
                            class="schedule-input m-l"/>:
                        <v-text-field
                            :id="`${i}-morning-end-minute`"
                            @change="mutateValue(day.name, 'morning', 'toHours')"
                            @click="select(`${i}-morning-end-minute`)"
                            v-model="companyHoursCopy[day.name].morning.toHours[1]"
                            class="schedule-input"/>
                    </span>
                </div>
                <div v-show="!companyOpeningHours[day.name].continuous.isActive && companyOpeningHours[day.name].isActive"
                     style="padding-top: 0"
                    class="col-md-6 first_col">
                    <v-checkbox
                        :label="$t('companyOpeningHours.evening')"
                        v-model="companyOpeningHours[day.name].evening.isActive"
                        :readonly="readonly"
                        color="#0c0733" class="schedule-checkbox" />
                    <span   class="schedule-wrapper"
                            style="padding-top: 5px;"
                            v-show="companyOpeningHours[day.name].evening.isActive">
                        <v-text-field
                            :id="`${i}-afternoon-start-hour`"
                            @change="mutateValue(day.name, 'evening', 'fromHours')"
                            @click="select(`${i}-afternoon-start-hour`)"
                            v-model="companyHoursCopy[day.name].evening.fromHours[0]"
                            class="schedule-input"/>:
                        <v-text-field
                            :id="`${i}-afternoon-start-minute`"
                            @change="mutateValue(day.name, 'evening', 'fromHours')"
                            @click="select(`${i}-afternoon-start-minute`)"
                            v-model="companyHoursCopy[day.name].evening.fromHours[1]"
                            class="schedule-input m-r"/>-
                        <v-text-field
                            :id="`${i}-afternoon-end-hour`"
                            @change="mutateValue(day.name, 'evening', 'toHours')"
                            @click="select(`${i}-afternoon-end-hour`)"
                            v-model="companyHoursCopy[day.name].evening.toHours[0]"
                            class="schedule-input m-l"/>:
                        <v-text-field
                            :id="`${i}-afternoon-end-minute`"
                            @change="mutateValue(day.name, 'evening', 'toHours')"
                            @click="select(`${i}-afternoon-end-minute`)"
                            v-model="companyHoursCopy[day.name].evening.toHours[1]"
                            class="schedule-input"/>
                    </span>
                </div>
            </div>
        </div>
    </v-row>
</template>

<script lang="ts">
import {Vue, Component, Prop, Watch} from "vue-property-decorator";

@Component({})
export default class SchedulePicker extends Vue {

    get week() {
        return [
            {label: this.$t("day.monday"), name: "monday"},
            {label: this.$t("day.tuesday"), name: "tuesday"},
            {label: this.$t("day.wednesday"), name: "wednesday"},
            {label: this.$t("day.thursday"), name: "thursday"},
            {label: this.$t("day.friday"), name: "friday"},
            {label: this.$t("day.saturday"), name: "saturday"},
            {label: this.$t("day.sunday"), name: "sunday"},
        ];
    }
    @Prop({default: null})
    public companyOpeningHours: any;

    @Prop({default: false})
    public readonly: boolean;

    private hours: any = [];
    private companyHoursCopy: any = {};
    private isLoading: boolean = true;

    @Watch("companyOpeningHours", { immediate: true, deep: true })
    public async handler() {
        this.companyHoursCopy = await JSON.parse(JSON.stringify(this.companyOpeningHours));
        this.fromDataToInput();
    }

    public mutateValue(day, type, hours) {
        if (this.formatNumber(+this.companyHoursCopy[day][type][hours][0]) &&
                this.formatNumber(+this.companyHoursCopy[day][type][hours][1])) {
            const openingHours = [this.formatNumber(+this.companyHoursCopy[day][type][hours][0]),
                this.formatNumber(+this.companyHoursCopy[day][type][hours][1])];
            this.companyHoursCopy[day][type][hours] = [];
            this.companyHoursCopy[day][type][hours] = openingHours;
            this.companyOpeningHours[day][type][hours] = `${this.companyHoursCopy[day][type][hours][0]}:${this.companyHoursCopy[day][type][hours][1]}`;
        }
    }

    private formatNumber(number) {
        return  number.toString().length === 1 ? "0" + number : number;
    }

    private select(elemId: string): void {
        const input: any = document.getElementById(elemId);
        input.focus();
        input.select();
    }

    private fromDataToInput() {
        const keysEntries = ["continuous", "morning", "evening"];
        const valEntries = ["fromHours", "toHours"];

        this.week.forEach((day) => {
            keysEntries.forEach((e) => {
                valEntries.forEach((h) => {
                    if (typeof this.companyHoursCopy[day.name][e][h] === "string") {
                        this.companyHoursCopy[day.name][e][h] = this.companyHoursCopy[day.name][e][h].split(":");
                    }
                });
            });
        });
        this.isLoading = false;
    }
}
</script>
