<template>
  <div id="nav" class="left_part d-lg-block" :class="{'display-none': !mobileMenu}">
    <section>
      <nav class="main_nav nav">
        <ul>
          <router-link
              v-if="tab.to"
              v-for="(tab, i) in displayedMenu"
              :key="i"
              exact
              active-class="active"
              tag="li"
              :to="tab.to"
              :title="$t(tab.title)"
          >
            <a href="#" :title="$t(tab.title)">
                <span v-if="tab.pictoType === 'materialDesign'" class="material-icons">
                    {{ tab.picto }}
                </span>
                <i
                    v-else
                    :class="tab.picto"
                ></i>
                {{$t(tab.title)}}
            </a>
          </router-link>
        </ul>
      </nav>
    </section>
  </div>
</template>
<script lang="ts">
import {Component, Vue} from "vue-property-decorator";
import {Getter} from "vuex-class";

@Component({})
    export default class SideNav extends Vue {
        @Getter private isMaster: (type?: string) => boolean;
        @Getter private isB2B: boolean;
        @Getter private isAdmin: boolean;
        @Getter private currentUser: any;
        @Getter private isLobyRef: boolean;
        @Getter private isInsuranceRef: boolean;
        @Getter private isMobileMenuOpen: boolean;
        @Getter private isDemo: boolean;

        get mobileMenu() {
            return this.isMobileMenuOpen;
        }

        get canUseBooking() {
            return !!this.currentUser?.company?.currentSubscription?.details?.options?.allowBooking?.isActive;
        }

        get isAgencyRef() {
            return this.currentUser?.company?.type === "B2B" && this.currentUser?.Relays?.length;
        }

        get displayedMenu() {
            if (this.isAdmin) {
                return this.navTabs().Admin;
            } else if (this.isB2B) {
                return this.navTabs().B2B;
            } else if (this.isLobyRef) {
                return this.navTabs().LobyRef;
            } else if (this.isInsuranceRef) {
                return this.navTabs().InsuranceRef;
            } else if (this.isMaster("INSURANCE")) {
                return this.navTabs().InsuranceMaster;
            } else {
                return this.navTabs().B2C;
            }
        }

        get relayTabLink() {
            return this.isMaster("B2B") || this.currentUser?.Relays?.length > 1
                ? {name: "relays"}
                : {name: "relay", params: {id: this.currentUser?.Relays?.[0]?.id}};
        }

        private navTabs(): any {
            return {
                Admin: [
                    {
                        to: {name: "admin-users"},
                        picto: "icon-picto_mes-contacts",
                        title: "nav.users",
                    }, {
                        to: {name: "keys"},
                        picto: "icon-picto_cle-partagees",
                        title: "nav.adminKeys",
                    }, {
                        to: {name: "companies"},
                        picto: "icon-picto_company",
                        title: "nav.companies",
                    }, {
                        to: {name: "admin-planning"},
                        picto: "event",
                        pictoType: "materialDesign",
                        title: "nav.planning",
                    },
                    {
                        to: null,
                        picto: "icon-picto_cartographie",
                        title: "nav.cartography",
                    }, {
                        to: {name: "relays-map"},
                        picto: "icon-picto_loby",
                        title: "nav.loby",
                    }, {
                        to: {name: "admin-relays"},
                        picto: "icon-picto_relais-agence",
                        title: "nav.allRelays",
                    }, {
                        to: {name: "relaysTransactions"},
                        picto: "icon-picto_cle-remise",
                        title: "nav.relaysTransactions",
                    }, {
                        to: {name: "prospects"},
                        picto: "icon-picto_sav",
                        title: "nav.prospects",
                    }, {
                        to: {name: "admin-logs"},
                        picto: "icon-picto_historique",
                        title: "nav.historical",
                    },
                ],
                B2B: [
                    {
                        to: {name: "contacts"},
                        picto: "icon-picto_mes-contacts",
                        title: "nav.my_contacts",
                    }, {
                        to: {name: "keys"},
                        picto: "icon-picto_cle-partagees",
                        title: "nav.keys",
                    }, {
                        to: null,
                        picto: "icon-picto_cartographie",
                        title: "nav.cartography",
                    }, {
                        to: null,
                        picto: "icon-picto_loby",
                        title: "nav.loby",
                    }, {
                        to:  this.isMaster("B2B") || this.isAgencyRef ? this.relayTabLink : null,
                        picto: "icon-picto_relais-agence",
                        title: "nav.relay_agency",
                    }, {
                        to: this.canUseBooking ? {name: "planning"} : null,
                        picto: "event",
                        pictoType: "materialDesign",
                        title: "nav.planning",
                    }, {
                        to:  this.isMaster("B2B") || this.isAgencyRef ? {name: "relaysTransactions"} : null,
                        picto: "icon-picto_cle-remise",
                        title: "nav.relaysTransactions",
                    }, {
                        to: null,
                        picto: "icon-picto_historique",
                        title: "nav.historical",
                    }, {
                        to: this.isMaster("B2B")
                            ? {name: "companyInvoices", params: {id: this.currentUser?.companyId}}
                            : null,
                        picto: "icon-picto_factures",
                        title: "nav.invoices",
                    }, {
                        to: null,
                        picto: "icon-picto_sav",
                        title: "nav.sav",
                    },
                ],
                B2C: [
                    {
                        to: {name: "contacts"},
                        picto: "icon-picto_mes-contacts",
                        title: "nav.my_contacts",
                    }, {
                        to: {name: "keys"},
                        picto: "icon-picto_cle-partagees",
                        title: "nav.keys",
                    }, {
                        to: null,
                        picto: "icon-picto_loby",
                        title: "nav.loby",
                    }, {
                        to: null,
                        picto: "icon-picto_historique",
                        title: "nav.historical",
                    }, {
                        to: {name: "planning"},
                        picto: "event",
                        pictoType: "materialDesign",
                        title: "nav.planning",
                    }, {
                        to: {name: "paymentMethod"} ,
                        picto: "icon-picto_credit-card",
                        title: "nav.paymentMethod",
                    }, {
                        to: this.isDemo ? null : {name: "billingActivity"} ,
                        picto: "icon-picto_receipt",
                        title: "nav.billingActivity",
                    },
                    {
                        to: null,
                        picto: "icon-picto_sav",
                        title: "nav.sav",
                    },
                ],
                LobyRef: [
                    {
                        to: {name: "contacts"},
                        picto: "icon-picto_mes-contacts",
                        title: "nav.my_contacts",
                    },
                    {
                        to: this.relayTabLink,
                        picto: "icon-picto_loby",
                        title: "nav.loby",
                    }, {
                        to: null,
                        picto: "icon-picto_historique",
                        title: "nav.historical",
                    }, {
                        to: {name: "relayInvoices", params: {id: this.currentUser?.Relays?.[0]?.id}},
                        picto: "icon-picto_factures",
                        title: "nav.invoices",
                    }, {
                        to: null,
                        picto: "icon-picto_sav",
                        title: "nav.sav",
                    },
                ],
                InsuranceRef: [
                    {
                        to: this.relayTabLink,
                        picto: "icon-picto_loby",
                        title: "nav.loby",
                    }, {
                        to: {name: "relaysTransactions"},
                        picto: "icon-picto_cle-remise",
                        title: "nav.relaysTransactions",
                    }, {
                        to: null,
                        picto: "icon-picto_historique",
                        title: "nav.historical",
                    }, {
                        to: {name: "relayInvoices", params: {id: this.currentUser?.Relays?.[0]?.id}},
                        picto: "icon-picto_factures",
                        title: "nav.invoices",
                    }, {
                        to: null,
                        picto: "icon-picto_sav",
                        title: "nav.sav",
                    },
                ],
                InsuranceMaster: [
                    {
                        to: {name: "contacts"},
                        picto: "icon-picto_mes-contacts",
                        title: "nav.my_contacts",
                    }, {
                        to: {name: "keys"},
                        picto: "icon-picto_cle-partagees",
                        title: "nav.keys",
                    }, {
                        to: null,
                        picto: "icon-picto_cartographie",
                        title: "nav.cartography",
                    }, {
                        to: null,
                        picto: "icon-picto_loby",
                        title: "nav.loby",
                    }, {
                        to: null,
                        picto: "icon-picto_historique",
                        title: "nav.historical",
                    }, {
                        to: {name: "companyInvoices", params: {id: this.currentUser?.companyId}},
                        picto: "icon-picto_factures",
                        title: "nav.invoices",
                    }, {
                        to: null,
                        picto: "icon-picto_sav",
                        title: "nav.sav",
                    },
                ],
            };
        }

}
</script>