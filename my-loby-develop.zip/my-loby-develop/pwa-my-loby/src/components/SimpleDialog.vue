<template>
    <v-dialog max-width="500px" v-model="dialog" persistent>
        <v-card>
            <v-card-title style="word-break: normal;">
                <span class="headline">{{ title }}</span>
            </v-card-title>
            <v-card-text class="pb-1">
                <v-container class="py-3">
                    <span>{{ text }}</span>
                </v-container>
            </v-card-text>
            <v-card-actions v-if="actions && actions.length">
                <v-spacer></v-spacer>
                <v-btn
                    v-if="actions.includes('cancel')"
                    @click="$emit('cancel')"
                    color="white"
                    text
                >
                    {{ $t("actions.cancel") }}
                </v-btn>
                <v-btn
                    v-if="actions.includes('close')"
                    @click="$emit('close')"
                    color="white"
                    text
                >
                    {{ $t("actions.close") }}
                </v-btn>
                <v-btn
                    v-if="actions.includes('confirm')"
                    @click="$emit('confirm')"
                    color="warning"
                >
                    {{ $t("actions.confirm") }}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";

@Component({})
export default class SimpleDialog extends Vue {
    @Prop({default: false})
    public dialog: boolean;

    @Prop({default: null})
    public title: string;

    @Prop({default: null})
    public text: string;

    @Prop({default: []})
    public actions: string[];
}
</script>