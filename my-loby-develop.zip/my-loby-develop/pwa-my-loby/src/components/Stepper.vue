<template>
    <v-stepper v-model="relay.status + 1">
        <v-stepper-header>
            <span v-for="(step, i) in steps" :key="i">
                <v-stepper-step
                    :complete="relay.status >= i"
                    :step="i+1"
                >
                    <span>{{$t(step.label)}}</span>
                    <span v-if="i === 0 && relay.createdAt">
                        {{relay.createdAt | formatShortDate}}
                    </span>
                    <span v-if="i+1 === steps.length && relay.activatedAt">
                        {{relay.activatedAt | formatShortDate}}
                    </span>
                </v-stepper-step>
                <v-divider></v-divider>
            </span>
        </v-stepper-header>
    </v-stepper>
</template>
<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";
@Component({})
export default class Stepper extends  Vue {
    @Prop({default: []})
    public steps: object[];

    @Prop({default: {}})
    public relay: object;

}
</script>