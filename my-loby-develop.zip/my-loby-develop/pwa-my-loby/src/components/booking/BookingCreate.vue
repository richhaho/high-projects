<template>
    <v-dialog
        persistent
        max-width="800px"
        :fullscreen="mobile"
        :hide-overlay="mobile"
        v-model="handToHandDialog"
    >
        <v-card>
            <v-card-title>
                <span class="headline">{{ `${editMode ? "" : $t('booking.create.title') + " -"} ${$t('booking.create.step2.title')}` }}</span>
            </v-card-title>
            <v-card-text class="py-0 py-3">
                <v-container class="py-0">
                    <v-row>
                        <v-col cols="12 pa-4">
                            <v-row cols="12 pl-0 pb-5 pt-0">
                                {{ `${$t('booking.create.step2.reservationKey')}:` }}
                                <custom-chip-link
                                    class="ml-2"
                                    type="key"
                                    :id="reservationInfos.key.id"
                                    :text="reservationInfos.key.name"
                                />
                            </v-row>
                            <v-row cols="12 pl-0 pb-5 pt-0">
                                {{ `${$t('booking.create.step2.reservationDestination')}:` }}
                                <custom-chip-link
                                    class="ml-2"
                                    type="user"
                                    :id="reservationInfos.user.id"
                                    :text="reservationInfos.user.name"
                                />
                            </v-row>
                            <v-form v-model="valid">
                                <v-row>
                                    <v-text-field
                                        v-model="bookingName"
                                        v-bind:label="`${$t('booking.create.step2.inputName')}`"
                                    ></v-text-field>
                                </v-row>
                                <v-row class="mt-5 mb-5">
                                    <datetime
                                        :phrases="wording"
                                        class="date-input"
                                        id="startDate"
                                        type="datetime"
                                        v-model="startDate"
                                        :rules="[rules.required]"
                                    >
                                        <label for="startDate" slot="before">
                                            {{ $t("common.startDate") }} :
                                        </label>
                                    </datetime>
                                    <v-icon v-if="!mobile">
                                        arrow_right_alt
                                    </v-icon>
                                    <v-col v-else cols="12">
                                        <v-row justify="center">
                                            <v-icon
                                            >
                                                arrow_right_alt
                                            </v-icon>
                                        </v-row>
                                    </v-col>
                                    <datetime
                                        :phrases="wording"
                                        :min-datetime="startDate"
                                        class="date-input"
                                        id="endDate"
                                        type="datetime"
                                        v-model="endDate"
                                        :rules="[rules.required]"
                                    >
                                        <label for="endDate" slot="before">
                                            {{ $t("common.endDate") }} :
                                        </label>
                                    </datetime>
                                </v-row>
                                <v-row v-if="!!startDate && !!endDate && accessExceeding">
                                    <p class="red--text">{{$t("booking.accessExceeding")}}: {{accessDate}}</p>
                                </v-row>
                                <v-row v-if="reccurenceAuthorized && !editMode && !!startDate && !!endDate">
                                    <v-select
                                        v-model="bookingReccurence"
                                        item-value="key"
                                        item-text="label"
                                        :items="recurrenceList"
                                        :label="$t('booking.reccurence')+' *'"
                                        :rules="[rules.required]"
                                    ></v-select>
                                </v-row>
                                <v-row v-if="reccurenceAuthorized && !editMode && bookingReccurence !== 'once'">

                                    <datetime
                                        :phrases="wording"
                                        :min-datetime="startDate"
                                        class="date-input"
                                        id="reccurenceLimit"
                                        v-model="reccurenceLimit"
                                        :rules="[rules.required]"
                                    >
                                        <label for="endDate" slot="before">
                                            {{ $t("booking.reccurenceLimit") }} :
                                        </label>
                                    </datetime>
                                </v-row>
                            </v-form>
                        </v-col>
                    </v-row>
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    @click="closeDialog"
                    color="white"
                    text
                >
                    {{ $t('actions.close') }}
                </v-btn>
                <v-btn
                    v-if="(!editMode && valid && !accessExceeding)"
                    @click="createBooking"
                    color="warning"
                    :loading="bookingCreation"
                >
                    {{ $t('actions.confirm') }}
                </v-btn>
                <v-btn
                    v-if="(editMode && userCanEdit && !isBookingInThePast)"
                    @click="deleteBooking"
                    color="error"
                >
                    {{ $t('actions.delete') }}
                </v-btn>
                <v-btn
                    v-if="(editMode && userCanEdit && !accessExceeding)"
                    @click="editBooking"
                    color="warning"
                >
                    {{ $t('actions.edit') }}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import {Getter} from "vuex-class";
import moment from "moment";
import {Datetime} from "vue-datetime";
import "vue-datetime/dist/vue-datetime.css";
import {formRules} from "@/utils/formRules";
import CustomChipLink from "@/components/CustomChipLink.vue";

@Component({
    components: {
        Datetime,
        CustomChipLink,
    },
})
export default class BookingCreate extends Vue {
    @Prop({default: false})
    public show: boolean;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: null})
    public activeKey: any;

    @Prop({default: null})
    public user: any;

    @Prop({default: null})
    public bookingStartingDate: any;

    @Prop({default: null})
    public activeEvent: any;

    @Prop({default: false})
    public editMode: boolean;

    private handToHandDialog: boolean = false;
    private startDate: any = null;
    private endDate: string = "";
    private wording: any = null;
    private bookingReccurence: string = "once";
    private rules: object = formRules;
    private valid: boolean = true;
    private bookingName: string = "";
    private reccurenceLimit: string = "";
    private bookingCreation: boolean = false;

    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;
    @Getter private isB2B: boolean;

    @Watch("show")
    public handlerShow(newVal, oldVal) {
        if (newVal === true) {
            this.handToHandDialog = true;
            if (this.bookingStartingDate) {
                const date = moment(this.bookingStartingDate.date);
                date.set({hour: this.bookingStartingDate.hour, minute: 0, second: 0});
                this.startDate = moment(date).format();
            } else if (this.editMode && this.activeEvent) {
                this.startDate = moment(this.activeEvent.start).format();
                this.endDate = moment(this.activeEvent.end).format();
                this.bookingName = this.activeEvent.bookingName;
            } else {
                this.startDate = moment().format();
            }
        }
    }

    get reservationInfos(): any {
        if (!this.activeKey) {
            return {
                key: "",
                user: "",
            };
        }
        return {
            key: {
                id: this.activeKey.id,
                name: this.activeKey.name,
            },
            user: {
                id: this.user.id,
                name: this.user.identity,
            },
        };
    }

    get recurrenceList(): any {
        const reccurence = [];
        if (this.startDate !== "" && this.endDate !== "") {
            const start = moment(this.startDate);
            const end = moment(this.endDate);
            const ms = start.diff(end);
            const d = moment.duration(ms);
            const hourDiff = Math.abs(Math.floor(d.asHours()));

            if (hourDiff < 24) {
                reccurence.push({key: "day", label: this.$t("booking.reccurenceType.day")});
            }
            if (hourDiff < 168) {
                reccurence.push({key: "week", label: this.$t("booking.reccurenceType.week")});
            }
            if (Math.abs(start.diff(end, "month")) < 1) {
                reccurence.push({key: "month", label: this.$t("booking.reccurenceType.month")});
            }
            if (Math.abs(start.diff(end, "year")) < 1) {
                reccurence.push({key: "year", label: this.$t("booking.reccurenceType.year")});
            }
        }
        return [
            {key: "once", label: this.$t("booking.reccurenceType.once")},
            ...reccurence,
        ];
    }

    get userCanEdit(): boolean {
        const managersId = this.activeKey.keyManagers.flatMap((managers) => {
            return managers?.Users?.map((user) => user.id);
        });
        return !!(  this.isAdmin
            || (managersId && managersId.includes(this.currentUser.id))
            || (this.activeEvent.createdBy === this.currentUser.id))
            || this.isGuestCanModify;
    }

    get isGuestCanModify(): boolean {
        return !this.isAdmin
            && !this.isB2B
            && this.activeEvent.createdBy !== this.currentUser.id
            && this.activeEvent.user.id === this.currentUser.id;
    }

    get accessExceeding(): boolean {
        let isExceeding = false;
        const userAccess = this.activeKey?.keyAccess?.filter((access) => !!access.startDate);
        if (this.isAdmin || !userAccess) {
            return isExceeding;
        }
        userAccess.map((access) => {
            if (!access) {
                return;
            }
            if ((access.startDate && access.endDate)
                && (this.startDate < access.startDate || this.endDate > access.endDate )) {
                isExceeding = true;
            }

            if ((access.startDate && !access.endDate)
                && this.startDate < access.startDate
            ) {
                isExceeding = true;
            }

            if (access.endDate && this.bookingReccurence !== "once" && this.reccurenceLimit > access.endDate) {
                isExceeding = true;
            }
        });

        if (this.activeKey?.keyManagers) {
            const isCurrentUserKeyManager = this.activeKey.keyManagers.some(
                (managers) => !!managers.Users.find((user) => user.id === this.currentUser.id),
            );
            if (isCurrentUserKeyManager) {
                return false;
            }
        }
        return isExceeding;
    }

    get accessDate(): string {
        let accessValue = "";
        const userAccess = this.activeKey?.keyAccess;
        if (!userAccess || userAccess.length === 0) {
            return accessValue;
        }

        userAccess.map((access) => {
            if (access.startDate && access.endDate) {
                accessValue += `${moment(access.startDate).format("YYYY-MM-DD HH:mm")} - ${moment(access.endDate).format("YYYY-MM-DD HH:mm")} `;
            }
        });
        return accessValue;
    }

    get isBookingInThePast(): boolean {
        return new Date() > new Date(this.startDate);
    }

    private mounted(): void {
        this.wording = {
            ok: this.$i18n.t("actions.next"),
            cancel: this.$i18n.t("actions.cancel"),
        };
    }

    private relayDisplayed(key): any {
      return key.Relays?.find((relay) => relay.type === "AGENCY")
          || key.Relays?.[0];
    }

    get reccurenceAuthorized(): boolean {
      if (!this.activeKey) {
        return false;
      }
      const relay = this.relayDisplayed(this.activeKey);
      return relay ? !!relay?.authorizeReccurence : false;
    }

    private closeDialog(): void {
        this.handToHandDialog = false;
        this.resetModal();
        this.$emit("closeModal");
    }

    private resetModal(): void {
        this.startDate = null;
        this.endDate = "";
        this.wording = {
            ok: this.$i18n.t("actions.next"),
            cancel: this.$i18n.t("actions.cancel"),
        };
        this.bookingReccurence = "once";
        this.valid = true;
        this.bookingName = "";
    }

    private createBooking(): void {
        this.bookingCreation = true;
        this.$store.dispatch("bookings/create", {
            booking: {
                name: this.bookingName,
                startDate: moment(this.startDate),
                endDate: moment(this.endDate),
                keyId: this.activeKey.id,
                userId: this.user ? this.user.id : this.currentUser.id,
                reccurence: {
                    type: this.bookingReccurence,
                    limit: this.reccurenceLimit
                        ? moment(this.reccurenceLimit).set({hour: 23, minute: 59, second: 59})
                        : null,
                },
                notificationType: this.user.notificationType,
            },
        }).then((res) => {
            const noBookingCreated = res.noBookingCreated;
            if (noBookingCreated) {
                this.$store.commit("alerts/displayError", {
                    msg: `${this.$i18n?.t("alerts.planning.creationConflict")} `,
                });
            } else {
                this.$store.commit("alerts/displaySuccess", {
                    msg: `${this.$i18n?.t("alerts.planning.creationSuccess")} ${res.conflict ? "- " + this.$i18n?.t("alerts.planning.creationConflicts") : ""} `,
                });
            }
            this.bookingCreation = false;
            this.$emit("bookingCreated");
            this.closeDialog();
        }).catch((err) => {
            if (err?.response?.data?.noBookingCreated) {
                this.$store.commit("alerts/displayError", {
                    msg: `${this.$i18n?.t("booking.error.keyIsAlreadyBooked")} `,
                });
                this.bookingCreation = false;
                this.closeDialog();
                return;
            }
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
            this.bookingCreation = false;
            this.closeDialog();
        });
    }

    private editBooking(): void {
        this.bookingCreation = true;
        this.$store.dispatch("bookings/update", {
            id: this.activeEvent.id,
            booking: {
                name: this.bookingName,
                startDate: moment(this.startDate),
                endDate: moment(this.endDate),
                reccurence: {
                    type: this.bookingReccurence,
                    limit: this.reccurenceLimit,
                },
            },
            alertCreator: this.isGuestCanModify,
        }).then(() => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("alerts.planning.editSuccess"),
            });
            this.bookingCreation = false;
            this.$emit("bookingCreated");
            this.closeDialog();
        }).catch((err) => {
            if (err?.response?.data?.noBookingCreated) {
                this.$store.commit("alerts/displayError", {
                    msg: `${this.$i18n?.t("booking.error.keyIsAlreadyBooked")} `,
                });
                this.bookingCreation = false;
                this.closeDialog();
                return;
            }
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
            this.closeDialog();
        });
    }

    private deleteBooking(): void {
        this.$emit("deleteBooking", {booking: this.activeEvent});
        this.closeDialog();
    }
}
</script>

<style lang="scss" scoped>
    .date-input {
        max-width: 200px;
        padding: 8px 10px;
        font-size: 16px;
        border: solid 1px #ddd;
        color: #444;
    }
</style>
