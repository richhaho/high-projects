<template>
    <v-dialog
        persistent
        max-width="500px"
        :fullscreen="mobile"
        :hide-overlay="mobile"
        v-model="handToHandDialog"
    >
        <v-card>
            <v-card-title>
                <span class="headline">{{ `${$t('booking.create.title')} - ${$t('booking.create.step1.title')}` }}</span>
            </v-card-title>
            <v-card-text class="py-0 py-3">
                <v-container class="py-0">
                    <v-row>
                        <v-col cols="12 pa-0">
                            <v-col cols="12 pl-0 pb-5 pt-0">
                                {{ $t('booking.create.step1.descriptionKey') }}
                            </v-col>
                            <v-autocomplete
                                :items="formattedKeysValues"
                                append-icon
                                solo
                                :search-input.sync="search"
                                :no-data-text="$t('key.handToHand.noUserFound')"
                                v-bind:label="$t('planning.search.keys')"
                                v-model="keySelected"
                            />
                            <v-radio-group
                                v-if="keySelected && (isAdmin || isB2B)"
                                v-model="reservationDestination"
                                hide-details
                                mandatory
                                class="mb-4 mt-0"
                            >
                                <v-radio
                                    :label="$t('booking.create.step1.choice1')"
                                    key="myself"
                                    value="myself"
                                    color="orange"
                                ></v-radio>
                                <v-radio
                                    :label="$t('booking.create.step1.choice2')"
                                    key="guest"
                                    value="guest"
                                    color="orange"
                                ></v-radio>
                            </v-radio-group>
                            <v-col cols="12 pa-0" v-if="reservationDestination === 'guest'">
                                <span v-if="guestOfActiveKey.length === 0">
                                    {{ $t('key.noGuests') }}
                                </span>
                                <v-autocomplete
                                    v-else
                                    :items="guestOfActiveKey"
                                    append-icon
                                    solo
                                    :search-input.sync="searchGuest"
                                    :no-data-text="$t('key.handToHand.noUserFound')"
                                    v-bind:label="$t('planning.search.users')"
                                    v-model="guestSelected"
                                />
                            </v-col>
                            <v-radio-group
                                v-if="keySelected && ((!reservationDestination && !isAdmin && !isB2B) || reservationDestination === 'myself' || (reservationDestination === 'guest' && guestSelected)) && allowMail && allowPhone"
                                v-model="notificationType"
                                hide-details
                                mandatory
                                class="my-4"
                            >
                                <v-radio
                                    v-if="allowPhone"
                                    :label="$t('invitation.reminder.sms')"
                                    key="sms"
                                    value="sms"
                                    color="orange"
                                ></v-radio>
                                <v-radio
                                    v-if="allowMail"
                                    :label="$t('invitation.reminder.mail')"
                                    key="email"
                                    value="email"
                                    color="orange"
                                ></v-radio>
                            </v-radio-group>
                        </v-col>
                    </v-row>
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    @click="closeDialog"
                    color="white"
                    text
                >
                    {{ $t('actions.cancel') }}
                </v-btn>
                <v-btn
                       v-if="isStep1Valid"
                       @click="openBookingModal"
                       color="warning"
                >
                    {{ $t('actions.confirm') }}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import {Getter} from "vuex-class";
import {regex} from "@/utils/formRules";

@Component({
    components: {
    },
})
export default class BookingCreateSelection extends Vue {
    @Prop({default: false})
    public show: boolean;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: []})
    public keys: any[];

    private handToHandDialog: boolean = false;
    private reservationDestination: string = "myself";
    private keySelected: any = null;
    private guestSelected: any = null;
    private search: string = "";
    private searchGuest: string = "";
    private notificationType: string = "sms";

    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;
    @Getter private isB2B: boolean;

    get formattedKeysValues() {
        return this.keys.map((key: any) => {
            return { text: key.name, value: key, ...key };
        });
    }

    get isStep1Valid() {
        const book = (!this.isAdmin && !this.isB2B) ? "myself" : this.reservationDestination;
        return this.keySelected && book && (book === "myself" || (book === "guest" && this.guestSelected));
    }

    get guestOfActiveKey() {
        const relatedKey = this.keySelected;
        if (relatedKey && relatedKey.guests.length === 0) {
            return [];
        }
        return relatedKey.guests.flatMap(
            (el) => (el.Users.reduce((a, u) => ([...a, { text: `${this.getUserIdentity(u)}`, value: u, ...u }]), [])),
        );
    }

    get allowMail(): boolean {
        const relatedUser = this.reservationDestination === "guest" ? this.guestSelected : this.currentUser;
        return !!relatedUser?.email && regex.email.test(relatedUser.email);
    }

    get allowPhone(): boolean {
        const relatedUser = this.reservationDestination === "guest" ? this.guestSelected : this.currentUser;
        return !!relatedUser?.phone;
    }

    get defaultNotificationType(): string {
        if (this.allowMail && !this.allowPhone) {
            return "email";
        }
        if (!this.allowMail && this.allowPhone) {
            return "sms";
        }
        return null;
    }

    @Watch("show")
    public handlerShow(newVal, oldVal) {
        if (newVal === true) {
            this.handToHandDialog = true;
            this.resetForm();
        }
    }

    private resetForm() {
        this.reservationDestination = "myself";
        this.keySelected = null;
        this.guestSelected = null;
        this.search = "";
        this.searchGuest = "";
    }

    private openBookingModal() {
        this.$emit("nextStep", {
            key: this.keySelected,
            user: this.reservationDestination === "guest" ? this.guestSelected : this.currentUser,
            notificationType: this.defaultNotificationType ? this.defaultNotificationType : this.notificationType,
        });
        this.closeDialog();
    }

    private closeDialog(): void {
        this.handToHandDialog = false;
        this.$emit("closeModal");
    }

    private getUserIdentity(user) {
        if (user.lastName && user.firstName) {
            return `${user.firstName} ${user.lastName} `;
        }
        if (user.phone) {
            return user.phone;
        }
        if (user.email) {
            return user.email;
        }
        return "";
    }
}
</script>
