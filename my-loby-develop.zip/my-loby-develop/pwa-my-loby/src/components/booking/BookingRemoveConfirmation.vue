<template>
    <v-dialog
        max-width="500px"
        v-model="confirmBlock"
    >
        <v-card>
            <v-card-title>
                <span class="headline">{{$t('booking.edit.confirmBlock')}}</span>
            </v-card-title>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    @click="$emit('closeModal')"
                    color="blue darken-1"
                    text
                >
                    {{$t('actions.cancel')}}
                </v-btn>
                <v-btn
                    @click="deleteBooking"
                    color="orange darken-1"
                    text
                >
                    {{$t('actions.confirm')}}
                </v-btn>
                <v-spacer></v-spacer>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";
import {Getter} from "vuex-class";
import "vue-datetime/dist/vue-datetime.css";
import moment from "moment";

@Component
export default class BookingCreate extends Vue {
    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: false})
    public confirmBlock: boolean;

    @Prop({default: null})
    public booking: any;

    @Getter private currentUser: any;

    private deleteBooking() {
        if (!this.booking.id) {
            this.$store.commit("alerts/displayError", {
                msg: "Réservation introuvable",
            });
            this.$emit("closeModal");
        }
        this.$store.dispatch("bookings/delete", {
            id: this.booking.id,
        }).then(() => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("alerts.planning.removeSuccess"),
            });
            this.$emit("removeSuccess");
        }).catch(() => {
            this.$store.commit("alerts/displayError", {
                msg: this.$i18n?.t("alerts.error.default"),
            });
            this.$emit("closeModal");
        });
    }
}
</script>
