<template>
    <div>
        <p class="tableau_titre">
            {{ $t('company.statistics') }}
            <a @click.prevent="displayStatistics = !displayStatistics" :title="$t('actions.openClose')"
               class="toggle_action"
               :class="{'open' : !displayStatistics}">
                <i class="icon-angle"></i>
            </a>
        </p>
        <v-expand-transition>
            <div v-show="displayStatistics" v-if="subscriptions.length">
                <v-col class="py-0">
                    <div id="timeline" style="width: 100%;"></div>
                </v-col>
            </div>
        </v-expand-transition>
    </div>
</template>
<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";
import ApexCharts from "apexcharts";

@Component
export default class CompanyGraphSubscriptions extends Vue {
    @Prop({default: null})
    public company: any;

    @Prop({default: null})
    public invoices: any[];

    @Prop({})
    public getStatusColor: (string) => string;

    @Prop({})
    public getStatusIcon: (string) => string;

    private subscriptions: any[] = [];
    private displayStatistics: boolean = true;
    private plans: string[] = null;

    public mounted() {
        this.getSubscriptions().then(() => {
            this.getPlans().then(() => {
                this.drawChart();
            });
        });
    }

    private getSubscriptions() {
        return this.$store.dispatch("companies/getSubscriptions", {
            id: this.company.id,
        })
        .then((res) => {
            // Get only the subscriptions of the corresponding invoices
            this.subscriptions = res.rows.
            filter((sub) => new Date(sub.startDate) < new Date()).
            sort((a, b) => a.startDate - b.startDate).
            reduce((a, c, i) => {
                if (!c.endDate || new Date(c.endDate) > new Date()) {
                    c.endDate = new Date();
                }
                a.push(c);
                return a;
            }, []);
        });
    }

    private getPlans() {
        const query = {type: this.company.type};
        return this.$store.dispatch("plans/read", {query})
        .then((res) => {
            this.plans = res.plans.sort((a, b) => a.monthlyPrice - b.monthlyPrice);
        });
    }

    private drawChart(): void {
        const fr = require("apexcharts/dist/locales/fr.json");
        const series: any[] = this.plans.map((plan: any) => ({
            name: this.$i18n.t("plan." + plan.name + ".name"),
            data: this.subscriptions.filter((sub) => sub.Plan.id === plan.id).map((subscription: any) => ({
                x: this.$i18n.t("plan.title"),
                y: [
                    new Date(subscription.startDate).getTime(),
                    new Date(subscription.endDate).getTime(),
                ],
            })),
        }));
        const options = {
            series,
            chart: {
                height: 200,
                type: "rangeBar",
                locales: [fr],
                defaultLocale: "fr",
            },
            plotOptions: {
                bar: {
                    horizontal: true,
                    barHeight: "80%",
                },
            },
            xaxis: {
                type: "datetime",
            },
            stroke: {
                width: 1,
            },
            fill: {
                type: "solid",
                opacity: 0.5,
            },
            legend: {
                position: "top",
            },
        };

        const chart = new ApexCharts(document.getElementById("timeline"), options);
        chart.render();
    }
}
</script>