<template>
    <div>
        <div class="tableau">
            <v-form v-model="valid">
                <v-row>
                    <v-col>
                        <v-text-field
                            v-model="company.name"
                            :rules="[rules.required]"
                            :label="$t('company.name')+' *'"
                        ></v-text-field>
                        <v-select
                            v-if="!company.id"
                            v-model="company.plan"
                            item-value="key" item-text="label"
                            :items="plansList"
                            :label="$t('company.plan')+' *'"
                            :rules="[rules.required]"
                        ></v-select>
                        <v-select
                            v-model="company.type"
                            item-value="key" item-text="label"
                            :items="companyTypesList"
                            :label="$t('company.type.title')+' *'"
                            :rules="[rules.required]"
                        ></v-select>
                        <v-select
                            v-model="company.activitySector"
                            item-value="key" item-text="label"
                            :items="activitySectorList"
                            :label="$t('company.activitySector')"
                            :rules="[rules.required]"
                        ></v-select>
                        <!-- TODO: Add custom SIRET rule -->
                        <v-text-field
                            v-model="company.siret"
                            :rules="[rules.required]"
                            :label="$t('company.siret')+' *'"
                        ></v-text-field>
                        <v-text-field
                            v-model="company.siren"
                            :rules="[rules.required, rules.siren]"
                            :label="$t('company.siren')+' *'"
                        ></v-text-field>
                        <v-autocomplete
                            append-icon
                            :item-text="itemStringified"
                            item-value="id"
                            :items="users"
                            :search-input.sync="searchUserMaster"
                            :loading="loading"
                            :no-data-text="$t('keysList.noUserFound')"
                            :rules="[rules.required]"
                            v-bind:label="$t('company.master')"
                            v-model="company.masterId"
                            no-filter
                            readonly
                        >
                            <template v-slot:selection="data">
                                <v-list-item-content style="overflow: initial;">
                                    <v-list-item-title
                                        v-html="data.item.displayName">
                                    </v-list-item-title>
                                    <v-list-item-subtitle style="height: 17px;"
                                        v-html="data.item.email">
                                    </v-list-item-subtitle>
                                </v-list-item-content>
                            </template>
                            <template v-slot:item="data">
                                <v-list-item-content :aria-disabled="!data.item.available">
                                    <v-list-item-title
                                        v-html="data.item.displayName">
                                    </v-list-item-title>
                                    <v-list-item-subtitle
                                        v-html="data.item.email">
                                    </v-list-item-subtitle>
                                </v-list-item-content>
                            </template>
                        </v-autocomplete>

                    </v-col>
                </v-row>
                <v-row>
                    <v-col class="mb-3">
                        <v-row justify="center">
                            <v-btn
                                v-if="company.id"
                                @click="confirmBlock = true"
                                class="mr-4"
                                color="error"
                            >
                                {{company.blockedAt ? $t('actions.unblock') : $t('actions.block')}}
                            </v-btn>
                            <v-btn
                                v-if="company.id"
                                :disabled="!valid"
                                color="success"
                                class="mr-4"
                                @click="$emit('edit', company)">
                                {{$t('actions.edit')}}
                            </v-btn>
                        </v-row>
                    </v-col>
                </v-row>
            </v-form>
        </div>
        <v-dialog
            max-width="500px"
            v-model="confirmBlock"
        >
            <v-card>
                <v-card-title>
                    <span class="headline">{{company.blockedAt ? $t('company.confirmUnblock') : $t('company.confirmBlock')}}</span>
                </v-card-title>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="confirmBlock = false"
                        color="blue darken-1"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-btn
                        @click="blockUnblockCompany"
                        color="orange darken-1"
                        text
                    >
                        {{$t('actions.confirm')}}
                    </v-btn>
                    <v-spacer></v-spacer>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>
<script lang="ts">
import {Vue, Component, Prop, Watch} from "vue-property-decorator";
import {formRules} from "@/utils/formRules";
import router from "@/router";

@Component
export default class CompanyInfo extends Vue {

    @Prop({default: null})
    public company: any;

    get companyTypesList() {
        return [
            {key: "B2B", label: this.$t("company.type.b2b")},
            {key: "INSURANCE", label: this.$t("company.type.insurance")},
        ];
    }

    get plansList() {
        return [
            {key: "FREE", label: this.$t("plan.FREE")},
            {key: "BASIC", label: this.$t("plan.BASIC")},
            {key: "STANDARD", label: this.$t("plan.STANDARD")},
            {key: "PREMIUM", label: this.$t("plan.PREMIUM")},
        ];
    }

    get activitySectorList() {
        return [
            {key: "Services à la personne", label: this.$t("company.activitySectors.personService")},
            {key: "Agence de femme de ménage", label: this.$t("company.activitySectors.cleaningAgency")},
            {
                key: "Agence immobilière Gestion Locative",
                label: this.$t("company.activitySectors.realEstateRentalAgency"),
            },
            {
                key: "Agence immobilière Syndic de co-propriété",
                label: this.$t("company.activitySectors.realEstateSyndicAgency"),
            },
            {key: "Groupe immobilier", label: this.$t("company.activitySectors.realEstateGroup")},
            {key: "Bailleurs sociaux", label: this.$t("company.activitySectors.socialDonors")},
            {key: "Property Management", label: this.$t("company.activitySectors.propertyManagement")},
            {key: "Constructeur", label: this.$t("company.activitySectors.manufacturer")},
            {key: "Maître d’oeuvre", label: this.$t("company.activitySectors.masterOfWork")},
            {key: "Artisan", label: this.$t("company.activitySectors.craftsman")},
            {key: "Assurance", label: this.$t("company.activitySectors.insurance")},
            {key: "Conciergerie Airbnb", label: this.$t("company.activitySectors.airbnbService")},
            {key: "Concessionnaire auto", label: this.$t("company.activitySectors.carDealer")},
        ];
    }

    private searchUserMaster: string = null;
    private users: any[] = [];
    private rules: object = formRules;
    private loading: boolean = false;
    private valid: boolean = true;
    private confirmBlock: boolean = false;

    @Watch("searchUserMaster", {deep: true})
    public handleSearchUserMaster() {
        if (this.searchUserMaster) {
            this.loading = true;
            this.$store.dispatch("users/search", {
                search: this.searchUserMaster,
            }).then((res) => {
                this.users = res.list;
                this.loading = false;
            });
        }
    }

    private mounted() {
        this.users = this.company.users;
    }

    private itemStringified = (item) => JSON.stringify(item);

    private blockUnblockCompany(): void {
        const blockedAt: string|null = this.company.blockedAt
            ? null
            : new Date().toISOString().substr(0, 19);
        const company = {
            ...this.company,
            blockedAt,
        };
        this.$store.dispatch("companies/updateById", {id: company.id, company}).then((res) => {
            router.push({name: "companies"});
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: this.$t(`register.error.${err.response.data.type}`),
            });
        });
    }
}
</script>