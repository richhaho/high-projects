<template>
    <div>
        <company-graph-subscription
            v-if="invoices && invoices.length"
            :company="company"
            :invoices="invoices"
            :getStatusColor="getStatusColor"
            :getStatusIcon="getStatusIcon"
            @reset="getInvoices"
        />
        <p class="tableau_titre">
            {{ $t('company.invoices') }}
            <a @click.prevent="displayInvoices = !displayInvoices" :title="$t('actions.openClose')"
               class="toggle_action"
               :class="{'open' : !displayInvoices}">
                <i class="icon-angle"></i>
            </a>
        </p>
        <v-expand-transition>
            <div class="tableau" v-if="displayInvoices">
                <div class="options">
                    <v-spacer></v-spacer>
                    <v-chip
                        v-if="isAdmin"
                        :title="$t('invoices.simulate')"
                        :href="currentInvoicingSimulation"
                        color="warning"
                        target="_blank"
                    >
                        {{ $t('invoices.simulate') }}
                    </v-chip>
                </div>
                <v-data-table
                    :headers="headers"
                    :items="invoices"
                    :options.sync="pagination"
                    :search="pagination.search"
                    :server-items-length="pagination.totalItems"
                    class="elevation-1"
                >
                    <template v-slot:header.status="{ header }">
                        {{ $t('invoice.status.title') }}
                    </template>
                    <template v-slot:header.invoiceNumber="{ header }">
                        {{ $t('invoice.invoiceNumber') }}
                    </template>
                    <template v-slot:header.totalPrice="{ header }">
                        {{ $t('invoice.totalPrice') }}
                    </template>
                    <template v-slot:header.invoicingDates="{ header }">
                        {{ $t('invoice.invoicingDates') }}
                    </template>
                    <template v-slot:header.createdAt="{ header }">
                        {{ $t('invoice.createdAt') }}
                    </template>
                    <template v-slot:header.dueDate="{ header }">
                        {{ $t('invoice.dueDate') }}
                    </template>
                    <template v-slot:item.status="{ item }">
                        <v-chip
                            :color="getStatusColor(item.status)"
                            text-color="white"
                            small
                        >
                            <v-icon left small>{{ getStatusIcon(item.status) }}</v-icon>
                            {{$t('invoice.status.' + item.status)}}
                        </v-chip>
                    </template>
                    <template v-slot:item.totalPrice="{ item }">
                        {{  $t('invoice.totalPriceFormatted', {price: item.totalPrice}) }}
                    </template>
                    <template v-slot:item.createdAt="{ item }">
                        {{ item.createdAt | formatShortDate }}
                    </template>
                    <template v-slot:item.invoicingDates="{ item }">
                        {{ item.startDate | formatShortDate }}
                        <v-icon>arrow_right_alt</v-icon>
                        {{ item.endDate | formatShortDate }}
                    </template>
                    <template v-slot:item.dueDate="{ item }">
                        {{ item.dueDate | formatShortDate }}
                    </template>
                    <template v-slot:item.actions="{ item }">
                        <v-btn
                            v-if="isAdmin || isMaster()"
                            :href="getSrc(item.pdfPath)"
                            icon
                            target="_blank"
                            :title="$t('invoices.seeThePdf')"
                            small
                        >
                            <v-icon>picture_as_pdf</v-icon>
                        </v-btn>
                        <v-btn
                            v-if="isAdmin"
                            icon
                            small
                            :title="$t('invoice.status.change.button')"
                        >
                            <v-icon
                                x-small
                                @click="editInvoice(item)"
                            >
                                edit
                            </v-icon>
                        </v-btn>
                        <v-dialog max-width="500px" v-model="updateStatusDialog">
                            <v-card>
                                <v-card-title>
                                            <span class="headline">
                                                {{$t('invoice.status.change.title')}}
                                            </span>
                                </v-card-title>
                                <v-card-text class="py-0">
                                    <v-container class="py-0">
                                        <v-row>
                                            <v-radio-group v-model="currentInvoice.status">
                                                <v-radio :label="$t('invoice.status.CREATED')" value="CREATED"></v-radio>
                                                <v-radio :label="$t('invoice.status.PAID')" value="PAID"></v-radio>
                                                <v-radio :label="$t('invoice.status.LATE')" value="LATE"></v-radio>
                                            </v-radio-group>
                                        </v-row>
                                    </v-container>
                                </v-card-text>
                                <v-card-actions>
                                    <v-spacer></v-spacer>
                                    <v-btn
                                        @click="updateStatusDialog = false"
                                        color="blue darken-1"
                                        text
                                    >
                                        {{$t('actions.cancel')}}
                                    </v-btn>
                                    <v-btn
                                        @click="updateInvoice(currentInvoice)"
                                        color="orange darken-1"
                                        text
                                    >
                                        {{$t('actions.confirm')}}
                                    </v-btn>
                                    <v-spacer></v-spacer>
                                </v-card-actions>
                            </v-card>
                        </v-dialog>
                    </template>
                </v-data-table>
            </div>
        </v-expand-transition>
        <input type="hidden" :value="searchQuery">
    </div>
</template>
<script lang="ts">
import {Vue, Component, Prop, Watch} from "vue-property-decorator";
import CompanyGraphSubscription from "@/components/company/CompanyGraphSubscription.vue";
import {Getter} from "vuex-class";
import {getSrc} from "@/utils/misc";
@Component({
        components: {CompanyGraphSubscription},
    })
export default class CompanyInvoicing extends Vue {

    get searchQuery() {
        const query  = this.$store.getters.getSearchQuery;
        this.pagination.search = query;
        return query;
    }

    get currentInvoicingSimulation(): string {
        return this.getSrc(`/api/companies/${this.company.id}/simulate-invoice`);
    }

    @Prop({default: null})
    public company: any;
    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;
    @Getter private isMaster: (type?: string) => boolean;

    private invoices: any[] = [];
    private displayInvoices: boolean = true;
    private headers: object[] = [
        {value: "invoiceNumber", sortable: true},
        {value: "invoicingDates", sortable: false},
        {value: "totalPrice", sortable: true},
        {value: "dueDate", sortable: true},
        {value: "status", sortable: true},
        {value: "createdAt", sortable: true},
        {value: "actions", sortable: false},
    ];
    private pagination: any = {
        sortDesc: [true],
        sortBy: ["updatedAt"],
        search: "",
        select: [],
        page: 1,
        itemsPerPage: 10,
        totalItems: 10,
        rowsPerPageItems: [1, 2, 4, 8, 16],
    };
    private currentInvoice: any = {};
    private updateStatusDialog: boolean = false;
    private getSrc: (string) => string = getSrc;

    @Watch("pagination", { deep: true })
    public handler() {
        this.getInvoices();
    }

    private getInvoices() {
        return this.$store.dispatch("companies/getInvoices", {
            id: this.company.id,
            query: this.pagination,
        })
        .then((res) => {
            this.invoices = res.rows;
            this.pagination.totalItems = res.count;
        });
    }

    private editInvoice(invoice: any) {
        this.currentInvoice = { ...invoice };
        this.updateStatusDialog = true;
    }

    private updateInvoice(invoice: any) {
        return this.$store.dispatch("invoices/updateById", {
            id: invoice.id,
            invoice,
        })
        .then(() => {
            this.updateStatusDialog = false;
            this.getInvoices();
            this.$store.commit("alerts/displaySuccess", {
                msg : this.$i18n.t("actions.saved"),
            });
        })
        .catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg : err,
            });
        });
    }

    private getStatusColor(status: string) {
        switch (status) {
            case "CREATED": return "blue";
            case "PAID": return "green";
            case "LATE": return "red";
            default: return "default";
        }
    }

    private getStatusIcon(status: string) {
        switch (status) {
            case "CREATED": return "send";
            case "PAID": return "check";
            case "LATE": return "priority_high";
            default: return "";
        }
    }
}
</script>