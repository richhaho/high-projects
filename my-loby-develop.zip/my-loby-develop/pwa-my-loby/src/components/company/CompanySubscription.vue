<template>
    <div>
        <v-row justify="center">
            <button
                type="button"
                class="option open_popup"
                :title="$t('subscription.new')"
                @click="newSubscriptionDialog = true"
            >
                <i class="icon-picto_ajouter"></i>
                {{$t('subscription.new')}}
            </button>
            <v-dialog max-width="1000px" v-model="newSubscriptionDialog">
                <v-card>
                    <v-card-title>
                        <span class="headline">{{$t('subscription.new')}}</span>
                    </v-card-title>
                    <v-card-text>
                        <company-subscription-form
                            :subscription="newSubscription"
                            :company="company"
                        />
                    </v-card-text>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn @click="newSubscriptionDialog = false" color="blue darken-1" text>{{$t('actions.cancel')}}</v-btn>
                        <v-btn
                            v-if="isValidSubscription(newSubscription)"
                            @click="createSubscription(newSubscription)"
                            color="orange darken-1"
                            text
                        >
                            {{$t('actions.create')}}
                        </v-btn>
                        <v-spacer></v-spacer>
                    </v-card-actions>
                </v-card>
            </v-dialog>
        </v-row>
        <v-data-table
            v-if="subscriptions.length"
            :headers="headers"
            :items="subscriptions"
            class="elevation-1 mt-5"
            show-expand
            single-expand
            :expanded.sync="expanded"
            :hide-default-footer="subscriptions.length <= 10"
        >
            <template v-slot:item.plan="{ item }">
                {{$t(`plan.${item.Plan.name}.nameAndPrice`, {price: item.Plan.monthlyPrice})}}
            </template>
            <template v-slot:item.startDate="{ item }">
                {{item.startDate | formatShortDate}}
            </template>
            <template v-slot:item.endDate="{ item }">
                <div v-if="item.endDate">
                    {{item.endDate | formatShortDate}}
                </div>
                <div v-else>
                    {{$t('subscription.ongoing')}}
                </div>
            </template>
            <template v-slot:expanded-item="{ item }">
                <td :colspan="headers.length">
                    <company-subscription-form
                        :subscription="item"
                        :company="company"
                        :relayBoxList="relayBoxList"
                        :relayBoxToDelete="relayBoxToDelete"
                    />
                    <v-row justify="center">
                        <v-btn
                            v-if="!item.chargedAt"
                            :disabled="!isValidSubscription(item)"
                            @click="updateSubscription(item)"
                            class="mb-4"
                            color="success"
                        >
                            {{$t('actions.edit')}}
                        </v-btn>
                    </v-row>
                </td>
            </template>
        </v-data-table>
    </div>
</template>
<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";
import CompanySubscriptionForm from "@/components/company/CompanySubscriptionForm.vue";

@Component({
    components: {
        CompanySubscriptionForm,
    },
})
export default class CompanySubscription extends Vue {
    @Prop({default: null})
    public company: any;

    private subscriptions: any[] = [];
    private headers: object[] = [];
    private expanded: object[] = [];
    private relayBoxList: object[] = [];
    private relayBoxToDelete: any[] = [];
    private newSubscriptionDialog: boolean = false;
    private newSubscription: object = null;

    private async mounted() {
        // await this.$store.dispatch("relays/removeConnectedBoxes", {
        //     relayId: 1,
        // });

        this.headers = [
            {value: "plan", text: this.$i18n.t("company.plan"), sortable: false},
            {value: "startDate", text: this.$i18n.t("common.startDate"), sortable: false},
            {value: "endDate", text: this.$i18n.t("common.endDate"), sortable: false},
            {value: "data-table-expand" },
        ];
        this.reset();
        this.relayBoxList = this.connectedBoxesOfCurrentCompany();
    }

    private reset() {
        this.expanded = [];
        this.getSubscriptions();
        this.newSubscriptionDialog = false;
        this.newSubscription = {
            Plan: {},
            options: {},
            details: {
                options: {
                    additionalRelays: {
                        initValue: 49,
                        discount: {
                            multiplier: 1,
                        },
                    },
                    connectedBoxes: {
                        initValue: 0,
                        discount: {
                            multiplier: 1,
                        },
                    },
                    dropKeyInFlowRelaysPackage: {
                        keysNumber: 75,
                        initValue: 100,
                    },
                    dropKeyInFlowRelaysSingle: {
                        initValue: 2,
                        discount: {
                            multiplier: 1,
                        },
                    },
                    manageStock: {
                        initValue: 50,
                        discount: {
                            multiplier: 1,
                        },
                    },
                    allowBooking: {
                        initValue: 50,
                        discount: {
                            multiplier: 1,
                        },
                    },
                },
                planOption: {
                    discount: {
                        multiplier: 1,
                    },
                },
            },
        };
    }

private isValidSubscription = (subscription: any) => {
        if (!subscription?.Plan?.id || !subscription.startDate) {
            return false;
        }
        if (subscription.Plan.monthlyPrice > 0 && !subscription?.paymentPeriodicity) {
            return false;
        }
        if (subscription.details.options.dropKeyInFlowRelaysPackage?.isActive
            && !(subscription.details.options.dropKeyInFlowRelaysPackage.keysNumber
                && subscription.details.options.dropKeyInFlowRelaysPackage.initValue)) {
            return false;
        }
        return true;
    }

    private getSubscriptions() {
        return this.$store.dispatch("companies/getSubscriptions", {
            id: this.company.id,
        })
        .then((res) => {
            this.subscriptions = res.rows;
        });
    }

    private createBox(relayId: number, connectedBox: any) {
        const columns = {S: 5, M: 2, L: 2};
        const lines = {S: 3, M: 2, L: 1};
        const leaflets = 1;
        return this.$store.dispatch("relays/addBox", {
            relayId,
            box: {
                number: connectedBox.number,
                sheets: leaflets,
                columns: columns[connectedBox.size],
                lines: lines[connectedBox.size],
                size: connectedBox.size,
                acsesLockesystemId: connectedBox.acsesLockesystemId,
                extensionsCount: connectedBox.extensionsCount,
            },
        });
    }

    private createSubscription(subscription: any) {
        this.$store.dispatch("subscriptions/createCompanySubscription", {
            subscription: {
                ...subscription,
                companyId: this.company.id,
                planId: subscription.Plan.id,
            },
        }).then((res) => {
            this.reset();
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("actions.created"),
            });
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: this.$t(`register.error.${err.response.data.type}`),
            });
        });
    }

    private async updateSubscription(subscription: any) {
        if (this.relayBoxToDelete.length !== 0) {
            await this.$store.dispatch("boxes/removeList", {
                idList: this.relayBoxToDelete.map((box) => box.id),
            });
        }

        let boxSaveFailed = false;
        await Promise.all(
            this.relayBoxList.map(
                async (relay: any) => await Promise.all(
                    relay.boxes.map(
                        async (box) => {
                            if (!box.acsesLockesystemId || !box.size || !Number.isInteger(box.extensionsCount)) {
                                return;
                            }
                            if (!box.id && !boxSaveFailed) {
                                try {
                                    const newBox = await this.createBox(relay.id, box);
                                    box.id = newBox.id;
                                } catch (err) {
                                    boxSaveFailed = true;
                                    this.$store.commit("alerts/displayError", {
                                        msg: this.$i18n?.t(`register.error.connectedBox`),
                                    });
                                    return;
                                }
                            } else if (box.modify && !boxSaveFailed) {
                                try {
                                    await this.$store.dispatch("boxes/update", {
                                        id: box.id,
                                        box: {
                                            sheets: box.sheets,
                                            columns: box.columns,
                                            lines: box.lines,
                                            size: box.size,
                                            acsesLockesystemId: box.acsesLockesystemId,
                                            extensionsCount: box.extensionsCount,
                                        },
                                    });
                                } catch (err) {
                                    boxSaveFailed = true;
                                    this.$store.commit("alerts/displayError", {
                                        msg: this.$i18n?.t(`register.error.connectedBox`),
                                    });
                                    return;
                                }
                            }
                            box.edit = false;
                            return box;
                        },
                    ),
                ),
            ),
        );

        if (boxSaveFailed) {
            return;
        }

        this.$store.dispatch("subscriptions/updateById", {
            id: subscription.id,
            subscription: {
                ...subscription,
                companyId: this.company.id,
                planId: subscription.Plan.id,
            },
        }).then((res) => {
            this.reset();
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("actions.saved"),
            });
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: this.$t(`register.error.${err.response.data.type}`),
            });
        });
    }

    private connectedBoxesOfCurrentCompany() {
        return this.company.Relays.map((relay) => {
            const relayBoxes = relay.Boxes.filter((box) => !!box.acsesLockesystemId);
            return {
                ...relay,
                boxes: relayBoxes?.map((box) => ({
                    ...box,
                    edit: false,
                })) || [],
            };
        });
    }
}
</script>