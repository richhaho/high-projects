<template>
    <v-col cols="12">
        <v-row>
            <v-col cols="4">
                <v-select
                    :disabled="!!subscription.chargedAt"
                    :items="formattedPlans"
                    :label="$t('company.plan')+' *'"
                    :rules="[rules.required]"
                    prepend-icon="attach_money"
                    class="mb-3"
                    item-text="label"
                    item-value="plan"
                    v-model="subscription.Plan"
                />
                <v-menu
                    v-model="startDateMenu"
                    :close-on-content-click="false"
                    transition="scale-transition"
                    offset-y
                    max-width="290px"
                    min-width="290px"
                >
                    <template v-slot:activator="{ on }">
                        <v-text-field
                            :disabled="!!subscription.chargedAt"
                            :value="subscription.startDate | formatShortDate"
                            :label="$t('common.startDate') + ' *'"
                            prepend-icon="event"
                            readonly
                            v-on="on"
                        />
                    </template>
                    <v-date-picker
                        :locale="lang"
                        v-model="subscription.startDate"
                        no-title
                        @input="startDateMenu = false"
                    />
                </v-menu>
                <v-menu
                    v-model="endDateMenu"
                    :close-on-content-click="false"
                    transition="scale-transition"
                    offset-y
                    max-width="290px"
                    min-width="290px"
                >
                    <template v-slot:activator="{ on }">
                        <v-text-field
                            :disabled="!!subscription.chargedAt"
                            :value="subscription.endDate | formatShortDate"
                            :label="$t((subscription.endDate || !subscription.startDate) ? 'common.endDate' : 'subscription.ongoing')"
                            prepend-icon="event"
                            readonly
                            v-on="on"
                        />
                    </template>
                    <v-date-picker
                        :locale="lang"
                        v-model="subscription.endDate"
                        no-title
                        :min="subscription.startDate"
                        @input="endDateMenu = false"
                    />
                </v-menu>
            </v-col>
            <v-col cols="2">
            </v-col>
            <v-col cols="6" v-if="isPlanNotFree(subscription.Plan)">
                <v-row>
                    <v-col class="pa-0" cols="12">
                        <h5 style="color: grey;">{{$t('subscription.paymentPeriodicity.title')}} *</h5>
                    </v-col>
                    <v-col class="pt-0">
                        <v-radio-group
                            :disabled="!!subscription.chargedAt"
                            :rules="[rules.required]"
                            class="mt-0"
                            v-model="subscription.paymentPeriodicity"
                            hide-details
                            @change="inputConnectedBoxesAndExtensions"
                        >
                            <v-radio
                                :label="$t('subscription.paymentPeriodicity.monthly')"
                                value="MONTHLY"
                            />
                            <v-radio
                                :label="$t('subscription.paymentPeriodicity.yearly')"
                                value="YEARLY"
                            />
                        </v-radio-group>
                    </v-col>
                </v-row>
                <v-row>
                    <v-col class="pa-0" cols="12">
                        <h5 style="color: grey; ">{{$t('subscription.details.options.title')}}</h5>
                    </v-col>
                    <v-col
                        class="py-0"
                        cols="12"
                        v-for="option in classicOptions"
                    >
                        <v-checkbox
                            :disabled="!!subscription.chargedAt"
                            :readonly="option === 'connectedBoxes' && companyHasConnectedBoxes"
                            :label="$t(`subscription.details.options.${[option]}`)"
                            class="my-0"
                            v-model="subscription.details.options[option].isActive"
                            hide-details
                            @click.native="displayInfoOnOptionChange(option)"
                        />
                        <v-row v-if="option === 'connectedBoxes' && subscription.details.options[option].isActive" class="ml-4">
                            <v-col cols="12" v-for="relay in relayBoxList" :key="relay.id">
                                <v-col cols="12" class="pa-0 ma-0">
                                    <div class="d-flex align-center justify-content-between">
                                        <p class="font-weight-bold h6">{{relay.name}}</p>
                                        <a
                                            v-if="relay.boxes.length === 0"
                                            class="d-flex"
                                            @click="addAcsesLockesystemId(relay.id)"
                                        >
                                            <i class="icon-picto_ajouter"></i>
                                        </a>
                                    </div>
                                </v-col>

                                <template>
                                    <v-col cols="12" class="pa-0 ma-0 d-flex" v-for="(val, k) in relay.boxes" :key="k">
                                        <div class="d-flex">
                                            <span class="mt-2 w-50">{{$t('box.connected', {size: val.size || ""}) }}</span>
                                            <v-text-field
                                                class="w-50 ml-1"
                                                v-model="val.acsesLockesystemId"
                                                @change="updateConnectedBox(val)"
                                                placeholder="id"
                                                :disabled="!val.edit"
                                                dense
                                                outlined
                                                type="text"
                                            />
                                            <v-select
                                                :items="sizeList"
                                                label=""
                                                :rules="[rules.required]"
                                                item-text="label"
                                                item-value="plan"
                                                :disabled="!val.edit"
                                                class="ml-2 ma-0 pa-0 mr-2"
                                                v-model="val.size"
                                                @change="updateConnectedBox(val)"
                                            />
                                            <v-text-field
                                                class="w-50 ml-1"
                                                @change="updateConnectedBox(val)"
                                                type="number"
                                                v-model.number="val.extensionsCount"
                                                placeholder="extensions"
                                                :disabled="!val.edit"
                                                min="0"
                                                max="9"
                                                pattern="[0-9]"
                                                inputmode="numeric"
                                                dense
                                                outlined
                                            />
                                            <a
                                                class="d-flex mt-2"
                                                @click="addAcsesLockesystemId(relay.id)"
                                            >
                                                <i class="icon-picto_ajouter"></i>
                                            </a>
                                            <a
                                                class="d-flex ml-1 mt-2"
                                                @click="editBox(val)"
                                            >
                                                <i class="icon-picto_editer"></i>
                                            </a>
                                            <a
                                                class="d-flex ml-1 mt-2"
                                                @click="removeAcsesLockesystemId(relay.id, k)"
                                            >
                                                <i class="icon-picto_supprimer"></i>
                                            </a>
                                        </div>
                                    </v-col>
                                </template>
                            </v-col>
                        </v-row>
                    </v-col>
                    <v-col
                        class="py-0"
                        cols="12"
                        v-if="singleKeyOption && singleKeyOption.isActive"
                    >
                        <v-row>
                            <v-col class="pt-1" cols="3">
                                <v-checkbox
                                    :disabled="!!subscription.chargedAt"
                                    :label="$t(`subscription.details.options.dropKeyInFlowRelaysPackage.title`)"
                                    class="my-0"
                                    hide-details
                                    v-model="subscription.details.options.dropKeyInFlowRelaysPackage.isActive"
                                />
                            </v-col>
                            <v-col class="pa-1" cols="2">
                                <v-text-field
                                    v-model="subscription.details.options.dropKeyInFlowRelaysPackage.keysNumber"
                                    :disabled="!subscription.details.options.dropKeyInFlowRelaysPackage.isActive"
                                    :rules="[rules.positive, rules.required]"
                                    dense
                                    outlined
                                    type="number"
                                />
                            </v-col>
                            <v-col class="px-0">
                                {{$t('subscription.details.options.dropKeyInFlowRelaysPackage.keysNumber')}}
                            </v-col>
                            <v-col class="pa-1" cols="3">
                                <v-text-field
                                    :suffix="$t('currency.symbol')"
                                    v-model="subscription.details.options.dropKeyInFlowRelaysPackage.initValue.toFixed(2)"
                                    :disabled="!subscription.details.options.dropKeyInFlowRelaysPackage.isActive"
                                    :rules="[rules.positive, rules.required]"
                                    dense
                                    outlined
                                    type="number"
                                />
                            </v-col>
                            <v-col class="px-0">
                                {{$t('subscription.details.options.dropKeyInFlowRelaysPackage.initValue')}}
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>
        <v-divider v-if="isPlanNotFree(subscription.Plan)"></v-divider>
        <v-row v-if="isPlanNotFree(subscription.Plan)">
            <v-col cols="12" class="ml-5 py-0">
                <v-row class="pb-2">
                    <h5 style="color: grey;">{{$tc('subscription.details.discount.title', 0)}}</h5>
                </v-row>
                <v-row v-if="subscription.details.planOption">
                    <h6 style="color: grey; text-transform: none;">{{$t(`subscription.details.discount.plan`)}}</h6>
                    <v-col class="py-0" cols="12">
                        <v-row>
                            <v-col cols="2" class="py-0">
                                <v-text-field
                                    :label="$t('subscription.details.discount.initialPrice')"
                                    :suffix="$t('currency.symbol')"
                                    :value="subscription.Plan.monthlyPrice.toFixed(2)"
                                    disabled
                                    type="number"
                                />
                            </v-col>
                            <v-col cols="2" class="py-0">
                                <v-text-field
                                    :disabled="!!subscription.chargedAt"
                                    :label="$tc('subscription.details.discount.multiplier', 1)"
                                    :max="100"
                                    :min="0"
                                    :rules="[rules.multiplier]"
                                    type="number"
                                    v-model="subscription.details.planOption.discount.multiplier"
                                />
                            </v-col>
                            <v-col cols="2" class="py-0">
                                <v-text-field
                                    :label="$t('subscription.details.discount.finalPrice')"
                                    :suffix="$t('currency.symbol')"
                                    :value="(subscription.Plan.monthlyPrice * subscription.details.planOption.discount.multiplier).toFixed(2)"
                                    disabled
                                    type="number"
                                />
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>
                <v-row v-for="option in activeOptions">
                    <h6 style="color: grey; text-transform: none;">{{$t(`subscription.details.discount.${option}`)}}</h6>
                    <v-col class="py-0" cols="12">
                        <v-row>
                            <v-col cols="2" class="py-0">
                                <v-text-field
                                    :label="$t('subscription.details.discount.initialPrice')"
                                    :suffix="$t('currency.symbol')"
                                    :value="subscription.details.options[option].initValue.toFixed(2)"
                                    disabled
                                    type="number"
                                />
                            </v-col>
                            <v-col cols="2" class="py-0">
                                <v-text-field
                                    :disabled="!!subscription.chargedAt"
                                    :label="$tc('subscription.details.discount.multiplier', 1)"
                                    :max="100"
                                    :min="0"
                                    :rules="[rules.multiplier]"
                                    type="number"
                                    v-model="subscription.details.options[option].discount.multiplier"
                                />
                            </v-col>
                            <v-col cols="2" class="py-0">
                                <v-text-field
                                    :label="$t('subscription.details.discount.finalPrice')"
                                    :suffix="$t('currency.symbol')"
                                    :value="(subscription.details.options[option].initValue * subscription.details.options[option].discount.multiplier).toFixed(2)"
                                    disabled
                                    type="number"
                                />
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
        </v-row>
        <v-dialog max-width="500px" v-model="connectBoxesModal">
            <v-card>
                <v-card-title>
                    <span class="headline">
                        {{$t('box.connectedBoxes.options.removeModalTitle')}}
                    </span>
                </v-card-title>
                <v-card-text class="py-0">
                    <v-container class="pb-0">
                        <p>{{$t('box.connectedBoxes.options.removeModalDescription')}}</p>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="connectBoxesModal = false"
                        color="blue darken-1"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-spacer></v-spacer>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <v-dialog max-width="500px" v-model="cantEditOrDeleteConnected">
            <v-card>
                <v-card-title>
                    <span class="headline">
                        {{$t('box.connectedBoxes.options.cantEditConnectedBoxTitle')}}
                    </span>
                </v-card-title>
                <v-card-text class="py-0">
                    <v-container class="pb-0">
                        <p>{{$t('box.connectedBoxes.options.cantEditConnectedBoxDescription')}}</p>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="cantEditOrDeleteConnected = false"
                        color="blue darken-1"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-spacer></v-spacer>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </v-col>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import {formRules} from "@/utils/formRules";
export const CONNECTED_BOXES = "CONNECTED_BOXES";
export const FREE = "FREE";
export const B2B = "B2B";
export const AGENCY = "AGENCY";

@Component
export default class CompanySubscriptionForm extends Vue {

    @Prop({default: {}})
    public subscription: any;

    @Prop({default: {}})
    public company: any;

    @Prop({default: () => []})
    public relayBoxList: any;

    @Prop({default: () => []})
    public relayBoxToDelete: any;

    private plans: any[] = [];
    private companyList: any[] = [];
    private sizeList: any[] = [
        {key: "S", label: "S"},
        {key: "M", label: "M"},
        {key: "L", label: "L"},
    ];

    private rules: object = formRules;
    private startDateMenu: boolean = false;
    private endDateMenu: boolean = false;
    private connects: any[] = ["S", "M", "L"];
    private connectBoxesModal: boolean = false;
    private cantEditOrDeleteConnected: boolean = false;

    @Watch("subscription.Plan")
    public handlerPlanChange(newPlan: any) {
        if (newPlan.type === "B2B") {
            // Automatically activate "more relays" option if plan authorized it
            this.subscription.details.options.additionalRelays.isActive = !!newPlan.details.canCreateMoreRelays;
            // Automatically activate "deposit in flow relays" option if plan authorized it
            this.subscription.details.options.dropKeyInFlowRelaysSingle.isActive = !!newPlan.details.canUseFlowRelays;
            // Automatically activate "manage stock" option if plan authorized it
            this.subscription.details.options.manageStock.isActive = !!newPlan.details.canManageStock;
            // Automatically activate "allow Booking" option if plan authorized it
            this.subscription.details.options.allowBooking.isActive = !!newPlan.details.canUseBooking;
        }
        if (newPlan.name === "PREMIUM") {
            this.subscription.details.options.allowBooking.initValue = 0;
            this.subscription.details.options.manageStock.initValue = 0;
        }
    }

    @Watch("subscription.details.options.dropKeyInFlowRelaysSingle.isActive", { immediate: true })
    public handlerSingleKeyOption(newVal: boolean) {
        if (!newVal) {
            this.subscription.details.options.dropKeyInFlowRelaysPackage.isActive = false;
        }
    }

    private mounted() {
        this.getPlans();
        if (this.subscription.startDate) {
            this.subscription.startDate = new Date(this.subscription.startDate).toISOString().substr(0, 10);
        }
        if (this.subscription.endDate) {
            this.subscription.endDate = new Date(this.subscription.endDate).toISOString().substr(0, 10);
        }
        this.inputConnectedBoxesAndExtensions();
    }

    get lang() {
        return this.$root.$i18n.locale;
    }

    get classicOptions(): any[] {
        return Object.keys(this.subscription.details.options)
            .filter((option) => option !== "dropKeyInFlowRelaysPackage");
    }

    get activeOptions(): any[] {
        return this.classicOptions.filter((option) => this.subscription.details.options[option].isActive);
    }

    get singleKeyOption(): any {
        return this.subscription.details.options?.dropKeyInFlowRelaysSingle;
    }

    get companyHasConnectedBoxes(): boolean {
        return this.relayBoxList.some((relay) => relay.boxes.length > 0);
    }

    private formatDate = (date: string) => {
        const [year, month, day] = date.split("-");
        return `${month}/${day}/${year}`;
    }

    private getPlans() {
        const query = {type: this.company.type};
        return this.$store.dispatch("plans/read", {query})
        .then((res) => {
            this.plans = res.plans.sort((a, b) => a.monthlyPrice - b.monthlyPrice);
        });
    }

    get formattedPlans() {
        return this.plans
        .map((plan) => ({
            key: plan.id,
            label: plan.name !== CONNECTED_BOXES
                ? this.$t(`plan.${plan.name}.nameAndPrice`, {price: plan.monthlyPrice})
                : this.$t(`plan.${plan.name}.name`) + ` (${plan.details.connectedBoxPrice}€/${this.$t("plan." + plan.name + ".name")})`,
            plan: {...plan},
        }));
    }

    private isPlanCharged = (plan: any) => plan.monthlyPrice > 0;
    private isPlanNotFree = (plan: any) => plan.name && plan.name !== FREE;

    private inputConnectedBoxesAndExtensions() {
        if (!this.subscription.Plan.details) {
            return;
        }
        const firstBoxPrice = this.subscription.Plan.details.firstConnectedBoxPrice || 49;
        const boxPrice = this.subscription.Plan.details.connectedBoxPrice || 89;

        let price = 0;
        let firstRelay = true;
        this.relayBoxList.forEach((relay) => {
            const relatedBoxConnected = relay.boxes.filter((box) => box.acsesLockesystemId);
            if (relatedBoxConnected.length > 0 && firstRelay) {
                price += boxPrice * relatedBoxConnected.length;
            }
            if (relatedBoxConnected.length > 0 && !firstRelay) {
                price += firstBoxPrice
                    + boxPrice * (relatedBoxConnected.length > 1 ? relatedBoxConnected.length - 1 : 0);
            }
            firstRelay = false;
        });
        this.subscription.details.options.connectedBoxes.initValue =
            (this.subscription.paymentPeriodicity === "YEARLY") ? price * 12 : price;
    }
    private addAcsesLockesystemId(relayId) {
        const relatedRelay = this.relayBoxList.findIndex((relay) => relay.id === relayId);
        if (relatedRelay === -1) {
            return;
        }

        let num = this.relayBoxList[relatedRelay].boxes.length;
        this.relayBoxList[relatedRelay].boxes.push({
            id: null,
            number: num++,
            sheets: null,
            columns: null,
            lines: null,
            size: "S",
            acsesLockesystemId: null,
            extensionsCount: 0,
            edit: true,
        });
        this.inputConnectedBoxesAndExtensions();
        this.$forceUpdate();
    }
    private async removeAcsesLockesystemId(relayId, k) {
        const relatedRelay = this.relayBoxList.findIndex((relay) => relay.id === relayId);
        if (relatedRelay === -1) {
            return;
        }
        const canEdit = await this.canEditOrDelete(this.relayBoxList[relatedRelay].boxes[k]);
        if (!canEdit) {
            return this.cantEditOrDeleteConnected = true;
        }

        this.relayBoxToDelete.push(this.relayBoxList[relatedRelay].boxes[k]);
        this.relayBoxList[relatedRelay].boxes.splice(k, 1);
        this.inputConnectedBoxesAndExtensions();
        this.$forceUpdate();
    }

    private updateConnectedBox(box) {
        box.modify = true;
        if (box.acsesLockesystemId && box.size && !isNaN(box.extensionsCount)) {
            this.inputConnectedBoxesAndExtensions();
        }
    }

    private async editBox(box) {
        const canEdit = await this.canEditOrDelete(box);
        if (!canEdit) {
            return this.cantEditOrDeleteConnected = true;
        }
        box.edit = !box.edit;
    }

    private displayInfoOnOptionChange(option): void {
        if (option !== "connectedBoxes") {
            return;
        }
        if (this.companyHasConnectedBoxes) {
            this.connectBoxesModal = true;
        }
    }

    private async canEditOrDelete(box) {
        if (!box.id) {
            return true;
        }
        const relatedBox = await this.$store.dispatch("boxes/getById", {id: box.id, query: {
            acsesObject: true
        }});
        return !relatedBox?.AcsesObjects.find((acsesObject) => !!acsesObject.keyId);
    }
}
</script>
