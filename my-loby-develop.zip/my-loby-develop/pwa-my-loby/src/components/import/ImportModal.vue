<template>
    <div>
        <button
            :disabled="disabled"
            type="button"
            class="option open_popup"
            :title="title"
            @click="showDialog = true"
        >
            <i class="icon-picto_importer"></i>
            {{title}}
        </button>
        <v-dialog
            persistent
            v-model="showDialog"
            max-width="910px">
            <v-card>
                <v-card-title>
                    <div class="contain_picto">
                        <i class="icon-picto_importer"></i>
                    </div>
                    <span class="headline">{{title}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-row>
                            <p>{{$t('import.formattingRules')}}</p>
                            <ul>
                                <li v-for="column in csvColumns">
                                    <b>{{$t(`import.${parsingType}.columns.${column}`)}} ; </b>
                                </li>
                            </ul>
                        </v-row>
                        <v-row>
                            <v-col lg="10" class="pt-0">
                                <v-file-input
                                    :hide-details="!!csvFile"
                                    :label="$t('contacts.chooseFile')"
                                    :messages="$t('contacts.noFile')"
                                    accept="csv"
                                    v-model="csvFile"
                                ></v-file-input>
                            </v-col>
                        </v-row>
                        <v-row justify="center" v-if="type === 'keys'">
                            <v-autocomplete
                                :disabled="relays && relays.length === 1"
                                :item-text="JSON.stringify"
                                :items="relays"
                                :no-data-text="$t('keysList.noRelayFound')"
                                :search-input.sync="searchRelays"
                                append-icon
                                flat
                                hide-details
                                item-value="id"
                                prepend-inner-icon="near_me"
                                solo
                                v-bind:label="$t('key.relay')"
                                v-model="relayId"
                            >
                                <template v-slot:selection="data">
                                    <v-list-item-content>
                                        <v-list-item-title v-html="data.item.name"></v-list-item-title>
                                        <v-list-item-subtitle
                                            v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city"
                                        ></v-list-item-subtitle>
                                        <v-list-item-subtitle
                                            v-if="data.item.totalReservedLocations"
                                            v-html="$tc('relay.reservedLocationsCount', data.item.totalReservedLocations)"
                                        ></v-list-item-subtitle>
                                        <v-list-item-subtitle
                                            v-if="data.item.totalReservedLocations || data.item.totalAvailableReservedLocations"
                                            v-html="$tc('relay.availableLocationsCount', data.item.totalAvailableReservedLocations)"
                                        ></v-list-item-subtitle>
                                    </v-list-item-content>
                                </template>
                                <template v-slot:item="data">
                                    <v-list-item-content :aria-disabled="!data.item.available">
                                        <v-list-item-title v-html="data.item.name"></v-list-item-title>
                                        <v-list-item-subtitle
                                            v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city"
                                        ></v-list-item-subtitle>
                                        <v-list-item-subtitle
                                            v-if="data.item.totalReservedLocations"
                                            v-html="$tc('relay.reservedLocationsCount', data.item.totalReservedLocations)"
                                        ></v-list-item-subtitle>
                                        <v-list-item-subtitle
                                            v-if="data.item.totalReservedLocations || data.item.totalAvailableReservedLocations"
                                            v-html="$tc('relay.availableLocationsCount', data.item.totalAvailableReservedLocations)"
                                        ></v-list-item-subtitle>
                                    </v-list-item-content>
                                </template>
                            </v-autocomplete>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="showDialog = false"
                        color="white"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-btn
                        v-if="csvFile && ((type === 'keys' && relayId) || type !== 'keys')"
                        :disabled="!csvFile || (type === 'keys' && !relayId)"
                        :loading="importing"
                        @click="parseFile"
                        color="warning"
                    >{{$t("actions.import")}}</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Prop, Watch } from "vue-property-decorator";
import {Getter} from "vuex-class";
import {canUseManagers} from "plan-restrictions";

@Component
export default class ImportModal extends Vue {
  @Prop({ default: null })
  public title: string;

  @Prop({ default: null })
  public type: string;

  @Prop({ default: false })
  public disabled: boolean;
  @Getter private currentUser: any;
  @Getter private isMaster: (type?: string) => boolean;

  private csvFile: any = null;
  private importing: boolean = false;
  private relays: any[] = null;
  private searchRelays: string = null;
  private relayId: string = null;
  private canUseManagers: (company: any) => boolean = canUseManagers;
  private showDialog: boolean = false;

  @Watch("searchRelays", { deep: true })
  public handlerSearchRelays() {
    this.getRelays();
  }

  private mounted() {
    if (this.type === "keys") {
      this.getRelays();
    }
  }

  get parsingType(): string {
      switch (this.type) {
          case "management":
              return "users";
          case "contacts":
              return "users";
          case "keys":
              return "keys";
          default:
              return null;
      }
  }

  get csvColumns(): string[] {
      switch (this.parsingType) {
          case "users":
              return [
                  "lastName",
                  "firstName",
                  "company",
                  "job",
                  "email",
                  "phone",
              ];
          case "keys":
              const columns: string[] = [
                  "name",
                  "description",
              ];
              if (this.canUseManagers(this.currentUser?.company)) {
                  columns.push("managers");
              }
              return columns;
          default:
              return [];
      }
  }

  private isAvailable(location: any) {
      if (location?.keyId) { return false; } // not occupied if location was never used
      if (!location?.KeyLocation?.length) { return true; } // not occupied if location was never used
      return !location?.KeyLocation?.map((kL) => kL.endDate).includes(null); // is location currently used
  }

  private getRelays(): void {
    if (this.isMaster("INSURANCE")) {
        const companyId = this.currentUser.masterOf
            .filter((companies) => companies.type === "INSURANCE")[0].id;
        this.$store
        .dispatch("relays/getAll", {
            query: {
                search: this.searchRelays,
                type: "LONG_TERM",
                reservedForCompanyId: companyId,
                itemsPerPage: 10,
            },
        })
        .then((res) => {
            this.relays = res?.relays || [];
            this.relays.forEach((relay) => {
                relay.totalReservedLocations = 0;
                relay.totalAvailableReservedLocations = 0;
                relay.Boxes?.forEach((box) => {
                    box.Locations?.forEach((location) => {
                        relay.totalReservedLocations++;
                        if (this.isAvailable(location)) {
                            relay.totalAvailableReservedLocations++;
                        }
                    });
                });
            });
            if (this.relays?.length === 1) {
                this.relayId = this.relays[0].id;
            }
        });
    } else {
        this.$store
        .dispatch("relays/getAll", {
            query: {
                search: this.searchRelays,
                type: "AGENCY",
                available: true,
                itemsPerPage: 10,
            },
        })
        .then((res) => {
            this.relays = res?.relays || [];
            this.relays.forEach((relay) => {
                relay.totalAvailableReservedLocations = 0;
                relay.Boxes?.forEach((box) => {
                    box.Locations?.forEach((location) => {
                        if (this.isAvailable(location)) {
                            relay.totalAvailableReservedLocations++;
                        }
                    });
                });
            });
            if (this.relays?.length === 1) {
                this.relayId = this.relays[0].id;
            }
        });
    }
  }

  private parseFile() {
    if (this.csvFile) {
      this.importing = true;
      const formData = new FormData();
      formData.append("file", this.csvFile);
      this.$store
        .dispatch("files/parseImportFile", {
          type: this.parsingType,
          formData,
        })
        .then((data) =>
          this.$router.push({
            name: `import-${this.parsingType}-preview`,
            params: {
              items: data.items,
              importType: this.type,
              relayId: this.relayId,
            },
          }),
        )
      .catch((err) => {
          this.importing = false;
          this.$store.commit("alerts/displayError", {
              msg: this.$i18n?.t("alerts.error.default"),
          });
      });
    }
  }
}
</script>
