<template>
    <v-dialog
        max-width="500px"
        v-if="stats"
        v-model="dialog"
        persistent
    >
        <v-card>
            <v-card-title>
                <span class="headline">{{$t('import.results')}}</span>
            </v-card-title>
            <v-card-text>
                <v-container>
                    <v-row justify="center">
                        {{$t(`import.${type}.total`, {count: stats.count})}}
                    </v-row>
                    <v-row class="mt-5" justify="center">
                        <v-tooltip bottom>
                            <template v-slot:activator="{ on }">
                                <v-icon
                                    :color="stats.inserted > 0 ? 'green' : 'default'"
                                    v-on="on"
                                >
                                    {{addIcon()}}
                                </v-icon>
                            </template>
                            <span>{{$t(`import.${type}.inserted`)}}</span>
                        </v-tooltip>
                        {{stats.inserted}}
                        <v-tooltip bottom>
                            <template v-slot:activator="{ on }">
                                <v-icon
                                    v-if="type === 'users'"
                                    :color="stats.updated > 0 ? 'blue' : 'default'"
                                    class="ml-5"
                                    v-on="on"
                                >
                                    autorenew
                                </v-icon>
                            </template>
                            <span>{{$t(`import.${type}.updated`)}}</span>
                        </v-tooltip>
                        {{stats.updated}}
                        <v-tooltip bottom>
                            <template v-slot:activator="{ on }">
                                <v-icon
                                    v-if="type === 'users'"
                                    :color="stats.ignored > 0 ? 'orange' : 'default'"
                                    class="ml-5"
                                    v-on="on"
                                >
                                    not_interested
                                </v-icon>
                            </template>
                            <span>{{$t(`import.${type}.ignored`)}}</span>
                        </v-tooltip>
                        {{stats.ignored}}
                        <v-tooltip bottom>
                            <template v-slot:activator="{ on }">
                                <v-icon
                                    :color="stats.error > 0 ? 'red' : 'default'"
                                    class="ml-5"
                                    v-on="on"
                                >
                                    error
                                </v-icon>
                            </template>
                            <span>{{$t('import.error')}}</span>
                        </v-tooltip>
                        {{stats.error}}
                    </v-row>
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    @click="$emit('close')"
                    color="white"
                    text>
                    {{$t('actions.close')}}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>
<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";

@Component
export default class ImportResults extends Vue {
    @Prop({default: false})
    public dialog: boolean;

    @Prop({default: null})
    public type: string;

    @Prop({default: null})
    public stats: any;

    private addIcon() {
        switch (this.type) {
            case "users": return "person_add";
            case "keys": return "add_circle";
            default: return "add_circle";
        }
    }
}
</script>
