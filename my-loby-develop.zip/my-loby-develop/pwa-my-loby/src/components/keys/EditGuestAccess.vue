<template>
    <div>
        <v-dialog max-width="910px" v-model="editGuestDialog" persistent>
            <v-card>
                <v-card-title>
                    <span class="headline">{{$t('keysList.editGuest')}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-row>
                            <v-list-item-avatar>
                                <img :src="guest && guest.profilePicture ? guest.profilePicture : defaultUserAvatar"
                                     alt="">
                            </v-list-item-avatar>
                            <v-list-item-content>
                                <v-list-item-title v-html="guest.name || guest.Users[0].displayName">
                                </v-list-item-title>
                                <v-list-item-subtitle v-html="guest.company"></v-list-item-subtitle>
                            </v-list-item-content>
                        </v-row>
                        <guest-invitation-options :edit="true" :invitation="guest.connectedUserInvitation">
                        </guest-invitation-options>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn @click="$emit('close')"
                           color="white"
                           text
                    >
                        {{$t('actions.close')}}
                    </v-btn>
                    <v-btn v-if="!isHolderInGroup"
                           @click="removeGuest()"
                           color="error"
                    >
                        {{$t('actions.delete')}}
                    </v-btn>
                    <v-btn @click="editGuestAccess()"
                           color="warning"
                    >
                        {{$t('actions.save')}}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <v-dialog max-width="910px" v-model="deleteGroupConfirmationDialog" persistent>
            <v-card>
                <v-card-title>
                    <span class="headline">{{$t('keysList.deleteGuest')}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <span>{{$t('keysList.deleteGuestFromGroupConfirm', {keyGroup: guest.invitations[0].keyAccess.keyGroup.name})}}</span>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn @click="deleteConfirmationDialog = false" color="white" text>
                        {{ $t("actions.cancel") }}
                    </v-btn>
                    <v-btn
                        color="warning"
                        @click="removeGuestAccess"
                    >
                        {{ $t("actions.confirm") }}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <v-dialog max-width="910px" v-model="deleteConfirmationDialog" persistent>
            <v-card>
                <v-card-title>
                    <span class="headline">{{$t('keysList.deleteGuest')}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                       <span>{{$t('keysList.deleteGuestConfirm', {guestName: guest.displayName})}}</span>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn @click="deleteConfirmationDialog = false" color="white" text>
                        {{ $t("actions.cancel") }}
                    </v-btn>
                    <v-btn
                        color="warning"
                        @click="removeGuestAccess"
                    >
                        {{ $t("actions.confirm") }}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import {defaultUserAvatar, defaultKeyPicture} from "@/utils/constants";
import GuestInvitationOptions from "@/components/keys/GuestInvitationOptions.vue";

@Component({
    components: {
        GuestInvitationOptions,
    },
})
export default class EditGuestAccess extends Vue {
    @Prop({})
    public editGuestDialog: any;

    @Prop({})
    public guest: any;

    @Prop({})
    public currentKey: any;

    private defaultUserAvatar: string = defaultUserAvatar;
    private defaultKeyPicture: string = defaultKeyPicture;
    private editDialog: boolean = true;
    private deleteConfirmationDialog: boolean = false;
    private deleteGroupConfirmationDialog: boolean = false;

    get isHolderInGroup(): boolean {
        return this.guest?.Users?.some((u) => this.currentKey?.holder?.id === u?.id);
    }

    private editGuestAccess() {
        if (!this.guest.connectedUserInvitation?.timeLimited) {
            this.guest.connectedUserInvitation.keyAccess.startDate = null;
            this.guest.connectedUserInvitation.keyAccess.endDate = null;
        } else {
            this.guest.connectedUserInvitation.keyAccess.startDate =
                this.guest.connectedUserInvitation.keyAccess.startDate.substr(0, 16);
            this.guest.connectedUserInvitation.keyAccess.endDate =
                this.guest.connectedUserInvitation.keyAccess.endDate.substr(0, 16);
        }
        this.$store.dispatch("keys/editGuestAccess", {
            key: this.currentKey,
            access: this.guest.connectedUserInvitation,
            keyGroup: {id: this.guest.keyGroupName ? this.guest.invitations[0].keyAccess.keyGroup.id : null},
        })
            .then(() => {
                this.$emit("reset");
            })
            .catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: this.$t(`alerts.error.${err?.response?.data?.error}`),
                });
            });
    }

    private removeGuestAccess() {
        this.deleteConfirmationDialog = false;
        this.$store.dispatch("keys/removeGuestAccess", {
            key: this.currentKey,
            access: this.guest.connectedUserInvitation,
        })
            .then(() => {
                this.$emit("reset");
            })
            .catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err,
                });
            });
    }

    private removeGuest() {
        if (this.guest.invitations[0].keyAccess.keyGroup.name) {
            this.deleteGroupConfirmationDialog = true;
        } else {
            this.deleteConfirmationDialog = true;
        }
        this.editGuestDialog = false;
    }
}
</script>
