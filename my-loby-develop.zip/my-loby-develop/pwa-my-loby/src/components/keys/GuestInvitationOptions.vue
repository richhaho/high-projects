<template>
    <v-row>
        <v-col cols="12" sm="6">
            <v-radio-group
                v-model="invitation.countLimited"
                hide-details
            >
                <v-radio
                    key="limited"
                    :label="$t('invitation.countLimited')"
                    :value="true"
                    color="orange"
                ></v-radio>
                <v-radio
                    key="unlimited"
                    :label="$t('invitation.countUnlimited')"
                    :value="false"
                    color="orange"
                ></v-radio>
            </v-radio-group>
            <v-checkbox
                color="orange"
                hide-details
                v-bind:label="$t('invitation.timeLimited')"
                v-model="invitation.timeLimited"
            ></v-checkbox>
            <v-row class="mt-10 mb-5" justify="center" v-if="invitation.timeLimited">
                <datetime
                    :phrases="wording"
                    class="date-input"
                    id="startDate"
                    type="datetime"
                    v-model="invitation.keyAccess.startDate"
                >
                    <label for="startDate" slot="before">
                        {{ $t("common.startDate") }} :
                    </label>
                </datetime>
                <v-icon v-if="!mobile">
                    arrow_right_alt
                </v-icon>
                <v-col v-else cols="12">
                    <v-row justify="center">
                        <v-icon
                        >
                            arrow_right_alt
                        </v-icon>
                    </v-row>
                </v-col>
                <datetime
                    :min-datetime="invitation.keyAccess.startDate"
                    :phrases="wording"
                    class="date-input"
                    id="endDate"
                    type="datetime"
                    v-model="invitation.keyAccess.endDate"
                >
                    <label for="endDate" slot="before">
                        {{ $t("common.endDate") }} :
                    </label>
                </datetime>
            </v-row>
        </v-col>
        <v-col v-if="!edit" cols="12" sm="6">
            <v-radio-group
                v-model="invitation.notificationType"
                hide-details
                mandatory
            >
                <v-radio
                    v-if="!blockMail"
                    key="email"
                    value="email"
                    color="orange"
                    :label="$t('invitation.mail')"
                />
                <v-radio
                    v-if="!blockPhone"
                    key="sms"
                    value="sms"
                    color="orange"
                    :label="$t('invitation.sms')"
                />
            </v-radio-group>
        </v-col>
    </v-row>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import {Datetime} from "vue-datetime";
import "vue-datetime/dist/vue-datetime.css";
import {regex} from "@/utils/formRules";

@Component({
    components: {
        Datetime,
    },
})
export default class GuestInvitationOptions extends Vue {
    @Prop({})
    public invitation: any;

    @Prop({})
    public newGuest: any;

    @Prop({})
    public newContact: any;

    @Prop({default: false})
    public edit: boolean;

    private wording: any = null;
    private blockMail: boolean = false;
    private blockPhone: boolean = false;

    @Watch("invitation.timeLimited")
    public handlerTimeLimited(newVal: boolean) {
        if (newVal && !this.invitation.keyAccess.endDate) {
            this.invitation.keyAccess.startDate = (new Date()).toISOString();
        }
    }

    @Watch("invitation.keyAccess.startDate")
    public handlerStartDate(newVal: any) {
        if (this.invitation.keyAccess.endDate && newVal > this.invitation.keyAccess.endDate) {
            this.invitation.keyAccess.endDate = newVal;
        }
    }

    @Watch("newGuest")
    public handlerNewGuest(newVal: any) {
        if (this.newGuest && newVal) {
            this.manageSendingMethode();
        }
    }

    @Watch("newContact", {deep: true})
    public handlerNewContact(newVal: any) {
        if (this.newContact && newVal) {
            this.manageSendingMethode();
        }
    }

    get mobile(): boolean {
        return window.screen.width < 576;
    }

    private mounted(): void {
       this.manageSendingMethode();
       this.wording = {
            ok: this.$i18n.t("actions.next"),
            cancel: this.$i18n.t("actions.cancel"),
        };
    }

    private manageSendingMethode(): void {
        // check if this is already a contact and hide email/phone if he doesn't have them
        if (this.newGuest?.Users) {
            this.blockPhone = !this.newGuest.Users[0].phone;
            this.blockMail = !regex.email.test(this.newGuest.Users[0].email);
        } else {
            // this part if it's a new inserted email or phone number
            // check if the user has a phone number => unblock sms option
            if (regex.validPhoneNumber.test(this.newContact?.phone || this.newGuest) ) {
                this.blockPhone = false;
            } else {
                this.blockPhone = true;
                this.invitation.notificationType = "email";
            }
            // check if the user has a mail address => unblock email option
            if (regex.email.test(this.newContact?.email || this.newGuest)) {
                this.blockMail = false;
            } else {
                this.blockMail = true;
                this.invitation.notificationType = "sms";
            }
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
    .date-input {
        max-width: 200px;
        padding: 8px 10px;
        font-size: 16px;
        border: solid 1px #ddd;
        color: #444;
    }
</style>
