<template>
    <v-dialog max-width="500px" :value="show" persistent>
        <v-card>
            <v-card-title>
                        <span
                            class="headline">
                            {{ $t('booking.keyIsBooked.title') }}
                        </span>
            </v-card-title>
            <v-card-text  class="mt-2">
                        <span>
                            {{ $t('booking.keyIsBooked.description') }}
                               <template v-if="currentBooker">
                                <custom-chip-link
                                    type="user"
                                    :id="currentBooker.id"
                                    :text="currentBooker.displayName"
                                />
                            </template>
                        </span>
            </v-card-text>
            <v-card-text>
                        <span>
                            {{ `${$t('booking.keyIsBooked.descriptionDate')} ${currentKeyBooking}` }}
                        </span>
            </v-card-text>
            <v-card-text v-if="currentKeyManagers.length > 0">
                        <span>
                            {{ `${$t('booking.keyIsBooked.contact')}` }}
                        </span>
                <custom-chip-link
                    class="mr-2"
                    v-for="(manager, index) in currentKeyManagers"
                    :key="index"
                    type="user"
                    :text="manager.displayName"
                    :id="manager.id"
                />
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    :to="route"
                    color="success"
                >
                    {{ $t('booking.actions.see') }}
                </v-btn>
                <v-btn @click="closeModal" color="white" text>{{ $t('actions.close') }}</v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import CustomChipLink from "@/components/CustomChipLink.vue";
import KeyStatus from "@/components/keys/KeyStatus.vue";
import {Getter} from "vuex-class";
import moment from "moment";

@Component({
    components: {
        KeyStatus,
        CustomChipLink,
    },
})
export default class KeysWithUsers extends Vue {

    @Prop()
    public currentKey: any;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: false})
    public show: boolean;

    @Getter private currentUser: any;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isAdmin: boolean;

    get currentKeyBooking(): string {
        if (!this.currentKey || !this.currentKey.currentBooking) {
            return "";
        }
        const startDate = this.currentKey.currentBooking.startDate;
        const endDate = this.currentKey.currentBooking.endDate;
        const parseStartDate = moment(startDate).format("DD-MM-YYYY HH:mm");
        const parseEndDate = moment(endDate).format("DD-MM-YYYY HH:mm");
        return parseStartDate + "  -  " + parseEndDate;
    }

    get currentBooker(): any {
        if (!this.currentKey || !this.currentKey.currentBooking) {
            return null;
        }
        return {
            displayName: this.currentKey.currentBooking?.User?.displayName ||
                this.currentKey.currentBooking?.User?.lastName,
            id: this.currentKey.currentBooking?.User?.id,
        };
    }

    get currentKeyManagers() {
        if (!this.currentKey || !this.currentKey.keyManagers) {
            return [];
        }
        return this.currentKey.keyManagers.map((manager) => ({
                ...manager,
                displayName: manager.Users.reduce((acc, u) => {
                    return acc + " " + u.displayName;
                }, ""),
            }),
        );
    }

    get route() {
        return {
            name: "planning",
            params: {
                key: this.currentKey,
                userId: this.currentBooker?.id,
            },
        };
    }

    private closeModal() {
        this.$emit("closeModal");
    }

}
</script>
