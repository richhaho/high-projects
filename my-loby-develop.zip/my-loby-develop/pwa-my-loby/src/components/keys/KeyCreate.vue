<template>
    <v-dialog max-width="910px"
              persistent
              v-model="showDialog"
              :fullscreen="isMobile"
              :hide-overlay="isMobile"
              :transition="isMobile ? 'dialog-bottom-transition' : ''">
        <v-card>
            <v-card-title>
                <div class="contain_picto">
                    <i class="icon-picto_cle-partagees"></i>
                </div>
                <span class="headline"
                      v-if="step === 0">{{ $tc('keysList.chooseRelay', true, {step: isB2B ? step : step + 1}) }}</span>
                <span class="headline"
                      v-if="step === 1">{{ $tc('keysList.keyInfo', true, {step: isB2B ? step : step + 1}) }}</span>
                <span class="headline"
                      v-if="step === 2">{{ $t('keysList.chooseSubscription', true, {step: isB2B ? step : step + 1}) }}</span>
                <span class="headline"
                      v-if="step === 3">{{ $t('keysList.paymentInfo', true, {step: isB2B ? step : step + 1}) }}</span>
            </v-card-title>
            <v-card-text class="py-0">
                <v-container v-if="step === 0 && (isMaster('INSURANCE') ? longTermRelays : flowRelays)">
                    <v-row>
                        <v-col cols="12 pa-0">
                            <v-autocomplete
                                :items="isMaster('INSURANCE') ? longTermRelays : flowRelays"
                                :search-input.sync="searchRelays[isMaster('INSURANCE') ? 'longTerm' : 'flow']"
                                append-icon
                                flat
                                hide-details
                                :no-data-text="$t('keysList.noRelayFound')"
                                prepend-inner-icon="near_me"
                                solo
                                no-filter
                                v-bind:label="$t('actions.search')"
                                v-model="newKey.mainRelay"
                            >
                                <template v-slot:selection="data">
                                    <v-list-item-content style="overflow: initial;">
                                        <v-list-item-title
                                            v-if="data.item.Company"
                                            v-html="data.item.name + ' - ' + data.item.Company.name"
                                        ></v-list-item-title>
                                        <v-list-item-title
                                            v-else
                                            v-html="data.item.name"
                                        ></v-list-item-title>
                                        <v-list-item-subtitle
                                            v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city"
                                        ></v-list-item-subtitle>
                                        <v-list-item-subtitle
                                            v-if="isMaster('INSURANCE') && data.item.totalReservedLocations"
                                            v-html="$tc('relay.reservedLocationsCount', data.item.totalReservedLocations)"
                                        ></v-list-item-subtitle>
                                        <v-list-item-subtitle
                                            v-if="isMaster('INSURANCE') && (data.item.totalReservedLocations || data.item.totalAvailableReservedLocations)"
                                            v-html="$tc('relay.availableLocationsCount', data.item.totalAvailableReservedLocations)"
                                        ></v-list-item-subtitle>
                                    </v-list-item-content>
                                </template>
                                <template v-slot:item="data">
                                    <v-list-item-content :aria-disabled="!data.item.available">
                                        <v-list-item-title
                                            v-if="data.item.Company"
                                            v-html="data.item.name + ' - ' + data.item.Company.name"
                                        ></v-list-item-title>
                                        <v-list-item-title
                                            v-else
                                            v-html="data.item.name"
                                        ></v-list-item-title>
                                        <v-list-item-subtitle
                                            v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city"
                                        ></v-list-item-subtitle>
                                        <v-list-item-subtitle
                                            v-if="isMaster('INSURANCE') && data.item.totalReservedLocations"
                                            v-html="$tc('relay.reservedLocationsCount', data.item.totalReservedLocations)"
                                        ></v-list-item-subtitle>
                                        <v-list-item-subtitle
                                            v-if="isMaster('INSURANCE') && (data.item.totalReservedLocations || data.item.totalAvailableReservedLocations)"
                                            v-html="$tc('relay.availableLocationsCount', data.item.totalAvailableReservedLocations)"
                                        ></v-list-item-subtitle>
                                    </v-list-item-content>
                                </template>
                            </v-autocomplete>
                        </v-col>
                    </v-row>
                </v-container>
                <v-container v-if="step === 1">
                    <v-row>
                        <v-col cols="2 pa-0">
                            <v-img
                                :src="uploadedImageSrc || defaultKeyPicture"
                                aspect-ratio="1"
                                max-height="80"
                                max-width="80"
                                style="border-radius: 50%;"
                            >
                                <template v-slot:placeholder>
                                    <v-row align="center" class="fill-height ma-0" justify="center">
                                        <v-progress-circular color="grey" indeterminate></v-progress-circular>
                                    </v-row>
                                </template>
                            </v-img>
                        </v-col>
                        <v-col cols="9 pa-0 pt-3">
                            <v-file-input
                                :label="$t('key.picture')"
                                :placeholder="$t('user.uploadImage')"
                                @change="fileChange"
                                accept="image/png, image/jpeg, image/bmp ,image/heif, image/heic"
                                prepend-icon="photo"
                                v-model="avatar"
                            ></v-file-input>
                        </v-col>
                    </v-row>
                    <v-row>
                        <v-text-field v-bind:label="$t('key.name')" v-model="newKey.name"></v-text-field>
                    </v-row>
                    <v-row>
                        <v-text-field v-bind:label="$t('key.description')" v-model="newKey.description"></v-text-field>
                    </v-row>
                    <v-row v-if="selectedRelay" class="mb-3">
                        <span v-if="isMaster('INSURANCE')" class="input-title">
                            {{ $t('key.relay') }}
                        </span>
                        <span v-else-if="isB2B" class="input-title">
                            {{ $t('keysList.chooseAgencyRelay') }}
                        </span>
                        <span v-else class="input-title">
                            {{ $t('keysList.chooseFlowRelay') }}
                        </span>
                        <v-list-item-title
                            v-if="selectedRelay.Company"
                            v-html="selectedRelay.name + ' - ' + selectedRelay.Company.name "
                        ></v-list-item-title>
                        <v-list-item-title
                            v-else
                            v-html="selectedRelay.name  "
                        ></v-list-item-title>
                        <v-list-item-subtitle
                            v-html="selectedRelay.address + ', ' + selectedRelay.zipCode + ', ' + selectedRelay.city"
                        ></v-list-item-subtitle>
                    </v-row>
                    <v-row v-else-if="isB2B && agencyRelays">
                        <span class="input-title">{{ $t('keysList.chooseAgencyRelay') }}</span>
                        <v-col cols="12 pa-0">
                            <v-autocomplete
                                :items="agencyRelays"
                                :search-input.sync="searchRelays.agency"
                                append-icon
                                flat
                                hide-details
                                :no-data-text="$t('keysList.noRelayFound')"
                                prepend-inner-icon="near_me"
                                solo
                                no-filter
                                v-bind:label="$t('actions.search')"
                                v-model="newKey.mainRelay"
                                @change="changeRelay"
                            >
                                <template v-slot:selection="data">
                                    <v-list-item-content style="overflow: initial;">
                                        <v-list-item-title
                                            v-if="data.item.Company"
                                            v-html="data.item.name + ' - ' + data.item.Company.name"
                                        ></v-list-item-title>
                                        <v-list-item-title
                                            v-else
                                            v-html="data.item.name"
                                        ></v-list-item-title>
                                        <v-list-item-subtitle
                                            v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city"
                                        ></v-list-item-subtitle>
                                    </v-list-item-content>
                                </template>
                                <template v-slot:item="data">
                                    <v-list-item-content :aria-disabled="!data.item.available">
                                        <v-list-item-title
                                            v-if="data.item.Company"
                                            v-html="data.item.name + ' - ' + data.item.Company.name"
                                        ></v-list-item-title>
                                        <v-list-item-title
                                            v-else
                                            v-html="data.item.name"
                                        ></v-list-item-title>
                                        <v-list-item-subtitle
                                            v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city"
                                        ></v-list-item-subtitle>
                                    </v-list-item-content>
                                </template>
                            </v-autocomplete>
                            <v-row justify="center">
                                <relay-closed
                                    v-if="newKey.mainRelay"
                                    :closures="newKey.mainRelay.exceptionalClosures"
                                    messagePath="key.relayClosedWarning"
                                ></relay-closed>
                            </v-row>
                        </v-col>
                    </v-row>
                    <key-managers-autocomplete
                        :currentKey.sync="newKey"
                        v-show="canManageUser && isMaster()"
                        ref="managers"
                    />
                    <key-guests-autocomplete
                        :currentKey.sync="newKey"
                        ref="guests"
                    />
                    <v-row>
                        <span class="input-title">Tags</span>
                        <v-col cols="12 pa-0">
                            <v-col cols="12 pa-0" v-if="newKey.tags && newKey.tags.length > 0">
                                <v-chip-group active-class="primary--text" column multiple>
                                    <v-chip
                                        :key="i"
                                        @click:close="remove(newKey.tags, tag)"
                                        :close="true"
                                        v-for="(tag, i) in newKey.tags"
                                    >{{ tag[lang] }}
                                    </v-chip>
                                </v-chip-group>
                            </v-col>
                            <v-autocomplete
                                :search-input.sync="searchTags"
                                v-model="newKey.tags"
                                :items="removeDuplicates(tags, newKey.tags)"
                                append-icon
                                chips
                                hide-no-data
                                no-filter
                                multiple
                                prepend-inner-icon="flag"
                                v-bind:label="$t('keysList.addTags')"
                            >
                                <template v-slot:selection="data"></template>
                                <template v-slot:item="data">
                                    <v-list-item-content>
                                        <v-list-item-title>{{ data.item[lang] }}</v-list-item-title>
                                    </v-list-item-content>
                                </template>
                            </v-autocomplete>
                        </v-col>
                    </v-row>

                    <v-row v-if="isB2B && canAssociateFlowRelay && flowRelays">
                        <span class="input-title">
                          {{$tc('key.flowRelays', newKeyFlowRelays.length)}}
                          ({{newKeyFlowRelays.length}})
                        </span>
                        <v-col cols="12 pa-0">
                            <v-autocomplete
                                :items="nonSelectedFlowRelays"
                                :search-input.sync="searchRelays.flow"
                                append-icon
                                flat
                                hide-details
                                no-filter
                                :no-data-text="$t('keysList.noRelayFound')"
                                multiple
                                prepend-inner-icon="add"
                                solo
                                v-bind:label="$t('keysList.addFlowRelay')"
                                v-model="newKey.Relays"
                            >
                                <template v-slot:selection="data"></template>
                                <template v-slot:item="data">
                                    <v-list-item-content :aria-disabled="!data.item.available">
                                        <v-list-item-title
                                            v-if="data.item.Company"
                                            v-html="data.item.name + ' - ' + data.item.Company.name"
                                        ></v-list-item-title>
                                        <v-list-item-title
                                            v-else
                                            v-html="data.item.name"
                                        ></v-list-item-title>
                                        <v-list-item-subtitle
                                            v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city"
                                        ></v-list-item-subtitle>
                                    </v-list-item-content>
                                </template>
                            </v-autocomplete>
                        </v-col>
                        <v-col cols="12 pa-0 pl-8" v-if="newKey.Relays && newKey.Relays.length > 0">
                            <v-chip-group active-class="primary--text" column multiple>
                                <v-chip
                                    :key="i"
                                    @click:close="remove(newKey.Relays, relay)"
                                    close
                                    v-for="(relay,i) in newKeyFlowRelays"
                                >{{ relay.name }}</v-chip>
                            </v-chip-group>
                        </v-col>
                    </v-row>
                </v-container>
                <v-container v-if="step === 2">
                    <v-row>
                        <v-col cols="12 pa-0">
                            <v-checkbox
                                v-model="newKey.subscription"
                                v-bind:label="$t('subscription.PUNCTUAL.title')"
                                color="orange"
                                value="PUNCTUAL"
                                hide-details
                            ></v-checkbox>
                            <p class="ml-8">{{ $t("subscription.PUNCTUAL.description") }}</p>
                            <v-checkbox
                                v-model="newKey.subscription"
                                v-bind:label="$t('subscription.STANDARD.title')"
                                color="orange"
                                value="STANDARD"
                                hide-details
                            ></v-checkbox>
                            <p class="ml-8">{{ $t("subscription.STANDARD.description") }}</p>
                            <v-checkbox
                                v-model="newKey.subscription"
                                v-bind:label="$t('subscription.PREMIUM.title')"
                                color="orange"
                                value="PREMIUM"
                                hide-details
                            ></v-checkbox>
                            <p class="ml-8">{{ $t("subscription.PREMIUM.description") }}</p>
                        </v-col>
                    </v-row>
                    <p class="subtitle-2">{{ $t("subscription.b2cDetails") }}</p>
                </v-container>
                <v-container v-if="step === 3">
                    <v-row>
                        <v-col cols="12 pa-0">
                            <payment
                                v-if="newKey.id"
                                :key-id="newKey.id"
                                :payment-method-id.sync="paymentMethodId"
                                :subscription.sync="newKey.subscription"
                                @close="close"
                            />
                        </v-col>
                    </v-row>
                </v-container>
            </v-card-text>

            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    @click="step === maxSteps && !currentUser.company ? cancelKeyCreation() : close()"
                    color="white"
                    text
                >
                    {{ $t('actions.cancel') }}
                </v-btn>
                <v-btn
                    v-if="!disabled"
                    :disabled="disabled"
                    :loading="loadingCreation"
                    @click="step < maxSteps ? step+=1 : createKey()"
                    color="warning"
                >
                    {{ $t(step < maxSteps ? 'actions.next' : 'actions.create') }}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import KeyManagersAutocomplete from "@/components/keys/KeyManagersAutocomplete.vue";
import KeyGuestsAutocomplete from "@/components/keys/KeyGuestsAutocomplete.vue";
import RelayClosed from "@/components/relays/RelayClosed.vue";
import {formRules} from "@/utils/formRules";
import {Getter} from "vuex-class";
import {defaultKeyPicture} from "@/utils/constants";
import {canUseManagers, canUseFlowRelays} from "plan-restrictions";
import {removeVuetifyFileInputBug} from "@/utils/misc";
import Payment from "@/views/front-office/Payment.vue";
import imageCompression from "browser-image-compression";
import heic2any from "heic2any";

@Component({
    components: {
        Payment,
        KeyManagersAutocomplete,
        KeyGuestsAutocomplete,
        RelayClosed,
    },
})
export default class KeyCreate extends Vue {
    @Prop({default: false})
    public show: boolean;

    @Prop({default: null})
    public selectedRelay: any;

    @Prop({default: false})
    public isMobile: boolean;

    @Getter private currentUser: any;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isB2B: boolean;

    private canUseManagers: (company: any) => boolean = canUseManagers;
    private canUseFlowRelays: (company: any) => boolean = canUseFlowRelays;
    private removeVuetifyFileInputBug: (document: any) => void = removeVuetifyFileInputBug;
    private rules: object = formRules;
    private defaultKeyPicture: string = defaultKeyPicture;
    private showDialog: boolean = false;
    private loadingCreation: boolean = false;
    private flowRelays: any[] = null;
    private agencyRelays: any[] = null;
    private longTermRelays: any[] = null;
    private searchRelays: any = {
        flow: null,
        agency: null,
        longTerm: null,
    };
    private step: number = 0;
    private newKey: any = {};
    private avatar: any = null;
    private uploadedImageSrc: any = null;
    private tags: any = [];
    private searchTags: string = null;
    private paymentMethodId: number = null;
    private heicFile: any = null;

    get lang() {
        return this.$root.$i18n.locale;
    }

    get disabled() {
        const keyRelay: any = this.newKey.mainRelay;
        switch (this.step) {
            case 0:
                return !keyRelay || (keyRelay.type === "LONG_TERM" && !keyRelay.totalAvailableReservedLocations);
            case 1:
                return !this.newKey.mainRelay || !this.newKey.name;
            case 2:
                return !this.newKey.subscription;
            case 3:
                return !this.paymentMethodId;
            default:
                return false;
        }
    }

    get maxSteps() {
        switch (this.currentUser?.company?.type) {
            case "B2B":
                return 1;
            case "INSURANCE":
                return 1;
            default:
                return 3;
        }
    }

    get canManageUser(): boolean {
        return this.canUseManagers(this.currentUser?.company);
    }

    get canAssociateFlowRelay(): boolean {
        return this.canUseFlowRelays(this.currentUser?.company);
    }

    get newKeyFlowRelays(): any[] {
        return this.newKey?.Relays?.filter((relay) => relay.type === "FLOW") || [];
    }

    get nonSelectedFlowRelays(): any[] {
        return this.flowRelays
            .filter((r: any) => this?.newKey?.Relays.every((selectedRelay: any) => selectedRelay.id !== r.id));
    }

    @Watch("showDialog")
    public handlerShowDialog(newVal, oldVal) {
        if (newVal === false) {
            this.$emit("update:show", false);
            this.initNewKey();
            this.step = this.isB2B || this.selectedRelay ? 1 : 0;
        } else {
            this.$emit("update:show", false);
        }
    }

    @Watch("show")
    public handlerShow(newVal, oldVal) {
        if (newVal === true) {
            this.showDialog = true;
        }
    }

    @Watch("searchRelays.flow", {immediate: true})
    public handlerSearchFlowRelays() {
        this.getFlowRelays();
    }

    @Watch("searchRelays.agency", {immediate: true})
    public handlerSearchAgencyRelays() {
        this.getAgencyRelays();
    }

    @Watch("searchRelays.longTerm", {immediate: true})
    public handlerSearchLongTermRelays() {
        this.getLongTermRelays();
    }

    @Watch("searchTags")
    public handlerSearchTags() {
        this.getTags();
    }

    @Watch("step")
    public handlerStep(newVal, oldVal): void {
        // Create key once the B2C user has selected a plan
        if (newVal === 3 && oldVal === 2) {
            this.createKey();
        }
    }

    @Watch("selectedRelay")
    public handlerSelectedRelay(newVal: any): void {
        if (newVal) {
            this.step = 1;
            this.newKey.mainRelay = this.selectedRelay;
        }
    }

    @Watch("newKey.presetGuests")
    public handlerPresetGuests(newVal, oldVal) {
        this.newKey.newGuests = [];
        if (newVal?.length > 0) {
            (this.$refs.guests as HTMLFormElement).getPresetUsers();
        }

    }

    @Watch("newKey.presetManagers")
    public handlerPresetManagers(newVal, oldVal) {
        this.newKey.keyManagers = [];
        if (this.$refs.managers && newVal?.length > 0) {
            (this.$refs.managers as HTMLFormElement).getPresetUsers();
        }

    }

    private mounted(): void {
        this.step = this.isB2B || this.selectedRelay ? 1 : 0;
        this.initNewKey();
        this.getTags();
    }

    private beforeUpdate(): void {
        this.removeVuetifyFileInputBug(document);
    }

    private initNewKey(): void {
        this.newKey = {
            id: null,
            name: "",
            description: "",
            mainRelay: null,
            /* TODO
            ownerId: this.currentUser.id,
            mainRelay: this.agencyRelays !== null
            && this.agencyRelays.length === 1 ?
            this.agencyRelays[0] : null,
             */
            ownerId: this.currentUser?.id,
            subscription: null,
            status: "",
            picture: false,
            Relays: [],
            keyManagers: [],
            newKeyManagers: [],
            guests: [],
            newGuests: [],
            presetGuests: [],
            presetManagers: [],
            tags: [],
            createdAt: "",
        };
        this.paymentMethodId = null;

    }

    private async fileChange(): Promise<void> {
        this.loadingCreation = true;
        this.heicFile = null;
        if (this.avatar) {
            if (this.avatar.type === "image/heif" || this.avatar.type === "image/heic" ) {
                const blob = this.avatar as Blob;
                this.heicFile = await heic2any({blob});
                const fr = new FileReader();
                fr.readAsDataURL(this.heicFile as Blob);
                fr.addEventListener("load", () => {
                    this.uploadedImageSrc = fr.result;
                });
            } else {
                const fr = new FileReader();
                fr.readAsDataURL(this.avatar);
                fr.addEventListener("load", () => {
                    this.uploadedImageSrc = fr.result;
                });
            }
        } else {
            this.uploadedImageSrc = null;
        }
        this.loadingCreation = false;
    }

    private changeRelay(): void {
        if (this.isB2B && !!this.newKey.mainRelay) {
            this.getPresetUsers();
        } else {
            this.newKey.presetGuests = [];
            this.newKey.presetManagers = [];
        }
    }

    private createKey(): void {
        this.loadingCreation = true;
        if (this.paymentMethodId) {
            this.$store.dispatch("payments/createOne", {
                subscriptionId: this.newKey.subscription,
                paymentMethodId: this.paymentMethodId,
            }).then((res) => {
                this.close();
                this.$store.commit("alerts/displaySuccess", {
                    icon: "icon-picto_cle-partagees",
                    msg: this.$i18n?.t("alerts.key.creationSuccess"),
                });
            }).catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err,
                });
                this.close();
            });

        } else {
            this.newKey.picturePath = !!this.avatar;
            if (this.newKey.newGuests?.length) {
                this.newKey.guests = this.newKey.guests.concat(
                    this.newKey.newGuests,
                );
            }
            if (this.newKey.mainRelay) {
                this.newKey.relayId = this.newKey.mainRelay.id;
            }
            this.newKey.Relays.push({id: this.newKey.mainRelay});
            this.newKey.tags = this.newKey.tags.map((t: any) => t?.id);
            this.newKey.Relays = this.newKey.Relays.map((t: any) => {
                return {id: t?.id};
            });
            this.$store.dispatch("keys/create", {key: this.newKey}).then(async (res) => {
                if (this.avatar) {
                    const options = {
                        maxSizeMB: 1,
                        useWebWorker: true,
                    };
                    let compressedFile: any = null;
                    if (!this.heicFile) {
                        compressedFile = await imageCompression(this.avatar, options);
                    }
                    const formData = new FormData();
                    formData.append("file", compressedFile ? compressedFile : this.heicFile);
                    formData.append("id", res.id);
                    formData.append("fileType", "key-picture");
                    await this.$store.dispatch("files/upload", {formData});
                }
                if (this.isB2B || res.status === "CREATED") {
                    this.$store.commit("alerts/displaySuccess", {
                        icon: "icon-picto_cle-partagees",
                        msg: this.$i18n?.t("alerts.key.creationSuccess"),
                    });
                    this.close();
                } else {
                    this.newKey = res;
                }
                this.loadingCreation = false;
            }).catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err,
                });
                this.close();
            });
        }
    }

    private getTags(): void {
        this.$store
            .dispatch("tags/getAll", {
                query: {
                    search: this.searchTags,
                    lang: this.lang,
                },
            })
            .then((res) => {
                this.tags = res.tags;
            });
    }

    private getFlowRelays(): void {
        this.$store.dispatch("relays/getAll", {
            query: {
                search: this.searchRelays?.flow,
                type: "FLOW",
                available: true,
                itemsPerPage: 10,
            },
        }).then((res) => {
            this.flowRelays = res?.relays;
        });
    }

    private getAgencyRelays(): void {
        if (this.currentUser?.company?.type === "B2B") {
            this.$store.dispatch("relays/getList", {
                query: {
                    search: this.searchRelays?.agency,
                    type: "AGENCY",
                    available: true,
                    itemsPerPage: 10,
                },
            }).then((res) => {
                this.agencyRelays = res?.relays;
                if (this.agencyRelays.length === 1) {
                    // TODO: this.newKey.mainRelay = this.agencyRelays[0];
                }
            });
        }
    }

    private getPresetUsers(): void {
        if (!!this.newKey.mainRelay) {
            this.$store.dispatch("relays/getPresetUsersById", {
                id: this.newKey.mainRelay.id,
            }).then((res) => {
                this.newKey.presetManagers = res.filter((m) => m.role === "MANAGER").map((t) => t?.Group);
                this.newKey.presetGuests = res.filter((m) => m.role === "GUEST").map((t) => t?.Group);
            });
        }
    }

    private getLongTermRelays(): void {
        if (this.isMaster("INSURANCE")) {
            const companyId = this.currentUser.masterOf
                .filter((companies) => companies.type === "INSURANCE")[0].id;
            this.$store.dispatch("relays/getAll", {
                query: {
                    search: this.searchRelays?.longTerm,
                    type: "LONG_TERM",
                    reservedForCompanyId: companyId,
                    itemsPerPage: 10,
                },
            }).then((res) => {
                this.longTermRelays = res?.relays || [];
                this.longTermRelays.forEach((relay) => {
                    relay.totalReservedLocations = 0;
                    relay.totalAvailableReservedLocations = 0;
                    relay.Boxes.forEach((box) => {
                        box.Locations.forEach((location) => {
                            relay.totalReservedLocations++;
                            if (this.isAvailable(location)) {
                                relay.totalAvailableReservedLocations++;
                            }
                        });
                    });
                });
                if (this.longTermRelays?.length === 1) {
                    this.newKey.mainRelay = this.longTermRelays[0];
                }
            });
        }
    }

    private isAvailable(location: any): boolean {
        if (location?.keyId) {
            return false;
        } // not occupied if location was never used
        if (!location?.KeyLocation?.length) {
            return true;
        } // not occupied if location was never used
        return !location?.KeyLocation?.map((kL) => kL.endDate).includes(null); // is location currently used
    }

    private jsonCopy = (item) => JSON.parse(JSON.stringify(item));

    private removeDuplicates(completeList, duplicates): any[] | null {
        if (!completeList || !duplicates) {
            return null;
        }
        return completeList.filter(
            (item: any) =>
                !duplicates.map((elem: any) => elem?.id)?.includes(item?.id),
        );
    }

    private remove(list, item): void {
        const pos = list.map((u) => u.id).indexOf(item.id);
        list.splice(pos, 1);
    }

    private close(): void {
        this.initNewKey();
        this.$emit("update-data");
        this.showDialog = false;
        this.loadingCreation = false;
        if (this.isMaster("INSURANCE")) {
            this.getLongTermRelays();
        }
        this.uploadedImageSrc = null;
      // this is useless and needs to stay commented .
      //  this.avatar = null;
    }

    private cancelKeyCreation(): void {
        this.$store.dispatch("keys/cancelCreation", {
            keyId: this.newKey.id,
        }).then((res) => {
            this.close();
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
            this.close();
        });
    }
}
</script>
