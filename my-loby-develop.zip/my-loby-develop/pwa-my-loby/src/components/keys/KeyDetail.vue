<template>
  <div v-if="currentKey">
    <section>
      <div class="bloc titre_bloc">
        <p>
          <img
            :src="getSrc(currentKey.picturePath) || defaultKeyPicture"
            alt="keyPicture"
            style="object-fit: cover; max-height: 40px; max-width: 40px; border-radius: 50%;"
          />
          <span class="key-title">
            <span class="strong">{{currentKey.name}}</span>
          </span>
        </p>
      </div>
    </section>
    <section v-show="currentKey.description || currentKey.Tags.length">
      <div class="bloc">
        <p v-if="currentKey.description" class="description">{{currentKey.description}}</p>
        <span v-if="currentKey.Tags.length">
          <v-chip label v-for="(tag, i ) in currentKey.Tags" :key="i">{{tag[lang]}}</v-chip>
        </span>
      </div>
    </section>
    <section>
      <div class="bloc key-details">
        <p>
          {{$t('key.status')}} :
          <span class="strong">{{$t('key.statusType.' + currentKey.status)}}</span>
        </p>
        <p v-if="currentKey.Subscription && currentKey.Subscription.length">
          {{$t('key.subscriptions.title')}} :
          <span class="strong">
              {{$t(`subscription.${currentKey.Subscription[0].Plan.name}.title`)}}
          </span>
        </p>
      </div>
    </section>
      <section class="warning-block">
          <div class="bloc" :class="{'warning-text': currentKey.status === 'LATE'}">
              <p class="with_picto">
                  <i :class="getStatusPicto(currentKey)"></i>
                  <key-status :current-key="currentKey"></key-status>
              </p>
          </div>
      </section>
      <last-logs
          :loading="loadingLogs"
          :logs="logs"
      />
  </div>
</template>
<script lang="ts">
import {Component, Prop, Vue, Watch} from "vue-property-decorator";
import LastLogs from "@/components/logs/LastLogs.vue";
import KeyStatus from "@/components/keys/KeyStatus.vue";
import {defaultKeyPicture} from "@/utils/constants";
import {getSrc} from "@/utils/misc";

@Component({
    components: {
        KeyStatus,
        LastLogs,
    },
})
export default class KeyDetail extends Vue {
  @Prop({default: []})
  public selectedKeys: object[];

  private currentKey: any = null;
  private loadingLogs: boolean = false;
  private logs: any = null;
  private defaultKeyPicture = defaultKeyPicture;
  private getSrc: (string) => string = getSrc;

  get lastKey() {
    const lastIndex = this.selectedKeys.length - 1;
    return this.selectedKeys[lastIndex];
  }

  get lang() {
    return this.$root.$i18n.locale;
  }

  @Watch("currentKey")
  public handlerCurrentKey(newVal) {
      if (newVal) {
          this.getLogs();
      }
  }

  @Watch("selectedKeys", { deep: true })
  public handlerSelectedKeys(newVal, oldVal) {
    if (newVal.length === 1) {
      this.currentKey = newVal[0];
    } else if (newVal.length < oldVal.length) {
      this.currentKey = this.lastKey;
    } else {
      let change: boolean = false;
      newVal.map((key, i) => {
        if (!oldVal.find((x) => x.id === key.id)) {
          change = true;
          this.currentKey = key;
        }
      });
    }
  }

  private showOneKey() {
    this.$router.push({ name: "key", params: { id: this.currentKey.id } });
  }

  private getLogs(): void {
      this.loadingLogs = true;
      this.$store.dispatch("logs/getLogs", {
          query: {
              currentPage: "keys",
              entityId: this.currentKey.id,
              entityType: "key",
          },
      }).then((res) => {
          this.logs = res;
          this.loadingLogs = false;
      });
  }

  private getStatusPicto(key: any) {
      switch (key.status) {
          case "CREATED": return "icon-picto_cle-partagees";
          case "WITH_SOMEBODY": return "icon-picto_cle-partagees";
          case "IN_RELAY": {
              if (key?.currentLocation?.Box?.Relay?.type === "AGENCY") {
                  return "icon-picto_relais-agence";
              } else {
                  return "icon-picto_loby";
              }
          }
          case "LATE": return "icon-picto_attention";
          case "IN_TRANSIT": return "icon-picto_courrier";
          default: return "icon-picto_cle-partagees";
      }
  }
}
</script>
<style lang="scss">
    .warning-block {
        margin-bottom: 0;
    }

    .warning {
        background: #ffffff !important;
    }
</style>