<template>
    <div class="group-detail">
        <section>
            <div class="bloc titre_bloc">
                <p style="padding-left: 55px!important;">
                    <i class="icon-picto_dossier"></i>
                    <span class="strong">{{selectedGroup.name}}</span>
                </p>
            </div>
        </section>
        <section>
            <div class="bloc liste_avec_picto">
                <p style="margin-bottom: 15px!important;" :style="item.picturePath ? 'padding-left: 0' : ''"
                   v-for="item in selectedGroup.Keys" :key="item.id">
                    <img :src="getSrc(item.picturePath) " alt="" class="key_picture" v-if="item.picturePath">
                    <i class="icon-picto_cle-partagees" v-else></i>
                    <a
                        @click.prevent="$router.push({ name: 'key', params: { id: item.id } })"
                        :class="['strong',!item.picturePath ? 'pl-3': '']"
                    >
                        {{item.name}}
                    </a>
                </p>
            </div>
        </section>
        <section v-if="selectedGroup.description">
            <div class="bloc">
                <p>
                    {{selectedGroup.description}}
                </p>
            </div>
        </section>
        <section>
        <div class="bloc contact_bloc d-block pt-2" v-if="keysManagers.length">
            <p class="mb-1"><strong>{{$tc('key.keyManagers',2)}}</strong></p>
            <div class="d-flex justify-space-between">
                <user-list-avatar :users="keysManagers.slice(0,5)"/>
                <a href="#" class="more_contact" v-if="keysManagers.length > 5">+{{keysManagers.length - 5}}</a>
            </div>
        </div>
        </section>
        <section>
            <div class="bloc contact_bloc d-block pt-2" v-if="guests.length">
                <p class="mb-1"><strong>{{$tc('key.guests',2)}}</strong></p>
                <div class="d-flex justify-space-between">
                    <user-list-avatar :users="guests.slice(0,5)"/>
                    <a href="#" class="more_contact" v-if="guests.length > 5">+{{guests.length - 5}}</a>
                </div>
            </div>
        </section>
        <last-logs
            :loading="loadingLogs"
            :logs="logs"
        />
    </div>
</template>
<script lang="ts">
import {Component, Prop, Vue, Watch} from "vue-property-decorator";
import LastLogs from "../logs/LastLogs.vue";
import UserListAvatar from "@/components/users/UserListAvatar.vue";
import {getSrc} from "@/utils/misc";

@Component({
    components: {
        LastLogs,
        UserListAvatar,
    },
})
export default class KeyGroupDetail extends Vue {
    @Prop({default: {}})
    public selectedGroup: any;

    private getSrc: (string) => string = getSrc;
    private loadingLogs: boolean = false;
    private logs: any = {};

    @Watch("selectedGroup", { immediate: true })
    public handlerSelectedGroup(newVal) {
        if (newVal) {
            this.getLogs();
        }
    }

    get keysManagers() {
        const users = [];
        this.selectedGroup.keyManagers.forEach((keyManager) => {
           keyManager.Users.forEach((user) => users.push(user));
        });
        return users;
    }
    get guests() {
        const users = [];
        this.selectedGroup.guests.forEach((guest) => {
            guest.Users.forEach((user) => users.push(user));
        });
        return users;
    }

    private getLogs(): void {
        this.loadingLogs = true;
        this.$store.dispatch("logs/getLogs", {
            query: {
                currentPage: "keyGroups",
                entityId: this.selectedGroup.id,
                entityType: "keyGroup",
            },
        }).then((res) => {
            this.logs = res;
            this.loadingLogs = false;
        });
    }
}
</script>