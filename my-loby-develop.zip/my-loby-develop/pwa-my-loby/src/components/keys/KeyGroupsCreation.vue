<template>
    <v-dialog
        max-width="910px"
        persistent
        v-model="displayCreateKeyGroupDialog">
        <v-card>
            <v-card-title>
                <div class="contain_picto">
                    <i class="icon-picto_cle-partagees"></i>
                </div>
                <span class="headline">{{$t("keyGroup.creation.title")}}</span>
            </v-card-title>
            <v-card-text>
                <v-container>
                    <v-row justify="center">
                        <v-col>
                            <v-row>
                                <v-text-field
                                    v-bind:label="$t('keyGroup.name')"
                                    v-model="keyGroupCreation.name"
                                ></v-text-field>
                            </v-row>
                            <v-row>
                                <v-text-field
                                    v-bind:label="
                                        $t('keyGroup.description')
                                    "
                                    v-model="keyGroupCreation.description"
                                ></v-text-field>
                            </v-row>
                            <v-row>
                               <span class="input-title">
                                    {{ $t("keyGroup.keysList") }}
                               </span>
                            </v-row>
                            <v-row>
                                <v-list-item
                                    two-line
                                    v-for="selectedKey in selectedKeys"
                                    v-bind:key="selectedKey.name"
                                >
                                    <v-list-item-content>
                                        <v-list-item-title>
                                            {{selectedKey.name}}
                                        </v-list-item-title>
                                        <v-list-item-subtitle>
                                            {{selectedKey.description}}
                                        </v-list-item-subtitle>
                                    </v-list-item-content>
                                </v-list-item>
                            </v-row>
                            <v-row v-if="selectKeyInput">
                                <v-col cols="12 pa-0 pb-3">
                                    <v-autocomplete
                                        :items="keys"
                                        :loading="isSearchingKeys"
                                        :search-input.sync="keySearch"
                                        hide-details
                                        hide-selected
                                        hide-no-data
                                        :label="$t('keysList.keys')"
                                        :no-data-text="$t('keysList.noKeyFound')"
                                        append-icon
                                        prepend-inner-icon="add"
                                        chips
                                        deletable-chips
                                        multiple
                                        v-model="selectedKeyGroup"
                                    ></v-autocomplete>
                                </v-col>
                            </v-row>
                            <v-row v-if="tooMuchUsers" class="pt-4">
                                <v-alert
                                    border="left"
                                    class="ma-0 mb-4"
                                    color="error"
                                    dense
                                    text
                                >
                                    <caption class="pa-0" style="width: 800px;">{{ $t("keyGroup.tooMuchUsers") }}</caption>
                                </v-alert>
                            </v-row>
                            <key-managers-autocomplete
                                :currentKey="keyGroupCreation"
                                :maxKeyGroupUsersNbr="maxKeyGroupUsersNbr"
                                v-if="canManageUser && isMaster()"
                            />
                            <key-guests-autocomplete
                                :currentKey="keyGroupCreation"
                                :maxKeyGroupUsersNbr="maxKeyGroupUsersNbr"
                            />
                        </v-col>
                    </v-row>
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn @click="close" color="white" text>
                    {{ $t("actions.cancel") }}
                </v-btn>
                <v-btn
                    color="warning"
                    v-if="keyGroupCreation.name && !tooMuchUsers"
                    :disabled="!keyGroupCreation.name || tooMuchUsers"
                    @click="createKeyGroup"
                >
                    {{ $t("actions.create") }}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from "vue-property-decorator";
import KeyManagersAutocomplete from "@/components/keys/KeyManagersAutocomplete.vue";
import KeyGuestsAutocomplete from "@/components/keys/KeyGuestsAutocomplete.vue";
import {Getter} from "vuex-class";
import {canUseManagers, canAddMoreUserToKey} from "plan-restrictions";

@Component({
  components: {
      KeyManagersAutocomplete,
      KeyGuestsAutocomplete,
  },
})
export default class KeyGroupCreation extends Vue {
    @Prop({ default: [] })
    public selectedKeys: [];

    @Prop({})
    public reRender: () => void;

    @Prop({})
    public close: () => void;

    @Prop({ default: false })
    public displayCreateKeyGroupDialog: boolean;

    @Prop({})
    public createKeyGroupFn: (group: {}) => void;

    @Prop({ default: false })
    public selectKeyInput: boolean;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;

    private canUseManagers: (company: any) => boolean = canUseManagers;
    private canAddMoreUserToKey: (
        company: any,
        existingKeyUsersNbr: number,
        newKeyUsersNbr: number,
    ) => boolean = canAddMoreUserToKey;
    private keyGroupCreation: any = {};
    private keys = [];
    private selectedKeyGroup = [];
    private isSearchingKeys: boolean = false;
    private keySearch: string = null;
    private pagination: any = {
        sortDesc: [false],
        sortBy: [""],
        search: "",
        page: 1,
        itemsPerPage: 10,
        totalItems: 10,
    };

    @Watch("keySearch", { immediate: false})
    public keySearchHandler() {
        this.pagination.search = this.keySearch;
        this.getKeysList();
    }

    @Watch("displayCreateKeyGroupDialog", { immediate: false})
    public displayCreateKeyGroupDialogHandler(val: boolean) {
        if (val) {
            this.getKeysList();
        }
    }

    private mounted() {
        if (!this.selectKeyInput) {
            this.keys = this.selectedKeys;
        }
        this.keyGroupCreation = {
            keyManagers: [],
            newGuests: [],
        };
    }

    get canManageUser() {
        return this.canUseManagers(this.currentUser?.company);
    }

    // To get number of users and not number of accesses
    private usersNbrInGroup: (accesses: any[]) => number = (accesses: any[]) =>
        accesses?.reduce((a, c) => a + c?.Users?.length || 1, 0) || 0

    get maxKeyGroupUsersNbr() {
        // Get the number of users on the key with the greatest number of users in the group
        return Math.max(...this.selectedKeyGroup
            .map((key) => this.usersNbrInGroup(key?.keyManagers) + this.usersNbrInGroup(key?.guests)),
        );
    }

    get tooMuchUsers(): boolean {
        // return true if there are more users than authorized
        return !this.canAddMoreUserToKey(
            this.currentUser?.company,
            this.usersNbrInGroup(this.keyGroupCreation?.keyManagers)
              + this.usersNbrInGroup(this.keyGroupCreation?.guests)
              + this.maxKeyGroupUsersNbr,
            this.usersNbrInGroup(this.keyGroupCreation?.newKeyManagers)
              + this.usersNbrInGroup(this.keyGroupCreation?.newGuests),
        );
    }

    private getKeysList() {
        this.isSearchingKeys = true;
        return this.$store.dispatch("users/getMyKeys", {
            id: this.currentUser.id,
            query: this.pagination,
        }).then((res) => {
            this.isSearchingKeys = false;
            this.keys = res.keys.map((key: any) => {
                return { text: key.name, value: key, ...key };
            });
        });
    }

    private selectedKeyGroupFn(event) {
        this.selectedKeyGroup = event;
    }
    private createKeyGroup() {
        this.keyGroupCreation.userGroup = this.keyGroupCreation?.userGroup?.map((item) => item.id);
        this.keyGroupCreation.keyManagers = this.keyGroupCreation?.keyManagers?.map((item) =>
            JSON.parse(JSON.stringify(item)));
        if (!this.selectKeyInput) {
            this.createKeyGroupFn(this.keyGroupCreation);
        } else if (this.selectedKeyGroup.length) {
            this.$store.dispatch("keys/createGroup", {
                    keys: this.selectedKeyGroup,
                    keyGroupCreation: this.keyGroupCreation,
                })
                .then((res) => {
                    this.clearFields();
                    this.close();
                    this.reRender();
                })
                .catch((err) => {
                    this.$store.commit("alerts/displayError", {
                        msg: err,
                    });
                });
        }
    }

    private clearFields() {
        this.keys = [];
        this.keyGroupCreation = {
            keyManagers: [],
            newGuests: [],
            userGroup: [],
        };
        this.selectedKeyGroup = [];
        this.keySearch = null;
    }
}
</script>
