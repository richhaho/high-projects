<template>
    <v-dialog
        max-width="910px"
        v-model="displayEditKeyGroupDialog"
        persistent>
        <v-card>
            <v-card-title>
                <div class="contain_picto">
                    <i class="icon-picto_cle-partagees"></i>
                </div>
                <span class="headline">{{$t("keyGroup.edit.title")}}</span>
            </v-card-title>
            <v-card-text >
                <v-container v-if="group && selectedKeys">
                    <v-row justify="center">
                        <v-col>
                            <v-row>
                                <v-text-field
                                    v-bind:label="$t('keyGroup.name')"
                                    v-model="group.name"
                                ></v-text-field>
                            </v-row>
                            <v-row>
                                <v-text-field
                                    v-bind:label="
                                        $t('keyGroup.description')
                                    "
                                    v-model="group.description"
                                ></v-text-field>
                            </v-row>
                            <v-row>
                                <v-combobox
                                    :items="removeDuplicates(keys, selectedKeys)"
                                    :label="$t('keysList.keys')"
                                    multiple
                                    hide-selected
                                    chips
                                    hide-no-data
                                    deletable-chips
                                    v-model="selectedKeys"
                                ></v-combobox>
                            </v-row>
                            <v-row v-if="tooMuchUsers">
                                <v-alert
                                    border="left"
                                    class="ma-0 mb-4"
                                    color="error"
                                    dense
                                    text
                                >
                                    <caption class="pa-0" style="width: 800px;">{{ $t("keyGroup.tooMuchUsers") }}</caption>
                                </v-alert>
                            </v-row>
                            <key-managers-autocomplete
                                :currentKey="group"
                                v-if="canManageUser && isMaster()"
                                :maxKeyGroupUsersNbr="maxKeyGroupUsersNbr"
                                :edit="true"
                                :custom-remove="deleteManager"
                            />
                            <key-guests-autocomplete
                                :currentKey="group"
                                :maxKeyGroupUsersNbr="maxKeyGroupUsersNbr"
                                :edit="true"
                                :custom-remove="deleteGuest"
                            />
                        </v-col>
                    </v-row>
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn @click="closeEdit" color="white" text>
                    {{$t("actions.close")}}
                </v-btn>
                <v-btn
                    color="warning"
                    :disabled="!group.name || tooMuchUsers"
                    @click="updateKeyGroup"
                >
                    {{$t("actions.save")}}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from "vue-property-decorator";
import KeyManagersAutocomplete from "@/components/keys/KeyManagersAutocomplete.vue";
import KeyGuestsAutocomplete from "@/components/keys/KeyGuestsAutocomplete.vue";
import {Getter} from "vuex-class";
import {canUseManagers, canAddMoreUserToKey} from "plan-restrictions";

@Component({
  components: {
      KeyManagersAutocomplete,
      KeyGuestsAutocomplete,
  },
})
export default class KeyGroupEdit extends Vue {
    @Prop({})
    public group: {
        id: number,
        Keys: any[],
        keyManagers: any[],
        newKeyManagers: any[],
        guests: any[],
        newGuests: any[],
        deletedGuests: any[],
        deletedManagers: any[],
    };

    @Prop({})
    public reRender: () => void;

    @Prop({})
    public close: () => void;

    @Prop({ default: false })
    public displayEditKeyGroupDialog: boolean;
    @Getter private isMaster: (type?: string) => boolean;

    private selectedKeys: any[] = [];
    private keys = [];
    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;
    private canUseManagers: (company: any) => boolean = canUseManagers;
    private canAddMoreUserToKey: (
        company: any,
        existingKeyUsersNbr: number,
        newKeyUsersNbr: number,
    ) => boolean = canAddMoreUserToKey;

    private mounted() {
        this.selectedKeys = this.selectableKeys(this.group.Keys);
        return this.$store.dispatch("users/getMyKeys", {
            id: this.currentUser.id,
        }).then((res) => {
            this.keys = this.selectableKeys(res.keys);
        });
    }

    @Watch("group", { deep: true })
    private handlerGroupKeysList() {
        this.selectedKeys = this.selectableKeys(this.group.Keys);
    }

    get canManageUser() {
        return this.canUseManagers(this.currentUser?.company);
    }

    // To get number of users and not number of accesses
    private usersNbrInGroup: (accesses: any[]) => number = (accesses: any[]) =>
        accesses?.reduce((a, c) => a + c?.Users?.length || 1, 0) || 0

    get maxKeyGroupUsersNbr() {
        // Get the number of users on the key with the greatest number of users in the group
        return Math.max(...this.selectedKeys
            .map((key) => this.usersNbrInGroup(key?.keyManagers) + this.usersNbrInGroup(key?.guests)),
        );
    }

    get tooMuchUsers(): boolean {
        // return true if there are more users than authorized
        return !this.canAddMoreUserToKey(
            this.currentUser?.company,
            this.usersNbrInGroup(this.group?.keyManagers)
              + this.usersNbrInGroup(this.group?.guests)
              + this.maxKeyGroupUsersNbr,
            this.usersNbrInGroup(this.group?.newKeyManagers) + this.usersNbrInGroup(this.group?.newGuests),
        );
    }

    private selectableKeys(keys: any[]) {
        return keys?.map((key: any) => ({ text: key.name, value: key, ...key }));
    }
    private updateKeyGroup() {
        this.close();
        if (this.group.newKeyManagers?.length) {
            this.group.keyManagers = this.group.keyManagers.concat(this.group.newKeyManagers);
        }
        if (this.group.newGuests?.length) {
            this.group.guests = this.group.guests.concat(this.group.newGuests);
        }
        return this.$store.dispatch("keys/updateKeyGroup", {
            group: this.group,
            keys: this.selectedKeys,
         })
            .then(() => {
                this.selectedKeys = null;
                this.reRender();
            })
            .catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err,
                });
            });
    }

    private deleteManager(item) {
        item.invitations.forEach((i) => this.group.deletedManagers.push(i.id));
    }

    private deleteGuest(item) {
        item.invitations.forEach((i) => this.group.deletedGuests.push(i.id));
    }

    private removeDuplicates(completeList, duplicates) {
        return completeList.filter((item: any) =>
            !duplicates.map((elem: any) => elem?.id)?.includes(item?.id));
    }

    private closeEdit() {
        this.selectedKeys = null;
        this.close();
    }

    private getGroupKeysList() {
        this.selectedKeys = this.selectableKeys(this.group.Keys);
    }
}
</script>
