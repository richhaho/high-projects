<template>
    <div>
        <v-tooltip top>
            <template v-slot:activator="{ on }">
                <v-btn
                    icon
                    v-on="on"
                    @click="open()"
                >
                    <v-icon
                        small
                    >
                        refresh
                    </v-icon>
                </v-btn>
            </template>
            <span>{{$t('key.guest.reminder.button')}}</span>
        </v-tooltip>
        <v-dialog max-width="500px" v-model="modal" persistent>
            <v-card>
                <v-card-title style="word-break: normal;">
                    <span class="headline">{{ $t('key.guest.reminder.title') }}</span>
                </v-card-title>
                <v-card-text class="py-4">
                    <v-container class="pa-0">
                        <p
                            v-if="!loading && (!users || !users.length)"
                            class="mb-1"
                        >
                            {{ $t(`key.guest.reminder.noUser`) }}
                        </p>
                        <p
                            v-if="users.length > 1"
                            class="mb-4"
                        >
                            {{ $t(`key.guest.reminder.select`) }}
                        </p>
                        <v-autocomplete
                            v-if="users && (users.length >= 1 || loading)"
                            :item-text="itemStringified"
                            :item-value="itemParsed"
                            :items="users"
                            :loading="loading"
                            :disabled="users.length === 1"
                            append-icon
                            solo
                            hide-details
                            class="pb-4"
                            :no-data-text="$t('key.handToHand.noUserFound')"
                            v-bind:label="$t('key.handToHand.selectUser')"
                            v-model="selectedGuest"
                        >
                            <template v-slot:selection="data">
                                <v-list-item-content style="overflow: initial !important;">
                                    <v-list-item-title
                                        v-html="data.item.displayName">
                                    </v-list-item-title>
                                    <v-list-item-subtitle
                                        v-html="data.item.company">
                                    </v-list-item-subtitle>
                                </v-list-item-content>
                            </template>
                            <template v-slot:item="data">
                                <v-list-item-content style="overflow: initial;">
                                    <v-list-item-title
                                        v-html="data.item.displayName">
                                    </v-list-item-title>
                                    <v-list-item-subtitle
                                        v-html="data.item.company">
                                    </v-list-item-subtitle>
                                </v-list-item-content>
                            </template>
                        </v-autocomplete>
                        <p
                            v-if="selectedGuest"
                            class="mb-1"
                        >
                            {{ $t(`key.guest.reminder.${defaultNotificationType || 'choice'}`) }}
                        </p>
                        <v-radio-group
                            v-if="allowMail && allowPhone"
                            v-model="notificationType"
                            hide-details
                            mandatory
                            class="my-4"
                        >
                            <v-radio
                                v-if="allowMail"
                                :label="$t('invitation.reminder.mail')"
                                key="email"
                                value="email"
                                color="orange"
                            ></v-radio>
                            <v-radio
                                v-if="allowPhone"
                                :label="$t('invitation.reminder.sms')"
                                key="sms"
                                value="sms"
                                color="orange"
                            ></v-radio>
                        </v-radio-group>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="close()"
                        color="white"
                        text
                    >
                        {{ $t("actions.cancel") }}
                    </v-btn>
                    <v-btn
                        v-if="selectedGuest && notificationType"
                        @click="send()"
                        :loading="loadingInvitationReminder"
                        color="warning"
                    >
                        {{ $t("actions.send") }}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <over-price-sms
            :dialog="acceptOverPrice"
            :loading="loadingInvitationReminder"
            @accept="send"
            @cancel="acceptOverPrice = false"
        ></over-price-sms>
    </div>
</template>

<script lang="ts">
import {Vue, Component, Prop, Watch} from "vue-property-decorator";
import OverPriceSms from "@/components/OverPriceSms.vue";

@Component({
    components: {
        OverPriceSms,
    },
})
export default class KeyGuestReminder extends Vue {
    @Prop({default: () => []})
    public users: any;

    @Prop({default: null})
    public keyId: number;

    @Prop({default: false})
    public loading: boolean;

    private modal: boolean = false;
    private loadingInvitationReminder: boolean = false;
    private notificationType: string = "email";
    private selectedGuest: any = null;
    private acceptOverPrice: boolean = false;

    get allowMail(): boolean {
        return !!this.selectedGuest?.email && !(this.selectedGuest?.email).startsWith("+");
    }

    get allowPhone(): boolean {
        return !!this.selectedGuest?.phone;
    }

    get defaultNotificationType(): string {
        if (this.allowMail && !this.allowPhone) {
            return "email";
        }
        if (!this.allowMail && this.allowPhone) {
            return "sms";
        }
        return null;
    }

    @Watch("selectedGuest", {immediate: true})
    public handlerSelectedGuest(): void {
        this.notificationType = this.defaultNotificationType || "email";
    }

    @Watch("users", {deep: true, immediate: true})
    public handlerUsers(): void {
        if (this.users?.length === 1) {
            this.selectedGuest = this.users[0];
        }
    }

    private mounted(): void {
        if (!this.users?.length) {
            this.$emit("get-users");
        }
    }

    private send(): void {
        this.loadingInvitationReminder = true;
        this.$store.dispatch("keys/invitationReminder", {
            keyId: this.keyId,
            guest: this.selectedGuest,
            notificationType: this.notificationType,
            acceptOverPrice: this.acceptOverPrice,
        }).then(() => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("actions.sent"),
            });
            this.close();
        }).catch((err) => {
            switch (err?.response?.data?.error) {
                case "smsLimitReached":
                    this.acceptOverPrice = true;
                    break;
                case "freemium":
                    this.$store.commit("alerts/displayError", {
                        msg: this.$i18n.t("invitation.freemium"),
                    });
                    break;
                default:
                    this.$store.commit("alerts/displayError", {
                        msg: this.$t(`alerts.error.${err?.response?.data?.error || "default"}`),
                    });
                    break;
            }
            this.loadingInvitationReminder = false;
        });
    }

    private open(): void {
        if (!this.users?.length) {
            this.$emit("get-key-users");
        }
        this.modal = true;
    }

    private close(): void {
        this.modal = false;
        this.acceptOverPrice = false;
        if (this.users?.length > 1) {
            this.selectedGuest = null;
        }
        this.loadingInvitationReminder = false;
    }

    private itemStringified: (object) => string = (item: object): string => JSON.stringify(item);

    private itemParsed: (object) => object = (item: object): object => JSON.parse(JSON.stringify(item));
}
</script>