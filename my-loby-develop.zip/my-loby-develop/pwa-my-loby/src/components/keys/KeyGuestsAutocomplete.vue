<template>
    <v-row>
        <span v-if="edit" class="input-title">
            {{ $tc("key.guests", currentKey.guests && currentKey.guests.length ? currentKey.guests.length : 0) }}
            ({{ currentKey.guests && currentKey.guests.length ? currentKey.guests.length : 0 }})
        </span>
        <span v-else class="input-title">
            {{ $tc("key.guests", currentKey.newGuests && currentKey.newGuests.length ? currentKey.newGuests.length : 0) }}
            ({{ currentKey.newGuests && currentKey.newGuests.length ? currentKey.newGuests.length : 0 }})
        </span>
        <v-col cols="12 pa-0" v-if="edit && currentKey.guests && currentKey.guests.length > 0">
            <group-list-avatar :groups="currentKey.guests" :custom-delete="removeOldGuest" :can-delete="canDelete" />
        </v-col>
        <v-col cols="12 pa-0 pt-3" v-if="currentKey.newGuests && currentKey.newGuests.length > 0">
            <span v-if="edit">
                {{ $tc("key.newGuests", currentKey.newGuests.length) }}
                ({{ currentKey.newGuests.length }})
            </span>
            <group-list-avatar :groups="currentKey.newGuests" :custom-delete="removeNewGuest" :can-delete="true"/>
            <v-avatar size="30" v-show="edit && currentKey.newGuests && currentKey.newGuests.length > MAX_GUESTS_DISPLAYED">
                <span class="subtitle-2">+ {{ currentKey.newGuests.length - MAX_GUESTS_DISPLAYED }}</span>
            </v-avatar>
        </v-col>
        <v-col cols="12 pa-0">
            <v-form
                v-model="valid"
            >
            <v-combobox
                :hint="disableMoreUsers ? $t('restrictions.maxUsersPerKey.text', {planName: planName, maxValue: maxUsersNbr}) : ''"
                :hide-details="!disableMoreUsers && valid"
                :persistent-hint="disableMoreUsers"
                :disabled="disableMoreUsers"
                :loading="loading"
                :items="contactsWithoutManagers"
                :no-data-text="$t('keysList.noUserFound')"
                :hide-no-data="disableMoreUsers"
                :rules="newGuestRules"
                :search-input.sync="search"
                append-icon
                no-filter
                flat
                hide-selected
                clearable
                prepend-inner-icon="add"
                solo
                class="ma-0"
                v-bind:label="$t('keysList.addGuest')"
                v-model="newGuest"
                @input="clearItems"
                @click:clear="getContactsGroups"
                @click="getContactsGroups"
            >
                <template v-slot:selection="data">
                    <v-list-item-avatar>
                        <img :src="getUserGroupPicture(data.item)" alt="">
                    </v-list-item-avatar>
                    <v-list-item-content style="overflow: initial;">
                        <v-list-item-title v-if="data.item.name || (data.item.Users && data.item.Users[0].displayName)">
                            {{ data.item.name || data.item.Users[0].displayName }}
                        </v-list-item-title>
                        <v-list-item-title v-else>
                            {{data.item}}
                        </v-list-item-title>
                        <v-list-item-subtitle
                            v-html="data.item.company"
                        ></v-list-item-subtitle>
                    </v-list-item-content>
                </template>
                <template v-slot:item="data">
                    <v-list-item-avatar>
                        <img :src="getUserGroupPicture(data.item)" alt="">
                    </v-list-item-avatar>
                    <v-list-item-content>
                        <v-list-item-title v-if="data.item.name || (data.item.Users && data.item.Users[0].displayName)">
                            {{ data.item.name || data.item.Users[0].displayName }}
                        </v-list-item-title>
                        <v-list-item-title v-else>
                            {{data.item}}
                        </v-list-item-title>
                        <v-list-item-subtitle
                          v-html="data.item.company"
                        ></v-list-item-subtitle>
                  </v-list-item-content>
                </template>
            </v-combobox>
            <v-row v-if="isB2B && isNewGuest">
                <v-col class="py-0">
                    <v-text-field
                        v-bind:label="$t('user.firstName')"
                        v-model="newContact.firstName"
                    />
                    <v-text-field
                        v-bind:label="$t('user.lastName')"
                        v-model="newContact.lastName"
                    />
                    <v-text-field
                        v-bind:label="$t('user.company')"
                        v-model="newContact.specificCompanyName"
                    />
                    <v-text-field
                        v-bind:label="$t('user.job')"
                        v-model="newContact.job"
                    />
                    <v-text-field
                        v-if="isNewGuestPhone"
                        :label="$t('user.email')"
                        :rules="[rules.email]"
                        v-model="newContact.email"
                    />
                    <v-text-field
                        v-if="isNewGuestEmail"
                        :label="$t('user.phone')"
                        :rules="[rules.phone]"
                        v-model="newContact.phone"
                    />
                </v-col>
            </v-row>
            </v-form>
            <guest-invitation-options
                v-if="newGuest"
                :newGuest="newGuest"
                :newContact="newContact"
                :invitation="invitation">
                ref="guestInvitationOptions"
            </guest-invitation-options>
            <v-row v-if="newGuest" justify="center" class="pt-5">
                <v-btn
                    @click="addGuest()"
                    :disabled="tooMuchUsers || wrongInvitation || !valid"
                    color="primary"
                >
                    {{ $t('actions.add') }}
                </v-btn>
            </v-row>
            <v-row v-if="tooMuchUsers">
                <v-col class="py-0">
                    {{ $t("restrictions.maxUsersPerKey.text", {planName: planName, maxValue: maxUsersNbr}) }}
                </v-col>
            </v-row>
            <v-row v-if="!newGuest">
                <v-col class="py-0">
                    {{ $t("rules.ifPhone") }}
                </v-col>
            </v-row>
        </v-col>
    </v-row>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import {defaultUserAvatar, defaultUserGroupAvatar, defaultKeyPicture} from "@/utils/constants";
import GroupListAvatar from "@/components/users/GroupListAvatar.vue";
import GuestInvitationOptions from "@/components/keys/GuestInvitationOptions.vue";
import {Getter} from "vuex-class";
import {canUseManagers, canAddMoreUserToKey} from "plan-restrictions";
import {TranslateResult} from "vue-i18n";
import Timeout = NodeJS.Timeout;
import {regex, formRules} from "@/utils/formRules";

export const DEBOUNCE_TIME_MILLI: number = 300;

@Component({
    components: {
        GroupListAvatar,
        GuestInvitationOptions,
    },
})
export default class KeyGuestsAutocomplete extends Vue {
    @Prop({})
    public currentKey: {
        guests: any[],
        newGuests: any[],
        keyManagers: any[],
        newKeyManagers: any[],
        presetGuests: any[],
    };

    // The number of users on the key with the greatest number of users in the group
    @Prop({default: 0})
    public maxKeyGroupUsersNbr?: number;

    @Prop({default: false})
    public edit?: boolean;

    @Prop({default: null})
    public customRemove?: (guest) => void;

    @Prop({default: null})
    public autocompleteInput?: any;

    @Getter private currentUser: any;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isAdmin: boolean;
    @Getter private isB2B: boolean;

    private MAX_GUESTS_DISPLAYED = 5;

    private rules: any = formRules;
    private defaultUserAvatar: string = defaultUserAvatar;
    private defaultUserGroupAvatar: string = defaultUserGroupAvatar;
    private defaultKeyPicture: string = defaultKeyPicture;
    private canUseManagers: (company: any) => boolean = canUseManagers;
    private canAddMoreUserToKey: (
        company: any,
        existingKeyUsersNbr: number,
        newKeyUsersNbr: number,
    ) => boolean = canAddMoreUserToKey;

    private contacts: any[] = [];
    private newGuest: any = null;
    private newContact: any = {};
    private valid: boolean = null;
    private invitation: any = null;
    private search: string = null;
    private canDelete: boolean = false;
    private timerId: Timeout = null;
    private loading: boolean = false;

    @Watch("search")
    public handlerSearch() {
        if (this.search || this.search === "") {
            // cancel pending call
            clearTimeout(this.timerId);
            // delay new call
            this.loading = true;
            this.timerId = setTimeout(() => {
                this.getContactsGroups();
            }, DEBOUNCE_TIME_MILLI);
        }
    }

    @Watch("autocompleteInput")
    public async handlerProp(newVal) {
        if (newVal) {
            this.newGuest = JSON.parse(JSON.stringify(this.autocompleteInput));
        }
    }

    @Watch("isAddButtonEnabled")
    public async handleIsAddButtonEnabled(newVal) {
        this.$emit("invitation-change", newVal);
    }

    get presetGuests(): any {
        return this.currentKey.presetGuests;
    }

    get planName(): TranslateResult {
        return this.$i18n.t(`plan.${this?.currentUser?.company?.currentSubscription?.Plan?.name}.name`);
    }

    get maxUsersNbr(): number {
        return this.currentUser?.company?.currentSubscription?.Plan?.details?.maxUsersPerKey || 1;
    }

    get wrongInvitation(): boolean {
        return this.invitation?.timeLimited
            && !(this.invitation.keyAccess.startDate && this.invitation.keyAccess.endDate);
    }

    get isAddButtonEnabled(): boolean {
        return this.newGuest && !this.tooMuchUsers && !this.wrongInvitation && this.valid;
    }

    get isNewGuest(): boolean {
        return typeof this.newGuest === "string";
    }

    get isNewGuestEmail(): boolean {
        return this.isNewGuest && regex.email.test(this.newGuest);
    }

    get isNewGuestPhone(): boolean {
        return this.isNewGuest && regex.validPhoneNumber.test(this.newGuest);
    }

    get newGuestRules(): any[] {
        return this.isNewGuest
            ? [this.rules.mainContact]
            : [];
    }

    private mounted() {
        this.getContactsGroups();
        if (this.customRemove) {
            this.canDelete = true;
        }
    }
    private created() {
        this.reset();
        if (this.autocompleteInput) {
            this.newGuest = Object.assign({}, JSON.parse(JSON.stringify(this.autocompleteInput)));
        }
    }
    private reset() {
        this.newGuest = null;
        this.newContact = {};
        this.invitation = {
            countLimited: true,
            timeLimited: false,
            notificationType: "email",
            keyAccess: {
                startDate: (new Date()).toISOString(),
            },
        };
    }

    private clearItems(): void {
        if (!!this.newGuest) {
            clearTimeout(this.timerId);
            this.loading = false;
            this.contacts = [];
        } else {
            this.getContactsGroups();
        }
    }

    // To get number of users and not number of accesses
    private usersNbrInGroup: (accesses: any[]) => number = (accesses: any[]) =>
        accesses?.reduce((a, c) => {
            // Count users in each group
            c?.Users?.forEach((user) => {
                if (a.every((userId) => userId !== user.id)) {
                    // Count each user only once
                    a.push(user.id);
                }
            });
            return a;
        }, [])?.length || 0

    get keyUsersNbr(): number {
        return this.maxKeyGroupUsersNbr
            || (this.usersNbrInGroup(this.currentKey?.keyManagers) + this.usersNbrInGroup(this.currentKey?.guests));
    }

    get keyUsersAtCreation() {
        return (this.currentUser?.companyId && !(this.isMaster || this.isAdmin)) ? 2 : 1;
    }

    get keyNewUsersNbr(): number {
        return this.usersNbrInGroup(this.currentKey?.newKeyManagers) + this.usersNbrInGroup(this.currentKey?.newGuests);
    }

    get disableMoreUsers(): boolean {
        // return true if there are exactly the maximum amount of users authorized
        return !this.canAddMoreUserToKey(
            this.currentUser?.company,
            this.keyUsersNbr + (!this.edit ? this.keyUsersAtCreation : 0),
            this.keyNewUsersNbr + 1, // +1 to prevent creator from selecting more users than authorized
        );
    }

    get tooMuchUsers(): boolean {
        // if the new invitation is for a group, get the number of users in the group
        const newUsersWantedNbr: number = this.newGuest?.Users?.length || 1;
        // return true if there are more users than authorized
        return !this.canAddMoreUserToKey(
            this.currentUser?.company,
            this.keyUsersNbr + (!this.edit ? this.keyUsersAtCreation : 0),
            this.keyNewUsersNbr + newUsersWantedNbr,
        );
    }

    get contactsWithoutManagers() {
        // Return only single users or 'guests' groups
        // And for single users check if the user isn't already in the managers of the key
        return this.contacts.filter((contactGroup) => contactGroup.type !== "subordinates",
/*
            && !this.currentKey?.keyManagers?.some((g) => g?.Users?.some((u) => u.id === contactGroup?.Users?.[0]?.id))
*/
            );
    }
    private getPresetUsers() {
       this.currentKey.newGuests = [];
       this.currentKey.presetGuests.forEach( (e) => {
            if (!this.currentKey.guests.find((nG) => nG.id === e.id)) {
                const newInvitation = {
                    countLimited: false,
                    timeLimited: false,
                    notificationType: "email",
                    keyAccess: {
                        startDate: null,
                        endDate: null,
                    },
                };
                this.currentKey.newGuests.push(
                    Object.assign({}, e, {
                        invitation: newInvitation,
                    }),
                );
            }
       });
    }

    private getContactsGroups() {
        const p: Array<Promise<any>> = [
            this.$store.dispatch("users/getContacts", {
                query: {
                    search: this.search,
                    groups: true,
                },
            }),
            this.$store.dispatch("users/getUserGroups", {
                userId: this.currentUser.id,
                query: {
                    search: this.search,
                    type: "contacts",
                },
            }),
        ];
        if (this.isMaster() && this.canUseManagers(this.currentUser?.company)) {
            p.push(
                this.$store.dispatch("users/getSubordinates", {
                    query: {
                        search: this.search,
                        groups: true,
                    },
                }),
                this.$store.dispatch("users/getUserGroups", {
                    userId: this.currentUser.id,
                    query: {
                        search: this.search,
                        type: "subordinates",
                    },
                }),
            );
        }
        Promise.all(p).then(([contacts, contactsGroups, subordinates, subordinatesGroups]) => {
            this.contacts = [
                ...contacts?.users || [],
                ...contactsGroups?.list || [],
                ...subordinates?.users || [],
                ...subordinatesGroups?.list || [],
            ].map((item: any) => ({...item}));
            this.loading = false;
        });
    }

    private addGuest(): void {
        if (this.isNewGuestEmail) {
            this.newContact.email = this.newGuest;
        }
        if (this.isNewGuestPhone) {
            this.newContact.phone = this.newGuest;
        }
        if (this.newGuest.Users) {
            if (regex.validPhoneNumber.test(this.newGuest.Users[0].email)) {
                this.newGuest = Object.assign({}, this.newGuest, {
                    phone: this.newGuest.Users[0].email,
                });
            }
        }
        if (!this.invitation?.timeLimited) {
            this.invitation.keyAccess.startDate = null;
            this.invitation.keyAccess.endDate = null;
        } else {
            this.invitation.keyAccess.startDate =
                this.invitation.keyAccess.startDate.substr(0, 16);
            this.invitation.keyAccess.endDate =
                this.invitation.keyAccess.endDate.substr(0, 16);
        }
        this.currentKey.newGuests.push(
            Object.assign({}, this.newGuest, {
                invitation: this.invitation,
                ...this.newContact,
            }),
        );
        this.reset();
        this.$emit("save", this.currentKey, {newGuests: true});
    }

    private getUserGroupPicture(group: any) {
        return !group?.creatorId
            ? (group?.Users?.[0]?.picturePath || this.defaultUserAvatar)
            : this.defaultUserGroupAvatar;
    }

    private removeGuest(list, item) {
        const pos = list.map((u) => u.id).indexOf(item.id);
        list.splice(pos, 1);
    }

    private removeNewGuest(item) {
        this.removeGuest(this.currentKey.newGuests, item);
    }

    private removeOldGuest(item) {
        if (this.customRemove) {
            this.removeGuest(this.currentKey.guests, item);
            this.customRemove(item);
        }
    }

}
</script>