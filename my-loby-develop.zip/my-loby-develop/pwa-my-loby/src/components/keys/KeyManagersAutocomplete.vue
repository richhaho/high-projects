<template>
    <v-row>
    <span class="input-title">
      {{ $tc('key.keyManagers', currentKey.keyManagers && currentKey.keyManagers.length ? currentKey.keyManagers.length : 0) }}
      ({{ currentKey.keyManagers && currentKey.keyManagers.length ? currentKey.keyManagers.length : 0 }})
    </span>
        <v-col cols="12 pa-0" v-if="currentKey.keyManagers && currentKey.keyManagers.length > 0">
            <v-row
                v-for="manager in currentKey.keyManagers.slice(0, MAX_MANAGERS_DISPLAYED)"
                :key="manager.id"
                align="center"
            >
                <v-col
                    v-if="manager.name || manager.Users[0]"
                    class="pa-0"
                >
                    <v-avatar class="ma-2" size="30">
                        <img :src="getUserGroupPicture(manager)" alt/>
                    </v-avatar>
                    {{ manager.name || manager.Users[0].displayName }}
                </v-col>
                <v-col class="pa-0" align="right">
                    {{ isOwnerInGroup(manager, currentKey) ? $t('key.owner') : $tc('key.keyManagers', 1) }}
                    <v-btn
                        v-if="!isOwnerInGroup(manager, currentKey) && !isHolderInGroup(manager, currentKey) && !disableDelete"
                        @click="remove(currentKey.keyManagers, manager)"
                        icon
                    >
                        <v-icon small>delete</v-icon>
                    </v-btn>
                </v-col>
            </v-row>
            <v-row
                justify="center"
                v-show="currentKey.keyManagers && currentKey.keyManagers.length > MAX_MANAGERS_DISPLAYED"
            >
                <v-btn @click="displayUsers(currentKey.keyManagers)" class="text-none" text>
                    {{
                        $t('keysList.displayXMore', {
                            count: currentKey.keyManagers.length -
                                MAX_MANAGERS_DISPLAYED
                        })
                    }}
                </v-btn>
            </v-row>
        </v-col>
        <v-col
            cols="12 pa-0"
            v-if="(isMaster() || isManager(currentUser,currentKey)) && currentKey.newKeyManagers && currentKey.newKeyManagers.length > 0"
        >
            {{ $tc('key.newKeyManagers', currentKey.keyManagers.length) }}
            ({{ currentKey.newKeyManagers.length }})
            <v-row
                v-for="manager in currentKey.newKeyManagers.slice(0, MAX_MANAGERS_DISPLAYED)"
                :key="manager.id"
                align="center"
            >
                <v-col
                    v-if="manager.name || manager.Users[0]"
                    class="pa-0"
                >
                    <v-avatar class="ma-2" size="30">
                        <img :src="getUserGroupPicture(manager)" alt/>
                    </v-avatar>
                    {{ manager.name || manager.Users[0].displayName }}
                </v-col>
                <v-col class="pa-0" align="right">
                    {{ manager.company }}
                    <v-btn @click="remove(currentKey.newKeyManagers, manager)" icon v-if="!disableDelete">
                        <v-icon small>delete</v-icon>
                    </v-btn>
                </v-col>
            </v-row>
            <v-row
                justify="center"
                v-show="currentKey.newKeyManagers && currentKey.newKeyManagers.length > MAX_MANAGERS_DISPLAYED"
            >
                <v-btn @click="displayUsers(currentKey.newKeyManagers)" class="text-none" text>
                    {{
                        $t('keysList.displayXMore', {
                            count: currentKey.newKeyManagers.length -
                                MAX_MANAGERS_DISPLAYED
                        })
                    }}
                </v-btn>
            </v-row>
        </v-col>
        <v-col cols="8 pa-0" v-if="isMaster() || isManager(currentUser,currentKey)">
            <v-autocomplete
                v-if="edit"
                :hint="$t('restrictions.maxUsersPerKey.text', {planName: planName, maxValue: maxUsersNbr})"
                :hide-details="!disableMoreUsers"
                :persistent-hint="disableMoreUsers"
                :disabled="disableMoreUsers"
                :items="subordinatesNotOnThisKey()"
                :no-data-text="$t('keysList.noUserFound')"
                :search-input.sync="search"
                :allow-overflow="false"
                append-icon
                no-filter
                flat
                class="ma-0"
                multiple
                prepend-inner-icon="add"
                solo
                v-bind:label="$t('key.addManagers')"
                v-model="currentKey.newKeyManagers"
            >
                <template v-slot:selection="data"></template>
                <template v-slot:item="data">
                    <template v-if="data.item">
                        <v-list-item-avatar>
                            <img :src="getUserGroupPicture(data.item)" alt/>
                        </v-list-item-avatar>
                        <v-list-item-content
                            v-if="data.item.type === 'user' && data.item.Users[0]"
                        >
                            <v-list-item-title v-html="data.item.Users[0].displayName"></v-list-item-title>
                            <v-list-item-subtitle v-html="data.item.Users[0].company"></v-list-item-subtitle>
                        </v-list-item-content>
                        <v-list-item-content
                            v-else
                        >
                            <v-list-item-title v-html="data.item.name"></v-list-item-title>
                        </v-list-item-content>
                    </template>
                </template>
            </v-autocomplete>
            <v-autocomplete
                v-else
                :hint="$t('restrictions.maxUsersPerKey.text', {planName: planName, maxValue: maxUsersNbr})"
                :hide-details="!disableMoreUsers"
                :persistent-hint="disableMoreUsers"
                :disabled="disableMoreUsers"
                :items="subordinatesNotOnThisKey()"
                :no-data-text="$t('keysList.noUserFound')"
                :search-input.sync="search"
                append-icon
                flat
                class="ma-0"
                multiple
                prepend-inner-icon="add"
                solo
                v-bind:label="$t('key.addManagers')"
                v-model="currentKey.keyManagers"
            >
                <template v-slot:selection="data"></template>
                <template v-slot:item="data">
                    <template v-if="data.item">
                        <v-list-item-avatar>
                            <img :src="getUserGroupPicture(data.item)" alt/>
                        </v-list-item-avatar>
                        <v-list-item-content
                            v-if="data.item.type === 'user' && data.item.Users[0]"
                        >
                            <v-list-item-title v-html="data.item.Users[0].displayName"></v-list-item-title>
                            <v-list-item-subtitle v-html="data.item.company"></v-list-item-subtitle>
                        </v-list-item-content>
                        <v-list-item-content
                            v-else
                        >
                            <v-list-item-title v-html="data.item.name"></v-list-item-title>
                        </v-list-item-content>
                    </template>
                </template>
            </v-autocomplete>
        </v-col>
    </v-row>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import {defaultUserAvatar, defaultUserGroupAvatar, defaultKeyPicture} from "@/utils/constants";
import {Getter} from "vuex-class";
import {canAddMoreUserToKey} from "plan-restrictions";
import {TranslateResult} from "vue-i18n";

@Component({})
export default class KeyManagersAutocomplete extends Vue {
    @Prop({})
    public currentKey: {
        guests: any[],
        newGuests: any[],
        keyManagers: any[],
        newKeyManagers: any[],
        presetManagers: any[],

    };

    // The number of users on the key with the greatest number of users in the group
    @Prop({default: 0})
    public maxKeyGroupUsersNbr: number;

    @Prop({default: false})
    public edit: boolean;

    @Prop({default: false})
    public disableDelete: boolean;

    @Prop({default: null})
    public customRemove: (manager) => void;

    @Getter private currentUser: any;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isAdmin: boolean;

    private MAX_MANAGERS_DISPLAYED = 5;

    private defaultUserAvatar: string = defaultUserAvatar;
    private defaultUserGroupAvatar: string = defaultUserGroupAvatar;
    private defaultKeyPicture: string = defaultKeyPicture;
    private canAddMoreUserToKey: (
        company: any,
        existingKeyUsersNbr: number,
        newKeyUsersNbr: number,
    ) => boolean = canAddMoreUserToKey;

    private subordinates: any[] = [];
    private search: string = null;

    @Watch("search")
    public handlerSearch() {
        if (this.isMaster() || this.isManager(this.currentUser, this.currentKey)) {
            this.getSubordinatesGroups();
        }
    }

    @Watch("currentKey.newKeyManagers")
    public handlerNewKeyManagers() {
        this.search = "";
    }

    get planName(): TranslateResult {
        return this.$i18n.t(`plan.${this.currentUser?.company?.currentSubscription?.Plan?.name}.name`);
    }

    get maxUsersNbr(): number {
        return this.currentUser?.company?.currentSubscription?.Plan?.details?.maxUsersPerKey;
    }
    // check if one of the user of one of the management groups match the current user
    private isManager = (user, key) => key?.keyManagers
        ?.some((g) => g?.Users?.some((u) => u.id === user?.id))

    private isOwnerInGroup = (group, key) => group?.Users?.some((u) => key?.ownerId === u?.id);

    private isHolderInGroup = (group, key) => group?.Users?.some((u) => key?.holder?.id === u?.id);

    private mounted() {
        this.getSubordinatesGroups();
    }

    private getPresetUsers() {
        this.currentKey.keyManagers = this.currentKey.presetManagers;
    }

    private getSubordinatesGroups() {
        Promise.all([
            this.$store.dispatch("users/getSubordinates", {
                query: {
                    search: this.search,
                    groups: true,
                },
            }),
            this.$store.dispatch("users/getUserGroups", {
                userId: this.$store.state.currentUser.id,
                query: {
                    search: this.search,
                    type: "subordinates",
                },
            }),
        ]).then(([subordinates, subordinatesGroups]) => {
            this.subordinates = [
                ...subordinates?.users || [],
                ...subordinatesGroups?.list || [],
            ].map((item: any) => ({...item}));
        });
    }

    // To get number of users and not number of accesses
    private usersNbrInGroup: (accesses: any[]) => number = (accesses: any[]) =>
        accesses?.reduce((a, c) => a + c?.Users?.length || 1, 0) || 0

    get keyUsersNbr(): number {
        return this.maxKeyGroupUsersNbr
            || (this.usersNbrInGroup(this.currentKey?.keyManagers) + this.usersNbrInGroup(this.currentKey?.guests));
    }

    get keyUsersAtCreation() {
        return (this.currentUser.companyId && !(this.isMaster || this.isAdmin)) ? 2 : 1;
    }

    get keyNewUsersNbr(): number {
        return this.usersNbrInGroup(this.currentKey?.newKeyManagers) + this.usersNbrInGroup(this.currentKey?.newGuests);
    }

    get disableMoreUsers(): boolean {
        // return true if there are exactly the maximum amount of users authorized
        return !this.canAddMoreUserToKey(
            this.currentUser?.company,
            this.keyUsersNbr + (!this.edit ? this.keyUsersAtCreation : 0),
            this.keyNewUsersNbr + 1, // +1 to prevent creator from selecting more users than authorized
        );
    }

    private remove(list, item) {
        if (this.customRemove) {
            this.customRemove(item);
        }
        const pos = list.map((u) => u.id).indexOf(item.id);
        list.splice(pos, 1);
    }

    private subordinatesNotOnThisKey() {
        const subordinates = this.subordinates;
        if (!subordinates) {
            return [];
        }
        return subordinates.filter(
            (item: any) =>
                !this.currentKey.keyManagers.map((elem: any) => elem?.id)?.includes(item?.id)
            && !this.currentKey?.newKeyManagers?.map((elem: any) => elem?.id)?.includes(item?.id),
        );
    }

    private getUserGroupPicture(group: any) {
        return !group?.creatorId
            ? (group.Users[0].picturePath || this.defaultUserAvatar)
            : this.defaultUserGroupAvatar;
    }
}
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
    .v-autocomplete__content .v-list{
        max-height: 200px;
    }
</style>