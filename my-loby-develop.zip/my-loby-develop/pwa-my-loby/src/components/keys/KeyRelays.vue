<template>
    <div>
        <div class="row no-gutters" v-for="relay in relays" :key="relay.id">
            <div class="col-sm-6">
                <h6>{{title ? title : $t('key.relayInfo')}}</h6>
                <p class="with_key"><span><i
                    class="icon-picto_relais-agence"></i></span><strong>{{relay.name}}</strong><br/>
                    <a
                        :href="relay.itinerary"
                        target="_blank"
                    >
                        {{relay.address}}<br/>{{relay.zipCode}} {{relay.city}}
                    </a>
                </p>
            </div>
            <div class="col-sm-6">
                <v-row class="ma-0">
                    <h6>{{$t('relay.schedule')}}
                        <a @click.prevent="showSchedule = !showSchedule"
                           :title="$t('actions.openClose')"
                           class="toggle_action"
                           :class="{'open' : !showSchedule}">
                            <i class="icon-angle" style="color:#c6c6d2"></i>
                        </a></h6>
                    <v-btn
                        v-if="mobile && relay.itinerary"
                        :href="relay.itinerary"
                        target="_blank"
                        color="warning"
                        outlined
                        small
                        absolute
                        top
                        style="top: 0;"
                        right
                    >
                        {{$t('relay.goTo')}}
                    </v-btn>
                    <v-btn
                        v-if="!mobile && canDeleteRelay"
                        type="button"
                        @click="$emit('remove-relay', relay)"
                        icon
                        :title="$t('key.removeRelay')"
                        outlined
                        small
                        absolute
                        top
                        style="top: 0;"
                        right
                    >
                        <v-icon small>delete</v-icon>
                    </v-btn>
                </v-row>
                <v-expand-transition>
                    <span v-if="showSchedule && relay.companyOpeningHours">
                        <p class="mb-0">
                        <span v-bind:class="{ today: day === 1 }" class="py-1">{{$t('day.monday')}} {{displaySchedule(relay.companyOpeningHours.monday)}}</span>
                        </p>
                        <p class="mb-0">
                            <span v-bind:class="{ today: day === 2 }" class="py-1">{{$t('day.tuesday')}} {{displaySchedule(relay.companyOpeningHours.tuesday)}}</span>
                        </p>
                        <p class="mb-0">
                            <span v-bind:class="{ today: day === 3 }" class="py-1">{{$t('day.wednesday')}} {{displaySchedule(relay.companyOpeningHours.wednesday)}}</span>
                        </p>
                        <p class="mb-0">
                            <span v-bind:class="{ today: day === 4 }" class="py-1">{{$t('day.thursday')}} {{displaySchedule(relay.companyOpeningHours.thursday)}}</span>
                        </p>
                        <p class="mb-0">
                            <span v-bind:class="{ today: day === 5 }" class="py-1">{{$t('day.friday')}} {{displaySchedule(relay.companyOpeningHours.friday)}}</span>
                        </p>
                        <p class="mb-0">
                            <span v-bind:class="{ today: day === 6 }" class="py-1">{{$t('day.saturday')}} {{displaySchedule(relay.companyOpeningHours.saturday)}}</span>
                        </p>
                        <p class="mb-0">
                            <span v-bind:class="{ today: day === 0 }" class="py-1">{{$t('day.sunday')}} {{displaySchedule(relay.companyOpeningHours.sunday)}}</span>
                        </p>
                    </span>
                </v-expand-transition>
            </div>
            <div v-if="relay.exceptionalClosures" class="col-sm-12 pt-2">
                <relay-exceptional-closures
                    :closures="relay.exceptionalClosures"
                />
            </div>
        </div>
    </div>
</template>
<script lang="ts">
import {Component, Prop, Vue} from "vue-property-decorator";
import RelayExceptionalClosures from "@/components/relays/RelayExceptionalClosures.vue";

@Component({
    components: {
        RelayExceptionalClosures,
    },
})export default class KeyRelays extends Vue {
    @Prop({default: []})
    public relays: object[];

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: null})
    public title: string;

    @Prop({default: false})
    public canDeleteRelay: boolean;

    private day = new Date().getDay();
    private showSchedule: boolean = false;

    private mounted() {
        this.showSchedule = !this.mobile;
    }

    private displaySchedule(day) {
        if (day.isActive) {
            if (day.continuous.isActive) {
                return `${day.continuous.fromHours} - ${day.continuous.toHours}`;
            } else if (day.morning.isActive && day.evening.isActive) {
                return `${day.morning.fromHours} - ${day.morning.toHours} / ${day.evening.fromHours} - ${day.evening.toHours}`;
            }
        }
    }
}
</script>