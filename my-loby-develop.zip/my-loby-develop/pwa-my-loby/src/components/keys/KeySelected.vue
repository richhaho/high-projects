<template>
  <v-overlay class="custom-overlay" v-if="selectedKeys.length">
    <v-row justify="center">
      <v-col cols="4">
        <div class="overlay-content">
          {{selectedKeys.length}} {{$t('keysList.selectedKeys')}} |
          <span
            @click="selectAll"
          >{{$t('keysList.selectAll')}}</span>
        </div>
      </v-col>
      <v-col cols="4">
        <div class="overlay-content end">
          <v-btn text @click="cancel">{{$t('actions.cancel')}}</v-btn>&nbsp;
          <button
            type="button"
            @click="createKeyGroup"
            :title="$t('keysList.createGroup')"
            class="creer"
          >
            <i class="icon-picto_exporter"></i>
            {{$t('keysList.createGroup')}}
          </button>
        </div>
      </v-col>
    </v-row>
  </v-overlay>
</template>
<script lang="ts">
import { Component, Vue, Prop } from "vue-property-decorator";

@Component
export default class KeySelected extends Vue {
  @Prop({ default: [] })
  public selectedKeys: object;

  @Prop({})
  public selectAll: () => void;

  @Prop({})
  public cancel: () => void;

  @Prop({})
  public deleteKeys: () => void;

  @Prop({})
  public createKeyGroup: () => void;
}
</script>