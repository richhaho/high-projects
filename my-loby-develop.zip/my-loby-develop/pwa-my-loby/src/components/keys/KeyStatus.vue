<template>
    <v-col v-if="currentKey.status === 'LATE'" class="pa-0">
        <v-row :justify="mobile ? 'center' : 'start'">
            <v-col
                class="pa-0 my-1"
                :class="!mobile ? 'mr-1' : ''"
                :cols="mobile ? '12' : 'auto'"
                :align="mobile ? 'center' : 'start'"
            >
                <v-btn
                    :to="{ name: 'user' , params: { id: currentKey.holder.id } }"
                    class="v-btn--active text-none"
                    color="red"
                    rounded
                    target="_blank"
                    text
                    x-small
                >
                    <v-icon left x-small>error</v-icon>
                    {{ $t('key.statusType.LATE') }}
                </v-btn>
            </v-col>
            <v-col
                class="pa-0 my-1"
                :cols="mobile ? '12' : 'auto'"

            >
                <i18n
                    path="key.statusDetails.WITH_SOMEBODY"
                    class="caption"
                >
                    <template v-slot:holder>
                        <v-btn
                            v-if="currentKey.holder"
                            :to="{ name: 'user' , params: { id: currentKey.holder.id } }"
                            class="v-btn--active text-none"
                            color="warning"
                            rounded
                            target="_blank"
                            text
                            x-small
                        >
                            <v-icon left x-small>people</v-icon>
                            {{ currentKey.holder.displayName }}
                        </v-btn>
                    </template>
                </i18n>
            </v-col>
        </v-row>
    </v-col>
    <i18n
        v-else
        :path="`key.statusDetails.${currentKey.status}`"
        class="caption"
    >
        <template v-slot:owner>
            <v-btn
                :to="{ name: 'user' , params: { id: currentKey.owner.id } }"
                class="v-btn--active text-none"
                color="warning"
                rounded
                target="_blank"
                text
                x-small
            >
                <v-icon left x-small>people</v-icon>
                {{currentKey.owner.displayName}}
            </v-btn>
        </template>
        <template v-slot:holder>
            <v-btn
                v-if="currentKey.holder"
                :to="{ name: 'user' , params: { id: currentKey.holder.id } }"
                class="v-btn--active text-none"
                color="warning"
                rounded
                target="_blank"
                text
                x-small
            >
                <v-icon left x-small>people</v-icon>
                {{ currentKey.holder.displayName }}
            </v-btn>
            <v-btn
                v-else
                class="v-btn--active text-none"
                color="warning"
                rounded
                text
                x-small
                disabled
                style="color: rgba(0,0,0,1) !important;"
            >
                <v-icon
                    left
                    x-small
                    style="color: rgba(0,0,0,1) !important;"
                >
                    people
                </v-icon>
                {{ $t('user.deleted') }}
            </v-btn>
        </template>
        <template v-slot:relay>
            <v-btn
                v-if="currentKey.status === 'IN_TRANSIT' ? keyReferenceAgency: currentRelay(currentKey)"
                :to="{ name: 'relay' , params: { id: currentKey.status === 'IN_TRANSIT' ? keyReferenceAgency.id : currentRelay(currentKey).id} }"
                class="v-btn--active text-none"
                color="green"
                rounded
                target="_blank"
                text
                x-small
            >
                <v-icon left x-small>home</v-icon>
                {{ currentKey.status === 'IN_TRANSIT' ? keyReferenceAgency.name : currentRelay(currentKey).name }}
            </v-btn>
        </template>
    </i18n>
</template>
<script lang="ts">
    import {Vue, Component, Prop} from "vue-property-decorator";
    
    @Component({})
    export default class KeyStatus extends Vue {
        @Prop({default: {}})
        public currentKey: any;

        @Prop({default: false})
        public mobile: boolean;

        private currentRelay = (key) => key?.currentLocation?.Box?.Relay;

        get keyReferenceAgency() {
            return this.currentKey?.Relays?.find((r) => r.type === "AGENCY");
        }

    }
</script>
