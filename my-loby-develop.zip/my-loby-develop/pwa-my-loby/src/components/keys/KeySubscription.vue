<template>
    <div>
        <p class="tableau_titre">
            {{$t('key.subscriptions.title')}}
            <a
                :title="$t('actions.openClose')"
                @click.prevent="displaySubscription = !displaySubscription"
                class="toggle_action"
                :class="{'open': !displaySubscription}"
            >
                <i class="icon-angle"></i>
            </a>
        </p>
        <v-expand-transition>
            <div class="tableau" v-if="displaySubscription">
                <div class="options">
                    <div class="option_left">
                        <div v-if="!!currentKey.archivedAt" class="banque_row row">
                            <v-col cols="12" class="py-0">
                                <label>{{$t('subscription.archived.title')}} :</label>
                                <p>{{$t(`subscription.archived.description.${archivedType}`)}}</p>
                            </v-col>
                        </div>
                    </div>
                    <div class="option_right">
                        <button
                            v-if="currentSubscription"
                            type="button"
                            class="option"
                            :title="$t('subscription.edit')"
                            @click="showEditSubscription = true"
                        >
                            <i class="icon-picto_editer"></i>
                            {{$t('actions.edit')}}
                        </button>
                        <button
                            v-else
                            type="button"
                            class="option"
                            :title="$t('subscription.new')"
                            @click="openCreateSubscription()"
                        >
                            <i class="icon-picto_ajouter"></i>
                            {{$t('actions.subscribe')}}
                        </button>
                        <key-subscription-edit
                            v-if="showEditSubscription"
                            :subscriptions="currentKey.Subscription.filter((s) => s.status !== 'CREATED')"
                            :userHasKey="userHasKey"
                            @close="showEditSubscription = false"
                            @reset="reset()"
                        />
                        <v-dialog
                            max-width="500px"
                            v-model="showCannotCreateSubscription"
                        >
                            <v-card>
                                <v-card-title>
                                    <span class="headline">{{$t('subscription.cannotCreate.title')}}</span>
                                </v-card-title>
                                <v-card-text class="py-4">
                                    <p class="subtitle-2 mb-2">{{$t("subscription.cannotCreate.details")}}</p>
                                </v-card-text>
                                <v-card-actions>
                                    <v-spacer></v-spacer>
                                    <v-btn
                                        @click="showCannotCreateSubscription = false"
                                        color="white"
                                        text
                                    >
                                        {{$t('actions.close')}}
                                    </v-btn>
                                    <v-spacer></v-spacer>
                                </v-card-actions>
                            </v-card>
                        </v-dialog>
                    </div>
                </div>
                <div class="banque_row row" v-if="currentSubscription">
                    <div class="col-md-4">
                        <label>{{$t('key.subscriptions.type')}} :</label>
                        <p><strong>{{$t(`subscription.${currentSubscription.Plan.name}.title`)}}</strong></p>
                    </div>
                    <div class="col-md-8">
                        <label>{{$t('key.subscriptions.description')}} :</label>
                        <p>{{$t(`subscription.${currentSubscription.Plan.name}.description`)}}</p>
                    </div>
                </div>
            </div>
        </v-expand-transition>
    </div>
</template>

<script lang="ts">
import {Component, Prop, Vue} from "vue-property-decorator";
import KeySubscriptionEdit from "@/components/keys/KeySubscriptionEdit.vue";
import {Getter} from "vuex-class";

@Component({
    components: {
        KeySubscriptionEdit,
    },
})
export default class KeySubscription extends  Vue {

    @Prop({default: null})
    public currentKey: any;

    @Getter private currentUser: any;

    private canCreateSubscription: boolean = false;
    private displaySubscription: boolean = true;
    private showEditSubscription: boolean = false;
    private showCannotCreateSubscription: boolean = false;

    get currentSubscription(): any {
        return this.currentKey?.Subscription?.filter((s) => s.status !== "CREATED")?.[0];
    }

    get userHasKey() {
        return this.currentKey?.KeyHolding?.find((kH) => !kH.endDate)?.userId === this.currentUser?.id;
    }

    get archivedType(): string {
        return !this.currentSubscription
            ? "classic"
            : "defaultPayment";
    }

    private mounted() {
        this.isRelayAvailable();
    }

    private reset(): void {
        this.showEditSubscription = false;
        this.isRelayAvailable();
        this.$emit("reset");
    }

    private openCreateSubscription() {
        if (this.canCreateSubscription) {
            this.showEditSubscription = true;
        } else {
            this.showCannotCreateSubscription = true;
        }
    }

    private isRelayAvailable(): void {
        this.$store.dispatch("relays/getAvailableLocations", {
            relayId: this.currentKey?.Relays?.[0]?.id,
        }).then((res) => {
            this.canCreateSubscription = (res?.count > 0);
        });
    }
}
</script>