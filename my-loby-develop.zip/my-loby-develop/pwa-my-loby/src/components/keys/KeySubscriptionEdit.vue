<template>
    <v-dialog
        max-width="910px"
        persistent
        v-model="showDialog"
        :fullscreen="isMobile"
        :hide-overlay="isMobile"
        :transition="isMobile ? 'dialog-bottom-transition' : ''"
    >
        <v-card>
            <v-card-title>
                <div class="contain_picto">
                    <i :class="cardIcon"></i>
                </div>
                <span :class="['headline', {'red--text': step === 'deleteSubscription'}]">
                    {{ cardTitle }}
                </span>
            </v-card-title>
            <v-card-text style="min-height: 200px">
                <v-container v-if="loading">
                    <v-col cols="12" class="py-10">
                        <v-row
                            justify="center"
                            class="loading"
                        >
                            <v-progress-circular
                                :width="3"
                                color="#0c0733"
                                indeterminate
                            />
                        </v-row>
                    </v-col>
                </v-container>
                <v-container v-else-if="step === 'deleteSubscription'">
                    <p class="subtitle-2 mb-2">{{$t("subscription.delete.details")}}</p>
                    <v-alert
                        v-if="isAnniversaryDateSoon"
                        class="px-5"
                        type="error"
                        outlined
                        text
                    >
                        <p class="subtitle-2 mb-0">
                            {{$t("subscription.delete.eightDays", {nextAnniversaryDate: $options.filters.formatAnniversaryDate(nextAnniversaryDate)})}}
                        </p>
                    </v-alert>
                    <p class="subtitle-2 mb-2">
                        {{$t("subscription.delete.confirm", {confirmationWord: deleteConfirmationWord})}}
                    </p>
                    <v-row justify="center">
                        <v-col cols="2" class="pa-0">
                            <v-text-field
                                clearable
                                hide-details
                                v-model="deleteConfirmation"
                            />
                        </v-col>
                    </v-row>
                </v-container>
                <v-container v-else-if="step === 'choosePaymentMethod'">
                    <v-alert
                        v-if="isAnniversaryDateSoon"
                        class="px-5"
                        type="warning"
                        outlined
                        text
                    >
                        <p class="subtitle-2 mb-0">
                            {{$t("subscription.editPaymentInfo.eightDays", {nextAnniversaryDate: $options.filters.formatAnniversaryDate(nextAnniversaryDate)})}}
                        </p>
                    </v-alert>
                    <payment
                        :key-id="keyId"
                        :payment-method-id.sync="newPaymentMethodId"
                        :subscription.sync="newSubscriptionId"
                        @update-subscription="updateSubscription()"
                        @close="reset()"
                    />
                </v-container>
                <v-container v-else-if="step === 'chooseSubscription'">
                    <v-row v-for="(plan, index) in possiblePlans" :key="index">
                        <v-col cols="12 pa-0">
                            <v-checkbox
                                :disabled="!!nextSubscription"
                                v-model="newPlanId"
                                v-bind:label="$t(`subscription.${plan.name}.title`)"
                                color="orange"
                                :value="plan.id"
                                hide-details
                            />
                            <p class="ml-8 mb-0">{{$t(`subscription.${plan.name}.description`)}}</p>
                            <p
                                v-if="!!currentSubscription && plan.id !== currentSubscription.Plan.id"
                                class="ml-8 mb-0"
                            >
                                {{$t(`subscription.${plan.name}.changingTiming`, {anniversaryDate: $options.filters.formatAnniversaryDate(nextAnniversaryDate)})}}
                            </p>
                        </v-col>
                    </v-row>
                    <v-alert
                        v-if="nextSubscription"
                        class="mt-4 px-5"
                        type="info"
                        outlined
                        text
                    >
                        <p class="subtitle-2 mb-0">
                            {{$t("subscription.nextPlanAlert", {newPlan: nextSubscription.Plan.name, anniversaryDate: $options.filters.formatAnniversaryDate(nextAnniversaryDate)})}}
                        </p>
                    </v-alert>
                    <p class="subtitle-2 mt-6">{{$t("subscription.b2cDetails")}}</p>
                    <div v-if="currentSubscription">
                        <a
                            v-if="currentSubscription.Plan.monthlyPrice > 0"
                            href="#"
                            @click="changeStep('choosePaymentMethod')"
                        >
                            {{$t("subscription.editPaymentInfo.title")}}
                        </a>
                        <v-divider></v-divider>
                        <i18n v-if="userHasKey" path="subscription.delete.sentence">
                            <a href="#" @click="changeStep('deleteSubscription')">
                                {{$t("common.clickHere")}}
                            </a>
                        </i18n>
                        <p v-else class="subtitle-2 mb-0">
                            {{$t("subscription.delete.mustHaveKey")}}
                        </p>
                    </div>
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    v-if="step === 'chooseSubscription'"
                    @click="$emit('close')"
                    color="white"
                    text
                >
                    {{$t('actions.cancel')}}
                </v-btn>
                <v-btn
                    v-else
                    @click="changeStep('chooseSubscription')"
                    color="white"
                    text
                >
                    {{$t('actions.back')}}
                </v-btn>
                <div v-if="validChange">
                    <v-btn
                        v-if="step === 'chooseSubscription'"
                        @click="updateSubscription()"
                        color="warning"
                    >
                        {{$t(`actions.${!currentSubscription ? "next" : "save"}`)}}
                    </v-btn>
                    <v-btn
                        v-else-if="step === 'choosePaymentMethod' && !currentSubscription && newPaymentMethodId"
                        @click="createPaymentMethod()"
                        color="warning"
                    >
                        {{$t("actions.create")}}
                    </v-btn>
                    <v-btn
                        v-else-if="step === 'choosePaymentMethod' && currentSubscription.paymentMethodId"
                        @click="updateSubscription()"
                        color="warning"
                    >
                        {{$t("actions.save")}}
                    </v-btn>
                    <v-btn
                        v-else-if="step === 'deleteSubscription'"
                        @click="cancelSubscription()"
                        color="error"
                    >
                        {{$t("actions.delete")}}
                    </v-btn>
                </div>
                <v-spacer></v-spacer>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>
<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";
import {Getter} from "vuex-class";
import Payment from "@/views/front-office/Payment.vue";
import {TranslateResult} from "vue-i18n";

export const WAIT_UX_MILLI: number = 1000;
export const ONE_DAY_MILLI: number = 24 * 60 * 60 * 1000;

@Component({
    components: {
        Payment,
    },
})
export default class KeySubscriptionEdit extends Vue {
    @Prop({default: null})
    public subscriptions: any;

    @Prop({})
    public userHasKey: () => boolean;

    @Prop({default: false})
    public isMobile: boolean;

    @Getter private currentUser: any;

    private plans: any[] = [];
    private newPlanId: number = null;
    private showDialog: boolean = false;
    private step: string = "chooseSubscription";
    private deleteConfirmationWord: string = null;
    private deleteConfirmation: string = null;
    private newSubscriptionId: any = null;
    private newPaymentMethodId: number = null;
    private loading: boolean = false;

    private mounted() {
        this.deleteConfirmationWord = String(this.$t("subscription.delete.confirmationWord"));
        this.newPlanId = this.currentSubscription?.Plan?.id;
        this.getPlans();
    }

    get currentSubscription(): any {
        return this.subscriptions?.[0];
    }

    get nextSubscription(): any {
        return this.subscriptions?.[1];
    }

    private getPlans(): void {
        this.$store.dispatch("plans/read", {
            query: {
                type: "B2C",
            },
        }).then((res) => {
            this.plans = res?.plans?.sort((a, b) => a.monthlyPrice - b.monthlyPrice) || [];
            this.showDialog = true;
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    get keyId(): number {
        return Number(this.$route.params.id);
    }

    get possiblePlans(): object[] {
        return !this.currentSubscription || this.currentSubscription?.Plan?.monthlyPrice === 0
            ? this.plans
            : this.plans.filter((p) => p.monthlyPrice > 0);
    }

    private changeStep(newStep: string): void {
        this.step = newStep;
    }

    get cardIcon(): string {
        switch (this.step) {
            case "deleteSubscription":
                return "icon-picto_attention red--text";
            case "choosePaymentMethod":
                return "icon-picto_credit-card";
            default:
                return "icon-picto_cle-partagees";
        }
    }

    get cardTitle(): TranslateResult {
        switch (this.step) {
            case "deleteSubscription":
                return this.$i18n.t("subscription.delete.title");
            case "choosePaymentMethod":
                return this.$i18n.t("subscription.paymentInfo");
            default:
                return !!this.currentSubscription
                    ? this.$i18n.t("subscription.edit")
                    : this.$i18n.t("subscription.new");
        }
    }

    get validChange(): boolean {
        switch (this.step) {
            case "deleteSubscription" :
                return this.deleteConfirmation === this.deleteConfirmationWord;
            case "choosePaymentMethod":
                return this.currentSubscription?.paymentMethodId
                    ? !!this.newPaymentMethodId && this.newPaymentMethodId !== this.currentSubscription.paymentMethodId
                    : !!this.newPaymentMethodId;
            case "chooseSubscription":
                return this.newPlanId && (this.newPlanId !== this.currentSubscription?.Plan?.id);
        }
    }

    get isAnniversaryDateSoon(): boolean {
        if (this.currentSubscription) {
            const today: any = new Date();
            const daysToAnniversaryDate: number = Math.round(
                Math.abs(this.nextAnniversaryDate - today) / ONE_DAY_MILLI);
            return (daysToAnniversaryDate < 8);
        } else {
            return false;
        }
    }

    get nextAnniversaryDate(): number {
        if (this.currentSubscription) {
            const today: any = new Date();
            // Get the anniversary date of the month
            const anniversaryDate: any = new Date(
                today.getFullYear(),
                today.getMonth(),
                this.currentSubscription.anniversaryDate,
            );
            // If anniversary date is already passed this month, get the next one
            if (today - anniversaryDate > ONE_DAY_MILLI) {
                anniversaryDate.setMonth(today.getMonth() + 1);
            }
            return anniversaryDate;
        } else {
            return null;
        }
    }

    private reset() {
        this.$emit("reset");
        this.loading = false;
    }

    private updateSubscription(): void {
        this.loading = true;
        this.$store.dispatch("keys/updateSubscription", {
            keyId: this.keyId,
            subscription: {
                ...this.currentSubscription,
                planId: this.newPlanId,
                paymentMethodId: this.newPaymentMethodId,
            },
        }).then((res) => {
            if (!this.currentSubscription) {
                this.loading = false;
                this.changeStep("choosePaymentMethod");
            } else {
                setTimeout(() => {
                    this.reset();
                    this.$store.commit("alerts/displaySuccess", {
                        msg: this.$i18n?.t("actions.saved"),
                    });
                }, WAIT_UX_MILLI);
            }
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private createPaymentMethod(): void {
        if (this.newPaymentMethodId) {
            this.loading = true;
            this.$store.dispatch("payments/createOne", {
                subscriptionId: this.newSubscriptionId,
                paymentMethodId: this.newPaymentMethodId,
            }).then((res) => {
                setTimeout(() => {
                    this.reset();
                    this.$store.commit("alerts/displaySuccess", {
                        msg: this.$i18n?.t("actions.created"),
                    });
                }, WAIT_UX_MILLI);
            }).catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err,
                });
            });

        }
    }

    private cancelSubscription(): void {
        this.loading = true;
        this.$store.dispatch("keys/cancelSubscription", {
            keyId: this.keyId,
        }).then((res) => {
            setTimeout(() => {
                this.reset();
                this.$store.commit("alerts/displaySuccess", {
                    msg: this.$i18n?.t("actions.deleted"),
                });
            }, WAIT_UX_MILLI);
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }
}
</script>
