<template>
    <div class="tableau">
        <v-row id="key-list" >
            <v-list three-line width="100%" v-if="keys.length">
                <template v-for="(item, index) in keys" v-if="keys.length">
                    <div class="d-flex align-items-center">
                        <mobile-list-key-item
                            :item="item"
                            :key="index"
                            :update-data="getKeys"
                            :from-relays-page="true"
                            :location="item.status === 'IN_RELAY'"
                        />
                        <relay-give-key-to-guest
                            v-if="accessToGuests(item) && isBookedKeyAvailable"
                            :mobile="isMobile"
                            :current-key="item"
                            :relay="relayDisplayed(item)"
                            :update-key-users="updateKeyUsers"
                            @reset="getKeys"
                        />
                        <relay-booked-key
                            v-if="item.currentBooking"
                            :current-key="item"
                        />
                    </div>
                    <v-divider v-if="index < keys.length - 1"/>
                </template>
            </v-list>
        </v-row>
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import KeyStatus from "@/components/keys/KeyStatus.vue";
import RelayGiveKeyToGuest from "@/components/relays/RelayGiveKeyToGuest.vue";
import MobileListKeyItem from "@/components/mobile/MobileListKeyItem.vue";
import {Getter} from "vuex-class";
import moment from "moment";
import RelayBookedKey from "@/components/relays/RelayBookedKey.vue";

@Component({
    components: {
        RelayGiveKeyToGuest,
        KeyStatus,
        MobileListKeyItem,
        RelayBookedKey,
    },
})
export default class KeysMobile extends Vue {

    // if user is manager of at least one key
    get isManagerOfOne(): boolean {
        return this.keys.some((key) => key.ownerId === this.currentUser?.id
            || key?.keyManagers?.some((g) => g?.Users?.some((u) => u.id === this.currentUser?.id)));
    }
    @Getter private currentUser: any;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isAdmin: boolean;
    @Getter private isB2B: boolean;
    @Getter private isMobile: boolean;

    private loading: boolean = true;
    private keys: any[] = [];
    private keysStatus: string[] = [];
    private search: string = "";
    private pagination: any = {
        sortDesc: [true],
        sortBy: ["updatedAt"],
        search: "",
        select: [],
        page: 1,
        itemsPerPage: 10,
    };
    private totalKeys: number = 0;
    private endCountdown: boolean = false;
    private headers: any[] = [];

    @Watch("pagination", {deep: true})
    public handler() {
        this.loading = true;
        this.getKeys();
    }

    // if user is manager of a given key
    private isManagerOf(key: any): boolean {
        return key.ownerId === this.currentUser?.id
            || key?.keyManagers?.some((g) => g?.Users?.some((u) => u.id === this.currentUser?.id));
    }

    private mounted() {
        this.getKeysStatus();
        if (this.isB2B || this.isAdmin) {
            // Agency -> All details
            this.headers = [
                {value: "name", sortable: true},
                {value: "owner", sortable: false},
                {value: "refAgency", sortable: false},
                {value: "status", sortable: false},
                {value: "countdown", sortable: false},
                {value: "actions", sortable: false},
            ];
        } else {
            // Flow or Long term relay -> No details
            this.headers = [
                {value: "countdown", sortable: false},
                {value: "status", sortable: false},
            ];
        }
        this.getKeys();
    }

    private clickRow(item) {
        if (this.isAdmin || this.isManagerOf(item)) {
            return this.$router.push({name: "key", params: {id: item.id}});
        }
    }

    private relayDisplayed(key): any {
        return key.Relays?.find((relay) => relay.type === "AGENCY")
            || key.Relays?.[0];
    }

    private accessToGuests(key): boolean {
        const relay = this.relayDisplayed(key);
        return relay ? !!relay?.canReferentsProcessKeys : false;
    }

    private getTime = (date) => date
        ? moment(new Date(date), "YYYY-MM-DD HH:mm:ss").valueOf()
        : moment().valueOf()

    // whether or not show days in countdown
    private showDays = (date) => Math.abs(moment(new Date(date), "YYYY-MM-DD HH:mm:ss").valueOf() - moment().valueOf())
        > 24 * 60 * 60 * 1000

    private getDifference(date): string {
        date = new Date(date);
        const a = moment(date, "YYYY-MM-DD hh:mm");
        const b = moment();
        const diffDays = b.diff(a, "days");
        const diffHours = b.diff(a, "hours");
        const diffMinutes = b.diff(a, "minutes");
        if (diffMinutes < 60) {
            return diffMinutes % 60 + " " + String(this.$tc("countDown.minutes", diffMinutes % 60));
        } else if (diffHours < 24) {
            return diffHours % 24 + " " + String(this.$tc("countDown.hours", diffHours % 24)) + ", "
                + diffMinutes % 60 + " " + String(this.$tc("countDown.minutes", diffMinutes % 60));
        } else {
            return diffDays + " " + String(this.$tc("countDown.days", diffDays)) + ", "
                + diffHours % 24 + " " + String(this.$tc("countDown.hours", diffHours % 24)) + ", "
                + diffMinutes % 60 + " " + String(this.$tc("countDown.minutes", diffMinutes % 60));
        }
    }

    private lateKey = (date) => moment(new Date(date), "YYYY-MM-DDTHH:mm:ss")
        .isBefore(moment().format("YYYY-MM-DDTHH:mm:ss"))

    private getKeys() {
        this.pagination.search = this.search;
        return this.$store.dispatch("users/getKeysOutIn", {
            id: this.currentUser.id,
            query: this.pagination,
        }).then((res) => {
            this.keys = res?.rows || [];
            this.totalKeys = res?.count || 0;
            this.loading = false;
        });

    }

    private findKeysBySearch(search) {
        this.search = search;
        this.getKeys();
    }

    private getKeyUsers(key: any): Promise<any[]> {
        return this.$store.dispatch("keys/getKeyUsers", {
            keyId: key.id,
        }).then((res) => {
            return res?.filter((user) =>
                // Remove the current user from the list of users
                user.id !== this.currentUser?.id
                // Remove guests with an upcoming (not valid right now) invitation
                && user.invitations?.some((i) => this.isValidAccess(i?.keyAccess)),
            ) || [];
        });
    }

    private isValidAccess = (access: any) => (access.countAccessLeft === -1 || access.countAccessLeft >= 1)
        && (access.startDate === null || new Date(access.startDate) <= new Date())
        && (access.endDate === null || new Date(access.endDate) >= new Date())

    private updateKeyUsers(key: any): Promise<void | any[]> {
        return this.getKeyUsers(key).then((users) => {
            this.$set(key, "users", users);
            this.$set(key, "guests", users);
            this.$set(key, "newGuests", []);
            this.$set(key, "loadingUsers", false);
        });
    }

    private getKeysStatus() {
        return this.$store.dispatch("keys/getStatus").then((res) => {
            this.keysStatus = res.keysStatus;
        });
    }

    private popSelected(item: string) {
        this.pagination.select.splice(this.pagination.select.indexOf(item), 1);
    }

    private isBookedKeyAvailable(key) {
        if (!key.currentBooking) {
            return true;
        }
        const hasRights = this.currentUser.id === key.currentBooking.createdBy
            || this.isManager
            || this.isAdmin;
        return (key.currentBooking && hasRights) || (this.currentUser.id === key.currentBooking.userId);
    }

    private isManager = (user, key) => key?.keyManagers
        ?.some((g) => g?.Users?.some((u) => u.id === user?.id)) || key.ownerId === user?.id
}
</script>
