<template>
    <div class="tableau">
        <v-data-table
            :headers="headers"
            :hide-default-footer="totalKeys < pagination.itemsPerPage"
            :items="keys"
            :loading="loading"
            :options.sync="pagination"
            :search="pagination.search"
            :server-items-length="totalKeys"
            class="elevation-1"
            :class="isAdmin || isManagerOfOne ? 'hover-pointer' : ''"
            @click:row="clickRow"
        >
            <template v-slot:header.name="{ header }">{{ $t('key.name') }}</template>
            <template v-slot:header.owner="{ header }">{{ $t('key.owner') }}</template>
            <template v-slot:header.refAgency="{ header }">{{ $t('key.refAgency') }}</template>
            <template v-slot:header.status="{ header }">{{ $t('key.status') }}</template>
            <template v-slot:header.countdown="{ header }">{{ $t('countDown.remaining') }}</template>
            <template v-slot:item.owner="{ item }">
                {{ item.owner.displayName }}
            </template>
            <template v-slot:item.refAgency="{ item }">
                <v-btn
                    v-if="relayDisplayed(item)"
                    :to="{ name: 'relay' , params: { id: relayDisplayed(item).id } }"
                    class="v-btn--active text-none"
                    color="green"
                    rounded
                    target="_blank"
                    text
                    x-small
                    style="font-weight: 600;"
                >
                    <v-icon left x-small>home</v-icon>
                    {{ relayDisplayed(item).name }}
                </v-btn>
            </template>
            <template v-slot:item.status="{ item }">
                <key-status :currentKey="item"/>
            </template>
            <template v-slot:item.countdown="{ item }">
                <v-alert
                    v-if="item.KeyHolding && item.KeyHolding[0] && item.KeyHolding[0].estimatedEndDate"
                    class="pa-1 my-0"
                    :color="lateKey(item.KeyHolding[0].estimatedEndDate) || endCountdown ? 'red' : 'blue'"
                    dense
                    outlined
                    text
                >
                    <v-row
                        v-if="!lateKey(item.KeyHolding[0].estimatedEndDate) && !endCountdown"
                        class="px-2 my-0 subtitle-2"
                    >
                        {{$t('countDown.remaining')}} :
                        <vue-countdown-timer
                            :start-time="getTime()"
                            :end-time="getTime(item.KeyHolding[0].estimatedEndDate)"
                            :interval="1000"
                            class="ml-1"
                            @end_callback="endCountdown = true"
                        >
                            <template slot="countdown" slot-scope="scope">
                                {{showDays(item.KeyHolding[0].estimatedEndDate) ? scope.props.days + ":" : ""}}{{scope.props.hours}}:{{scope.props.minutes}}:{{scope.props.seconds}}
                            </template>
                        </vue-countdown-timer>
                    </v-row>
                    <p
                        v-else
                        class="px-2 my-0 subtitle-2"
                    >
                        {{$t('countDown.late')}} {{ getDifference(item.KeyHolding[0].estimatedEndDate) }}
                    </p>
                </v-alert>
            </template>
        </v-data-table>
        <input type="hidden" :value="searchQuery">
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import KeyStatus from "@/components/keys/KeyStatus.vue";
import {Getter} from "vuex-class";
import moment from "moment";

@Component({
    components: {
        KeyStatus,
    },
})
export default class KeysWithUsers extends Vue {

    get searchQuery() {
        this.pagination.search = this.getSearchQuery;
        return this.getSearchQuery;
    }

    // if user is manager of at least one key
    get isManagerOfOne(): boolean {
        return this.keys.some((key) => key.ownerId === this.currentUser?.id
            || key?.keyManagers?.some((g) => g?.Users?.some((u) => u.id === this.currentUser?.id)));
    }
    @Getter private currentUser: any;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isAdmin: boolean;
    @Getter private isB2B: boolean;
    @Getter private getSearchQuery: string;

    private loading: boolean = true;
    private keys: any[] = [];
    private keysStatus: string[] = [];
    private pagination: any = {
        sortDesc: [true],
        sortBy: ["updatedAt"],
        search: "",
        select: [],
        page: 1,
        itemsPerPage: 10,
    };
    private totalKeys: number = 0;
    private endCountdown: boolean = false;
    private headers: any[] = [];

    @Watch("pagination", {deep: true})
    public handler() {
        this.loading = true;
        this.getKeys();
    }

    // if user is manager of a given key
    private isManagerOf(key: any): boolean {
        return key.ownerId === this.currentUser?.id
            || key?.keyManagers?.some((g) => g?.Users?.some((u) => u.id === this.currentUser?.id));
    }

    private mounted() {
        this.getKeysStatus();
        if (this.isB2B || this.isAdmin) {
            // Agency -> All details
            this.headers = [
                {value: "name", sortable: true},
                {value: "owner", sortable: false},
                {value: "refAgency", sortable: false},
                {value: "status", sortable: false},
                {value: "countdown", sortable: false},
            ];
        } else {
            // Flow or Long term relay -> No details
            this.headers = [
                {value: "countdown", sortable: false},
                {value: "status", sortable: false},
            ];
        }
    }

    private clickRow(item) {
        if (this.isAdmin || this.isManagerOf(item)) {
            return this.$router.push({name: "key", params: {id: item.id}});
        }
    }

    private relayDisplayed(key): object {
        return key.Relays?.find((relay) => relay.type === "AGENCY")
            || key.Relays?.[0];
    }

    private getTime = (date) => date
        ? moment(new Date(date), "YYYY-MM-DD HH:mm:ss").valueOf()
        : moment().valueOf()

    // whether or not show days in countdown
    private showDays = (date) => Math.abs(moment(new Date(date), "YYYY-MM-DD HH:mm:ss").valueOf() - moment().valueOf())
        > 24 * 60 * 60 * 1000

    private getDifference(date): string {
        date = new Date(date);
        const a = moment(date, "YYYY-MM-DD hh:mm");
        const b = moment();
        const diffDays = b.diff(a, "days");
        const diffHours = b.diff(a, "hours");
        const diffMinutes = b.diff(a, "minutes");
        if (diffMinutes < 60) {
            return diffMinutes % 60 + " " + String(this.$tc("countDown.minutes", diffMinutes % 60));
        } else if (diffHours < 24) {
            return diffHours % 24 + " " + String(this.$tc("countDown.hours", diffHours % 24)) + ", "
                + diffMinutes % 60 + " " + String(this.$tc("countDown.minutes", diffMinutes % 60));
        } else {
            return diffDays + " " + String(this.$tc("countDown.days", diffDays)) + ", "
                + diffHours % 24 + " " + String(this.$tc("countDown.hours", diffHours % 24)) + ", "
                + diffMinutes % 60 + " " + String(this.$tc("countDown.minutes", diffMinutes % 60));
        }
    }

    private lateKey = (date) => moment(new Date(date), "YYYY-MM-DDTHH:mm:ss")
        .isBefore(moment().format("YYYY-MM-DDTHH:mm:ss"))

    private getKeys() {
        return this.$store.dispatch("users/getKeysWithUsers", {
            id: this.currentUser.id,
            query: this.pagination,
        }).then((res) => {
            this.keys = res?.rows || [];
            this.totalKeys = res?.count || 0;
            this.loading = false;
        });

    }

    private getKeysStatus() {
        return this.$store.dispatch("keys/getStatus").then((res) => {
            this.keysStatus = res.keysStatus;
        });
    }

    private popSelected(item: string) {
        this.pagination.select.splice(this.pagination.select.indexOf(item), 1);
    }
}
</script>
