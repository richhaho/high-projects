<template>
    <div>
        <button type="button" class="action_button"
                @click="showDialog = true">
            <span>
                 <i class="icon-picto_cle-partagees" />
                {{$t('key.actions.changeStatus')}}
            </span>
        </button>
        <v-dialog
            persistent
            max-width="910px"
            v-model="showDialog"
            :fullscreen="mobile"
            :hide-overlay="mobile"
            :transition="mobile ? 'dialog-bottom-transition' : ''"
        >
            <v-card>
                <v-card-title>
                    <div class="contain_picto">
                        <i class="icon-picto_cle-partagees"></i>
                    </div>
                    <span class="headline">{{$t('key.changeStatus.title')}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-row class="key-view">
                           <key-give
                               :currentKey="currentKey"
                               :update-data="updateData"
                           />
                            <key-drop-agency
                                v-if="isKeyB2B(currentKey)"
                                :currentKey="currentKey"
                                :update-data="updateData"
                            />
                            <key-drop-my-loby
                                :currentKey="currentKey"
                                :update-data="updateData"
                            />
                            <key-transit
                                v-if="isKeyB2B(currentKey)"
                                :currentKey="currentKey"
                                :update-data="updateData"
                            />
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="showDialog = false"
                        color="white"
                        text>
                        {{$t('actions.cancel')}}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>

</template>

<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";
import KeyTransit from "@/components/keys/actions/KeyTransit.vue";
import KeyDropAgency from "@/components/keys/actions/KeyDropAgency.vue";
import KeyDropMyLoby from "@/components/keys/actions/KeyDropMyLoby.vue";
import KeyGive from "@/components/keys/actions/KeyGive.vue";
@Component({
    components: {KeyGive, KeyDropMyLoby, KeyDropAgency, KeyTransit},
})
export default class ChangeStatus extends Vue {

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: null})
    private currentKey: any;

    @Prop({})
    private updateData: () => void;

    private showDialog: boolean = false;

    private isKeyB2B = (key: any) => key?.Relays?.some((r) => r.type === "AGENCY");
}
</script>