<template>
    <div v-if="canDropOrGive(currentUser, currentKey)"  :style="{width: mobile ? '100%':''}">
        <hr v-if="mobile" style="margin: 0 5px 0 5px">
        <button
            style="width: inherit"
            :disabled="disabled"
            type="button"
            class="action_button"
            @click="handToHandDialog = true"
        >
            <span v-if="!mobile">
                <span class="icon-picto_donner-main-a-main">
                    <i class="path1"></i>
                    <i class="path2"></i>
                    <i class="path3"></i>
                </span>
                {{$t('key.actions.giveHandToHand')}}
            </span>
            <v-list-item-icon v-else class="list_btn_action">
                <p class="with_key action_key" style="min-width: 200px;">
                <span class="icon-picto_donner-main-a-main-2 mobile">
                    <i class="path1"></i>
                    <i class="path2"></i>
                    <i class="path3"></i>
                </span>
                    <strong>{{ $t('key.actions.giveHandToHand') }}</strong>
                </p>
            </v-list-item-icon>
        </button>
        <v-dialog
            persistent
            max-width="500px"
            v-model="handToHandDialog"
            :fullscreen="mobile"
            :hide-overlay="mobile"
            :transition="mobile ? 'dialog-bottom-transition' : ''"
        >
            <v-card>
                <v-card-title>
                    <span v-show="!handToHandQrCode" class="headline">{{$t('keysList.handToHandQrTitle')}}</span>
                    <span v-show="handToHandQrCode" class="headline">{{verificationBySMS ? $t('keysList.handToHandSMSLabel') : $t('keysList.handToHandQrCode')}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-row>
                            <v-col cols="12 pa-0" v-show="!handToHandQrCode">
                                <v-autocomplete
                                    :item-text="itemStringified"
                                    item-value="id"
                                    :items="users"
                                    append-icon
                                    solo
                                    :no-data-text="$t('key.handToHand.noUserFound')"
                                    v-bind:label="$t('key.handToHand.selectUser')"
                                    v-model="handToHandSelectedGuest"
                                >
                                    <template v-slot:selection="data">
                                        <v-list-item-content style="overflow: initial !important;">
                                            <v-list-item-title
                                                v-html="data.item.displayName">
                                            </v-list-item-title>
                                            <v-list-item-subtitle
                                                v-html="data.item.company">
                                            </v-list-item-subtitle>
                                        </v-list-item-content>
                                    </template>
                                    <template v-slot:item="data">
                                        <v-list-item-content style="overflow: initial;">
                                            <v-list-item-title
                                                v-html="data.item.displayName">
                                            </v-list-item-title>
                                            <v-list-item-subtitle
                                                v-html="data.item.company">
                                            </v-list-item-subtitle>
                                        </v-list-item-content>
                                    </template>
                                </v-autocomplete>
                            </v-col>
                            <v-col v-show="handToHandQrCode" class="text-center">
                                <img :src="handToHandQrCode" v-if="!verificationBySMS">
                                <v-text-field
                                    v-else
                                    :rules="[rules.pin]"
                                    class="input-group--focused"
                                    dense
                                    outlined
                                    pattern="[0-9]*"
                                    inputmode="numeric"
                                    :placeholder="$t('pin.enter')"
                                    rounded
                                    type="number"
                                    v-model="sms"
                                    min="0"
                                    hide-details
                                    @focus="pinFailed=false"
                                >
                                </v-text-field>
                                <span v-show="pinFailed" class="text-danger">{{$t('keysList.pinFailed')}}</span>
                            </v-col>
                        </v-row>
                        <v-row>
                            <v-col class="d-flex justify-content-center">
                                <v-btn v-if="handToHandQrCode && !verificationBySMS"
                                       @click="switchSmsOrQR"
                                       color="warning"
                                >
                                    {{$t('keysList.handToHandSMS')}}
                                </v-btn>
                                <v-btn
                                    v-if="handToHandSelectedGuest && handToHandQrCode && verificationBySMS"
                                    @click="validateSMS"
                                    color="warning"
                                >
                                    {{$t('actions.validate')}}
                                </v-btn>
                            </v-col>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn v-if="!handToHandQrCode"
                           @click="closeDialog"
                           color="white"
                           text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-btn v-if="handToHandSelectedGuest && !handToHandQrCode"
                           :disabled="!handToHandSelectedGuest"
                           :loading="loadHandToHand"
                           @click="selectGuestHandToHand"
                           color="warning"
                    >
                        {{$t('actions.give')}}
                    </v-btn>
                    <v-btn v-if="handToHandSelectedGuest && handToHandQrCode"
                           @click="closeDialog"
                           color="white"
                           text
                    >
                        {{$t('actions.close')}}
                    </v-btn>
                    <v-btn v-if="handToHandQrCode && verificationBySMS"
                           @click="switchSmsOrQR"
                           color="white"
                           text
                    >
                        {{$t('keysList.handToHandQrCodeReturn')}}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <over-price-sms
            :dialog="acceptOverPrice"
            :loading="loadingSms"
            @accept="sendSMS"
            @cancel="acceptOverPrice = false"
        ></over-price-sms>
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import {Getter} from "vuex-class";
import OverPriceSms from "@/components/OverPriceSms.vue";
import {formRules} from "@/utils/formRules";

@Component({
    components: {
        OverPriceSms,
    },
})
export default class HandToHand extends Vue {

    @Prop({default: {}})
    public currentKey: any;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: false})
    public disabled: boolean;

    @Prop({})
    public updateData: () => void;
    @Getter private currentUser: any;

    private handToHandDialog: boolean = false;
    private handToHandSelectedGuest: number = null;
    private handToHandQrCode: string = null;
    private loadHandToHand: boolean = false;
    private users: any[] = [];
    private verificationBySMS: boolean = false;
    private sms: string = null;
    private loadingSms: boolean = false;
    private pinFailed: boolean = false;
    private acceptOverPrice: boolean = false;
    private rules: object = formRules;

    @Watch("handToHandDialog")
    public handler(newVal: any): void {
        if (newVal) {
            this.getUsers();
        }
    }

    private isValidAccess = (access: any) => (access.countAccessLeft === -1 || access.countAccessLeft >= 1)
        && (access.startDate === null || new Date(access.startDate) <= new Date())
        && (access.endDate === null || new Date(access.endDate) >= new Date())

    private getUsers(): void {
        this.$store.dispatch("keys/getKeyUsers", {
            keyId: this.currentKey.id,
        }).then((res) => {
            // Remove the current user from the list of users
            this.users = res?.filter((user) => user.id !== this.currentUser?.id) || [];
            // Remove guest with an upcoming (not valid right now) invitation
            this.users = this.users?.filter((user) =>
                !user.invitations || user.invitations?.some((i) =>
                    this.isValidAccess(i?.keyAccess),
                ),
            ) || [];
        });
    }

    private selectGuestHandToHand() {
        this.loadHandToHand = true;
        if (!this.verificationBySMS) {
            return this.$store.dispatch("keys/giveHandToHand", {
                keyId: this.currentKey.id,
                sourceUserId: this.currentUser.id,
                targetUserId: this.handToHandSelectedGuest,
            }).then((res) => {
                this.loadHandToHand = false;
                this.handToHandQrCode = res;
            }).catch(() => {
                this.$store.commit("alerts/displayError", {
                    iconGroup: "icon-picto_donner-main-a-main",
                    msg: this.$i18n?.t("alerts.error.default"),
                });
                this.updateData();
                this.closeDialog();
            });
        }
    }

    private cancelGuestHandToHand() {
        this.$store.dispatch("keys/cancelHandToHand", {
            keyId: this.currentKey.id,
        });
        this.handToHandQrCode = null;
        this.handToHandSelectedGuest = null;
        this.updateData();
    }

    private switchSmsOrQR() {
        this.pinFailed = false;
        this.verificationBySMS = !this.verificationBySMS;
        if (this.verificationBySMS) {
            this.sendSMS();
        }
    }

    private sendSMS() {
        this.loadingSms = true;
        return this.$store.dispatch("keys/sendSms", {
            keyId: this.currentKey.id,
            sourceUserId: this.currentUser.id,
            targetUserId: this.handToHandSelectedGuest,
            acceptOverPrice: this.acceptOverPrice,
        }).then(() => {
            this.acceptOverPrice = false;
        }).catch((err) => {
            switch (err?.response?.data?.error) {
                case "smsLimitReached":
                    this.acceptOverPrice = true;
                    break;
                default:
                    this.$store.commit("alerts/displayError", {
                        msg: this.$t(`alerts.error.${err?.response?.data?.error || "default"}`),
                    });
                    this.closeDialog();
                    break;
            }
        }).finally(() => {
            this.loadingSms = false;
        });
    }

    private validateSMS() {
        this.pinFailed = false;
        if (!this.sms) {
            return;
        }
        return this.$store.dispatch("keys/smsVerification", {
            keyId: this.currentKey.id,
            pin: this.sms,
            targetUserId: this.handToHandSelectedGuest,
            acceptOverPrice: this.acceptOverPrice,
        }).then((res) => {
            if (res !== "SUCCESS") {
                this.pinFailed = true;
                return;
            }
            this.closeDialog();
        }).catch(() => {
            this.$store.commit("alerts/displayError", {
                iconGroup: "icon-picto_donner-main-a-main",
                msg: this.$i18n?.t("alerts.error.default"),
            });
            this.closeDialog();
        });
    }

    private closeDialog() {
        this.acceptOverPrice = false;
        this.updateData();
        this.cancelGuestHandToHand();
        this.handToHandDialog = false;
        this.verificationBySMS = false;
    }

    private canDropOrGive = (user, key) => this.isKeyInitialized(key)
        || this.isKeyUnarchived(key)
        || (this.userHasKey(user, key) && !this.isKeyInRelay(key))
        && !this.isKeyBooked(key)

    private isKeyInitialized = (key: any) => key?.status === "CREATED";

    private isKeyUnarchived = (key: any) => key?.status === "UNARCHIVED";

    private isKeyBooked(key: any): boolean {
        if (!key?.currentBooking) return false;
        return new Date() > new Date(key.currentBooking?.startDate)
            && new Date() < new Date(key.currentBooking?.endDate);
    }


    private userHasKey = (user, key) => key?.KeyHolding?.find((kH) => !kH.endDate)?.userId === user?.id;

    private isKeyInRelay = (key: any) => key?.status === "IN_RELAY";

    private itemStringified = (item) => JSON.stringify(item);
}
</script>
