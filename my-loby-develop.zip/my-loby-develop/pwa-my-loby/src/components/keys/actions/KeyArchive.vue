<template>
    <div>
        <v-tooltip bottom>
            <template v-slot:activator="{ on }">
                <span v-on="isArchiveActionDisable ? on: null">
                    <button
                        type="button"
                        class="option open_popup"
                        @click="disableKeyArchive ? isRestrictedOn = 'cantArchive' : showDialog = true"
                        :disabled="isArchiveActionDisable"
                    >
                        <i class="icon-picto_dossier"></i>
                        {{$t(dialogText.button)}}
                    </button>
                </span>
            </template>
            <span>{{$t("key.archive.rule")}}</span>
        </v-tooltip>
        <v-dialog
            persistent
            max-width="500px"
            v-model="showDialog">
            <v-card>
                <v-card-title>
                    <div class="contain_picto">
                        <i class="icon-picto_cle-partagees"></i>
                    </div>
                    <span class="headline">{{$t(dialogText.title)}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        {{$t(dialogText.confirmation, {key: currentKey.name})}}
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="showDialog = false"
                        color="white"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-btn
                        @click="archiveKey"
                        color="warning"
                    >
                        {{$t('actions.confirm')}}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <restriction-dialog
            v-if="currentUser && currentUser.companyId"
            @close="isRestrictedOn = null"
            :type="isRestrictedOn"
        />
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";
import {canArchiveKeys} from "plan-restrictions";
import {Getter} from "vuex-class";
import RestrictionDialog from "@/components/RestrictionDialog.vue";
@Component({
    components: {
        RestrictionDialog,
    },
})
export default class KeyArchive extends Vue {

    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;

    @Prop({default: null})
    private currentKey: any;

    @Prop({})
    private updateData: () => void;

    private showDialog: boolean = false;
    private canArchiveKeys: (company: any) => boolean = canArchiveKeys;
    private disableKeyArchive: boolean = false;
    private isRestrictedOn: string = null;

    get isArchived() {
        return this.currentKey.status === "ARCHIVED";
    }

    get isArchiveActionDisable() {
        return this.currentKey.status === "IN_RELAY" || this.currentKey.status === "IN_TRANSIT";
    }

    get dialogText() {
        if (!this.isArchived) {
            return {
                button: "actions.archive",
                title: "key.archive.title",
                confirmation: "key.archive.confirmation",
                success: "alerts.key.archiveSuccess",
            };
        }
        return {
            button: "actions.unarchive",
            title: "key.unarchive.title",
            confirmation: "key.unarchive.confirmation",
            success: "alerts.key.unarchiveSuccess",
        };
    }

    private mounted() {
        this.disableKeyArchive = !this.canArchiveKeys(this.currentUser.company);
    }

    private archiveKey() {
        this.$store.dispatch("keys/archive", {keyId: this.currentKey.id})
            .then(() => {
                const successMsg = this.isArchived ? "alerts.key.archiveSuccess" : "alerts.key.unarchiveSuccess";
                this.$store.commit("alerts/displaySuccess", {
                    msg: this.$i18n?.t(successMsg, {key: this.currentKey.name}),
                });
                this.archiveKeyDone();
            }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: this.$i18n?.t(`alerts.error.${err.response.data.error}`),
            });
            this.archiveKeyDone();
        });

    }

    private archiveKeyDone() {
        this.updateData();
        this.showDialog = false;
    }
}
</script>
