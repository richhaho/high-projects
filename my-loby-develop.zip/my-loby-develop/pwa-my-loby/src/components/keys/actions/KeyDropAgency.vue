<template>
    <div v-if="((canDropOrGive && isKeyB2B) || (isAdmin && !isKeyInRelay)) && !isKeyInConnectedBox && relayHasValidClassicBox" :style="{width: mobile ? '100%':''}">
        <hr v-if="mobile"  style="margin: 0 5px 0 5px">
        <button
            style="width: inherit"
            v-if="!listView"
            :disabled="disabled"
            @click="buttonClick"
            class="action_button"
            type="button"
        >
            <span v-if="!mobile">
                <i class="icon-picto_depot-agence"></i>
                {{$t('key.actions.dropB2B')}}
            </span>
            <v-list-item-icon class="list_btn_action" v-else>
                <p class="with_key action_key">
                    <span class="rapatrier_picto">
                        <i class="icon-picto_depot-agence mobile"></i>
                    </span>
                    <strong>{{ $t('key.actions.dropB2B') }}</strong>
                </p>
            </v-list-item-icon>
        </button>
        <v-tooltip top v-else>
            <template v-slot:activator="{ on }">
                <v-btn
                    :disabled="disabled"
                    type="button"
                    class="action_button"
                    @click.stop="isKeyB2B && canAddTagAtDrop ? displayTagAddition = true : skip(true)"
                    icon
                    v-on="on"
                >
                    <span>
                        <i class="icon-picto_depot-agence mobile"></i>
                    </span>
                </v-btn>
            </template>
            <span>{{$t('key.actions.dropB2B')}}</span>
        </v-tooltip>
        <!--add tag -->
        <v-dialog
            persistent
            max-width="910px"
            v-model="displayTagAddition"
            :fullscreen="mobile"
            :hide-overlay="mobile"
            :transition="mobile ? 'dialog-bottom-transition' : ''"
        >
            <v-card>
                <v-card-title>
                    <span class="headline">{{ $t('key.actions.dropB2B') }}</span>
                </v-card-title>
                <v-spacer style="height: 15px"></v-spacer>
                <v-card-text>
                    <v-row class="mb-4">
                        <span class="input-title">
                            {{ $t('key.addTag') }}
                        </span>
                    </v-row>
                    <v-row>
                        <span
                            v-if="currentKey.Tags && currentKey.Tags.length"
                            class="input-title"
                        >
                            {{ $tc('key.currentTags', currentKey.Tags.length) }}
                        </span>
                        <v-col cols="12 pa-0">
                            <v-col cols="12 pa-0" v-if="currentKey.Tags && currentKey.Tags.length > 0">
                                <v-chip-group active-class="primary--text" column multiple>
                                    <v-chip
                                        :key="i"
                                        @click:close="remove(currentKey.Tags, tag)"
                                        :close="true"
                                        v-for="(tag, i) in currentKey.Tags"
                                    >{{ tag[lang] }}
                                    </v-chip>
                                </v-chip-group>
                            </v-col>
                            <v-autocomplete
                                :search-input.sync="searchTags"
                                v-model="currentKey.Tags"
                                :items="removeDuplicates(tags, currentKey.Tags)"
                                append-icon
                                chips
                                hide-no-data
                                no-filter
                                multiple
                                prepend-inner-icon="flag"
                                v-bind:label="$t('keysList.addTags')"
                            >
                                <template v-slot:selection="data"></template>
                                <template v-slot:item="data">
                                    <v-list-item-content>
                                        <v-list-item-title>
                                            {{ data.item[lang] }}
                                        </v-list-item-title>
                                    </v-list-item-content>
                                </template>
                            </v-autocomplete>
                        </v-col>
                    </v-row>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="skip(true)"
                        color="white"
                        text
                    >
                        {{ $t('actions.ignore') }}
                    </v-btn>
                    <v-btn
                        v-if="relay && displayConfirm"
                        :disabled="!relay"
                        :loading="loadingAdminAction"
                        @click="skip(false)"
                        color="warning"
                    >
                        {{ $t('actions.confirm') }}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <v-dialog
            persistent
            max-width="910px"
            v-model="displayAdminConfirmation"
            :fullscreen="mobile"
            :hide-overlay="mobile"
            :transition="mobile ? 'dialog-bottom-transition' : ''"
        >
            <v-card>
                <v-card-title>
                    <span class="headline">{{$t('key.actions.dropB2B')}}</span>
                </v-card-title>
                <v-card-text>
                    <v-row>
                        <v-combobox
                            v-if="relay"
                            append-icon
                            disabled
                            flat
                            hide-details
                            prepend-inner-icon="near_me"
                            solo
                            v-model="relay"
                        >
                            <template v-slot:selection="data">
                                <v-list-item-content>
                                    <v-list-item-title
                                        v-html="data.item.name"></v-list-item-title>
                                    <v-list-item-subtitle
                                        v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city"
                                    ></v-list-item-subtitle>
                                </v-list-item-content>
                            </template>
                        </v-combobox>
                        <p v-else class="mt-5">{{$t('key.noAgencyRelay')}}</p>
                    </v-row>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="displayAdminConfirmation = false"
                        color="white"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-btn
                        v-if="relay"
                        :disabled="!relay"
                        :loading="loadingAdminAction"
                        @click="dropKey(currentUser)"
                        color="warning"
                    >
                        {{$t('actions.confirm')}}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <qr-code-reader
            action="DROP"
            :location="currentKey.currentLocation"
            :key-picture="currentKey.picturePath"
            :key-description=currentKey.description
            :mobile="mobile"
            :display-qr-code-reader-modal="displayQrCodeReader"
            :read-qr-code="readQRCode"
            @close="reset"
            v-if="displayQrCodeReader"
            :qr-code-error="qrCodeReaderError"
        />
        <pin-code
            :keyId="currentKey.id"
            :key-picture=currentKey.picturePath
            :key-description=currentKey.description
            :mobile="mobile"
            :relayId="relayId"
            :relayType="relayType"
            :display-pin-pad="displayPinPad"
            :display-transaction-loader="displayTransactionLoader"
            @manual-pin="displayTransactionLoader = false"
            @qr-code-pin="displayTransactionLoader = false"
            @success="successCallback()"
            @failure="failureCallback('alerts.error.transactionDenied')"
            @close="closePinPad"
            @valid-pin="dropKey"
            v-if="displayPinPad"
        />
        <key-booked-modal
            :show="showBooked"
            :currentKey="currentKey"
            @closeModal="closeModal"
        />
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import QrCodeReader from "@/components/QrCodeReader.vue";
import PinCode from "@/components/relays/PinCode.vue";
import {Getter} from "vuex-class";
import router from "@/router";
import KeyBookedModal from "@/components/keys/KeyBookedModal.vue";

@Component({
    components: {
        QrCodeReader,
        PinCode,
        KeyBookedModal,
    },
})export default class KeyDropAgency extends Vue {

    @Prop({default: {}})
    public currentKey: any;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: false})
    public disabled: boolean;

    @Prop({})
    public updateData: () => void;

    @Prop({default: false})
    public listView: boolean;

    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;

    private displayAdminConfirmation: boolean = false;
    private displayQrCodeReader: boolean = false;
    private displayTransactionLoader: boolean = false;
    private displayTagAddition: boolean = false;
    private displayPinPad: boolean = false;
    private loadingAdminAction: boolean = false;
    private token: string = "";
    private relayId: number = null;
    private relayType: string = null;
    private qrCodeReaderError: any = null;

    private searchTags: string = null;
    private tags: any = [];
    private oldTags: any = [];
    private skipped: boolean = false;
    private showBooked: boolean = false;

    @Watch("searchTags")
    public handlerSearchTags() {
        this.getTags();
    }

    @Watch("currentKey")
    public handlerKeyChange(newVal) {
        if (newVal?.Tags) {
            this.oldTags = [...newVal?.Tags];
        }
    }

    private mounted(): void {
        this.getTags();
        if (this.currentKey?.Tags) {
            this.oldTags = [...this.currentKey?.Tags];
        }
    }

    get relay(): any {
        return this.currentKey?.Relays?.find((r) => r.type === "AGENCY");
    }

    get canAddTagAtDrop(): any {
        return this.relay?.canAddTagAtDrop;
    }

    get canDropOrGive(): boolean {
        return this.isKeyInitialized || this.isKeyUnarchived
            || ((this.currentUserHasKey || this.keyIsDropableByAnyone)
                && !this.isKeyInRelay);
    }

    get isKeyInRelay(): boolean {
        return this.currentKey?.status === "IN_RELAY";
    }

    get isKeyInConnectedBox(): boolean {
        return this.currentKey?.status === "IN_CONNECTED_BOX";
    }

    get relayHasValidClassicBox(): boolean {
        const relayBoxes = this.currentKey?.Relays?.[0]?.Boxes;
        return relayBoxes?.some((box) =>
                !box.acsesLockesystemId
                && box.columns !== 0
                && box.lines !== 0
                && box.sheets !== 0,
            );
    }

    get isKeyInitialized(): boolean {
        return this.currentKey?.status === "CREATED";
    }

    get isKeyUnarchived(): boolean {
        return this.currentKey?.status === "UNARCHIVED";
    }

    get isKeyB2B(): boolean {
        return this.currentKey?.Relays?.some((r) => r.type === "AGENCY");
    }

    get currentUserHasKey(): boolean {
        return this.currentKey?.KeyHolding?.find((kH) => !kH.endDate)?.userId === this.currentUser?.id;
    }

    get keyIsDropableByAnyone(): boolean {
        return this.currentKey?.Relays?.some((r) => r.isDropByAnyoneAuthorized);
    }

    get lang() {
        return this.$root.$i18n.locale;
    }

    get displayConfirm() {
        const newTags: boolean = this.mapIds(this.currentKey?.Tags)?.
            some((tagId) => !this.mapIds(this.oldTags)?.includes(tagId));
        const removedTags: boolean = this.mapIds(this.oldTags)?.
            some((tagId) => !this.mapIds(this.currentKey?.Tags)?.includes(tagId));
        return newTags || removedTags;
    }

    get isBookedKeyAvailable() {
        if (!this.currentKey?.currentBooking) {
            return true;
        }
        const hasRights = this.currentUser.id === this.currentKey?.currentBooking.createdBy
            || this.isManager(this.currentUser, this.currentKey)
            || this.isAdmin;
        return (
            this.currentKey?.currentBooking && hasRights)
            || (this.currentUser.id === this.currentKey?.currentBooking.userId);
    }

    private mapIds = (array) => array?.map((item) => item.id) || [];

    private removeDuplicates(completeList, duplicates): any[] | null {
        if (!completeList || !duplicates) {
            return null;
        }
        return completeList.filter(
            (item: any) =>
                !duplicates.map((elem: any) => elem?.id)?.includes(item?.id),
        );
    }

    private remove(list, item): void {
        const pos = list.map((u) => u.id).indexOf(item.id);
        list.splice(pos, 1);
    }

    private isManager = (user, key) => key?.keyManagers?.some((g) => g?.Users?.some((u) => u.id === user?.id));

    private getTags(): void {
        this.$store
            .dispatch("tags/getAll", {
                query: {
                    search: this.searchTags,
                    lang: this.lang,
                },
            })
            .then((res) => {
                this.tags = res.tags;
            });
    }

    private readQRCode(token) {
        this.token = token;
        this.qrCodeReaderError = null;
        return this.$store.dispatch("locations/qrCodeVerification", {
            token,
            keyId: this.currentKey.id,
            keyStatus: this.currentKey.status,
        }).then((res) => {
            if (res.dropped) {
                if (!this.skipped) {
                    this.updateKeyTags();
                }
                this.successCallback();
            } else if (res.validLocation) {
                this.resetQrCodeReader();
                if (res.relayType === "AGENCY" || res.relayType === "LONG_TERM") {
                    this.displayTransactionLoader = true;
                }
                this.displayPinPad = true;
                this.relayId = res.relayId;
                this.relayType = res.relayType;
            } else {
                this.qrCodeReaderError = this.$i18n.t("alerts.error." + res.errorMessage || "default");
            }
        }).catch((err) => {
            this.qrCodeReaderError = this.$i18n.t(`alerts.error.${err?.response?.data?.error || "qrCodeNotFound"}`);
        });
    }

    private resetQrCodeReader(): void {
        this.qrCodeReaderError = null;
        this.displayQrCodeReader = false;
    }

    private beforeDestroy() {
        this.resetQrCodeReader();
    }

    private  dropKey(referent: any) {
        this.loadingAdminAction = true;
        if (!this.skipped) {
             this.updateKeyTags();
        }
        this.$store.dispatch("keys/drop", {
            keyId: this.currentKey.id,
            token: this.token,
            referentId: this.isAdmin ? this.currentUser.id : referent.id,
            relayId: this.relay.id,
            holderId: this.isAdmin ? this.currentKey.KeyHolding[0]?.userId : null,
        }).then(() => this.successCallback()).catch(() => this.failureCallback());
    }

    private updateKeyTags() {
        this.currentKey.newTags = this.currentKey.Tags;
        this.currentKey.Tags = this.mapIds(this.currentKey.Tags);
        return this.$store
            .dispatch("keys/update", {
                key: this.currentKey,
                params: {
                    info: true,
                },
            });
    }

    // if user skips adding tags , updating tags method won't be called
    private skip(skipped: boolean) {
        this.isAdmin ? this.displayAdminConfirmation = true : this.displayQrCodeReader = true;
        this.displayTagAddition = false;
        this.skipped = skipped;
    }

    private successCallback(): void {
        this.$store.commit("alerts/displaySuccess", {
            icon: "icon-picto_depot-agence",
            msg: this.$i18n?.t("alerts.key.dropSuccess", {
                key: this.currentKey.name,
                relay: this.relay.name,
            }),
        });
        this.dropKeyDone();

    }

    private failureCallback(err?: string): void {
        this.$store.commit("alerts/displayError", {
            icon: "icon-picto_depot-agence",
            msg: this.$i18n?.t(err || "alerts.error.default"),
        });
        this.dropKeyDone();
    }

    private dropKeyDone() {
        this.displayQrCodeReader = false;
        if (this.mobile || this.listView) {
            this.updateData();
        } else {
            router.push({name: "keys"});
        }
    }

    private reset() {
        this.resetQrCodeReader();
        this.displayAdminConfirmation = false;
        this.updateData();
    }

    private buttonClick() {
        if (this.currentKey.currentBooking && !this.isBookedKeyAvailable) {
            return this.showBooked = true;
        }
        return this.isKeyB2B && this.canAddTagAtDrop ? this.displayTagAddition = true : this.skip(true);
    }

    private closeModal() {
        this.showBooked = false;
    }

    private closePinPad() {
        this.displayPinPad = false;
        this.updateData();
    }
}
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
    .v-autocomplete__content .v-list{
        max-height: 200px;
    }
</style>
