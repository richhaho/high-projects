<template>
    <div v-if="(canDropInFlowRelay && canDropOrGive) || (isAdmin && !isKeyInRelay)" :style="{width: mobile ? '100%':''}">
        <hr v-if="mobile"  style="margin: 0 5px 0 5px">
        <button
            style="width: inherit"
            :disabled="disabled"
            @click="openDialog"
            class="action_button"
            type="button"
        >
            <span v-if="!mobile">
                <i class="icon-picto_depot-myloby"></i>
                {{isKeyB2B ? $t('key.actions.dropB2C') : $t('key.actions.drop.button')}}
            </span>
            <v-list-item-icon class="list_btn_action" v-else>
              <p class="with_key action_key">
                    <span class="rapatrier_picto">
                    <i class="icon-picto_depot-myloby mobile"></i>
                    </span>
                <strong>{{isKeyB2B ? $t('key.actions.dropB2C') : $t('key.actions.drop.button')}}</strong>
              </p>
            </v-list-item-icon>
        </button>
        <v-dialog
            persistent
            max-width="910px"
            v-model="dropKeyB2BinFlowRelayDialog" v-if="isKeyB2B"
            :fullscreen="mobile"
            hide-overlay
            :transition="mobile?'dialog-bottom-transition' : ''">
            <v-card>
                <v-card-title>
                    <span class="headline">{{$t('key.actions.dropB2C')}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-row v-if="keyFlowRelays.length">
                            <v-col cols="12">
                                {{$t('key.dropB2C.overcharge')}}
                            </v-col>
                            <v-col cols="12">
                                <v-data-table
                                    :headers="[
                                        {value: 'name', sortable: true},
                                        {value: 'address', sortable: true},
                                    ]"
                                    :items="keyFlowRelays"
                                    item-key="id"
                                    item-value="id"
                                    show-select
                                    single-select
                                    :hide-default-header="mobile"
                                    v-model="selected"
                                    hide-default-footer
                                    hide-default-pagination
                                    @click:row="selectRelay"
                                >
                                    <template v-slot:header.name="{ header }">
                                        {{ $t('relay.name') }}
                                    </template>
                                    <template v-slot:header.address="{ header }">
                                        {{ $t('relay.address') }}
                                    </template>
                                    <template v-slot:item.address="{ item }">
                                        {{ item.address }} - {{ item.city }} ({{ item.zipCode }})
                                    </template>
                                </v-data-table>
                            </v-col>
                        </v-row>
                        <v-row v-else>
                            <v-col cols="12">
                                {{isManager(currentUser, currentKey)
                                ? $t('key.dropB2C.noRelay.manager')
                                : $t('key.dropB2C.noRelay.guest')}}
                            </v-col>
                        </v-row>
                        <v-row v-if="isManager(currentUser, currentKey)">
                            <v-col cols="12">
                                {{$t('key.dropB2C.addRelay')}}
                            </v-col>
                            <v-col cols="12">
                                <v-autocomplete
                                    :item-text="itemStringified"
                                    item-value="id"
                                    :items="flowRelays"
                                    :search-input.sync="searchFlowRelays"
                                    append-icon
                                    flat
                                    :loading="loadingRelays"
                                    no-filter
                                    hide-details
                                    :no-data-text="$t('keysList.noRelayFound')"
                                    prepend-inner-icon="near_me"
                                    solo
                                    v-bind:label="$t('actions.search')"
                                    v-model="newFlowRelayId"
                                    clearable
                                >
                                    <template v-slot:selection="data">
                                        <v-list-item-content>
                                            <v-list-item-title
                                                v-html="data.item.name">
                                            </v-list-item-title>
                                            <v-list-item-subtitle
                                                v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city">
                                            </v-list-item-subtitle>
                                        </v-list-item-content>
                                    </template>
                                    <template v-slot:item="data">
                                        <v-list-item-content :aria-disabled="!data.item.available">
                                            <v-list-item-title
                                                v-html="data.item.name">
                                            </v-list-item-title>
                                            <v-list-item-subtitle
                                                v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city">
                                            </v-list-item-subtitle>
                                        </v-list-item-content>
                                    </template>
                                </v-autocomplete>
                            </v-col>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="dropKeyB2BinFlowRelayDialog = false"
                        color="white"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-btn
                        v-if="(keyFlowRelays.length || isManager(currentUser, currentKey)) && selectedFlowRelay"
                        @click="dropKeyB2BinFlowRelay"
                        color="warning"
                    >
                        {{$t('actions.validate')}}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <v-dialog
            persistent
            max-width="500px"
            v-model="dropKeyB2CAdminDialog"
            v-if="isAdmin"
            :fullscreen="mobile"
            hide-overlay
            :transition="mobile?'dialog-bottom-transition' : ''">
            <v-card>
                <v-card-title>
                    <span class="headline">{{$t('key.actions.dropB2C')}}</span>
                </v-card-title>
                <v-card-text>
                    <v-row>
                        <v-combobox
                            v-if="keyFlowRelays[0]"
                            append-icon
                            disabled
                            flat
                            hide-details
                            prepend-inner-icon="near_me"
                            solo
                            v-model="keyFlowRelays[0]"
                        >
                            <template v-slot:selection="data">
                                <v-list-item-content>
                                    <v-list-item-title
                                        v-html="data.item.name"></v-list-item-title>
                                    <v-list-item-subtitle
                                        v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city"
                                    ></v-list-item-subtitle>
                                </v-list-item-content>
                            </template>
                        </v-combobox>
                        <p v-else class="mt-5">{{$t('key.noAgencyRelay')}}</p>
                    </v-row>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="dropKeyB2CAdminDialog = false"
                        color="white"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-btn
                        v-if="keyFlowRelays[0]"
                        @click="dropKeyB2CAdmin"
                        color="warning"
                        :disabled="!keyFlowRelays[0]"
                        :loading="loadingAdminAction"
                    >
                        {{$t('actions.validate')}}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <qr-code-reader
            action="DROP"
            :location="keyLocation"
            :key-picture="currentKey.picturePath"
            :key-description="relayType === 'AGENCY' ? currentKey.description : null"
            :mobile="mobile"
            :display-qr-code-reader-modal="displayQrCodeReader"
            :read-qr-code="readQRCode"
            @close="displayQrCodeReader = false"
            v-if="displayQrCodeReader"
            :qr-code-error="qrCodeReaderError"
        />
        <pin-code
            :keyId="currentKey.id"
            :key-picture="currentKey.picturePath"
            :key-description="relayType === 'AGENCY' ? currentKey.description : null"
            :mobile="mobile"
            :relayId="relayId"
            :relayType="relayType"
            :display-transaction-loader="displayTransactionLoader"
            @manual-pin="displayTransactionLoader = false"
            @qr-code-pin="displayTransactionLoader = false"
            @update-data="updateData()"
            @success="successCallback()"
            @failure="failureCallback('alerts.error.transactionDenied')"
            @close="displayPinPad = false"
            @valid-pin="dropKey"
            :display-pin-pad="displayPinPad"
            v-if="displayPinPad"
        />
        <simple-dialog
            :dialog="displayValidationModal"
            :title="$t('key.actions.drop.done.text', {date: $options.filters.formatDate(new Date())})"
            :text="$t('key.showScreenReferent')"
            :actions="['close']"
            @close="dropKeyDone"
        />
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import QrCodeReader from "@/components/QrCodeReader.vue";
import PinCode from "@/components/relays/PinCode.vue";
import SimpleDialog from "@/components/SimpleDialog.vue";
import {Getter} from "vuex-class";
import router from "@/router";
import {canUseFlowRelays} from "plan-restrictions";
import Timeout = NodeJS.Timeout;

export const DEBOUNCE_TIME_MILLI: number = 500;

@Component({
    components: {
        QrCodeReader,
        PinCode,
        SimpleDialog,
    },
})export default class KeyDropMyLoby extends Vue {

    get keyFlowRelays() {
        return this.currentKey?.Relays?.filter((r) => r.type === "FLOW");
    }

    @Prop({default: {}})
    public currentKey: any;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: false})
    public disabled: boolean;

    @Prop({})
    public updateData: () => void;
    @Getter private currentUser: any;
    @Getter private isB2B: boolean;
    @Getter private isAdmin: boolean;

    private canUseFlowRelays: (company: any) => boolean = canUseFlowRelays;
    private dropKeyB2BinFlowRelayDialog: boolean = false;
    private displayQrCodeReader: boolean = false;
    private displayTransactionLoader: boolean = false;
    private displayPinPad: boolean = false;
    private displayValidationModal: boolean = false;
    private loadingAdminAction: boolean = false;
    private token: string = "";
    private relayId: number = null;
    private relayType: string = null;
    private flowRelays: any[] = [];
    private selected: any[] = [];
    private loadingRelays: boolean = false;
    private timerId: Timeout = null;
    private searchFlowRelays: string = null;
    private newFlowRelayId: number = null;
    private dropKeyB2CAdminDialog: boolean = false;
    private qrCodeReaderError: any = null;

    @Watch("searchFlowRelays", {deep: true})
    public handlerSearchFlowRelays(newVal: string) {
        if (newVal) {
            this.searchRelays();
        }
    }

    get canDropOrGive(): boolean {
        return this.isKeyInitialized || this.isKeyUnarchived || (this.currentUserHasKey && !this.isKeyInRelay);
    }

    get canDropInFlowRelay(): boolean {
        return !this.isB2B || this.canUseFlowRelays(this.currentUser?.company);
    }

    get keyLocation(): any {
        return this.currentKey.currentLocation || this.currentKey.ReservedLocations[0];
    }

    get isKeyInRelay(): boolean {
        return this.currentKey?.status === "IN_RELAY";
    }

    get isKeyInitialized(): boolean {
        return this.currentKey?.status === "CREATED";
    }

    get isKeyUnarchived(): boolean {
        return this.currentKey?.status === "UNARCHIVED";
    }

    get isKeyB2B(): boolean {
        return this.currentKey?.Relays?.some((r) => r.type === "AGENCY");
    }

    get currentUserHasKey(): boolean {
        return this.currentKey?.KeyHolding?.find((kH) => !kH.endDate)?.userId === this.currentUser?.id;
    }

    private openDialog() {
        if (this.isKeyB2B) {
            this.getRelays();
            this.dropKeyB2BinFlowRelayDialog = true;
        } else if (this.isAdmin) {
            this.dropKeyB2CAdminDialog = true;
        } else {
            this.displayQrCodeReader = true;
        }
    }

    // check if one of the user of one of the management groups match the current user
    private isManager = (user, key) => key?.keyManagers
    ?.some((g) => g?.Users?.some((u) => u.id === user?.id)) || key.ownerId === user?.id

    get selectedFlowRelay() {
        return this.newFlowRelayId || this.selected?.[0]?.id;
    }

    private selectRelay(relay: any) {
        this.selected = [relay];
    }

    private async dropKeyB2BinFlowRelay() {
        this.dropKeyB2BinFlowRelayDialog = false;
        // Flow relay is either a new flow relay chosen by the user,
        // or the one selected by the user among flow relays chosen by managers
        const flowRelayId = this.selectedFlowRelay;
        if (!this.keyFlowRelays.map((r) => r.id).includes(flowRelayId)) {
            this.currentKey.Relays.push({id: flowRelayId});
            await this.$store.dispatch("keys/update", {key: this.currentKey, params: {relays: true}});
        }
        return this.$store.dispatch("relays/reserveLocation", {
            relayId: flowRelayId,
            keyId: this.currentKey.id,
        }).then((res) => {
            this.currentKey.currentLocation = res;
            if (this.isAdmin) {
                this.relayId = flowRelayId;
                this.dropKey(this.currentUser);
            } else {
                this.displayQrCodeReader = true;
            }

        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private searchRelays(): void {
        this.loadingRelays = true;
        // cancel pending call
        clearTimeout(this.timerId);
        // delay new call
        this.timerId = setTimeout(() => {
            this.getRelays().then(() => {
                this.loadingRelays = false;
            });
        }, DEBOUNCE_TIME_MILLI);
    }

    private getRelays(): Promise<any> {
        return this.$store.dispatch("relays/getAll", {
            query: {
                search: this.searchFlowRelays,
                type: "FLOW",
                available: true,
                itemsPerPage: 10,
            },
        }).then((res) => {
            this.flowRelays = res?.relays || [];
        });
    }

    private readQRCode(token) {
        this.token = token;
        this.qrCodeReaderError = null;
        return this.$store.dispatch("locations/qrCodeVerification", {
            token,
            keyId: this.currentKey.id,
            keyStatus: this.currentKey.status,
        }).then((res) => {
            if (res.dropped) {
                this.successCallback();
            } else if (res.validLocation) {
                this.displayQrCodeReader = false;
                if (res.relayType === "AGENCY" || res.relayType === "LONG_TERM") {
                    this.displayTransactionLoader = true;
                }
                this.displayPinPad = true;
                this.relayId = res.relayId;
                this.relayType = res.relayType;
            } else {
                this.qrCodeReaderError = this.$i18n.t("alerts.error." + res.errorMessage || "default");
            }
        }).
        catch((err) => {
            this.qrCodeReaderError = this.$i18n.t(`alerts.error.${err?.response?.data?.error || "qrCodeNotFound"}`);
        });
    }

    private dropKeyB2CAdmin() {
        this.relayId = this.keyFlowRelays[0].id;
        this.dropKey(this.currentUser);
    }

    private dropKey(referent: any, way?: string) {
        this.loadingAdminAction = true;
        this.$store.dispatch("keys/drop", {
            keyId: this.currentKey.id,
            token: this.token,
            referentId: referent.id,
            relayId: this.relayId,
            holderId: this.isAdmin ? this.currentKey.KeyHolding[0]?.userId || null : null,
        }).
        then(() => this.successCallback(way)).
        catch(() => this.failureCallback());
    }

    private successCallback(way?: string): void {
        if (way === "qrCodePin") {
            this.displayValidationModal = true;
        } else {
            this.$store.commit("alerts/displaySuccess", {
                icon: "icon-picto_depot-myloby",
                msg: this.$i18n?.t("alerts.key.dropSuccess", {
                    key: this.currentKey.name,
                    relay: this.keyLocation.Box?.Relay?.name || this.currentKey.Relays[0]?.name,
                }),
            });
            this.dropKeyDone();
        }
    }

    private failureCallback(err?: string): void {
        this.$store.commit("alerts/displayError", {
            icon: "icon-picto_depot-myloby",
            msg: this.$i18n?.t(err || "alerts.error.default"),
        });
        this.dropKeyDone();
    }

    private dropKeyDone() {
        this.displayValidationModal = false;
        if (this.mobile) {
            this.updateData();
        } else {
            router.push({name: "keys"});
        }
    }

    private itemStringified = (item) => JSON.stringify(item);
}
</script>
