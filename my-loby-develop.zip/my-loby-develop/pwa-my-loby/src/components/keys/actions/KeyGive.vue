<template>
    <div v-if="isAdmin">
        <button
            :disabled="disabled"
            type="button"
            class="action_button"
            @click="showDialog = true"
        >
            <span>
                <i class="icon-picto_cle-remise"></i>
                {{$t('key.actions.give')}}
            </span>
        </button>
        <v-dialog
            persistent
            max-width="910px"
            v-model="showDialog"
            :fullscreen="mobile"
            :hide-overlay="mobile"
            :transition="mobile ? 'dialog-bottom-transition' : ''"
        >
            <v-card>
                <v-card-title>
                    <span class="headline">{{$t('key.actions.give')}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-row>
                            <v-autocomplete
                                :items="guestsAndReferents"
                                v-model="selectedUser"
                            >
                                <template v-slot:selection="data">
                                    <v-list-item-avatar>
                                        <img :src="getUserGroupPicture(data.item)" alt="">
                                    </v-list-item-avatar>
                                    <v-list-item-content>
                                        <v-list-item-title v-if="data.item.id">
                                            {{ data.item.name || data.item.Users[0].displayName }}
                                        </v-list-item-title>
                                        <v-list-item-title v-else>
                                            {{data.item}}
                                        </v-list-item-title>
                                        <v-list-item-subtitle
                                            v-html="data.item.company"></v-list-item-subtitle>
                                    </v-list-item-content>
                                </template>
                                <template v-slot:item="data">
                                    <v-list-item-avatar>
                                        <img :src="getUserGroupPicture(data.item)" alt="">
                                    </v-list-item-avatar>
                                    <v-list-item-content>
                                        <v-list-item-title v-if="data.item.id">
                                            {{ data.item.name || data.item.Users[0].displayName }}
                                        </v-list-item-title>
                                        <v-list-item-title v-else>
                                            {{data.item}}
                                        </v-list-item-title>
                                        <v-list-item-subtitle
                                            v-html="data.item.company"></v-list-item-subtitle>
                                    </v-list-item-content>
                                </template>
                            </v-autocomplete>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="showDialog = false"
                        color="white"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-btn
                        @click="giveKey"
                        :loading="loadingAdminAction"
                        color="warning"
                        v-if="selectedUser"
                    >
                        {{$t('actions.confirm')}}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";
import {defaultUserAvatar, defaultUserGroupAvatar} from "@/utils/constants";
import {Getter} from "vuex-class";
import router from "@/router";
import {getSrc} from "@/utils/misc";

@Component({})
export default class KeyGive extends Vue {

    get guestsAndReferents() {
        return this.currentKey?.keyManagers?.concat(this.currentKey.guests);
    }

    @Prop({default: {}})
    public currentKey: any;

    @Prop({default: false})
    public disabled: boolean;

    @Prop({})
    public updateData: () => void;
    @Getter private isAdmin: boolean;

    @Prop({default: false})
    private mobile: boolean;

    private showDialog: boolean = false;
    private selectedUser: any = null;
    private defaultUserAvatar: string = defaultUserAvatar;
    private defaultUserGroupAvatar: string = defaultUserGroupAvatar;
    private getSrc: (string) => string = getSrc;
    private loadingAdminAction: boolean = false;

    private giveKey() {
        this.loadingAdminAction = true;
        this.$store.dispatch("keys/retrieve", {
            keyId: this.currentKey.id,
            userId: this.selectedUser.Users[0].id,
        }).then(() => {
            this.$store.commit("alerts/displaySuccess", {
                icon: "icon-picto_rapatrier",
                msg: this.$i18n?.t("alerts.key.giveSuccess", {
                    key: this.currentKey.name,
                    user: this.selectedUser.Users[0].displayName,
                }),
            });
            if (this.mobile) {
                this.updateData();
            } else {
                router.push({name: "keys"});
            }
        });
    }

    private getUserGroupPicture(group: any) {
        return group?.Users?.length === 1
            ? this.getSrc(group.Users[0].picturePath) || this.defaultUserAvatar
            : this.defaultUserGroupAvatar;
    }

}
</script>