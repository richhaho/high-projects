<template>
    <div v-if="canRetrieveKey"  :style="{width: mobile ? '100%':''}">
        <hr v-if="mobile" style="margin: 0 5px 0 5px">
        <button
            style="width: inherit"
            :disabled="disabled"
            type="button"
            class="action_button"
            @click="retrieveDialog = true"
        >
            <span v-if="!mobile">
                <i class="icon-picto_rapatrier"></i>
                {{ $t('key.actions.retrieve') }}
            </span>
            <v-list-item-icon class="list_btn_action" v-else>
                <p class="with_key action_key">
                  <span class="rapatrier_picto">
                        <i class="icon-picto_rapatrier mobile"></i>
                    </span>
                    <strong>{{ $t('key.actions.retrieve') }}</strong>
                </p>
            </v-list-item-icon>
        </button>
        <v-dialog
            persistent
            max-width="500px"
            v-model="retrieveDialog"
            :fullscreen="mobile"
            :hide-overlay="mobile"
            :transition="mobile ? 'dialog-bottom-transition' : ''"
        >
            <v-card v-if="currentKey">
                <v-card-title>
                    <span class="headline">{{ $t('key.retrieve.title') }}</span>
                </v-card-title>
                <v-card-text class="py-0">
                    <v-container>
                        <v-row>
                            <h5>{{ $t('title.warning') }}</h5>
                        </v-row>
                        <v-row>
                            <p>{{ $t('key.retrieve.text') }}</p>
                        </v-row>
                        <v-row>
                            <v-col class="pa-0" cols="12">
                                <v-checkbox
                                    class="ma-0 mb-4"
                                    color="orange"
                                    hide-details
                                    v-bind:label="$t('actions.confirm')"
                                    v-model="confirmRetrieve"
                                    value="true"
                                ></v-checkbox>
                            </v-col>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="retrieveDialog = false"
                        color="white"
                        text
                    >
                        {{ $t('actions.cancel') }}
                    </v-btn>
                    <v-btn
                        @click="retrieveKey"
                        color="warning"
                        v-if="confirmRetrieve"
                        :loading="loading"
                        :disabled="!confirmRetrieve"
                    >
                        {{ $t('actions.confirm') }}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";
import {Getter} from "vuex-class";
import router from "@/router";

@Component
export default class KeyRetrieve extends Vue {

    @Prop({default: {}})
    public currentKey: any;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: false})
    public disabled: boolean;

    @Prop({})
    public updateData: () => void;
    @Getter private currentUser: any;

    private retrieveDialog: boolean = false;
    private confirmRetrieve: boolean = false;
    private loading: boolean = false;

    get canRetrieveKey(): boolean {
        return ((this.isManager || this.isMaster)
            && !this.currentUserHasKey
            && !this.isKeyInRelay);
    }

    get currentUserHasKey(): boolean {
        return this.currentKey?.KeyHolding?.find((kH) => !kH.endDate)?.userId === this.currentUser?.id;
    }

    get isKeyInRelay(): boolean {
        return this.currentKey?.status === "IN_RELAY";
    }

    // check if one of the user of one of the management groups match the current user
    get isManager(): boolean {
        return this.currentKey?.keyManagers?.some((g) => g?.Users?.some((u) => u.id === this.currentUser?.id))
            && this.currentKey?.status !== "IN_CONNECTED_BOX";
    }

    get isMaster(): boolean {
        return this.currentKey.ownerId === this.currentUser?.id;
    }

    private retrieveKey() {
        this.loading = true;
        this.$store.dispatch("keys/retrieve", {
            keyId: this.currentKey.id,
            userId: this.currentUser.id,
        }).then(() => {
            this.$store.commit("alerts/displaySuccess", {
                icon: "icon-picto_rapatrier",
                msg: this.$i18n?.t("alerts.key.retrieveSuccess", {key: this.currentKey.name}),
            });
            this.keyRetrieveDone();
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                icon: "icon-picto_rapatrier",
                msg: this.$i18n?.t("alerts.error.default"),
            });
            this.keyRetrieveDone();
        });
    }

    private keyRetrieveDone() {
        this.loading = false;
        this.retrieveDialog = false;
        this.updateData();
    }
}
</script>
