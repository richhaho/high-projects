<template>
    <v-dialog
        persistent
        v-model="displayChooseHour"
        max-width="500px"
    >
        <v-card>
            <v-card-title style="word-break: normal;">
                <span class="headline">{{ $t('key.actions.chooseReturnDate') }}</span>
            </v-card-title>
            <v-spacer style="height: 15px"></v-spacer>
            <v-card-text>
                <v-row>
                    <v-col>
                        <v-text-field
                            type="number"
                            v-model.number="numberToAdd"
                            min="0"
                            pattern="[0-9]*"
                            inputmode="numeric"
                            hide-details
                            solo
                            @focus="$event.target.select()"
                        >
                        </v-text-field>

                    </v-col>
                    <v-col>
                        <v-select
                            :items="items"
                            v-model="unite"
                            hide-details
                            item-text="text"
                            item-value="label"
                            solo
                            @change="value=>changeValue(value)"
                        ></v-select>
                    </v-col>
                </v-row>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    color="white"
                    text
                    @click="cancel"
                >
                    {{ $t('actions.cancel') }}
                </v-btn>
                <v-btn
                    color="warning"
                    v-if="numberToAdd > 0"
                    @click="validate"
                >
                    {{ $t('actions.confirm') }}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";
import moment from "moment";
@Component({
    components: {},
})
export default class KeyReturningDate extends Vue {
    @Prop({default: false})
    public displayChooseHour: boolean;

    @Prop({default: null})
    public initalDate: any;

    private unite: any = {label: "h", text: "Hours"};
    private uniteToAdd: any = "h";
    private numberToAdd: any = 0;

    get items(): object[] {
        return [
            {
                label: "m",
                text: this.$tc("countDown.minutes", this.numberToAdd),
            },
            {
                label: "h",
                text: this.$tc("countDown.hours", this.numberToAdd),
            },
            {
                label: "d",
                text: this.$tc("countDown.days", this.numberToAdd),
            },
            {
                label: "w",
                text: this.$tc("countDown.weeks", this.numberToAdd),
            },
        ];
    }

    private validate() {
        let newTime: any;
        if (this.initalDate) {
            newTime = moment(this.initalDate).add(this.numberToAdd, this.uniteToAdd);
        } else {
            newTime = moment().add(this.numberToAdd, this.uniteToAdd);
        }
        this.$emit("validTime", newTime?.format("YYYY-MM-DDTHH:mm:ss"));
    }

    private changeValue(value) {
        this.uniteToAdd = value;
    }

    private cancel() {
        this.$emit("cancel");
    }

}
</script>
