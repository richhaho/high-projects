<template>
    <div v-if="(canTransitKey && isKeyB2B) || (isAdmin && !isKeyInRelay)" :style="{width: mobile ? '100%':''}">
        <hr v-if="mobile" style="margin: 0 5px 0 5px">
        <button
            style="width: inherit"
            :disabled="disabled"
            type="button"
            class="action_button"
            @click="transitDialog = true"
        >
            <span v-if="!mobile">
                <i class="icon-picto_transit"></i>
                {{$t('key.actions.transit')}}
            </span>
            <v-list-item-icon v-else class="list_btn_action">
                <p class="with_key action_key">
                    <span class="rapatrier_picto">
                        <i class="icon-picto_transit mobile"></i>
                    </span>
                    <strong>{{ $t('key.actions.transit') }}</strong>
                </p>
            </v-list-item-icon>
        </button>
        <v-dialog
            persistent
            max-width="500px"
            v-model="transitDialog"
            :fullscreen="mobile"
            :hide-overlay="mobile"
            :transition="mobile ? 'dialog-bottom-transition' : ''"
        >
            <v-card>
                <v-card-title>
                    <span class="headline">{{$t('key.transit.title')}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-row>
                            <v-combobox
                                append-icon
                                disabled
                                flat
                                hide-details
                                prepend-inner-icon="near_me"
                                solo
                                :value="keyReferenceAgency"
                            >
                                <template v-slot:selection="data">
                                    <v-list-item-content style="overflow: initial;">
                                        <v-list-item-title
                                            v-html="data.item.name"></v-list-item-title>
                                        <v-list-item-subtitle
                                            v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city"
                                        ></v-list-item-subtitle>
                                    </v-list-item-content>
                                </template>
                            </v-combobox>
                        </v-row>
                        <v-row>
                            {{$t('key.transit.text')}}
                        </v-row>
                        <v-row>
                            <v-col class="pa-0" cols="12">
                                <v-checkbox
                                    color="orange"
                                    hide-details
                                    v-bind:label="$t('key.transit.mode.POSTAL_BOX')"
                                    v-model="currentKey.transitMode"
                                    value="POSTAL_BOX"
                                ></v-checkbox>
                            </v-col>
                            <v-col class="pa-0" cols="12">
                                <v-checkbox
                                    color="orange"
                                    hide-details
                                    v-bind:label="$t('key.transit.mode.MAILING')"
                                    v-model="currentKey.transitMode"
                                    value="MAILING"
                                ></v-checkbox>
                            </v-col>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="transitDialog = false"
                        color="white"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-btn
                        v-if="currentKey.transitMode"
                        :loading="loadingAction"
                        @click="transitKey"
                        color="warning"
                    >
                        {{$t('actions.confirm')}}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";
import router from "@/router";
import {Getter} from "vuex-class";

@Component
export default class KeyTransit extends Vue {

    @Prop({default: {}})
    public currentKey: any;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: false})
    public disabled: boolean;

    @Prop({})
    public updateData: () => void;

    @Getter private isAdmin: boolean;
    @Getter private currentUser: any;

    private transitDialog: boolean = false;
    private loadingAction: boolean = false;

    get canTransitKey(): boolean {
        return this.keyReferenceAgency?.isTransitAuthorized
        && this.canDropOrGive
        && this.isKeyB2B;
    }

    get canDropOrGive(): boolean {
        return this.isKeyInitialized || this.isKeyUnarchived || (this.currentUserHasKey && !this.isKeyInRelay);
    }

    get currentUserHasKey(): boolean {
        return this.currentKey?.KeyHolding?.find((kH) => !kH.endDate)?.userId === this.currentUser?.id;
    }

    get isKeyInRelay(): boolean {
        return this.currentKey?.status === "IN_RELAY";
    }

    get isKeyInitialized(): boolean {
        return this.currentKey?.status === "CREATED";
    }

    get isKeyUnarchived(): boolean {
        return this.currentKey?.status === "UNARCHIVED";
    }

    get isKeyB2B(): boolean {
        return this.currentKey?.Relays?.some((r) => r.type === "AGENCY");
    }

    get keyReferenceAgency(): any {
        return this.currentKey?.Relays?.find((r) => r.type === "AGENCY");
    }

    private mounted() {
        this.loadingAction = false;
    }

    private transitKey() {
        this.loadingAction = true;
        this.$store.dispatch("keys/transit", {
            keyId: this.currentKey.id,
            sourceUserId: this.currentUser.id,
            targetRelayId: this.keyReferenceAgency?.id,
            transitMode: this.currentKey.transitMode,
        }).then(() => {
            this.$store.commit("alerts/displaySuccess", {
                icon: "icon-picto_transit",
                msg: this.$i18n?.t("alerts.key.transitSuccess", {key: this.currentKey.name,
                    relay: this.keyReferenceAgency?.name}),
            });
            this.dropKeyDone();
        }).catch(() => {
            this.$store.commit("alerts/displayError", {
                icon: "icon-picto_transit",
                msg: this.$i18n?.t("alerts.error.default"),
            });
            this.dropKeyDone();
        });
    }

    private dropKeyDone() {
        this.loadingAction = false;
        if (this.mobile) {
            this.updateData();
        } else {
            router.push({name: "keys"});
        }
    }
}
</script>
