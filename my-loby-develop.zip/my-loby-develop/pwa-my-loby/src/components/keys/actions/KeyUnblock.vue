<template>
    <div>
        <button type="button" class="action_button"
                @click="showDialog = true">
            <span>
                 <i class="icon-picto_cle-partagees" />
                {{$t(dialogText.button)}}
            </span>
        </button>
        <v-dialog
            persistent
            max-width="500px"
            v-model="showDialog"
            :fullscreen="mobile"
            :hide-overlay="mobile"
            :transition="mobile ? 'dialog-bottom-transition' : ''"
        >
            <v-card>
                <v-card-title>
                    <div class="contain_picto">
                        <i class="icon-picto_cle-partagees"></i>
                    </div>
                    <span class="headline">{{$t(dialogText.title)}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        {{$t(dialogText.confirmation, {key: currentKey.name})}}
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="showDialog = false"
                        color="white"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-btn
                        @click="unblockKey"
                        color="warning"
                    >
                        {{$t('actions.confirm')}}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>

</template>

<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";
import router from "@/router";
@Component({
})
export default class KeyUnblock extends Vue {

    get unblockAction() {
        return !this.currentKey.hasAllRights;
    }

    get dialogText() {
        if (this.unblockAction) {
            return {
                button: "key.actions.unblock",
                title: "key.unblock.title",
                confirmation: "key.unblock.confirmation",
                success: "alerts.key.blockSuccess",
            };
        }
        return {
            button: "key.actions.block",
            title: "key.block.title",
            confirmation: "key.block.confirmation",
            success: "alerts.key.blockSuccess",
        };
    }

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: null})
    private currentKey: any;

    @Prop({})
    private updateData: () => void;

    private showDialog: boolean = false;

    private unblockKey() {
        this.$store.dispatch("keys/unblock", {keyId: this.currentKey.id})
            .then(() => {
                this.$store.commit("alerts/displaySuccess", {
                    msg: this.$i18n?.t(this.dialogText.success, {key: this.currentKey.name}),
                });
                this.unblockKeyDone();
            }).catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: this.$i18n?.t("alerts.error.default"),
                });
                this.unblockKeyDone();
        });

    }

    private unblockKeyDone() {
        this.updateData();
        this.showDialog = false;
    }

}
</script>