<template>
    <div v-if="canWithdraw(currentUser, currentKey)" :style="{width: mobile ? '100%':''}">
        <hr v-if="mobile" style="margin: 0 5px 0 5px">
        <button
            v-if="!listView"
            style="width: inherit"
            :disabled="disabled"
            type="button"
            class="action_button"
            @click="buttonClick"
        >
            <span v-if="!mobile">
                <i :class="withdrawIcon"></i>
                {{ $t('key.actions.withdraw.button') }}
            </span>
            <v-list-item-icon v-else class="list_btn_action">
                <p class="with_key action_key">
                    <span class="rapatrier_picto">
                        <i :class="withdrawIcon"></i>
                    </span>
                    <strong>{{$t('key.actions.withdraw.button')}}</strong>
                </p>
            </v-list-item-icon>
        </button>
        <v-tooltip top v-else>
            <template v-slot:activator="{ on }">
                <v-btn
                    :disabled="disabled"
                    type="button"
                    class="action_button"
                    @click.stop="canGuestChooseReturnHour ? displayChooseHour = true : displayQrCodeReader = true"
                    icon
                    v-on="on"
                >
                    <span v-if="!mobile">
                        <i :class="withdrawIcon"></i>
                    </span>
                </v-btn>
            </template>
            <span>{{$t('key.actions.withdraw.button')}}</span>
        </v-tooltip>
        <key-returning-date
            ref="returningDate"
            :displayChooseHour="displayChooseHour"
            v-if="displayChooseHour && canGuestChooseReturnHour"
            @validTime="validateTime"
            @cancel="displayChooseHour=false"
        />
        <qr-code-reader
            v-if="displayQrCodeReader"
            :location="currentKey.currentLocation"
            :key-picture="currentKey.picturePath"
            :key-description="currentKey.description"
            :read-qr-code="readQRCode"
            :mobile="mobile"
            @close="resetQrCodeReader"
            :display-qr-code-reader-modal="displayQrCodeReader"
            :qr-code-error="qrCodeReaderError"
        />
        <pin-code
            v-if="displayPinPad"
            :keyId="currentKey.id"
            :key-picture="currentKey.picturePath"
            :key-description="currentKey.description"
            :relayId="relayId"
            :relayType="relayType"
            :display-transaction-loader="displayTransactionLoader"
            @manual-pin="displayTransactionLoader = false"
            @qr-code-pin="displayTransactionLoader = false"
            @success="successCallback()"
            @failure="failureCallback('alerts.error.transactionDenied')"
            @valid-pin="withdrawKey"
            :mobile="mobile"
            :display-pin-pad="displayPinPad"
            @close="displayPinPad = false"
        />
        <simple-dialog
            :dialog="displayValidationModal"
            :title="$t('key.actions.withdraw.done.text', {date: $options.filters.formatDate(new Date())})"
            :text="$t('key.showScreenReferent')"
            :actions="['close']"
            @close="dropKeyDone"
        />
        <key-booked-modal
            :show="showBooked"
            :currentKey="currentKey"
            @closeModal="closeModal"
        />
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";
import QrCodeReader from "@/components/QrCodeReader.vue";
import PinCode from "@/components/relays/PinCode.vue";
import SimpleDialog from "@/components/SimpleDialog.vue";
import moment from "moment";
import {Getter} from "vuex-class";
import router from "@/router";
import KeyReturningDate from "@/components/keys/actions/KeyReturningDate.vue";
import KeyBookedModal from "@/components/keys/KeyBookedModal.vue";

@Component({
    components: {
        KeyReturningDate,
        QrCodeReader,
        PinCode,
        SimpleDialog,
        KeyBookedModal,
    },
})export default class KeyWithdraw extends Vue {

    @Prop({default: {}})
    public currentKey: any;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: false})
    public listView: boolean;

    @Prop({default: false})
    public disabled: boolean;

    @Prop({})
    public updateData: () => void;
    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;

    private displayQrCodeReader: boolean = false;
    private displayChooseHour: boolean = false;
    private displayTransactionLoader: boolean = false;
    private displayPinPad: boolean = false;
    private displayValidationModal: boolean = false;
    private token: string = "";
    private relayId: number = null;
    private relayType: string = null;
    private qrCodeReaderError: any = null;
    private estimatedEndDate: string = null;
    private showBooked: boolean = false;

    private canWithdraw = (user, key) => this.isKeyInRelayOrConnected(key)
        && (this.isManager(user, key) || this.isGuest(user, key)) && !this.isKeyBooked(user, key)
        && (
            this.isAdmin
            || !this.isRetrieveOnlyBookedKeyOptionActive(key)
            || (this.isRetrieveOnlyBookedKeyOptionActive(key) && this.isKeyBookedForCurrentUser(user, key))
        )

    private isKeyInRelayOrConnected = (key: any) => key?.status === "IN_RELAY";

    private isManager = (user, key) => key?.keyManagers?.some((g) => g?.Users?.some((u) => u.id === user?.id));

    private isGuest = (user, key) => key?.guests?.some((g) => g?.Users?.some((u) => u.id === user?.id));

    private isKeyBooked = (user, key) => key.currentBooking ? key.currentBooking.userId !== user?.id
        && moment().isAfter(moment(key.currentBooking.startDate))
        && moment().isBefore(moment(key.currentBooking.endDate)) : false

    private isKeyBookedForCurrentUser = (user, key) => key.currentBooking ? key.currentBooking.userId === user?.id
        && moment().isAfter(moment(key.currentBooking.startDate))
        && moment().isBefore(moment(key.currentBooking.endDate)) : false

    private isRetrieveOnlyBookedKeyOptionActive = (key) => {
        const relatedRelay = key?.Relays?.[0];
        return !!relatedRelay.retrieveOnlyBookedKey;
    }

    get currentRelay(): any {
        return this.currentKey?.currentLocation?.Box?.Relay;
    }

    get currentRelayType(): string {
        return this.currentRelay?.type;
    }

    get canGuestChooseReturnHour(): boolean {
        return this.currentRelay?.canGuestChooseReturnHour;
    }

    get withdrawIcon(): string {
        return (this.mobile ? "mobile " : "") + (this.currentRelayType === "AGENCY"
            ? "icon-picto_retrait-agence"
            : "icon-picto_retrait-myloby");
    }

    get isBookedKeyAvailable() {
        if (!this.currentKey?.currentBooking) {
            return true;
        }
        const hasRights = this.currentUser.id === this.currentKey?.currentBooking.createdBy
            || this.isManager(this.currentUser, this.currentKey)
            || this.isAdmin;
        return (
            this.currentKey?.currentBooking && hasRights)
            || (this.currentUser.id === this.currentKey?.currentBooking.userId);
    }

    private resetQrCodeReader(): void {
        this.qrCodeReaderError = null;
        this.displayQrCodeReader = false;
    }

    private validateTime(value) {
        this.estimatedEndDate = (new Date(value)).toISOString().substr(0, 19);
        this.displayChooseHour = false;
        this.displayQrCodeReader = true;
    }

    private readQRCode(token) {
        this.token = token;
        this.qrCodeReaderError = null;
        return this.$store.dispatch("locations/qrCodeVerification", {
            token,
            keyId: this.currentKey.id,
            keyStatus: this.currentKey.status,
            estimatedEndDate: this.estimatedEndDate,
            referentId: this.currentUser.id,
        }).then((res) => {
            if (res.withdrawn) {
                this.successCallback();
            } else if (res.validLocation) {
                this.displayQrCodeReader = false;
                if (res.relayType === "AGENCY" || res.relayType === "LONG_TERM") {
                    this.displayTransactionLoader = true;
                }
                this.displayPinPad = true;
                this.relayId = res.relayId;
                this.relayType = res.relayType;
            } else {
                this.qrCodeReaderError = this.$i18n.t("alerts.error." + res.errorMessage || "default");
            }
        }).catch((err) => {
            this.qrCodeReaderError = this.$i18n.t(`alerts.error.${err?.response?.data?.error || "qrCodeNotFound"}`);
        });
    }

    private beforeDestroy() {
        this.resetQrCodeReader();
    }

    private withdrawKey(referent: any, way?: string) {
        this.$store.dispatch("keys/withdraw", {
            keyId: this.currentKey.id,
            token: this.token,
            referentId: referent.id,
            estimatedEndDate: this.estimatedEndDate,
        }).then(() => this.successCallback(way)).catch((err) => this.failureCallback(err));
    }

    private successCallback(way?: string): void {
        if (way === "qrCodePin") {
            this.displayValidationModal = true;
        } else {
            this.$store.commit("alerts/displaySuccess", {
                icon: this.withdrawIcon,
                msg: this.$i18n?.t("alerts.key.retrieveSuccess", {key: this.currentKey?.name}),
            });
            this.dropKeyDone();
        }
    }

    private failureCallback(err?: string): void {
        this.$store.commit("alerts/displayError", {
            icon: this.withdrawIcon,
            msg: this.$i18n?.t(err || "alerts.error.default"),
        });
        this.dropKeyDone();
    }

    private dropKeyDone() {
        this.displayValidationModal = false;
        this.displayQrCodeReader = false;
        if (this.mobile || this.listView) {
            this.updateData();
        } else {
            router.push({name: "keys"});
        }
    }

    private buttonClick() {
        if (this.currentKey.currentBooking && !this.isBookedKeyAvailable) {
            return this.showBooked = true;
        }
        return this.canGuestChooseReturnHour ? this.displayChooseHour = true : this.displayQrCodeReader = true;
    }

    private closeModal() {
        this.showBooked = false;
    }
}
</script>
