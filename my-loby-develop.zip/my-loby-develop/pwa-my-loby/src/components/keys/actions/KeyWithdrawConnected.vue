<template>
    <div v-if="canWithdraw(currentUser, currentKey)" :style="{width: mobile ? '100%':''}">
        <hr v-if="mobile"  style="margin: 0 5px 0 5px">
        <button
            style="width: inherit"
            v-if="!listView"
            :disabled="disabled"
            @click="displayWithdrawConnectedBox"
            class="action_button"
            type="button"
        >
            <span v-if="!mobile">
                <i :class="withdrawIcon"></i>
                {{ $t('key.actions.withdrawConnected.button') }}
            </span>
            <v-list-item-icon v-else class="list_btn_action">
                <p class="with_key action_key">
                    <span class="rapatrier_picto">
                        <i :class="withdrawIcon"></i>
                    </span>
                    <strong>{{$t('key.actions.withdrawConnected.button')}}</strong>
                </p>
            </v-list-item-icon>
        </button>
        <v-tooltip top v-else>
            <template v-slot:activator="{ on }">
                <v-btn
                    :disabled="disabled"
                    type="button"
                    class="action_button"
                    @click.stop="displayWithdrawConnectedBox"
                    icon
                    v-on="on"
                >
                    <span v-if="!mobile">
                        <i :class="withdrawIcon"></i>
                    </span>
                </v-btn>
            </template>
            <span>{{$t('key.actions.withdrawConnected.button')}}</span>
        </v-tooltip>
        <!--add tag -->
        <v-dialog
            persistent
            max-width="910px"
            v-model="step1Modal"
            :fullscreen="mobile"
            :hide-overlay="mobile"
            :transition="mobile ? 'dialog-bottom-transition': ''"
        >
            <v-card>
                <a @click="cancel" class="fil_arianne" style="margin-left: 15px">
                    <i class="icon-picto_retour"></i>
                </a>
                <v-card-text>
                    <v-container class="pa-0 pt-5">
                        <v-row justify="center" class="mt-5">
                            <h5 class="ma-0 text-center mt-5">
                                {{ $t('key.actions.withdrawConnected.step1.title')}}
                            </h5>
                        </v-row>
                        <v-row justify="center" class="mt-5">
                            <h5 class="ma-0 text-center">
                                {{ (code).toUpperCase() }}
                            </h5>
                        </v-row>

                        <v-row justify="center" class="mt-5">
                            {{$t('key.actions.closeTheDoor')}}
                        </v-row>
                        <v-row justify="center" class="mt-5">
                            <a class="mt-5"
                                @click="keyIsNotInside"><u>{{$t('key.actions.withdrawConnected.step1.keyIsNotInside')}}</u></a>
                        </v-row>
                        <v-row justify="center" class="mt-5">
                            <a class="mt-5"
                                @click="lockerNotOpen"><u>{{$t('key.actions.withdrawConnected.step1.lockerNotOpen')}}</u></a>
                        </v-row>
                        <v-row justify="center">
                            <v-col align="center" class="px-0">
                                <img
                                    :src="getSrc(currentKey.picturePath) || defaultKeyPicture"
                                    alt="keyPicture"
                                    style="object-fit: contain; max-width: 300px;"
                                />
                                <p v-if="currentKey.description" class="text-center mb-0 mt-4">{{currentKey.description}}</p>
                            </v-col>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn @click="verifyWithdraw()" color="warning" :loading="isLoading">{{$t('actions.done')}}</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <v-dialog
            persistent
            max-width="910px"
            v-model="step2Modal"
            :fullscreen="mobile"
            :hide-overlay="mobile"
            :transition="mobile ? 'dialog-bottom-transition': ''"
        >
            <v-card>
                <a @click="cancel" class="fil_arianne" style="margin-left: 15px">
                    <i class="icon-picto_retour"></i>
                </a>
                <v-card-text>
                    <v-container class="pa-0 pt-5">
                        <v-row justify="center" class="mt-5">
                            <h5 class="ma-0 text-center mt-5">
                                {{ $t('key.actions.withdrawConnected.step2.title1')}}
                            </h5>
                        </v-row>
                        <v-row justify="center">
                            <h5 class="ma-0 text-center">
                                {{ $t('key.actions.withdrawConnected.step2.title2')}}
                            </h5>
                        </v-row>
                        <v-row justify="center">
                            <h5 class="ma-0 text-center">
                                {{ $t('key.actions.withdrawConnected.step2.title3')}}
                            </h5>
                        </v-row>
                        <v-row justify="center" class="mt-5">
                            <h5 class="ma-0 text-center">
                                {{ (code).toUpperCase() }}
                            </h5>
                        </v-row>
                        <v-row justify="center" class="mt-5">
                            <a class="mt-5"
                                @click="lockerNotOpen"><u>{{$t('key.actions.withdrawConnected.step1.lockerNotOpen')}}</u></a>
                        </v-row>
                        <v-row justify="center">
                            <v-col align="center" class="px-0">
                                <img
                                    :src="getSrc(currentKey.picturePath) || defaultKeyPicture"
                                    alt="keyPicture"
                                    style="object-fit: contain; max-width: 300px;"
                                />
                                <p v-if="currentKey.description" class="text-center mb-0 mt-4">{{currentKey.description}}</p>
                            </v-col>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn @click="verifyWithdraw()" color="warning" :loading="isLoading">{{$t('actions.done')}}</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <v-dialog
            persistent
            max-width="910px"
            v-model="step3Modal"
            :fullscreen="mobile"
            :hide-overlay="mobile"
            :transition="mobile ? 'dialog-bottom-transition': ''"
        >
            <v-card>
                <v-card-text>
                    <v-container class="pa-0 pt-5">
                        <v-row justify="center" class="mt-10">
                            <h5 class="ma-0 text-center mt-5">
                                {{ $t('key.actions.withdrawConnected.step3.title')}}
                            </h5>
                        </v-row>
                        <v-row justify="center" class="mt-5">
                            {{$t('key.actions.closeTheDoor')}}
                        </v-row>
                        <v-row justify="center" class="mt-5">
                            <a class="mt-5"
                               @click="keyIsNotInside"><u>{{$t('key.actions.withdrawConnected.step1.keyIsNotInside')}}</u></a>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn @click="finish" color="warning" :loading="isLoading">{{$t('actions.confirm')}}</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import QrCodeReader from "@/components/QrCodeReader.vue";
import PinCode from "@/components/relays/PinCode.vue";
import {Getter} from "vuex-class";
import { getSrc } from "@/utils/misc";
import {defaultKeyPicture} from "@/utils/constants";
import moment from "moment";

@Component({
    components: {
        QrCodeReader,
        PinCode,
    },
})export default class KeyDropAgency extends Vue {

    @Prop({default: {}})
    public currentKey: any;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: false})
    public disabled: boolean;

    @Prop({})
    public updateData: () => void;

    @Prop({default: false})
    public listView: boolean;

    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;

    private code: string = "";
    private acsesObjectId: number = null;
    private booking: any = {};
    private step1Modal: boolean = false;
    private step2Modal: boolean = false;
    private step3Modal: boolean = false;
    private getSrc: (string) => string = getSrc;
    private defaultKeyPicture = defaultKeyPicture;
    private isLoading: boolean = false;

    get relay(): any {
        return this.currentKey?.Relays?.find((r) => r.type === "AGENCY");
    }

    get hasConnectedBoxes(): boolean {
        if (!this.relay) {
            return false;
        }
        const connectedBoxes = this.relay.Boxes.filter((box) => box.size);
        return connectedBoxes.length > 0;
    }

    get canAddTagAtDrop(): any {
        return this.relay?.canAddTagAtDrop;
    }

    get canDropOrGive(): boolean {
        return this.isKeyInitialized || this.isKeyUnarchived
            || ((this.currentUserHasKey || this.keyIsDropableByAnyone)
                && !this.isKeyInRelay);
    }

    get isKeyInRelay(): boolean {
        return this.currentKey?.status === "IN_RELAY";
    }

    get isKeyInitialized(): boolean {
        return this.currentKey?.status === "CREATED";
    }

    get isKeyUnarchived(): boolean {
        return this.currentKey?.status === "UNARCHIVED";
    }

    get isKeyB2B(): boolean {
        return this.currentKey?.Relays?.some((r) => r.type === "AGENCY");
    }

    get currentUserHasKey(): boolean {
        return this.currentKey?.KeyHolding?.find((kH) => !kH.endDate)?.userId === this.currentUser?.id;
    }

    get keyIsDropableByAnyone(): boolean {
        return this.currentKey?.Relays?.some((r) => r.isDropByAnyoneAuthorized);
    }

    get lang() {
        return this.$root.$i18n.locale;
    }

    get withdrawIcon(): string {
        return "icon-picto_retrait-myloby";
    }

    get currentRelay(): any {
        return this.currentKey?.currentLocation?.Box?.Relay;
    }

    get currentRelayType(): string {
        return this.currentRelay?.type;
    }

    private canWithdraw = (user, key) => this.isKeyInConnectedBox(key)
        && (this.isManager(user, key) || this.isGuest(user, key)) && !this.isKeyBooked(user, key)
        && (
            this.isAdmin
            || !this.isRetrieveOnlyBookedKeyOptionActive(key)
            || (this.isRetrieveOnlyBookedKeyOptionActive(key) && this.isKeyBookedForCurrentUser(user, key))
        )

    private isKeyInConnectedBox = (key: any) => key?.status === "IN_CONNECTED_BOX";

    private isManager = (user, key) => key?.keyManagers?.some((g) => g?.Users?.some((u) => u.id === user?.id));

    private isGuest = (user, key) => key?.guests?.some((g) => g?.Users?.some((u) => u.id === user?.id));

    private isKeyBooked = (user, key) => key.currentBooking ? key.currentBooking.userId !== user?.id
        && moment().isAfter(moment(key.currentBooking.startDate))
        && moment().isBefore(moment(key.currentBooking.endDate)) : false

    private isKeyBookedForCurrentUser = (user, key) => key.currentBooking ? key.currentBooking.userId === user?.id
        && moment().isAfter(moment(key.currentBooking.startDate))
        && moment().isBefore(moment(key.currentBooking.endDate)) : false

    private isRetrieveOnlyBookedKeyOptionActive = (key) => {
        const relatedRelay = key?.Relays?.[0];
        return !!relatedRelay.retrieveOnlyBookedKey;
    }

    private displayWithdrawConnectedBox() {
        this.getAcses();
    }

    private getAcses() {
        this.$store.dispatch("keys/getWithdrawAcses", {
            keyId: this.currentKey.id,
        }).then((res) => {
            this.code = res.code;
            this.booking = res;
            this.acsesObjectId = res.acsesObjectId;
            this.step1Modal = true;
        }).catch((err) => {
            if (err.response.data.error === "409") {
                this.$store.commit("alerts/displayError", {
                    icon: "icon-picto_depot-agence",
                    msg: this.$i18n?.t("key.actions.dropErrorCreateAcsesNoSpace"),
                });
            } else {
                this.$store.commit("alerts/displayError", {
                    icon: "icon-picto_depot-agence",
                    msg: this.$i18n?.t("key.actions.dropErrorCreateAcses"),
                });
            }
        });
    }

    private cancel() {
        this.step1Modal = false;
        this.step2Modal = false;
        const bookingId = this.booking.id;
        if (bookingId) {
            this.$store.dispatch("keys/resetCodeBooking", {
                keyId: this.currentKey.id,
                acsesObjectId: this.acsesObjectId,
                acsesBookingId: this.booking.id,
            }).then(() => {
                this.isLoading = false;
                this.updateData();
            }).catch(() => {
                this.isLoading = false;
                this.$store.commit("alerts/displayError", {
                    icon: "icon-picto_depot-agence",
                    msg: this.$i18n?.t("alerts.error.default"),
                });
            });
        }
    }

    private lockerNotOpen() {
        this.$store.dispatch("keys/lockerNotOpen", {
            keyId: this.currentKey.id,
            acsesObjectId: this.acsesObjectId,
            acsesBookingId: this.booking.id,
        }).then(() => {
            this.closeModals();
            this.$store.commit("alerts/displaySuccess", {
                icon: "icon-picto_depot-agence",
                msg: this.$i18n?.t("relay.alertKeys.transit.report.emailSent"),
            });
        });
    }

    private keyIsNotInside() {
        this.$store.dispatch("keys/keyIsNotInside", {
            keyId: this.currentKey.id,
            acsesObjectId: this.acsesObjectId,
            acsesBookingId: this.booking.id,
        }).then(() => {
            this.closeModals();
            this.$store.commit("alerts/displaySuccess", {
                icon: "icon-picto_depot-agence",
                msg: this.$i18n?.t("relay.alertKeys.transit.report.emailSent"),
            });
        });
    }

    private stillKeyWithYou() {
        this.$store.dispatch("keys/keyNotWithdrawn", {
            keyId: this.currentKey.id,
            acsesObjectId: this.acsesObjectId,
            acsesBookingId: this.booking.id,
        }).then(() => {
            this.closeModals();
            this.$store.commit("alerts/displaySuccess", {
                icon: "icon-picto_depot-agence",
                msg: this.$i18n?.t("relay.alertKeys.transit.report.emailSent", {
                    key: this.currentKey.name,
                    relay: this.relay.name,
                }),
            });
        });
    }

    private verifyWithdraw() {
        this.isLoading = true;
        const bookingId = this.booking.tableKey;
        if (this.currentKey.id) {
            this.$store.dispatch("keys/readBooking", {
                keyId: this.currentKey.id,
                bookingId,
            }).then((res) => {
                this.isLoading = false;
                this.code = res.code;
                if (
                    process.env.VUE_APP_FORCE_ACSES_STATUS === "true"
                    || res.lastaction === "checkout"
                    || res.lastaction === "dropoff"
                ) {
                    this.step2Modal = false;
                    this.step1Modal = false;
                    this.step3Modal = true;
                } else {
                    this.step2Modal = true;
                    this.step1Modal = false;
                }
            }).catch(() => {
                this.isLoading = false;
                this.$store.commit("alerts/displayError", {
                    icon: "icon-picto_depot-agence",
                    msg: this.$i18n?.t("alerts.error.default"),
                });
            });
        }
    }
    private finish() {
        this.step2Modal = false;
        this.step1Modal = false;
        this.step3Modal = false;
        this.isLoading = true;
        if (this.currentKey) {
            this.$store.dispatch("keys/withdrawOnConnected", {
                keyId: this.currentKey.id,
                locationId: this.currentKey.currentLocation.id,
                referentId: null,
                estimatedEndDate: null,
                acsesObjectId: this.acsesObjectId,
                acsesBookingId: this.booking.id,
            }).then(() => {
                this.isLoading = false;
                this.$store.commit("alerts/displaySuccess", {
                    icon: "icon-picto_rapatrier",
                    msg: this.$i18n?.t("alerts.key.retrieveSuccess", {key: this.currentKey.name}),
                });
                this.updateData();
            }).catch(() => {
                this.isLoading = false;
                this.$store.commit("alerts/displayError", {
                    icon: "icon-picto_depot-agence",
                    msg: this.$i18n?.t("alerts.error.default"),
                });
            });
        }
    }

    private closeModals(): void {
        this.isLoading = false;
        this.step1Modal = false;
        this.step2Modal = false;
        this.step3Modal = false;
    }
}
</script>

