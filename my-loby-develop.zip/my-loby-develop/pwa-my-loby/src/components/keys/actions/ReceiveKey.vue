<template>
    <div v-if="canReceive"  :style="{width: mobile ? '100%':''}">
        <hr v-if="mobile" style="margin: 0 5px 0 5px">
        <button
            style="width: inherit"
            :disabled="disabled"
            type="button"
            class="action_button"
            @click="receiveKeyDialog = true"
        >
            <span v-if="!mobile">
                <span class="icon-picto_donner-main-a-main">
                    <i class="path1"></i>
                    <i class="path2"></i>
                    <i class="path3"></i>
                </span>
                {{$t('key.actions.receiveKey')}}
            </span>
            <v-list-item-icon v-else class="list_btn_action">
                <p class="with_key action_key" style="min-width: 200px;">
                <span class="icon-picto_donner-main-a-main-2 mobile">
                    <i class="path1"></i>
                    <i class="path2"></i>
                    <i class="path3"></i>
                </span>
                    {{$t('key.actions.receiveKey')}}
                </p>
            </v-list-item-icon>
        </button>
        <v-dialog
            persistent
            max-width="500px"
            v-model="receiveKeyDialog"
            :fullscreen="mobile"
            :hide-overlay="mobile"
            :transition="mobile ? 'dialog-bottom-transition' : ''"
        >
            <v-card>
                <v-card-title>
                    <span class="headline">{{$t('key.actions.receiveKey')}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-row>
                            <v-col class="text-center">
                                <v-text-field
                                    type="number"
                                    v-model.number="sms"
                                    min="0"
                                    pattern="[0-9]*"
                                    inputmode="numeric"
                                    hide-details
                                    solo
                                    @focus="pinFailed=false"
                                >
                                </v-text-field>
                                <span v-show="pinFailed" class="text-danger">{{$t('keysList.pinFailed')}}</span>
                            </v-col>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                           @click="closeDialog"
                           color="warning"
                    >
                        {{$t('actions.close')}}
                    </v-btn>
                    <v-btn
                           @click="validateSMS"
                           color="info"
                    >
                        {{$t('actions.validate')}}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <over-price-sms
            :dialog="acceptOverPrice"
            @accept="validateSMS"
            @cancel="acceptOverPrice = false"
        ></over-price-sms>
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import {Getter} from "vuex-class";
import OverPriceSms from "@/components/OverPriceSms.vue";

@Component({
    components: {
        OverPriceSms,
    },
})
export default class HandToHand extends Vue {

    @Prop({default: {}})
    public currentKey: any;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: false})
    public disabled: boolean;

    @Prop({})
    public updateData: () => void;
    @Getter private currentUser: any;

    private receiveKeyDialog: boolean = false;

    private sms: string = null;
    private pinFailed: boolean = false;
    private canReceive: boolean = false;
    private acceptOverPrice: boolean = false;

    private receivePinHandToHand(): void {
        this.canReceive = false;
        this.$store.dispatch("keys/receivePinHandToHand", {
            keyId: this.currentKey.id,
            targetUserId: this.currentUser.id,
        }).then((res) => {
            if (res === "EXIST") {
                this.canReceive = true;
                return;
            }
        });
    }

    private validateSMS() {
        this.pinFailed = false;
        if (!this.sms) {
            return;
        }
        return this.$store.dispatch("keys/smsVerification", {
            keyId: this.currentKey.id,
            pin: this.sms,
            targetUserId: this.currentUser.id,
        }).then((res) => {
            if (res === "FAILED") {
                this.pinFailed = true;
                return;
            }
            this.closeDialog();
        }).catch((err) => {
            switch (err?.response?.data?.error) {
                case "smsLimitReached":
                    this.acceptOverPrice = true;
                    break;
                default:
                    this.$store.commit("alerts/displayError", {
                        msg: this.$t(`alerts.error.${err?.response?.data?.error || "default"}`),
                    });
                    this.closeDialog();
                    break;
            }
        });
    }

    private closeDialog() {
        this.acceptOverPrice = false;
        this.updateData();
        this.receiveKeyDialog = false;
    }

    private isKeyInitialized = (key: any) => key?.status === "CREATED";

    private userHasKey = (user, key) => key?.KeyHolding?.find((kH) => !kH.endDate)?.userId === user?.id;

    private isKeyInRelay = (key: any) => key?.status === "IN_RELAY";

}
</script>
