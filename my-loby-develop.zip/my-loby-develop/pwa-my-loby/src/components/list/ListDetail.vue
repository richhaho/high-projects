<template>
    <div v-if="currentItem">
        <section v-if="!isGroup">
            <div class="bloc py-4">
                <router-link :to="{name: 'user', params: {id: currentItem.id}}">
                    <p>
                        <img :src="currentItem.picture || defaultItemPicture" alt="" class="img_profil">
                        <span v-if="isUser" class="strong">{{currentItem.firstName}} {{currentItem.lastName}}</span><br>
                        <span v-if="isUser && currentItem.company">{{currentItem.company}}</span>
                    </p>
                </router-link>
            </div>
        </section>
        <section v-if="isGroup" class="pointer" @click="showGroup()">
            <div class="bloc titre_bloc group_bloc">
                <p>
                    <i class="icon-picto_dossier"></i>
                    <span class="strong" style="margin-left:40px">{{currentItem.name}}</span>
                </p>
            </div>
        </section>
        <section v-if="isGroup">
            <div class="bloc contact_bloc">
                <user-list-avatar :users="currentItem.Users"/>
            </div>
        </section>
        <section v-if="isUser">
            <div class="bloc">
                <div class="contacts">
                    <a :href="`tel:${currentItem.phone}`" v-if="currentItem.phone">
                        <i class="icon-picto_telephone"></i> {{currentItem.phone}}
                    </a>
                    <a :href="`mailto:${currentItem.email}`">
                        <i class="icon-picto_courrier"></i> {{currentItem.email}}
                    </a>
                    <a href="#">
                        <i class="icon-picto_cle-partagees"></i> {{currentItem.KeyHolding.length}}
                    </a>
                </div>
                <!-- /.contacts -->
            </div>
        </section>
        <section v-if="!isUser && currentItem.description">
            <div class="bloc">
                <p>
                    {{currentItem.description}}
                </p>
            </div>
        </section>
        <last-logs
            :loading="loadingLogs"
            :logs="logs"
        />
    </div>

</template>
<script lang="ts">
    import {Component, Prop, Vue, Watch} from "vue-property-decorator";
    import LastLogs from "@/components/logs/LastLogs.vue";
    import UserListAvatar from "@/components/users/UserListAvatar.vue";
    import {defaultUserAvatar} from "@/utils/constants";

    @Component({
        components: {
            LastLogs,
            UserListAvatar,
        },
    })
    export default class ListDetail extends Vue {
        @Prop({default: []})
        public selectedItems: object[];

        @Prop({default: "users"})
        public type: string;

        @Prop({})
        public showGroup: () => void;

        private currentItem: any = null;
        private loadingLogs: boolean = false;
        private logs: any = {};

        @Watch("currentItem", { immediate: true })
        public handlerCurrentItem(newVal) {
            if (newVal) {
                this.getLogs();
            }
        }

        get lastItem() {
            const lastIndex = this.selectedItems.length - 1;
            return this.selectedItems[lastIndex];
        }

        get defaultItemPicture() {
            return defaultUserAvatar;
        }

        get isUser() {
            return this.type === "users";
        }

        get isGroup() {
            return this.type === "userGroups";
        }

        @Watch("selectedItems", {deep: true})
        public handlerSelectedItems(newVal, oldVal) {
            if (newVal.length === 1) {
                this.currentItem = newVal[0];
            } else if (newVal.length < oldVal.length) {
                this.currentItem = this.lastItem;
            } else {
                let change: boolean = false;
                newVal.map((item, i) => {
                    if (!oldVal.find((x) => x.id === item.id)) {
                        change = true;
                        this.currentItem = item;
                    }
                });
            }
            if (this.selectedItems.length < 1 && this.isGroup) {
                this.currentItem = null;
            }
        }

        private getLogs(): void {
            this.loadingLogs = true;
            this.$store.dispatch("logs/getLogs", {
                query: {
                    currentPage: this.type,
                    entityId: this.currentItem.id,
                    entityType: this.type?.slice(0, -1),
                },
            }).then((res) => {
                this.logs = res;
                this.loadingLogs = false;
            });
        }
}
</script>
