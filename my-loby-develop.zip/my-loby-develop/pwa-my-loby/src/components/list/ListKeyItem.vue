<template>
    <div class="d-flex">
        <key-withdraw
            v-if="!isHandToHandKey && !isKeyArchived && !isKeyInConnectedBox"
            :currentKey="item"
            :mobile="false"
            :update-data="updateKeyData"
            :disabled="isCompanyBlocked"
            :listView="true"
        />
        <key-withdraw-connected
            v-if="!isHandToHandKey && !isKeyArchived"
            :currentKey="item"
            :mobile="false"
            :update-data="updateKeyData"
            :disabled="isCompanyBlocked"
            :listView="true"
        />
        <key-drop-agency
            v-if="displayDropByAnyone"
            :currentKey="item"
            :mobile="false"
            :update-data="updateKeyData"
            :disabled="isCompanyBlocked"
            :listView="true"
        />
        <key-drop-connected
            v-if="displayDropInConnectedBox"
            :currentKey="item"
            :mobile="false"
            :update-data="updateKeyData"
            :disabled="isCompanyBlocked"
            :listView="true"
        />
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";
import KeyWithdraw from "@/components/keys/actions/KeyWithdraw.vue";
import KeyWithdrawConnected from "@/components/keys/actions/KeyWithdrawConnected.vue";
import KeyDropAgency from "@/components/keys/actions/KeyDropAgency.vue";
import KeyDropConnected from "@/components/keys/actions/KeyDropConnected.vue";
import {Getter} from "vuex-class";

@Component({
    components: {
        KeyDropAgency,
        KeyWithdraw,
        KeyWithdrawConnected,
        KeyDropConnected,
    },
})
export default class ListKeyItem extends Vue {

    get isKeyPage() {
        return !!this.$route.params.id;
    }

    get isCompanyBlocked(): boolean {
        return this.item?.company && !!this.item?.company?.blockedAt;
    }

    get isKeyArchived() {
        return this.item?.archivedAt && !this.item?.hasAllRights;
    }

    get isKeyInConnectedBox() {
        return this.item?.status && this.item?.status === "IN_CONNECTED_BOX";
    }

    @Prop({default: {}})
    public item: any;

    @Prop({})
    public updateData: () => void;

    @Getter private currentUser: any;

    private showActions: boolean = false;

    get isKeyB2B(): boolean {
        return this.item?.Relays?.some((r) => r.type === "AGENCY");
    }

    get isKeyInitialized(): boolean {
        return this.item?.status === "CREATED";
    }

    get isKeyInRelay(): boolean {
        return this.item?.status === "IN_RELAY";
    }

    get currentUserHasKey(): boolean {
        return this.item?.KeyHolding?.find((kH) => !kH.endDate)?.userId === this.currentUser?.id;
    }

    // check if one of the user of one of the management groups match the current user
    get isManager(): boolean {
        return this.item?.keyManagers?.some((g) => g?.Users?.some((u) => u.id === this.currentUser?.id));
    }

    get isHandToHandKey() {
        return this.item?.HandToHand && this.item?.HandToHand.length > 0;
    }

    get keyIsDropableByAnyone(): boolean {
        return this.item?.Relays?.some((r) => r.type === "AGENCY" && r.isDropByAnyoneAuthorized);
    }

    get displayDropByAnyone() {
        return this.isKeyB2B
            /*  && this.keyIsDropableByAnyone
             && !this.currentUserHasKey this needs to be verified*/
            && !this.isKeyArchived
            && !this.isHandToHandKey
            && !this.isKeyInRelay;
    }

    get displayDropInConnectedBox() {
        return this.isKeyB2B
            // && !this.currentUserHasKey
            && !this.isKeyArchived
            && !this.isKeyInRelay
            && !this.isHandToHandKey
            && !this.isKeyInRelay;
    }

    private updateKeyData() {
        this.showActions = false;
        this.updateData();
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

</style>