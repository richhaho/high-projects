<template>
    <v-overlay class="custom-overlay" v-if="selectedItems.length" color="#0c0733">
        <v-row justify="center">
            <v-col cols="4">
                <div class="overlay-content">
                    {{selectedItems.length}} {{type === 'users'?  $t('list.selectedUsers') : $t('list.selectedKeys')}} |
                    <span @click="selectAll" > {{$t('list.selectAll')}}</span>
                </div>
            </v-col>
            <v-col cols="4">
                <div class="overlay-content end">
                    <v-btn text @click="cancel">{{$t('actions.cancel')}}</v-btn>&nbsp;
                    <button
                        type="button"
                        @click="deleteItems"
                        :title="$t('actions.delete')"
                        class="suppr"
                    >
                        <i class="icon-picto_supprimer"></i>
                        {{$t('actions.delete')}}
                    </button>&nbsp;&nbsp;
                    <button
                        type="button"
                        @click="createGroup"
                        :title="$t('keysList.createGroup')"
                        class="creer"
                    >
                        <i class="icon-picto_exporter"></i>
                        {{$t('keysList.createGroup')}}
                    </button>
                </div>
            </v-col>
        </v-row>
    </v-overlay>
</template>
<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";

@Component
export default class ListSelectOverlay extends Vue {
    @Prop({default: "users"})
    public type: string;

    @Prop({default: []})
    public selectedItems: object;

    @Prop({})
    public selectAll: () => void;

    @Prop({})
    public cancel: () => void;

    @Prop({})
    public deleteItems: () => void;

    @Prop({})
    public createGroup: () => void;

}
</script>