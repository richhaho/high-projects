<template>
    <section>
        <v-row v-if="loading" justify="center">
            <v-progress-circular
                :width="3"
                color="#0c0733"
                indeterminate
            />
        </v-row>
        <div
            v-else-if="!lastLogs || lastLogs.length === 0"
            class="info_suivi d-flex justify-content-center"
        >
            <p>{{$t("logs.noLogs")}}</p>
        </div>
        <div
            v-else
            class="info_suivi"
            v-for="log in lastLogs"
        >
            <log-element :log="log"/>
        </div>
        <div
            v-if="moreLogs"
            class="info_suivi d-flex justify-content-center"
        >
            <p>{{moreLogs}} {{$tc("logs.more", moreLogs)}}</p>
        </div>
    </section>
</template>
<script lang="ts">
import {Component, Prop, Vue} from "vue-property-decorator";
import LogElement from "@/components/logs/LogElement.vue";

export const MAX_LOGS_DISPLAYED: number = 5;

@Component({
    components: {
        LogElement,
    },
})
export default class LastLogs extends Vue {

    @Prop({default: null})
    public logs: any;

    @Prop({default: false})
    public loading: any;

    get lastLogs(): any[] {
        return this.logs?.rows?.slice(0, MAX_LOGS_DISPLAYED);
    }

    get moreLogs(): number {
        return this.logs?.count - this.lastLogs?.length;
    }
}
</script>
