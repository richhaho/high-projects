<template>
    <i18n :path="`logs.event.${log.type}.${log.grantedAccessAs}`" class="caption">
        <template v-slot:user1>
            <custom-chip-link
                v-if="log.data.user1"
                type="user"
                :id="log.data.user1.id"
                :text="log.data.user1.name"
            />
        </template>
        <template v-slot:user2>
            <custom-chip-link
                v-if="log.data.user2"
                type="user"
                :id="log.data.user2.id"
                :text="log.data.user2.name"
            />
        </template>
        <template v-slot:tag>
            <custom-chip-link
                v-if="log.data.tag"
                type="tag"
                :id="log.data.tag.id"
                :text="log.data.tag.fr"
            />
        </template>
        <template v-slot:key>
            <custom-chip-link
                v-if="log.data.key"
                type="key"
                :id="log.data.key.id"
                :text="log.data.key.name"
            />
        </template>
        <template v-slot:oldName>
            <custom-chip-link
                v-if="log.data.key"
                type="key"
                :id="log.data.key.id"
                :text="log.data.key.oldValue.name"
            />
        </template>
        <template v-slot:newName>
            <custom-chip-link
                v-if="log.data.key"
                type="key"
                :id="log.data.key.id"
                :text="log.data.key.newValue.name"
            />
        </template>
        <template v-slot:relay>
            <custom-chip-link
                v-if="log.data.relay"
                type="relay"
                :id="log.data.relay.id"
                :text="log.data.relay.name"
            />
        </template>
        <template v-slot:relay1>
            <custom-chip-link
                v-if="log.data.relay1"
                type="relay"
                :id="log.data.relay1.id"
                :text="log.data.relay1.name"
            />
        </template>
        <template v-slot:relay2>
            <custom-chip-link
                v-if="log.data.relay2"
                type="relay"
                :id="log.data.relay2.id"
                :text="log.data.relay2.name"
            />
        </template>
        <template v-slot:location>
            <v-chip
                    v-if="log.data.location"
                    x-small
            >
                {{ log.data.location.name }}
            </v-chip>
        </template>
        <template v-slot:userGroup>
            <custom-chip-link
                v-if="log.data.userGroup"
                type="userGroup"
                :id="log.data.userGroup.id"
                :text="log.data.userGroup.name"
            />
        </template>
        <template v-slot:keyGroup>
            <custom-chip-link
                v-if="log.data.keyGroup"
                type="keyGroup"
                :id="log.data.keyGroup.id"
                :text="log.data.keyGroup.name"
            />
        </template>
        <template v-slot:group>
            <custom-chip-link
                v-if="log.data.group"
                type="userGroup"
                :id="log.data.group.id"
                :text="log.data.group.name"
            />
        </template>
        <template v-slot:count>
            <v-btn
                    disabled
                    text
                    x-small
            >
                {{ log.data.count }}
            </v-btn>
        </template>
        <template v-slot:transitType>
            {{ $t(`key.transit.mode.${log.data.transitType}`) }}
        </template>
    </i18n>
</template>
<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";
import CustomChipLink from "@/components/CustomChipLink.vue";
@Component({
    components: {
        CustomChipLink,
    },
})
  export default class LogElement extends  Vue {

  @Prop({default: {}})
  public log: object;
}
</script>
