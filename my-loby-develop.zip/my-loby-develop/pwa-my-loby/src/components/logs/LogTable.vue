<template>
    <div class="mb-5">
        <p class="tableau_titre"
           v-if="collapsibleTitle">
            {{$t('logs.traceability')}}
            <a class="toggle_action"
               @click.prevent="displayLogs = !displayLogs"
               :class="{'open': !displayLogs}"
               :title="$t('actions.openClose')">
                <i class="icon-angle"></i>
            </a>
        </p>
        <p v-else class="tableau_titre">{{$t('logs.traceability')}} <i class="icon-header_triangle"></i></p>
        <v-expand-transition>
            <div class="tableau tableu-logs" v-if="displayLogs">
                <div class="options">
                    <div class="option_left">
                        <button class="option" @click.stop="displayFilter = !displayFilter">
                            <i class="icon-picto_filtrer"></i>
                            {{$t('actions.filter')}}
                        </button>
                        <div class="with_filters">
                            <ul class="filters mb-5" :class="{'d-block': displayFilter}">
                                <li v-for="(type, index) in logs.types" :key="index">
                                    <label>
                                        <p-check :value="type"
                                                 v-model="pagination.select"
                                                 class="p-default p-curve mt-2 p-bigger"
                                                 color="primary">
                                        </p-check>
                                        {{$t(`logs.name.${type}`)}}
                                    </label>
                                </li>
                            </ul>
                    </div>
                </div>
                <div class="option_right">
                </div>
            </div>
            <v-data-table
                :headers="headers"
                :hide-default-footer="!logs.rows || logs.count < pagination.itemsPerPage"
                :items="logs.rows"
                :no-data-text="$t('logs.noLogs')"
                :no-results-text="$t('logs.noLogs')"
                :options.sync="pagination"
                :server-items-length="logs.count"
                class="elevation-1 tracabilite"
                hide-default-header
                :footer-props="{
                    'items-per-page-options': [10, 25,50]
                }"
            >
                <template v-slot:item.type="{ item }">
                    {{$t(`logs.name.${item.type}`)}}
                </template>
                <template v-slot:item.createdAt="{ item }">
                    {{ item.createdAt | formatDate}}
                </template>
                <template v-slot:item.data="{ item }">
                    <log-element :log="item"/>
                </template>
            </v-data-table>
            </div>
        </v-expand-transition>
    </div>
</template>

<script lang="ts">
import {Component, Prop, Vue, Watch} from "vue-property-decorator";
import LogElement from "@/components/logs/LogElement.vue";
import {Getter} from "vuex-class";

@Component({
    components: {
        LogElement,
    },
})
export default class LogTable extends Vue {
    @Prop({default: null})
    public logs: {
        count: number,
        rows: any[],
        types: string[],
    };

    @Prop({default: false})
    public collapsibleTitle: boolean;

    @Getter private isAdmin: boolean;

    private displayFilter: boolean = false;
    private displayLogs: boolean = true;
    private pagination: any = {
        select: [],
        page: 1,
        itemsPerPage: 10,
    };
    private headers: any[] = [];

    @Watch("pagination", { deep: true })
    public handler() {
        this.$emit("get-logs", this.pagination);
    }

    private mounted() {
        this.headers = [
            {value: "createdAt", text: this.$t("logs.createdAt"), sortable: true},
            {value: "data", text: this.$tc("logs.data"), sortable: false},
        ];
        if (this.isAdmin) {
            this.headers.unshift({value: "type", text: this.$tc("logs.type"), sortable: false});
        }
    }
}
</script>>