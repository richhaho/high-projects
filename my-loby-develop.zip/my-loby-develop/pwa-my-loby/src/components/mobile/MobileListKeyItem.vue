<template>
    <div class="m-key-card">
        <v-list-item  :class="{'m-key-list': true, 'description': description}" >
            <v-row>
                <!--<v-col
                    v-if="!isKeyPage && !isKeyArchived"
                    :cols="2"
                    class="m-key-card-buttons pa-0 ma-0"
                >
                    <div v-if="isHandToHandKey">
                        <button type="button" class="action_button"
                                :disabled="isCompanyBlocked"
                                @click="goHandToHandScan">
                            <v-list-item-icon
                                style="background-color: orange; padding:8px; border-radius: 50%;">
                                <span class="icon-picto_recevoir-main-a-main mobile">
                                    <i class="path1"></i>
                                    <i class="path2"></i>
                                    <i class="path3"></i>
                                </span>
                            </v-list-item-icon>
                        </button>
                    </div>
                    <hand-to-hand
                        v-if="!isHandToHandKey"
                        :currentKey="item"
                        :mobile="true"
                        :update-data="updateKeyData"
                        :disabled="isCompanyBlocked"
                    />
                    <key-withdraw
                        v-if="!isHandToHandKey"
                        :currentKey="item"
                        :mobile="true"
                        :update-data="updateKeyData"
                        :disabled="isCompanyBlocked"
                    />
                    <key-drop-agency
                        v-if="displayDropByAnyone"
                        :currentKey="item"
                        :mobile="true"
                        :update-data="updateKeyData"
                        :disabled="isCompanyBlocked"
                    />
                    <key-drop-my-loby
                        v-if="!isKeyB2B && !isHandToHandKey"
                        :currentKey="item"
                        :mobile="true"
                        :update-data="updateKeyData"
                        :disabled="isCompanyBlocked"
                    />
                    <key-retrieve
                        v-if="!isKeyInitialized"
                        :currentKey="item"
                        :mobile="true"
                        :update-data="updateKeyData"
                        :disabled="isCompanyBlocked"
                    />
                    <div>
                        <button
                            type="button"
                            class="action_button"
                            @click="showActions = !showActions"
                            v-if="isKeyB2B && canDropOrGive && !isHandToHandKey"
                        >
                            <v-list-item-icon
                                style="height: 40px; background-color: whitesmoke; border-radius: 50%; transition: all 0.3s ease;"
                                :style="{padding: showActions ? '10px 10px 14px 10px' : '14px 10px 10px 10px'}"
                            >
                                <i
                                    class="icon-picto_chevron-bac mobile"
                                    style="font-size: 14px; transition: all 0.3s ease;"
                                    :style="{transform: showActions ? 'rotateX(180deg)' : ''}"
                                ></i>
                            </v-list-item-icon>
                        </button>
                    </div>
                </v-col>-->
                <!--<v-col v-else :cols="2"></v-col>-->
                <v-col :cols="12" class="pa-0 ma-0" style="padding: 0">
                    <a v-if="fromRelaysPage" href="#">
                        <v-row align="center">
                            <v-col
                                :cols="12"
                                class="pa-0"
                            >
                                <v-row :class="{'archived': isKeyArchived && !isKeyPage}" class="align-items-center">
                                    <image-key-renderer
                                        v-if="item.picturePath"
                                        :picturePath="item.picturePath"
                                        class="key_list_picture"
                                        :key="imgUpdate"
                                    />
                                    <v-list-item-avatar
                                        v-else
                                        class="key_list_item"
                                    >
                                        <i class="icon-picto_cle-partagees no-img-key"></i>
                                    </v-list-item-avatar>
                                    <v-list-item-content class="ml-2 key_list_content">
                                        <v-list-item-title v-html="item.name"></v-list-item-title>
                                        <v-list-item-subtitle
                                            v-html="item.description"
                                            v-if="description && item.description"
                                            class="map-item-description"
                                        >
                                        </v-list-item-subtitle>
                                        <v-list-item-subtitle>
                                            <key-status
                                                :currentKey="item"
                                                :mobile="isKeyPage"
                                            />
                                        </v-list-item-subtitle>
                                        <v-list-item-subtitle style="display: flex;flex-direction: row" v-if="item.currentBooking && !isKeyPage">
                                            <v-icon small>lock</v-icon>
                                            <strong>{{ $t('booking.keyIsBooked.mobileTitle') }}</strong>
                                        </v-list-item-subtitle>
                                        <v-list-item-subtitle v-if="location && item.locationDisplayed">
                                            {{ $tc('box.locations', 1) }} n°{{ item.locationDisplayed.codeName }}
                                        </v-list-item-subtitle>
                                    </v-list-item-content>
                                </v-row>
                            </v-col>
                        </v-row>
                    </a>
                    <router-link :to="{ name: 'key', params: { id: item.id }}" v-else>
                        <v-row align="center">
                            <v-col
                                cols="11"
                                class="pa-0"
                            >
                                <v-row :class="{'archived': isKeyArchived && !isKeyPage}" class="align-items-center">
                                    <image-key-renderer
                                        v-if="item.picturePath"
                                        :picturePath="item.picturePath+'?timestamp='+timeNowImg"
                                        alt="keyPicture"
                                        :key="imgUpdate"
                                        class="key_list_picture"
                                    />
                                    <v-list-item-avatar
                                        v-else
                                        class="key_list_item"
                                    >
                                        <i class="icon-picto_cle-partagees" style="color: #212529"></i>
                                    </v-list-item-avatar>
                                    <v-list-item-content class="ml-2 key_list_content">
                                        <v-list-item-title v-html="item.name"></v-list-item-title>
                                        <v-list-item-subtitle
                                            v-html="item.description"
                                            v-if="description && item.description"
                                            style="white-space: normal;"
                                        >
                                        </v-list-item-subtitle>
                                        <v-list-item-subtitle>
                                            <key-status
                                                :currentKey="item"
                                                :mobile="isKeyPage"
                                            />
                                        </v-list-item-subtitle>
                                        <v-list-item-subtitle style="display: flex;flex-direction: row"
                                                              v-if="item.currentBooking && !isKeyPage">
                                            <v-icon small>lock</v-icon>
                                            <strong>{{ $t('booking.keyIsBooked.mobileTitle') }}</strong>
                                        </v-list-item-subtitle>
                                        <v-list-item-subtitle v-if="location && item.locationDisplayed && !item.connectedBoxLocker">
                                            {{ $tc('box.locations', 1) }} n°{{ item.locationDisplayed.codeName }}
                                        </v-list-item-subtitle>
                                        <v-list-item-subtitle v-if="location && item.connectedBoxLocker">
                                            {{ $tc('box.locations', 1) }} n°{{ item.connectedBoxLocker }}
                                        </v-list-item-subtitle>
                                        <v-list-item-subtitle class="tags" v-if="isKeyPage && item.Tags && item.Tags.length > 0">
                                            <button
                                                type="button"
                                                v-for="(tag,i) in item.Tags"
                                                :key="i"
                                                class="py-0 mt-2"
                                            >
                                                {{tag[lang]}}
                                            </button>
                                        </v-list-item-subtitle>
                                    </v-list-item-content>
                                </v-row>
                            </v-col>
                            <v-col
                                cols="1"
                                class="pa-0"
                                v-if="!isKeyPage"
                                align="center"
                            >
                                <v-btn icon>
                                    <v-icon color="grey lighten-1">arrow_forward_ios</v-icon>
                                </v-btn>
                            </v-col>
                        </v-row>
                        <v-row
                            v-if="isKeyPage && item.KeyHolding.length > 0 && item.KeyHolding[0].estimatedEndDate"
                            justify="center"
                        >
                            <v-col cols="12" class="py-0">
                                <v-alert
                                    class="pa-1 mb-3"
                                    :color="lateKey(item.KeyHolding[0].estimatedEndDate) || endCountdown ? 'red' : 'blue'"
                                    dense
                                    outlined
                                    text
                                >
                                    <p
                                        v-if="!lateKey(item.KeyHolding[0].estimatedEndDate) && !endCountdown"
                                        class="px-2 my-0 subtitle-2"
                                    >
                                        {{$t('countDown.remaining')}}
                                        <vue-countdown-timer
                                            :start-time="getTime()"
                                            :end-time="getTime(item.KeyHolding[0].estimatedEndDate)"
                                            :interval="1000"
                                            @end_callback="endCountdown = true"
                                        >
                                            <template slot="countdown" slot-scope="scope">
                                                <h6 class="my-1">
                                                    <b>
                                                        {{showDays(item.KeyHolding[0].estimatedEndDate) ? scope.props.days + ":" : ""}}{{scope.props.hours}}:{{scope.props.minutes}}:{{scope.props.seconds}}
                                                    </b>
                                                </h6>
                                            </template>
                                        </vue-countdown-timer>
                                    </p>
                                    <p
                                        v-else
                                        class="px-2 my-0 subtitle-2"
                                    >
                                        {{$t('countDown.late')}} {{ getDifference(item.KeyHolding[0].estimatedEndDate) }}
                                    </p>
                                </v-alert>
                            </v-col>
                            <v-col cols="12" class="py-0">
                                <button type="button"
                                    @click="displayChooseHour = true"
                                    class="option mb-3"
                                    :style="{margin:lateKey(item.KeyHolding[0].estimatedEndDate) ? '0 auto':''}"
                                    :title="$t('key.extendHoldingDuration')"
                                    v-if="isCurrentUserHolder || isManager(currentUser, item)"
                                >
                                    <i class="icon-picto_ajouter"></i>
                                    {{ $t('key.extendHoldingDuration') }}
                                </button>
                            </v-col>
                            <key-returning-date
                                style="margin: 0 auto"
                                ref="returningDate"
                                :displayChooseHour="displayChooseHour"
                                v-if="displayChooseHour"
                                :initalDate="item.KeyHolding[0].estimatedEndDate"
                                @validTime="validateTime"
                                @cancel="displayChooseHour = false"
                            />
                        </v-row>
                    </router-link>
                </v-col>
            </v-row>
        </v-list-item>
        <v-divider v-if="showActions && !isKeyArchived"/>
        <!--<v-list-item v-if="showActions && !isKeyArchived" style="min-height: 80px;">
            <v-row justify="center" class="m-key-card-actions">
                <key-drop-agency
                    :currentKey="item"
                    :mobile="true"
                    :update-data="updateKeyData"
                    :disabled="isCompanyBlocked"
                />
                <key-transit
                    :currentKey="item"
                    :mobile="true"
                    :update-data="updateKeyData"
                    :disabled="isCompanyBlocked"
                />
                <key-drop-my-loby
                    :currentKey="item"
                    :mobile="true"
                    :update-data="updateKeyData"
                    :disabled="isCompanyBlocked"
                />
                <key-retrieve
                    :currentKey="item"
                    :mobile="true"
                    :update-data="updateKeyData"
                    :disabled="isCompanyBlocked"
                />
            </v-row>
        </v-list-item>-->
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import KeyStatus from "@/components/keys/KeyStatus.vue";
import KeyTransit from "@/components/keys/actions/KeyTransit.vue";
import KeyRetrieve from "@/components/keys/actions/KeyRetrieve.vue";
import HandToHand from "@/components/keys/actions/HandToHand.vue";
import KeyWithdraw from "@/components/keys/actions/KeyWithdraw.vue";
import KeyWithdrawConnected from "@/components/keys/actions/KeyWithdrawConnected.vue";
import KeyDropMyLoby from "@/components/keys/actions/KeyDropMyLoby.vue";
import KeyDropAgency from "@/components/keys/actions/KeyDropAgency.vue";
import {Getter} from "vuex-class";
import { mdiArrowRightDropCircleOutline } from "@mdi/js";
import {getSrc} from "@/utils/misc";
import KeyReturningDate from "@/components/keys/actions/KeyReturningDate.vue";
import moment from "moment";
import ImageKeyRenderer from "@/components/ImageKeyRenderer.vue";

@Component({
    components: {
        KeyStatus,
        KeyTransit,
        KeyRetrieve,
        KeyDropMyLoby,
        KeyDropAgency,
        KeyWithdraw,
        KeyWithdrawConnected,
        HandToHand,
        KeyReturningDate,
        ImageKeyRenderer,
    },
})
export default class MobileListKeyItem extends Vue {

    @Prop({default: {}})
    public item: any;

    @Prop({})
    public updateData: () => void;

    @Prop({default: false})
    public description: boolean;

    @Prop({default: false})
    public owner: boolean;
    @Prop({default: false})
    public isRefferent: boolean;

    @Prop({default: false})
    public location: boolean;

    @Prop({default: false})
    public fromRelaysPage: boolean;

    @Prop({ default: "" })
    public timestamp: string;

    @Prop({default: 0})
    public imgUpdate: number;

    @Getter private currentUser: any;
    private getSrc: (string) => string = getSrc;
    private arrow: any = mdiArrowRightDropCircleOutline;
    private displayChooseHour: boolean = false;
    private endCountdown: boolean = false;
    private timeNowImg: any = Date.now();
    private showActions: boolean = false;

    @Watch("timestamp", {deep: true} )
    public handlerSearchTags(): void {
        this.timeNowImg = this.timestamp;
        this.$forceUpdate();
    }

    get lang(): string {
        return this.$root.$i18n.locale;
    }

    get isKeyB2B(): boolean {
        return this.item?.Relays?.some((r) => r.type === "AGENCY");
    }

    get isKeyInitialized(): boolean {
        return this.item?.status === "CREATED";
    }
    get isKeyInRelay(): boolean {
        return this.item?.status === "IN_RELAY";
    }

    get canDropOrGive(): boolean {
        return this.isKeyInitialized || (this.currentUserHasKey && !this.isKeyInRelay);
    }

    get currentUserHasKey(): boolean {
        return this.item?.KeyHolding?.find((kH) => !kH.endDate)?.userId === this.currentUser?.id;
    }

    get isCurrentUserHolder(): boolean {
        return this.item?.holder?.id === this.currentUser?.id;
    }

    get isHandToHandKey() {
        return this.item?.HandToHand &&  this.item?.HandToHand.length > 0;
    }

    get keyIsDropableByAnyone(): boolean {
        return this.item?.Relays?.some((r) => r.type === "AGENCY" && r.isDropByAnyoneAuthorized);
    }

    get displayDropByAnyone() {
        return this.isKeyB2B
            && this.keyIsDropableByAnyone
            && !this.isHandToHandKey
            && !this.currentUserHasKey
            && !this.isKeyInRelay
            && !this.isKeyInitialized;
    }

    get isKeyPage() {
        return !!this.$route?.params?.id;
    }

    get isCompanyBlocked(): boolean {
        return this.item?.company && !!this.item?.company?.blockedAt;
    }

    get isKeyArchived() {
        return this.item?.archivedAt && !this.item?.hasAllRights;
    }

    // check if one of the user of one of the management groups match the current user
    private isManager = (user, key) => key?.keyManagers
        ?.some((g) => g?.Users?.some((u) => u?.id === user?.id))

    private isValidAccess = (access: any) => (access.countAccessLeft === -1 || access.countAccessLeft >= 1)
        && (access.startDate === null || new Date(access.startDate) <= new Date())
        && (access.endDate === null || new Date(access.endDate) >= new Date())

    private goHandToHandScan() {
        this.$router.push({
            name: "key-hand-to-hand-scan",
            params: {
                keyid: this.item?.id,
                token: this.item.HandToHand[0].token,
            },
        });
    }

    private updateKeyData() {
        this.showActions = false;
        this.updateData();
    }

    private lateKey = (date) => moment(new Date(date), "YYYY-MM-DDTHH:mm:ss")
        .isBefore(moment().format("YYYY-MM-DDTHH:mm:ss"))

    private getTime = (date) => date ? moment(new Date(date), "YYYY-MM-DD HH:mm:ss").valueOf() : moment().valueOf() ;

    // whether or not show days in countdown
    private showDays = (date) => Math.abs(moment(new Date(date), "YYYY-MM-DD HH:mm:ss").valueOf() - moment().valueOf())
        > 24 * 60 * 60 * 1000

    private getDifference(date): string {
        date = new Date(date);
        const a = moment(date, "YYYY-MM-DD hh:mm");
        const b = moment();
        const diffDays = b.diff(a, "days");
        const diffHours = b.diff(a, "hours");
        const diffMinutes = b.diff(a, "minutes");
        if (diffMinutes < 60) {
            return diffMinutes % 60 + " " + String(this.$tc("countDown.minutes", diffMinutes % 60));
        } else if (diffHours < 24) {
            return diffHours % 24 + " " + String(this.$tc("countDown.hours", diffHours % 24)) + ", "
                + diffMinutes % 60 + " " + String(this.$tc("countDown.minutes", diffMinutes % 60));
        } else {
            return diffDays + " " + String(this.$tc("countDown.days", diffDays)) + ", "
                + diffHours % 24 + " " + String(this.$tc("countDown.hours", diffHours % 24)) + ", "
                + diffMinutes % 60 + " " + String(this.$tc("countDown.minutes", diffMinutes % 60));
        }
    }

    // extend holding key
    private validateTime(date) {
        this.displayChooseHour = false;
        this.$store.dispatch("keys/extendKeyHolding", {
            keyId: this.item?.id,
            newEstimatedEndDate: (new Date(date)).toISOString().substr(0, 19),
        }).then(() => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("alerts.key.addTimeSuccess", {
                    key: this.item?.name,
                    time: moment(date).format("DD/MM/YYYY HH:mm"),
                }),
            });
            this.updateData();
        });
    }

    // whether or not show days in countdown
    private isGuest = (user, key) => key?.guests
        ?.some((g) => g?.Users?.some((u) => u?.id === user?.id))

}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">

</style>