<template>
    <v-list-item>
        <v-list-item-avatar style="background-color: #f8f9fa; padding:10px; border-radius: 50%">
            <i style="color: #212529" class="icon-picto_relais-agence"></i>
        </v-list-item-avatar>

        <v-list-item-content>
            <v-list-item-title v-html="item.title"></v-list-item-title>
            <v-list-item-subtitle v-html="item.subtitle"></v-list-item-subtitle>
        </v-list-item-content>

        <v-list-item-icon style="background-color: #ffeacc; padding:10px; border-radius: 50%;">
            <v-icon style="color:#fe9301">arrow_forward_ios</v-icon>
        </v-list-item-icon>
    </v-list-item>
</template>

<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";

@Component({})
export default class MobileListRelayItem extends Vue {

    @Prop({default: {}})
    public item: any;
}
</script>