<template>
    <v-card>
        <v-card-title class="pb-0">
            <v-col>
                <v-row>
                    <v-col class="headline ml-3 pa-0">
                        <v-row>
                            {{$tc('box.number', box.number, {number: box.number})}}
                        </v-row>
                        <v-row v-if="totalLocations(box) !== totalLocations(oldDimensions)">
                            <p class="ma-0 subtitle-2">
                                {{$t('box.futureLocations', totalLocations(box))}} : {{ totalLocations(box) }}
                            </p>
                        </v-row>
                        <v-row>
                            <p class="subtitle-2">
                                {{$tc('box.locations', totalLocations(oldDimensions))}} :
                                {{ totalLocations(oldDimensions) }}
                            </p>
                        </v-row>
                    </v-col>
                    <v-col class="pa-0">
                        <v-row>
                            <v-col class="pb-0">
                                <v-text-field
                                    :label="$tc('box.sheets', box.sheets)"
                                    :min="oldDimensions.sheets || 0"
                                    :rules="[largerSheets]"
                                    type="number"
                                    v-model="box.sheets"
                                >
                                </v-text-field>
                            </v-col>
                            <v-col class="pb-0">
                                <v-text-field
                                    :label="$tc('box.columns', box.columns)"
                                    :min="oldDimensions.columns || 0"
                                    :rules="[largerColumns]"
                                    type="number"
                                    v-model="box.columns"
                                >
                                </v-text-field>
                            </v-col>
                            <v-col class="pb-0">
                                <v-text-field
                                    :label="$tc('box.lines', box.lines)"
                                    :min="oldDimensions.lines || 0"
                                    :rules="[largerLines]"
                                    type="number"
                                    v-model="box.lines"
                                >
                                </v-text-field>
                            </v-col>
                        </v-row>
                        <p class="caption red--text" v-if="boxReduced()">
                            {{$t('box.reduced')}}
                        </p>
                        <p class="caption red--text"
                           v-if="totalLocations(oldDimensions) === 0 && totalLocations(box) === 0">
                            {{$t('box.empty')}}
                        </p>
                    </v-col>
                </v-row>
                <v-row>
                    <v-col class="pb-0">
                        <v-row justify="center">
                            <v-text-field
                                :append-outer-icon="search ? 'search' : ''"
                                :hint="$t('box.exactLocation')"
                                :label="$t('actions.search')"
                                @change="updateSearch"
                                @click:append-outer="updateSearch"
                                @click:clear="clearSearch"
                                clearable
                                outlined
                                placeholder="#-#-#-#"
                                type="text"
                                v-model="search"
                            ></v-text-field>
                        </v-row>
                    </v-col>
                    <v-col class="pb-0">
                        <v-row justify="center" v-if="box.Locations && box.Locations.length >= 1">
                            <v-btn
                                :href="$store.state.baseURL ? `${$store.state.baseURL}/api/boxes/${box.id}/generate-qr-code` :
                            `/api/boxes/${box.id}/generate-qr-code`"
                                outlined
                                small
                                target="_blank"
                            >
                                {{$t('box.printAllQrCodes')}}
                            </v-btn>
                        </v-row>
                    </v-col>
                </v-row>
            </v-col>
        </v-card-title>
        <v-card-text class="py-0">
            <v-container class="py-0">
                <v-row justify="center">
                    <v-col align="center" class="pt-0" v-if="box.Locations && box.Locations.length === 1">
                        <v-btn
                            :href="$store.state.baseURL ? `${$store.state.baseURL}/api/locations/${box.Locations[0].id}/generate-qr-code` :
                            `/api/boxes/${box.id}/generate-qr-code`"
                            icon
                            target="_blank">
                            <v-icon>dashboard</v-icon>
                        </v-btn>
                        <p class="ma-0">{{box.Locations[0].codeName}}</p>
                    </v-col>
                    <v-col class="pt-0" v-else-if="box.Locations && box.Locations.length > 0">
                        <ul v-if="insurancesList.length">
                            {{$t('box.companies')}}
                            <li
                                v-for="insurance in insurancesList"
                                :key="insurance.id"
                            >
                                {{insurance.name}} :
                                <v-icon :color="insurance.color">dashboard</v-icon>
                            </li>
                        </ul>
                        <v-tabs centered
                                v-if="oldDimensions.sheets > 1 && box.Locations.length > 1"
                        >
                            <v-tab
                                @click="changeTab(i)"
                                v-for="i in oldDimensions.sheets"
                                :key="i"
                            >
                                {{$tc('box.sheets', 1)}} {{i}}
                            </v-tab>
                        </v-tabs>
                        <v-simple-table
                            dense
                            fixed-header
                        >
                            <template v-slot:default>
                                <thead>
                                <tr>
                                    <th></th>
                                    <th
                                        :key="x"
                                        class="text-center"
                                        v-for="x in oldDimensions.columns"
                                    >
                                        {{String.fromCharCode(96 + x).toUpperCase()}}
                                    </th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr :key="i" v-for="i in oldDimensions.lines">
                                    <td
                                        class="text-center"
                                    >
                                        {{i}}
                                    </td>
                                    <td
                                        class="text-center"
                                        v-for="(loc, idx) in box.Locations.slice((i-1) * oldDimensions.columns, (i-1) * oldDimensions.columns + oldDimensions.columns)"
                                    >
                                        <v-tooltip top>
                                            <template v-slot:activator="{ on }">
                                                <v-btn
                                                    :href="$store.state.baseURL ? `${$store.state.baseURL}/api/locations/${loc.id}/generate-qr-code` :
                            `/api/boxes/${box.id}/generate-qr-code`"
                                                    icon
                                                    target="_blank">
                                                    <v-icon
                                                        v-on="on"
                                                        :color="loc.ReservedCompany ? loc.ReservedCompany.color : null"
                                                    >
                                                        dashboard
                                                    </v-icon>
                                                </v-btn>
                                            </template>
                                            <v-row justify="center">
                                                <span>{{loc.codeName}}</span>
                                            </v-row>
                                            <span v-if="loc.ReservedCompany">
                                                {{loc.ReservedCompany.name}}
                                            </span>
                                        </v-tooltip>
                                    </td>
                                </tr>
                                </tbody>
                            </template>
                        </v-simple-table>
                    </v-col>
                    <p v-else>
                        {{$t('box.noLocation')}}
                    </p>
                </v-row>
            </v-container>
        </v-card-text>
        <v-card-actions>
            <v-container class="pt-0">
                <v-row justify="center">
                    <v-btn
                        @click="$emit('close-modal')"
                        color="primary"
                        text
                    >
                        {{$t('actions.close')}}
                    </v-btn>
                    <v-btn
                        :loading="updating"
                        @click="saveBox(box)"
                        color="primary"
                        v-if="(box.Locations.length === 0 && search === '') || (totalLocations(box) !== totalLocations(oldDimensions))"
                    >
                        {{$t(box.Locations.length === 0 ? 'box.generateQrCodes' : 'box.saveAndGenerateQrCodes')}}
                    </v-btn>
                </v-row>
            </v-container>
        </v-card-actions>
    </v-card>
</template>
<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";

@Component
export default class BoxDetails extends Vue {
    @Prop({default: null})
    public box: any;

    @Prop({default: null})
    public oldDimensions: any;

    private search: string = "";
    private updating: boolean = false;
    private sheet: number = 1;
    private totalLocations = (box) => box.sheets * box.columns * box.lines;
    private boxReduced = () => this.box.sheets < this.oldDimensions.sheets ||
        this.box.columns < this.oldDimensions.columns ||
        this.box.lines < this.oldDimensions.lines
    private largerSheets: any = (v) => {
        return v >= this.oldDimensions.sheets || "";
    }
    private largerColumns: any = (v) => {
        return v >= this.oldDimensions.columns || "";
    }
    private largerLines: any = (v) => {
        return v >= this.oldDimensions.lines || "";
    }

    get insurancesList() {
        const isItemInList = (item, list) => list.map((c) => c.id).includes(item.id);
        const uniqueList = [];
        this.box.Locations.forEach((location) => {
            if (location.ReservedCompany && !isItemInList(location.ReservedCompany, uniqueList)) {
                uniqueList.push(location.ReservedCompany);
            }
        });
        return uniqueList;
    }

    private saveBox(box: any) {
        this.updating = true;
        this.$store.dispatch("boxes/update", {id: box.id, box})
            .then((res) => {
                this.updateSearch();
                this.updating = false;
            })
            .catch((err) => {
                this.updating = false;
                this.$store.commit("alerts/displayError", {
                    msg: err,
                });
            });
    }

    private updateSearch(sheet?: number) {
        this.$emit("box-update", this.box.id, {
            search: this.search,
            sheet: this.sheet,
        });
    }

    private clearSearch() {
        this.search = "";
        this.updateSearch();
    }

    private changeTab(tab) {
        this.sheet = tab;
        this.updateSearch();
    }
}
</script>
