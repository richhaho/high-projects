<template>
    <v-dialog
        persistent
        max-width="910px"
        v-model="displayPinPad"
        :fullscreen="mobile"
        :hide-overlay="mobile"
        :transition="mobile ? 'dialog-bottom-transition' : ''"
    >
        <v-card>
            <v-card-title v-if="displayManualPin">
                <v-container class="py-0">
                    <v-row justify="center" class="ma-0">
                        <h5 class="ma-0">
                            {{keyGuest ? $t("pin.askGuestCode"): $t("pin.letReferent") }}
                        </h5>
                    </v-row>
                </v-container>
            </v-card-title>
            <v-card-text>
                <v-container v-if="displayTransactionLoader" class="pb-0">
                    <v-row justify="center" class="ma-10 pa-10">
                        <v-progress-circular
                            :width="4"
                            color="#0c0733"
                            indeterminate
                        />
                    </v-row>
                    <v-row justify="center">
                        <p class="subtitle-2 ma-0">
                            {{ $t('pin.transactionLoader') }}
                        </p>
                    </v-row>
                    <v-row justify="center" class="mt-1 mb-1">
                        <v-alert
                            v-if="error"
                            color="red"
                            outlined
                            text
                        >
                            {{ error }}
                        </v-alert>
                    </v-row>
                    <v-row justify="center" class="mt-3">
                        <input
                            class="input-group--focused text-center mr-2 ml-5 w-50"
                            type="text"
                            :placeholder="$t('pin.force')"
                            ref="fromUsbScaner"
                            v-model="qrcodeString"
                            @keypress="enterKeyPress"
                        > 
                        <v-btn @click="forceReadQR" color="warning">{{$t('actions.validate')}}</v-btn>
                    </v-row>
                    <v-row justify="center" class="mt-5">
                        <p class="subtitle-2">
                            {{ $t('pin.explainQrcode') }}
                        </p>
                    </v-row>
                    <v-row justify="center" v-if="isLongTerm || isAgency">
                        <a class="underline" @click="openQrCodePin"><u>{{$t('pin.qrCode')}}</u></a>
                    </v-row>
                </v-container>
                <v-container v-else-if="!(displayManualPin || displayQrCodePin)" class="pb-0">
                    <v-row justify="center" class="my-5 text-center">
                        <p class="subtitle-2 ma-0">
                            {{ keyGuest ? $t('pin.askGuestCode') : $t('pin.askReferent') }}
                        </p>
                    </v-row>
                    <v-row justify="center" class="mt-1 mb-1">
                        <v-alert
                            v-if="error"
                            color="red"
                            outlined
                            text
                        >
                            {{ error }}
                        </v-alert>
                    </v-row>
                    <v-row justify="center" class="mt-3">
                        <input
                            class="input-group--focused text-center mr-2 ml-5 w-50"
                            type="text"
                            :placeholder="$t('pin.force')"
                            ref="fromUsbScaner"
                            v-model="qrcodeString"
                            @keypress="enterKeyPress"
                        > 
                        <v-btn @click="forceReadQR" color="warning">{{$t('actions.validate')}}</v-btn>
                    </v-row>
                    <v-row justify="center" class="mt-5">
                        <p class="subtitle-2">
                            {{ $t('pin.explainQrcode') }}
                        </p>
                    </v-row>
                    <v-row justify="center">
                        <a v-if="!keyGuest"
                           class="underline"
                           @click="openQrCodePin"><u>{{$t('pin.qrCode')}}</u></a>
                    </v-row>
                    <v-row justify="center">
                        <v-col align="center" lg="4" md="4" sm="4" xl="4">
                            <img
                                :src="getSrc(keyPicture) || defaultKeyPicture"
                                alt="keyPicture"
                                style="object-fit: contain; max-width: 300px;"
                            />
                            <p v-if="keyDescription">{{keyDescription}}</p>
                        </v-col>
                    </v-row>
                </v-container>
                <v-container v-else-if="displayManualPin" class="pb-0">
                    <v-alert
                        v-if="error"
                        color="red"
                        outlined
                        text
                    >
                        {{ error }}
                    </v-alert>
                    <v-row justify="center">
                        <v-col align="center" lg="6" md="6" sm="6" xl="6" class="pb-0">
                            <v-text-field
                                :rules="[rules.pin]"
                                class="input-group--focused"
                                dense
                                outlined
                                pattern="[0-9]*"
                                inputmode="numeric"
                                :placeholder="$t('pin.enter')"
                                rounded
                                type="number"
                                v-model="pin"
                            ></v-text-field>
                            <v-btn
                                v-if="pin"
                                :disabled="!valid"
                                :loading="validatingPin"
                                @click="!keyGuest ? validate():validateKeyToGuest()"
                                color="warning"
                            >
                                {{ $t('pin.validate') }}
                            </v-btn>
                        </v-col>
                    </v-row>
                    <v-row justify="center">
                        <v-col align="center" lg="4" md="4" sm="4" xl="4" class="pt-0">
                            <img
                                :src="getSrc(keyPicture) || defaultKeyPicture"
                                alt="keyPicture"
                                style="object-fit: contain; max-width: 300px;"
                            />
                            <p v-if="keyDescription">{{keyDescription}}</p>
                        </v-col>
                    </v-row>
                </v-container>
                <v-container v-else-if="displayQrCodePin" class="pb-0">
                    <qr-code-reader
                        action="PIN"
                        :read-qr-code="readQRCode"
                        :mobile="mobile"
                        :key-picture="keyPicture"
                        :display-qr-code-reader-modal="displayQrCodePin"
                        :qr-code-error="error"
                        :has-force-input="false"
                        @close="closeAllMethods()"
                    />
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    @click="displayManualPin && isFlow ? closeAllMethods() : $emit('close')"
                    color="white"
                    text
                >
                    {{$t('actions.cancel')}}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Component, Prop, Vue, Watch} from "vue-property-decorator";
import {defaultKeyPicture} from "@/utils/constants";
import { getSrc } from "@/utils/misc";
import {formRules} from "@/utils/formRules";
import QrCodeReader from "@/components/QrCodeReader.vue";
import {TranslateResult} from "vue-i18n";
import {Getter} from "vuex-class";

const REFRESH_TIME_MILLI: number = 1000;

@Component({
    components: {
        QrCodeReader,
    },
})
export default class PinCode extends Vue {
    @Prop({default: null})
    public relayId: number;

    @Prop({default: null})
    public relayType: string;

    @Prop({default: null})
    public keyId: number;

    @Prop({default: ""})
    public keyPicture: string;

    @Prop({default: ""})
    public keyDescription: string;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: false})
    public displayPinPad: boolean;

    @Prop({default: false})
    public displayTransactionLoader: boolean;

    @Prop({default: false})
    public giveKeyToGuest: boolean;

    @Prop({default: null})
    public keyGuest: number;

    @Prop({default: null})
    public defaultMethod?: string;

    @Getter private currentUser: any;

    private qrcodeString: any = "";
    private pin: string = "";
    private displayManualPin: boolean = false;
    private displayQrCodePin: boolean = false;
    private validatingPin: boolean = false;
    private valid: boolean = true;

    private getSrc: (string) => string = getSrc;
    private defaultKeyPicture = defaultKeyPicture;
    private error: TranslateResult = null;
    private rules: object = formRules;
    private intervalId: any = null;

    @Watch("displayTransactionLoader", { immediate: true })
    public handlerTransactionLoader(newVal: boolean): void {
        if (newVal) {
            this.intervalId = setInterval(() => this.getKeyTransaction(), REFRESH_TIME_MILLI);
        }
    }

    get isAgency(): boolean {
        return this.relayType === "AGENCY";
    }

    get isLongTerm(): boolean {
        return this.relayType === "LONG_TERM";
    }

    get isFlow(): boolean {
        return this.relayType === "FLOW";
    }

    get validationWay(): string {
        if (this.displayManualPin) {
            return "manualPin";
        } else if (this.displayQrCodePin) {
            return "qrCodePin";
        } else {
            return "other";
        }
    }

    private mounted(): void {
        if (this.defaultMethod === "manualPin") {
            this.openManualPin();
        }
        const fromUsbScaner = this.$refs.fromUsbScaner as HTMLFormElement;
        if (fromUsbScaner) {
            setTimeout(() => fromUsbScaner.focus(), 500);
        }
    }

    private forceReadQR() {
        if (this.qrcodeString) {
            this.pin = this.qrcodeString;
            this.validate();
        }
    }
    private enterKeyPress(e) {
        if (e.keyCode === 13) {
            this.forceReadQR();
        }
    }

    private validate(): void {
        this.error = null;
        this.validatingPin = true;
        this.$store.dispatch("relays/pinVerification", {relayId: this.relayId, pin: this.pin}).then((referent) => {
            if (!referent.id) {
                this.error = this.$i18n.t("alerts.error.wrongPin");
            } else {
                this.$emit("valid-pin", referent, this.validationWay);
                this.$emit("close");
            }
            this.validatingPin = false;
        }).catch((err) => {
            this.error = this.$i18n.t("alerts.error.wrongPin");
            this.validatingPin = false;
        });
    }

    private validateKeyToGuest(): void {
        this.error = null;
        this.$store.dispatch("relays/pinVerificationToGuest", {
            relayId: this.relayId,
            pin: this.pin,
            guest: this.keyGuest,
        }).then((res) => {
            this.$emit("valid-pin", this.currentUser, this.validationWay);
            this.$emit("close");
        }).catch((err) => {
            this.error = this.$i18n.t("alerts.error.wrongPin");
        });
    }

    private getKeyTransaction(): void {
        this.$store.dispatch("relays/getTransactionByKeyId", {
            keyId: this.keyId,
        }).then((data) => {
            if (data?.outcome === "ACCEPTED") {
                clearInterval(this.intervalId);
                this.$emit("close");
                this.$emit("success");
            } else if (data?.outcome === "DENIED") {
                clearInterval(this.intervalId);
                this.$emit("close");
                this.$emit("failure");
            } else if (!data) {
                clearInterval(this.intervalId);
                this.$store.commit("alerts/displayError", {
                    icon: "icon-picto_historique",
                    msg: this.$i18n?.t("alerts.error.transactionExpired"),
                });
                this.$emit("close");
            }
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private openManualPin(): void {
        this.$emit("manual-pin");
        this.displayManualPin = true;
    }

    private openQrCodePin(): void {
        this.$emit("qr-code-pin");
        this.displayQrCodePin = true;
    }

    private closeAllMethods(): void {
        this.displayQrCodePin = false;
        this.displayManualPin = false;
        this.pin = null;
        this.error = null;
    }

    private readQRCode(pin): void {
        this.pin = pin;
        this.validate();
    }

    private beforeDestroy(): void {
        clearInterval(this.intervalId);
    }
}
</script>
