<template>
    <v-row>
        <span class="input-title">{{ $t('form.default_guests') }}</span>
        <v-col cols="12 pa-0">
            <v-row
                v-for="(guest, i) in newGuests"
                :key="i"
                align="center"
            >
                <span></span>
                <v-col class="pa-0 pl-4">
                    <v-avatar class="ma-2" size="30">
                        <img :src="getUserGroupPicture(guest)" alt/>
                    </v-avatar>
                    {{ guest.name || guest.Users[0].displayName }}
                </v-col>
                <v-col class="py-0" align="right">
                    {{ guest.company }}
                    <v-btn @click="remove(guest)" icon>
                        <v-icon small>delete</v-icon>
                    </v-btn>
                </v-col>
            </v-row>
            <v-autocomplete
                :search-input.sync="search"
                v-model="newGuests"
                :items="removeDuplicates(contacts, newGuests)"
                append-icon
                hide-no-data
                :no-data-text="$t('keysList.noUserFound')"
                flat
                no-filter
                multiple
                solo
                prepend-inner-icon="add"
                v-bind:label="$t('key.addGuests')"
            >
                <template v-slot:selection="data"></template>
                <template v-slot:item="data">
                    <v-list-item-avatar>
                        <img :src="getUserGroupPicture(data.item)" alt/>
                    </v-list-item-avatar>
                    <v-list-item-content
                        v-if="data.item.type === 'user'"
                    >
                        <v-list-item-title v-html="data.item.Users[0].displayName"></v-list-item-title>
                        <v-list-item-subtitle v-html="data.item.Users[0].company"></v-list-item-subtitle>
                    </v-list-item-content>
                    <v-list-item-content
                        v-else
                    >
                        <v-list-item-title v-html="data.item.name"></v-list-item-title>
                    </v-list-item-content>
                </template>
            </v-autocomplete>
        </v-col>
    </v-row>
</template>

<script lang="ts">
import {Vue, Component, Prop, Watch} from "vue-property-decorator";
import {defaultUserAvatar, defaultUserGroupAvatar, defaultKeyPicture} from "@/utils/constants";
import {getSrc} from "@/utils/misc";
import {Getter} from "vuex-class";
import {canUseManagers} from "plan-restrictions";
import {TranslateResult} from "vue-i18n";

@Component({})
export default class RelayAddGuests extends Vue {

    @Prop({default: null})
    public guests: any;

    @Getter private currentUser: any;
    @Getter private isMaster: (type?: string) => boolean;
    private contacts: any = [];
    private search: string = null;
    private defaultUserAvatar: string = defaultUserAvatar;
    private defaultUserGroupAvatar: string = defaultUserGroupAvatar;
    private newGuests: any = [];

    public async mounted() {
        this.getContacts();
        this.newGuests = await JSON.parse(JSON.stringify(this.guests));
    }

    @Watch("search")
    public handlerSearch() {
        this.getContacts();
    }

    @Watch("newGuests")
    public handlernewGuests() {
        this.$emit("update:guests", this.newGuests);
    }

    get planName(): TranslateResult {
        return this.$i18n.t(`plan.${this.currentUser?.company?.currentSubscription?.Plan?.name}.name`);
    }

    private getContacts() {
        const p: Array<Promise<any>> = [
            this.$store.dispatch("users/getContacts", {
                query: {
                    search: this.search,
                    groups: true,
                },
            }),
            this.$store.dispatch("users/getUserGroups", {
                userId: this.currentUser.id,
                query: {
                    search: this.search,
                    type: "contacts",
                },
            }),
        ];
        Promise.all(p).then(([contacts, contactsGroups]) => {
            this.contacts = [
                ...contacts?.users || [],
                ...contactsGroups?.list || [],
            ].map((item: any) => ({...item}));
        });
    }

    private getUserGroupPicture(group: any) {
        return group?.name === null
            ? (group?.Users?.[0]?.picturePath || this.defaultUserAvatar)
            : this.defaultUserGroupAvatar;
    }

    private removeDuplicates(completeList, duplicates) {
        if (!completeList || !duplicates) {
            return null;
        }
        return completeList.filter(
            (item: any) =>
                !duplicates.map((elem: any) => elem?.id)?.includes(item?.id),
        );
    }

    private remove(item) {
        const index = this.newGuests.findIndex((i: any) => i?.id === item.id);
        if (index >= 0) {
            this.newGuests.splice(index, 1);
        }
    }
}
</script>
