<template>
    <v-row>
        <span class="input-title">{{$t('form.referents')}}</span>
        <v-col cols="12 pa-0">
            <v-row
                v-for="(referent, i) in newReferents"
                :key="i"
                align="center"
            >
                <v-col class="pa-0 pl-4">
                    <v-avatar class="ma-2" size="30">
                        <img :src="getSrc(referent.picturePath) || defaultUserAvatar" alt />
                    </v-avatar>
                    {{referent.displayName}}
                </v-col>
                <v-col class="py-0" align="right">
                    {{referent.company}}
                    <v-btn @click="remove(referent)" icon>
                        <v-icon small>delete</v-icon>
                    </v-btn>
                </v-col>
            </v-row>
            <v-autocomplete
                :hint="$tc('restrictions.maxReferents.text', maxReferentsNbr, {planName: planName, maxValue: maxReferentsNbr})"
                :hide-details="!disableMoreReferents"
                :persistent-hint="disableMoreReferents"
                :disabled="disableMoreReferents"
                :search-input.sync="search"
                v-model="newReferents"
                :items="removeDuplicates(subordinates, newReferents)"
                append-icon
                hide-no-data
                flat
                no-filter
                multiple
                solo
                prepend-inner-icon="add"
                v-bind:label="$t('relay.addReferents')"
            >
                <template v-slot:selection="data"></template>
                <template v-slot:item="data">
                    <v-list-item-avatar>
                        <img :src="getSrc(data.item.picturePath) || defaultUserAvatar" alt />
                    </v-list-item-avatar>
                    <v-list-item-content>
                        <v-list-item-title v-html="data.item.displayName"></v-list-item-title>
                    </v-list-item-content>
                </template>
            </v-autocomplete>
        </v-col>
    </v-row>
</template>

<script lang="ts">
import {Vue, Component, Prop, Watch} from "vue-property-decorator";
import { defaultUserAvatar } from "@/utils/constants";
import {getSrc} from "@/utils/misc";
import {Getter} from "vuex-class";
import {canUseManagers, canAddMoreReferents} from "plan-restrictions";
import {TranslateResult} from "vue-i18n";

@Component({})
export default class RelayAddReferents extends Vue {
    @Prop({default: null})
    public referents: any;

    @Getter private currentUser: any;
    @Getter private isMaster: (type?: string) => boolean;
    private subordinates: any = [];
    private search: string = null;
    private defaultUserAvatar: string = defaultUserAvatar;
    private getSrc: (string) => string = getSrc;
    private newReferents: any = [];
    private canUseManagers: (company: any) => boolean = canUseManagers;
    private canAddMoreReferents: (
        company: any,
        existingReferentsNbr: number,
        newReferentsNbr: number,
    ) => boolean = canAddMoreReferents;

    public async mounted() {
        this.newReferents = await JSON.parse(JSON.stringify(this.referents));
        if (this.canUseManagers(this.currentUser.company) && !this.disableMoreReferents) {
            this.getSubordinates();
        }
    }

    @Watch("search")
    public handlerSearch() {
        if (this.canUseManagers(this.currentUser.company) && !this.disableMoreReferents) {
            this.getSubordinates();
        }
    }

    @Watch("newReferents")
    public handlerNewReferents() {
        this.$emit("update:referents", this.newReferents);
    }

    get planName(): TranslateResult {
        return this.$i18n.t(`plan.${this.currentUser?.company?.currentSubscription?.Plan?.name}.name`);
    }

    get maxReferentsNbr(): number {
        return this.currentUser?.company?.currentSubscription?.Plan?.details?.maxReferents;
    }

    get disableMoreReferents(): boolean {
        return !this.currentUser.isAdmin && !this.canAddMoreReferents(
            this.currentUser.company,
            1, // master of the relay
            this.newReferents.length + 1, // +1 to prevent master from selecting more referents than authorized
        );
    }

    private getSubordinates() {
        this.$store
            .dispatch("users/getSubordinates", {query: {search: this.search}})
            .then((res) => {
                this.subordinates = res.users.filter((u) => u);
            });
    }

    private removeDuplicates(completeList, duplicates) {
        if (!completeList || !duplicates) {
            return null;
        }
        return completeList.filter(
            (item: any) =>
                !duplicates.map((elem: any) => elem?.id)?.includes(item?.id),
        );
    }

    private remove(item) {
        const index = this.newReferents.findIndex((i: any) => i?.id === item.id);
        if (index >= 0) {
            this.newReferents.splice(index, 1);
        }
    }
}
</script>
