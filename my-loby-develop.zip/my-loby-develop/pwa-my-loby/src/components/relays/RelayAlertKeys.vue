<template>
    <div>
        <div v-if="lateKeys.length || transitKeys.length">
            <p class="tableau_titre">{{$t('relay.alertKeys.title')}} <i class="icon-header_triangle"></i></p>
            <div class="tableau">
                <div class="banque_row row">
                    <div class="col-md-6" v-if="lateKeys.length">
                        <label>{{$t('relay.alertKeys.late.title')}} :</label>
                        <v-alert
                            min-width="200px"
                            max-width="400px"
                            class="ma-3 pa-0"
                            color="red"
                            outlined
                            text
                            v-for="key in lateKeys"
                        >
                            <v-row align="center">
                                <v-col class="grow">
                                    <v-avatar class="ma-0" size="30">
                                        <img :src="getSrc(key.picturePath) || defaultKeyPicture" alt/>
                                    </v-avatar>
                                    {{key.name}}
                                </v-col>
                            </v-row>
                        </v-alert>
                    </div>
                    <div class="col-md-6" v-if="transitKeys.length">
                        <label>{{$t('relay.alertKeys.transit.title')}} :</label>
                        <v-alert
                            min-width="200px"
                            max-width="400px"
                            class="ma-3 pa-0"
                            color="orange"
                            outlined
                            text
                            v-for="key in transitKeys"
                        >
                            <v-row align="center">
                                <v-col class="grow">
                                    <v-avatar size="30">
                                        <img :src="getSrc(key.picturePath) || defaultKeyPicture" alt/>
                                    </v-avatar>
                                    {{key.name}}
                                </v-col>
                                <v-col align="center" class="shrink pt-3">
                                    <v-dialog
                                        persistent
                                        max-width="500px"
                                        :retain-focus="false"
                                        v-model="transitRetrieveDialog">
                                        <template v-slot:activator="{ on }">
                                            <v-btn
                                                v-if="key.status!==IN_TRANSIT"
                                                @click="currentKey = key"
                                                icon
                                                outlined
                                                v-on="on"
                                                small
                                            >
                                                <v-tooltip top>
                                                    <template v-slot:activator="{ on }">
                                                        <v-icon v-on="on">check</v-icon>
                                                    </template>
                                                    <span>{{$t('relay.alertKeys.transit.retrieve.button')}}</span>
                                                </v-tooltip>
                                            </v-btn>
                                        </template>
                                        <v-card v-if="currentKey">
                                            <v-card-title>
                                                <span
                                                    class="headline">{{$t('relay.alertKeys.transit.retrieve.title')}}</span>
                                            </v-card-title>
                                            <v-card-text class="py-0">
                                                <v-container>
                                                    <v-row>
                                                        <h5>{{$t('title.warning')}}</h5>
                                                        <p>{{$t('relay.alertKeys.transit.retrieve.text', {key: currentKey.name})}}</p>
                                                    </v-row>
                                                    <v-row>
                                                        <v-col class="pa-0" cols="12">
                                                            <v-checkbox
                                                                class="ma-0"
                                                                color="orange"
                                                                hide-details
                                                                v-bind:label="$t('actions.confirm')"
                                                                v-model="confirmTransitRetrieve"
                                                                value="true"
                                                            ></v-checkbox>
                                                        </v-col>
                                                    </v-row>
                                                </v-container>
                                            </v-card-text>
                                            <v-card-actions>
                                                <v-spacer></v-spacer>
                                                <v-btn
                                                    @click="transitRetrieveDialog = false"
                                                    color="white"
                                                    text
                                                >
                                                    {{$t('actions.cancel')}}
                                                </v-btn>
                                                <v-btn
                                                    @click="retrieveTransitKey"
                                                    color="warning"
                                                    v-if="confirmTransitRetrieve"
                                                >
                                                    {{$t('actions.confirm')}}
                                                </v-btn>
                                            </v-card-actions>
                                        </v-card>
                                    </v-dialog>
                                </v-col>
                                <v-col align="center" class="shrink pl-0 pt-3">
                                    <v-dialog
                                        v-if="alertKeyId !== key.id"
                                        persistent
                                        max-width="500px"
                                        :retain-focus="false"
                                        v-model="reportMissingDialog">
                                        <template v-slot:activator="{ on }">
                                            <v-btn
                                                @click="currentKey = key"
                                                color="red"
                                                icon
                                                outlined
                                                v-on="on"
                                                small
                                            >
                                                <v-tooltip top>
                                                    <template v-slot:activator="{ on }">
                                                        <v-icon v-on="on">priority_high</v-icon>
                                                    </template>
                                                    <span>{{$t('relay.alertKeys.transit.report.button')}}</span>
                                                </v-tooltip>
                                            </v-btn>
                                        </template>
                                        <v-card v-if="currentKey">
                                            <v-card-title>
                                                <span
                                                    class="headline">{{$t('relay.alertKeys.transit.report.title')}}</span>
                                            </v-card-title>
                                            <v-card-text class="py-0">
                                                <v-container>
                                                    <v-row>
                                                        <p>{{$t('relay.alertKeys.transit.report.text', {key: currentKey.name})}}</p>
                                                    </v-row>
                                                </v-container>
                                            </v-card-text>
                                            <v-card-actions>
                                                <v-spacer></v-spacer>
                                                <v-btn
                                                    @click="reportMissingDialog = false"
                                                    color="white"
                                                    text
                                                >
                                                    {{$t('actions.cancel')}}
                                                </v-btn>
                                                <v-btn
                                                    @click="reportMissingKey"
                                                    color="warning"
                                                >
                                                    {{$t('actions.confirm')}}
                                                </v-btn>
                                            </v-card-actions>
                                        </v-card>
                                    </v-dialog>
                                    <v-tooltip v-else top>
                                        <template v-slot:activator="{ on }">
                                            <v-icon v-on="on" color="red">send</v-icon>
                                        </template>
                                        <span>{{$t('relay.alertKeys.transit.report.alerted')}}</span>
                                    </v-tooltip>
                                </v-col>
                            </v-row>
                        </v-alert>
                    </div>
                </div>
            </div>
        </div>
        <v-dialog
            persistent
            max-width="500px"
            v-model="newLocationDialog"
        >
            <v-card>
                <v-card-title>
                    <span class="headline"
                          v-if="newLocation">{{$t('relay.alertKeys.transit.retrieve.newLocation')}}</span>
                    <span class="headline" v-else>{{$t('relay.alertKeys.transit.retrieve.noLocation')}}</span>
                </v-card-title>
                <v-card-text class="py-0">
                    <v-container v-if="newLocation">
                        <v-row>
                            <p>{{$t('relay.alertKeys.transit.retrieve.newLocationText')}}</p>
                        </v-row>
                        <v-row justify="center">
                            <p>{{newLocation.codeName}}</p>
                        </v-row>
                    </v-container>
                    <v-container v-else>
                        <v-row>
                            <p>{{$t('relay.alertKeys.transit.retrieve.noLocationText')}}</p>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="newLocationDialog = false"
                        color="blue darken-1"
                        text
                    >
                        {{$t('actions.close')}}
                    </v-btn>
                    <v-spacer></v-spacer>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";
import KeyStatus from "@/components/keys/KeyStatus.vue";
import {defaultKeyPicture} from "@/utils/constants";
import {getSrc} from "@/utils/misc";

@Component({
    components: {
        KeyStatus,
    },
})
export default class RelayAlertKeys extends Vue {
    @Prop({default: null})
    public relay: any;

    @Prop({})
    public updateData: () => void;

    private IN_TRANSIT: string = "IN_TRANSIT";

    private lateKeys: any[] = [];
    private transitKeys: any[] = [];
    private alertKeyId: number = null;
    private currentKey: any = null;
    private newLocation: any = null;
    private transitRetrieveDialog: boolean = false;
    private reportMissingDialog: boolean = false;
    private newLocationDialog: boolean = false;
    private confirmTransitRetrieve: boolean = false;
    private defaultKeyPicture: string = defaultKeyPicture;
    private getSrc: (string) => string = getSrc;

    private mounted() {
        this.getAlertKeys();
    }

    private getAlertKeys() {
        return this.$store.dispatch("relays/getAlertKeys", {
            relayId: this.relay.id,
        }).then((res) => {
            this.lateKeys = [];
            this.transitKeys = [];
            if (res) {
                this.lateKeys = res.filter((key) => key.status === "LATE");
                this.transitKeys = res.filter((key) => key.status === "IN_TRANSIT");
            }
        });
    }

    private retrieveTransitKey() {
        this.transitRetrieveDialog = false;
        this.confirmTransitRetrieve = false;
        return this.$store.dispatch("keys/retrieveFromTransit", {
            relayId: this.relay.id,
            keyId: this.currentKey?.id,
        }).then((res) => {
            this.$store.commit("alerts/displaySuccess", {
                icon: "icon-picto_transit",
                msg: this.$i18n?.t("alerts.key.transitRetrieveSuccess", {key: this.currentKey.name,
                    relay: res.Box?.Relay?.name || ""}),
            });
            if (res) {
                this.$emit("reset");
                this.newLocation = res;
            }
            this.newLocationDialog = true;
            this.updateData();
            this.getAlertKeys();
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                icon: "icon-picto_transit",
                msg: this.$i18n?.t("alerts.error.default"),
            });
        });
    }

    private reportMissingKey() {
        this.reportMissingDialog = false;
        return this.$store.dispatch("keys/reportMissing", {
            relayId: this.relay.id,
            keyId: this.currentKey?.id,
        }).then(() => {
            this.alertKeyId = this.currentKey.id;
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("relay.alertKeys.transit.report.emailSent"),
            });
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }
}
</script>