<template>
    <div v-if="balanceInfo">
        <p class="tableau_titre">{{$t('relay.infoBalance.title')}}<i class="icon-header_triangle"></i></p>
        <div class="tableau">
            <div class="solde_actuel_row row no-gutters">
                <div class="col-md-6">
                    <div class="statistiques">
                        <h1>
                            <strong>{{balanceInfo.totalPriceHT.toFixed(2)}}{{$t("currency.symbol")}}</strong>
                            ({{$t("currency.excludingTaxes")}})
                            <br>
                            <span v-if="relay.activatedAt">
                                {{$t('relay.infoBalance.since')}} {{balanceInfo.startDate | formatShortDate}}
                            </span>
                            <span v-else>
                                {{$t('relay.notActivated')}}
                            </span>
                        </h1>
                    </div>
                    <!-- /.statistiques_agence -->
                </div>
                <div class="col-md-6 text-right">
                    <div v-if="isAdmin">
                        <button
                            @click="editRatesModal = true"
                            class="btn_style"
                        >
                            <i class="icon-picto_mon-compte"></i>
                            {{$t('relay.infoBalance.editRates.title')}}
                        </button>
                        <relay-edit-rates
                            :relay="relay"
                            :dialog="editRatesModal"
                            :update="update"
                            @close="editRatesModal = false"
                        />
                    </div>
                    <div v-else>
                        <button
                            :disabled="!relay.activatedAt"
                            :title="relay.activatedAt ? $t('relay.infoBalance.editInvoice.title') : $t('relay.notActivated')"
                            @click="editInvoiceModal = true"
                            class="btn_style"
                        >
                            <i class="icon-picto_factures"></i>
                            {{$t('relay.infoBalance.editInvoice.title')}}
                        </button>
                        <relay-edit-invoice
                            :relayId="relay.id"
                            :lastInvoice="balanceInfo.lastInvoice"
                            :dialog="editInvoiceModal"
                            @close="editInvoiceModal = false"
                            @reset="$emit('reset')"
                        />
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";
import {Getter} from "vuex-class";
import RelayEditInvoice from "@/components/relays/RelayEditInvoice.vue";
import RelayEditRates from "@/components/relays/RelayEditRates.vue";

@Component({
    components: {
        RelayEditInvoice,
        RelayEditRates,
    },
})
export default class RelayBalance extends Vue {
    @Prop({default: null})
    public relay: any;

    @Prop({default: {}})
    public balanceInfo: any;

    @Prop({})
    public update: (relay) => void;

    @Getter private isAdmin: boolean;

    private editInvoiceModal: boolean = false;
    private editRatesModal: boolean = false;
}
</script>