<template>
    <div>
        <p class="tableau_titre">{{$t('relay.infoBank.title')}} <i class="icon-header_triangle"></i></p>
        <div class="tableau">
            <div class="options">
                <div class="option_left"></div>
                <div class="option_right">
                    <a @click="showEdit" class="option" v-if="hasRight" >
                        <i class="icon-picto_editer"></i>
                        {{$t('actions.edit')}}
                    </a>
                </div>
            </div>
            <div class="banque_row row">
                <div class="col-md-6">
                    <label>{{$t('relay.infoBank.holder')}} :</label>
                    <p>{{relay.bankHolder ||  $t('relay.infoBank.blank')}}</p>
                </div>
                <div class="col-md-6">
                    <label>IBAN :</label>
                    <p>{{relay.iban ||  $t('relay.infoBank.blank')}}</p>
                </div>
            </div>
        </div>
        <v-dialog
            persistent
            max-width="910px"
            v-model="isEdit"
        >
            <v-card v-if="newInfo">
                <v-card-title>
                    <div class="contain_picto">
                        <i class="icon-picto_factures"></i>
                    </div>
                    <span class="headline">{{$t('relay.infoBank.edit')}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-row>
                            <v-text-field :label="$t('relay.infoBank.holder')" v-model="newInfo.bankHolder"></v-text-field>
                        </v-row>
                        <v-row>
                            <v-text-field label="Iban" v-model="newInfo.iban"></v-text-field>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn text @click="closeEdit" color="white">{{$t('actions.cancel')}}</v-btn>
                    <v-btn
                        v-if="newInfo.bankHolder && newInfo.iban"
                        @click="save"
                        color="warning"
                    >{{$t('actions.save')}}</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";

@Component({})
export default class RelayBankInfo extends Vue {
    @Prop({default: null})
    public relay: any;

    @Prop({})
    public update: (relay) => void;

    @Prop({default: false})
    public hasRight: boolean;

    private isEdit: boolean = false;
    private newInfo: any = null;

    private closeEdit() {
        this.newInfo = {};
        this.isEdit = false;
    }

    private async showEdit() {
        this.newInfo = await JSON.parse(JSON.stringify(this.relay));
        this.isEdit = true;
    }

    private save() {
        this.update(this.newInfo);
        this.closeEdit();
    }
}
</script>