<template>
    <div>
        <v-btn
            v-if="!mobile"
            @click.stop="openModal" icon
            style="width: inherit"
        >
            <v-icon small>lock</v-icon>
        </v-btn>
        <button
            v-if="mobile"
            style="width: inherit"
            type="button"
            class="action_button"
            @click="openModal"
        >
            <p class="with_key action_key">
                    <span class="rapatrier_picto">
                        <v-icon small>lock</v-icon>
                    </span>
                <strong>{{$t('booking.keyIsBooked.mobileTitle')}}</strong>
            </p>
        </button>
        <key-booked-modal
            :show="quickBookedKeyDialog"
            :currentKey="currentKey"
            @closeModal="closeModal"
        />
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import {Getter} from "vuex-class";
import KeyBookedModal from "@/components/keys/KeyBookedModal.vue";

@Component({
    components: {
        KeyBookedModal,
    },
})
export default class RelayBookedKey extends Vue {
    @Prop({default: {}})
    public currentKey: any;

    @Prop({default: false})
    public mobile: boolean;

    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;

    private quickBookedKeyDialog: boolean = false;

    private openModal() {
        this.quickBookedKeyDialog = true;
    }

    private closeModal() {
        this.quickBookedKeyDialog = false;
    }
}
</script>
