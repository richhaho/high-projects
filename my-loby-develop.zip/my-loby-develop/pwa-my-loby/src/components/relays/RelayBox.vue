<template>
    <div style="flex-wrap:wrap ;max-width: none;min-height: 355px; overflow:hidden;" class="tableau">
    <v-row style="margin-right: auto !important;" class="fill-height">
        <v-col :cols="box.Tags && box.Tags.length > 0 ? '5' :'12'"  class="equipement_details">
            <i class="icon-picto_mosaique"></i>
            <relay-create-or-edit-box
                v-if="!box.Tags || box.Tags.length===0"
                :box="box"
                @reset="$emit('reset')"
            >
            </relay-create-or-edit-box>
            <p><strong>{{!box.size ? "Loby Box": ""}} {{box.size ? $t('box.connected', {size: box.size || ""}) : ''}} n°{{index+1}}</strong></p>
            <p v-if="box.name"><strong>{{ $tc("key.name") + ': ' + box.name }}</strong></p>
            <p>
                {{ $tc('box.locations', 0) }} :
                {{ boxDimensions || 0 }}
            </p>
            <a @click="displayLocationsDialog()" class="lien btn_style no_picto">{{ $t('box.seeMap') }}</a>
            <br/>
            <a :href="$store.state.baseURL ? `${$store.state.baseURL}/api/boxes/${box.id}/generate-qr-code` :
                            `/api/boxes/${box.id}/generate-qr-code`"
               v-if="boxDimensions && !box.size"
               class="lien btn_style no_picto"
               target="_blank"
            >{{ $t('box.printAllQrCodes') }}</a>
        </v-col>
        <v-col v-if="box.Tags && box.Tags.length > 0" cols="2" align="center" class="pa-0">
            <v-divider vertical></v-divider>
        </v-col>
        <v-col v-if="box.Tags && box.Tags.length" cols="5" class="equipement_details ">
            <relay-create-or-edit-box
                :box="box"
                @reset="$emit('reset')"
            >
            </relay-create-or-edit-box>
            <div class="tags mt-5" v-if="box.Tags.length>0">
                <div v-if="box.Locations">
                    <span class="strong">{{ $t("box.stockTitle") }} :</span>
                    <div v-for="(tag,i) in box.Tags.slice(0,4)" :key="i">
                        <p  v-if="getKeyNbr(tag) >= minimumKeys">
                            <i class="icon-picto_cle-partagees mr-2"></i> {{getKeyNbr(tag)}} / {{minimumKeys}} {{tag[lang]}}
                        </p>
                        <p v-else style="color: red">
                            <i class="icon-picto_cle-partagees mr-2"></i>  {{getKeyNbr(tag)}} / {{minimumKeys}} {{tag[lang]}}
                        </p>
                    </div>
                    <p v-if="box.Tags.length > tagsDisplayed">
                        <a @click="showMoreTags=true" style="color: #fe9303;" title="Actions"><i class="icon-picto_ajouter mr-2"></i>
                            {{
                                $t('keysList.displayXMore', {
                                    count: box.Tags.length - tagsDisplayed
                                })
                            }}</a>
                    </p>
                </div>
                <div v-else>
                    <p class="mt-10">
                        {{$t('box.noKeysInBox')}}
                    </p>
                </div>
            </div>
        </v-col>

        <relay-box-locations
            v-if="showLocations"
            :show="showLocations"
            :close="closeLocationsDialog"
            :loading="loadingLocations"
            :locations="boxLocations"
            :box="box"
        />
        <v-dialog
            v-if="showMoreTags"
            persistent
            width="910px"
            v-model="box"
        >
            <v-card>
                <v-card-title>
                    <span class="headline">{{$tc('key.currentTags',box.Tags.length)}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container >
                        <div class="tags  mt-2 ">
                            <div v-for="(tag,i) in box.Tags" :key="i">
                                <p v-if="getKeyNbr(tag) >= minimumKeys">
                                    <i class="icon-picto_cle-partagees mr-2"></i> {{getKeyNbr(tag)}} / {{minimumKeys}} {{tag[lang]}}
                                </p>
                                <p v-else style="color: red">
                                    <i class="icon-picto_cle-partagees mr-2"></i>  {{getKeyNbr(tag)}} / {{minimumKeys}} {{tag[lang]}}
                                </p>
                            </div>
                        </div>

                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="showMoreTags = false"
                        color="white"
                        text
                    >
                        {{ $t('actions.close') }}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>

    </v-row>
    </div>
</template>


<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";
import RelayBoxLocations from "@/components/relays/RelayBoxLocations.vue";
import RelayCreateOrEditBox from "@/components/relays/RelayCreateOrEditBox.vue";

@Component({
    components: {
        RelayBoxLocations,
        RelayCreateOrEditBox,
    },
})

export default class RelayBox extends Vue {
    @Prop({default: null})
    public relay: any;

    @Prop({default: null})
    public box: any;

    @Prop({default: 0})
    public index: number;

    @Prop({default: 0})
    public minimumKeys: number;

    public showMoreTags: boolean = false;

    get boxDimensions(): number {
        return this.box ? this.box.sheets * this.box.columns * this.box.lines : 0;
    }
    get lang(): string {
        return this.$root.$i18n.locale;
    }

    private loadingLocations: boolean = true;
    private showLocations: boolean = false;
    private boxLocations: any[] = [];
    private tagsDisplayed: number = 4;

    private displayLocationsDialog(): void {
        this.showLocations = true;
        this.getLocations();
    }

    private getLocations(): void {
        this.$store.dispatch("boxes/getLocations", {id: this.box.id}).then(
            (data) => {
                this.boxLocations = data?.rows || [];
                this.loadingLocations = false;
            },
        );
    }

    private closeLocationsDialog(): void {
        this.showLocations = false;
    }

    private getKeyNbr(tag): number {
        let keyWithExistantTag: number = 0;
        this.box.Locations.forEach((l) => {
            l.KeyLocation.forEach((kl) => {
                kl.Key.Tags.forEach((t) => {
                    if (tag.id === t.id) {
                        keyWithExistantTag++;
                    }
                });
            });
        });
        return keyWithExistantTag;
    }

}
</script>