<template>
    <div id="popup_ou_sont_cles"  :class="['popup', {'open': show}]">
        <div class="bloc">
            <a class="fermer" @click="closeDialog"><i class="icon-picto_ajouter"></i></a>
            <v-row v-if="loading" justify="center" style="min-height: 250px;">
                <v-progress-circular
                    :width="3"
                    color="#0c0733"
                    indeterminate
                    style="margin-top: 110px;"
                />
            </v-row>
            <div class="keys_location" v-else-if="locations.length">
                <div :style="tableStyle">
                    <table>
                        <thead>
                        <tr>
                            <th></th>
                            <th v-for="(col, i) in columnsName" :key="i">{{col}}</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr v-for="(line, i) in orderedLocations[activeSheet - 1]" :key="i">
                            <td>{{i + 1}}</td>
                            <td v-for="(loc, j) in line" :key="j">
                                <v-tooltip bottom>
                                    <template v-slot:activator="{ on }">
                                        <a :href="`${$store.state.baseURL}/api/locations/${loc.id}/generate-qr-code`" target="_blank">
                                            <span v-on="on" :style="getCellStyle(loc)" :class="[{'vide': isLocationEmpty(loc)},{'plein': !isLocationEmpty(loc) }]">
                                                <i
                                                    v-if="!isLocationEmpty(loc)"
                                                    :class="getLocationIcon(loc)"
                                                    :style="loc.ReservedCompany ? 'color: white;' : ''"
                                                ></i>
                                            </span>
                                        </a>
                                    </template>
                                    <v-row justify="center" class="ma-0">
                                        <span>{{loc.codeName}}</span>
                                    </v-row>
                                    <v-row v-if="loc.ReservedCompany && loc.KeyLocation.some((kL) => kL.endDate === null)" justify="center" class="ma-0">
                                        {{ $t("locations.usedBy", {name: loc.ReservedCompany.name}) }}
                                    </v-row>
                                    <v-row v-else-if="loc.KeyLocation.some((kL) => kL.endDate === null)" justify="center" class="ma-0">
                                        {{ $t("locations.actuallyUsed") }}
                                    </v-row>
                                    <v-row v-else-if="loc.ReservedCompany" justify="center" class="ma-0">
                                        {{ $t("locations.reservedFor", {name: loc.ReservedCompany.name}) }}
                                    </v-row>
                                    <v-row v-else-if="loc.ReservedKey" justify="center" class="ma-0">
                                        {{ $t("locations.reservedForUser") }}
                                    </v-row>
                                </v-tooltip>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <p class="ma-0"><span></span>{{$t('box.availableSpot')}}</p>
                <p class="ma-0" v-for="(insurance, i) in insurancesList">
                    <span :style="`background-color: ${insurance.color}; opacity: 0.9;`"></span>{{insurance.name}}
                </p>
                <ul v-if="box.sheets <= paginationStyleThreshold" class="pagination">
                    <li>
                        <a :class="['first', {'off': activeSheet === 1 }]" @click="changeSheet('minus')"><i class="icon-header_triangle"></i></a>
                    </li>
                    <li v-for="(sh, i) in box.sheets" :key="i">
                        <a @click="activeSheet= i+1" :class="{'on': activeSheet === i+1}">{{i+1}}</a>
                    </li>
                    <li>
                        <a :class="['last', {'off': activeSheet === this.box.sheets }]" @click="changeSheet('plus')"><i class="icon-header_triangle"></i></a>
                    </li>
                </ul>
                <ul v-else class="pagination">
                    <!-- Prev -->
                    <li>
                        <a :class="['first', {'off': activeSheet === 1 }]" @click="changeSheet('minus')"><i class="icon-header_triangle"></i></a>
                    </li>
                    <!-- First -->
                    <li v-if="!nextToActiveSheets.includes(1)">
                        <a @click="activeSheet=1" :class="{'on': activeSheet === 1}">1</a>
                    </li>
                    <!-- ... -->
                    <li v-if="!nextToActiveSheets.includes(2)">
                        <a>...</a>
                    </li>
                    <!-- Currents -->
                    <li v-for="(sh, i) in nextToActiveSheets" :key="i">
                        <a @click="activeSheet=sh" :class="{'on': activeSheet === sh}">{{sh}}</a>
                    </li>
                    <!-- ... -->
                    <li v-if="!nextToActiveSheets.includes(box.sheets - 1)">
                        <a>...</a>
                    </li>
                    <!-- Last -->
                    <li v-if="!nextToActiveSheets.includes(box.sheets)">
                        <a @click="activeSheet=box.sheets" :class="{'on': activeSheet === box.sheets}">{{box.sheets}}</a>
                    </li>
                    <!-- Next -->
                    <li>
                        <a :class="['last', {'off': activeSheet === this.box.sheets }]" @click="changeSheet('plus')"><i class="icon-header_triangle"></i></a>
                    </li>
                </ul>
            </div>
            <p class ="ta-center mt-5" v-else>{{$t('box.noQRCodeCreated')}}</p>
        </div>
    </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";
import LogTable from "@/components/logs/LogTable.vue";

const MAX_DISPLAYED_TABS: number = 2;

@Component({
    components: {LogTable},
})
export default class RelayBoxLocation extends Vue {
    @Prop({default: null})
    public locations: any;

    @Prop({default: null})
    public box: any;

    @Prop({default: false})
    public show: boolean;

    @Prop({default: true})
    public loading: boolean;

    @Prop({})
    public close: () => void;

    private activeSheet: number = 1;

    get tableStyle(): string {
        const height = (this.box.lines - 1) * 80 + 150 + 20;
        return `width: 100%; height: ${height}px; overflow: auto; max-height: 700px`;
    }

    get paginationStyleThreshold(): number {
        return MAX_DISPLAYED_TABS * 4;
    }

    get nextToActiveSheets(): number[] {
        const baseArray: number[] = Array.from(Array(this.box.sheets).keys());
        return baseArray.map((i) => i + 1).filter((i) =>
            i >= this.activeSheet - MAX_DISPLAYED_TABS
            && i <= this.activeSheet + MAX_DISPLAYED_TABS,
        );
    }

    get columnsName(): string[] {
        const columns = [];
        for (let i = 0; i < this.box.columns ; i++) {
            columns.push(this.getColumnName(i));
        }
        return columns;
    }

    get orderedLocations(): any[] {
        const locations = [];
        for (let i = 0; i < this.box.sheets ; i++) {
            locations.push([]);
        }
        for (let i = 0; i < this.box.lines ; i++) {
            locations.map((sheet) => {
                sheet.push([]);
            });
        }
        this.locations.map((loc) => {
           locations[loc.sheet - 1][loc.line - 1][loc.column - 1] = loc;
        });
        return locations;
    }

    get insurancesList(): any[] {
        const isItemInList = (item, list) => list.map((obj) => obj.id).includes(item.id);
        return this.locations.reduce((a, c) => {
            if (c.ReservedCompany && !isItemInList(c.ReservedCompany, a)) {
                a.push(c.ReservedCompany);
            }
            return a;
        }, []);
    }

    private isLocationEmpty(loc: any): boolean {
        // If there is no key at the location, and it is not reserved, then it's empty
        return !(loc.KeyLocation?.some((kL) => kL.endDate === null) || loc.keyId || loc.companyId);
    }

    private getLocationIcon(loc: any): string {
        if (loc.KeyLocation?.some((kL) => kL.endDate === null)) {
            return "icon-picto_cle-partagees";
        } else if (loc.companyId) {
            return "icon-picto_company";
        } else if (loc.keyId) {
            return "icon-picto_mes-contacts";
        } else {
            return "";
        }
    }

    private getCellStyle(loc: any): string {
        return loc.ReservedCompany
            ? `background-color: ${loc.ReservedCompany.color}; opacity: 0.9;`
            : "";
    }

    private getColumnName(val): string {
        return (val >= 26 ? this.getColumnName( Math.floor((val / 26) - 1)) : "") +
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ"[(val % 26)];
    }

    private closeDialog(): void {
        this.close();
    }

    private changeSheet(type: string) {
        if (type === "plus" && this.activeSheet !== this.box.sheets) {
            this.activeSheet += 1;
        } else if (type === "minus" && this.activeSheet !== 1) {
            this.activeSheet -= 1;
        }
    }

}
</script>