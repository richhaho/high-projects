<template>
    <v-alert
        v-if="currentClosure"
        color="red"
        class="py-0 ma-0"
        dense
        outlined
        text
    >
        <v-row justify="center">
            <p class="text-center mb-0 pa-1" style="color: red;" :style="mobile ? 'font-size: 12px;' : ''">
                {{ $t(messagePath, {endDate: $options.filters.formatAnniversaryDate(currentClosure.endDate)}) }}
            </p>
        </v-row>
    </v-alert>
</template>
<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";

@Component
export default class RelayClosed extends Vue {
    @Prop({default: null})
    public closures: any;

    @Prop({default: null})
    public messagePath: string;

    @Prop({default: false})
    public mobile: boolean;

    get currentClosure(): any {
        if (!this.closures?.items?.length) {
            // If the relay has no closures saved, it's open
            return false;
        } else {
            // Else, check if we are in a period of closure
            return this.closures.items.find((closure) => new Date() > new Date(closure?.startDate)
                && new Date() < new Date(closure?.endDate));
        }
    }

}
</script>