<template>
    <v-dialog
        persistent
        max-width="910px"
        v-model="showDialog"
        v-if="showDialog" >
        <v-card>
            <v-form v-model="valid">
                <v-card-title>
                    <div class="contain_picto">
                        <i class="icon-picto_relais-agence"></i>
                    </div>
                    <span class="headline">{{$t('relay.create.default')}}<br/>{{$t(`relay.createStep.${step}`)}}</span>
                </v-card-title>
                <v-card-text v-if="step === 1">
                    <v-container>
                        <v-row>
                            <v-autocomplete
                                v-if="isAdmin"
                                no-filter
                                :items="companies"
                                :rules="[rules.required]"
                                :search-input.sync="searchCompany"
                                v-bind:label="$t('user.company')+' *'"
                                v-model="company"
                            >
                                <template v-slot:selection="data">
                                    <v-list-item-content>
                                        <v-list-item-title
                                            v-html="data.item.name">
                                        </v-list-item-title>
                                    </v-list-item-content>
                                </template>
                                <template v-slot:item="data">
                                    <v-list-item-content>
                                        <v-list-item-title
                                            v-html="data.item.name">
                                        </v-list-item-title>
                                    </v-list-item-content>
                                </template>
                            </v-autocomplete>
                        </v-row>
                        <v-row>
                            <v-text-field :rules="[rules.required]" :label="$t('relay.name')+' *'" v-model="relay.name"></v-text-field>
                        </v-row>
                        <v-row>
                            <address-geo
                                v-bind:address.sync="relay.address"
                                v-bind:postcode.sync="relay.zipCode"
                                v-bind:city.sync="relay.city"
                                v-bind:country.sync="relay.country"
                                v-bind:latitude.sync="relay.latitude"
                                v-bind:longitude.sync="relay.longitude"
                                v-bind:addressdisplayname.sync="relay.addressdisplayname"
                                :rules="[rules.required]"
                                :label="$t('form.companyAddress')+' *'"
                            ></address-geo>
                        </v-row>
                        <v-row>
                            <v-text-field :label="$t('form.companyPhone1')" v-model="relay.phone1"></v-text-field>
                        </v-row>
                        <v-row>
                            <v-text-field :label="$t('form.companyPhone2')" v-model="relay.phone2"></v-text-field>
                        </v-row>
                        <v-row>
                            <v-text-field :label="$t('form.companyEmail')" v-model="relay.email"></v-text-field>
                        </v-row>
                        <schedule-picker
                            :company-opening-hours="relay.companyOpeningHours"
                        />
                        <relay-add-referents
                            v-if="!isAdmin"
                            :referents.sync="relay.referents"
                        />
                    </v-container>
                </v-card-text>
                <v-card-text v-if="step === 2">
                    <v-container>
                    <v-radio-group
                        :label="$t('relay.storageIsNeeded')"
                        v-model="relay.hasStorage">
                        <v-radio name="active" :label="$t('actions.no')" :value="false" checked></v-radio>
                        <v-radio name="active" :label="$t('actions.yes')" :value="true"></v-radio>
                    </v-radio-group>
                    <div v-if="relay.hasStorage">
                        <v-row align="center">
                            <v-col
                                cols="6"
                                v-for="(box, i) in relay.Boxes" :key="i"
                            >
                                <v-row>
                                    <p class="mt-2 ml-3">
                                        {{$tc('box.number', i + 1, {number: i + 1})}}
                                        -
                                        {{$tc('box.locations', 0)}} :
                                        {{box.sheets * box.columns * box.lines || 0}}
                                    </p>
                                    <v-spacer></v-spacer>
                                    <v-btn
                                        @click="removeOneBox(i)"
                                        icon
                                    >
                                        <v-icon>
                                            delete
                                        </v-icon>
                                    </v-btn>
                                </v-row>
                                <v-text-field
                                    type="number"
                                    :label="$t('relay.nbSheet')+' *'"
                                    v-model="box.sheets"
                                    :rules="[rules.required, rules.positive]"
                                >
                                </v-text-field>
                                <v-text-field
                                    type="number"
                                    :label="$t('relay.nbColumn')+' *'"
                                    v-model="box.columns"
                                    :rules="[rules.required, rules.positive]"
                                >
                                </v-text-field>
                                <v-text-field
                                    type="number"
                                    :label="$t('relay.nbRow')+' *'"
                                    v-model="box.lines"
                                    :rules="[rules.required, rules.positive]"
                                >
                                </v-text-field>
                            </v-col>
                            <v-col cols="6" align="center">
                                <v-btn
                                    @click="addOneBox"
                                    class="mb-3"
                                    color="default"
                                    outlined
                                    text
                                >
                                    {{$t('box.addOne')}}
                                </v-btn>
                            </v-col>
                        </v-row>
                    </div>
                    <v-text-field
                        :label="$t(`box.${relay.hasStorage ? 'moreLocationsWantedNbr' : 'locationsWantedNbr'}`)"
                        :rules="[rules.positive]"
                        type="number"
                        v-model="relay.locationsWanted"
                    />
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-btn v-if="step !== 1" text @click="step -= 1" color="white">{{$t('actions.back')}}</v-btn>
                    <v-spacer></v-spacer>
                    <v-btn text @click="showDialog = false" color="white">{{$t('actions.cancel')}}</v-btn>
                    <v-btn v-if="step < 2 && isFormComplete"
                        :disabled="!isFormComplete"
                        @click="step += 1"
                        color="warning"
                    >{{$t('actions.next')}}</v-btn>
                    <v-btn v-if="step === 2 && isFormComplete"
                        :disabled="!isFormComplete"
                        :loading="loading"
                        @click="createRelay"
                        color="warning"
                    >{{$t('actions.save')}}</v-btn>
                </v-card-actions>
            </v-form>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Vue, Component, Prop, Watch} from "vue-property-decorator";
import SchedulePicker from "@/components/SchedulePicker.vue";
import RelayAddReferents from "@/components/relays/RelayAddReferents.vue";
import {formRules} from "@/utils/formRules";
import router from "@/router";
import AddressGeo from "@/components/AddressGeo.vue";
import {Getter} from "vuex-class";

const openingHoursFieldDayFn = () => ({
    isActive: true,
    continuous: {
        isActive: true,
        fromHours: "09:00",
        toHours: "18:00",
    },
    morning: {
        isActive: false,
        fromHours: "00:20",
        toHours: "00:00",
    },
    evening: {
        isActive: false,
        fromHours: "00:20",
        toHours: "00:00",
    },
});

@Component({
    components: {SchedulePicker, RelayAddReferents, AddressGeo},
})
export default class RelayCreate extends Vue {

    @Prop({default: false})
    public show: boolean;

    @Prop({})
    public updateData: () => void;

    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;

    private showDialog: boolean = false;
    private rules: object = formRules;
    private valid: boolean = true;
    private loading: boolean = false;
    private relay: any = {
        hasStorage: false,
        Boxes: [{}],
        locationsWanted: null,
        type: "AGENCY",
        company: "test",
        referents: [],
        companyOpeningHours: {
            monday: openingHoursFieldDayFn(),
            tuesday: openingHoursFieldDayFn(),
            wednesday: openingHoursFieldDayFn(),
            thursday: openingHoursFieldDayFn(),
            friday: openingHoursFieldDayFn(),
            saturday: openingHoursFieldDayFn(),
            sunday: openingHoursFieldDayFn(),
        },
    };
    private company: any = null;
    private referents: object[] = [];
    private companies: object[] = [];
    private searchCompany: string = "";
    private step: number = 1;

    @Watch("showDialog")
    public handlerShowDialog(newVal, oldVal) {
        if (newVal === false) {
            this.$emit("update:show", false);
            this.initRelay();
            this.step = 1;
        } else {
            this.$emit("update:show", false);
        }
    }

    @Watch("show")
    public handlerShow(newVal, oldVal) {
        if (newVal === true) {
            this.showDialog = true;
        }
    }

    @Watch("searchCompany", {immediate: true})
    public handleSearchCompany() {
        if (this.isAdmin) {
            this.getB2BCompanies();
        }
    }

    get isFormComplete(): boolean {
        return this.valid && /^(?=.*[0-9])/.test(this.relay?.address);
    }

    private createRelay() {
        this.loading = true;
        this.relay.referents = this.relay.referents.map((r) => r.id);
        let relayOwner: any = null;
        if (this.isAdmin) {
            relayOwner = {
                id: this.company.ManagementRelation[0].subordinateId,
            };
        }
        this.$store.dispatch("relays/createRelay", {
            relay: this.relay,
            user: relayOwner,
        })
            .then((res) => {
                this.loading = false;
                this.showDialog = false;
                this.updateData();
            })
            .catch((err) => {
                this.loading = false;
                this.$store.commit("alerts/displayError", {
                    msg : err,
                });
            });
    }

    private getB2BCompanies(): void {
        this.$store.dispatch("companies/read", {
            query: {
                search: this.searchCompany,
                type: "B2B",
            },
        }).then((res) => {
            this.companies = res.rows;
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private addOneBox() {
        this.relay.Boxes.push({
            sheets: null,
            columns: null,
            lines: null,
        });
    }

    private removeOneBox(i) {
        this.relay.Boxes.splice(i, 1);
    }

    private remove(item) {
        const index = this.relay.referents.indexOf(item.id);
        if (index >= 0) { this.relay.referents.splice(index, 1); }
    }

    private initRelay() {
        this.relay = {
            hasStorage: true,
            Boxes: [],
            locationsWanted: null,
            type: "AGENCY",
            referents: [],
            companyOpeningHours: {
                monday: openingHoursFieldDayFn(),
                tuesday: openingHoursFieldDayFn(),
                wednesday: openingHoursFieldDayFn(),
                thursday: openingHoursFieldDayFn(),
                friday: openingHoursFieldDayFn(),
                saturday: openingHoursFieldDayFn(),
                sunday: openingHoursFieldDayFn(),
            },
        };
    }
}
</script>