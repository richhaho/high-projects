<template>
    <v-dialog
        persistent
        max-width="500px"
        v-model="dialog"
    >
        <template v-slot:activator="{ on }">
            <v-btn
                v-if="!box"
                color="default"
                outlined
                v-on="on"
            >
                {{$t('box.addOne')}}
            </v-btn>
            <v-btn
                class="ma-3"
                v-else
                color="default"
                icon
                v-on="on"
                absolute
                top
                right
            >
                <v-icon>edit</v-icon>
            </v-btn>
        </template>
        <v-card>
            <v-card-title>
                <span class="headline" v-if="!box && relayBoxes">
                    {{ $tc('box.number', relayBoxes.length + 1, {number: relayBoxes.length + 1}) }}
                </span>
                <span class="headline" v-else-if="box">
                    {{ $tc('box.number', box.number, {number: box.number}) }}
                </span>
            </v-card-title>
            <v-card-text>
                <v-container>
                    <p v-if="!box" class="ma-0">
                        {{ $t('box.addOneDetails') }}
                    </p>
                    <v-form v-model="valid">
                        <v-text-field
                            type="text"
                            :label="$t('box.boxName')+' '"
                            v-model="currentDimensions.name"
                        />
                        <v-text-field
                            type="number"
                            :label="$t('relay.nbSheet')+' *'"
                            v-model="currentDimensions.sheets"
                            :rules="[rules.positive, rules.required].concat(box ? largerSheets : [])"
                        />
                        <v-text-field
                            type="number"
                            :loading="loading"
                            :label="$t('relay.nbColumn')+' *'"
                            v-model="currentDimensions.columns"
                            :rules="[rules.positive, rules.required].concat(box ? largerColumns : [])"
                        />
                        <v-text-field
                            :loading="loading"
                            type="number"
                            :label="$t('relay.nbRow')+' *'"
                            v-model="currentDimensions.lines"
                            :rules="[rules.positive, rules.required].concat(box ? largerLines : [])"
                        />
                    </v-form>
                    <v-row>
                        <span>{{$tc('key.currentTags')}}</span>
                        <v-col cols="12 pa-0" v-if="currentDimensions.newTags && currentDimensions.newTags.length > 0">
                            <v-chip-group
                                active-class="primary--text"
                                column
                                multiple
                            >
                                <v-chip :key="i"
                                        @click:close="removeTags(tag)"
                                        :close="true"
                                        v-for="(tag, i) in currentDimensions.newTags"
                                >
                                    {{ tag[lang] }}
                                </v-chip>
                            </v-chip-group>
                        </v-col>
                        <v-col cols="12 pa-0">
                            <v-autocomplete
                                :search-input.sync="searchTags"
                                v-model="currentDimensions.newTags"
                                :items="removeTagDuplicates(tags, currentDimensions.newTags)"
                                multiple
                                append-icon
                                hide-no-data
                                no-filter
                                chips
                                prepend-inner-icon="flag"
                                :label="$t('keysList.addTags')"
                            >
                                <template v-slot:selection="data">
                                </template>
                                <template v-slot:item="data">
                                    <v-list-item-content>
                                        <v-list-item-title>{{ data.item[lang] }}</v-list-item-title>
                                    </v-list-item-content>
                                </template>
                            </v-autocomplete>
                        </v-col>
                    </v-row>

                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    @click="dialog = false"
                    color="white"
                    text
                >
                    {{ $t('actions.cancel') }}
                </v-btn>
                <v-btn
                    v-if="box && valid && changed(box, currentDimensions) && !boxReduced(box, currentDimensions)"
                    @click="editBox(currentDimensions)"
                    color="warning"
                    :loading="loading"
                >
                    {{ $t('actions.save') }}
                </v-btn>
                <v-btn
                    v-if="!box && valid"
                    @click="createBox(currentDimensions)"
                    color="warning"
                    :loading="loading"
                >
                    {{ $t('actions.create') }}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Vue, Component, Prop, Watch} from "vue-property-decorator";
import {formRules} from "@/utils/formRules";

@Component({})
export default class RelayAddBox extends Vue {
    @Prop({default: null})
    public relayBoxes: any[];

    @Prop({default: null})
    public box: any;

    private dialog: boolean = false;
    private rules: object = formRules;
    private valid: boolean = false;
    private loading: boolean = false;
    private currentDimensions: any = {};
    private searchTags: string = null;
    private tags: any = [];

    get relayId(): string {
        return this.$route.params?.id;
    }
    get lang(): string {
        return this.$root.$i18n.locale;
    }

    @Watch("dialog", {deep: true})
    public handler() {
        if (this.box) {
            this.box.newTags = this.box.Tags;
        }
        this.currentDimensions = JSON.parse(JSON.stringify(this.box || {newTags: []}));
    }

    @Watch("searchTags")
    public handlerSearchTags(): void {
        this.getTags();
    }

    private mounted() {
        this.getTags();
    }

    private changed = (oldDimensions: any, newDimensions: any) =>
        newDimensions.sheets !== oldDimensions.sheets ||
        newDimensions.columns !== oldDimensions.columns ||
        newDimensions.lines !== oldDimensions.lines ||
        newDimensions.name !== oldDimensions.name ||
        newDimensions.newTags !== oldDimensions.newTags

    private boxReduced = (oldDimensions: any, newDimensions: any) =>
        newDimensions.sheets < oldDimensions.sheets ||
        newDimensions.columns < oldDimensions.columns ||
        newDimensions.lines < oldDimensions.lines

    private largerSheets(v) {
        return v >= this.box?.sheets || this.$i18n.t("box.reduced");
    }

    private largerColumns(v) {
        return v >= this.box?.columns || this.$i18n.t("box.reduced");
    }

    private largerLines(v) {
        return v >= this.box?.lines || this.$i18n.t("box.reduced");
    }

    private createBox(dimensions: any) {
        this.loading = true;
        this.$store.dispatch("relays/addBox", {
            relayId: this.relayId,
            box: {
                number: this.relayBoxes?.length + 1,
                sheets: dimensions.sheets,
                columns: dimensions.columns,
                lines: dimensions.lines,
                name: dimensions.name,
                tags: dimensions.newTags,
            },
        }).then((res) => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("actions.created"),
            });
            this.dialog = false;
            this.loading = false;
            this.$emit("reset");
        }).catch((err) => {
            this.dialog = false;
            this.loading = false;
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private editBox(dimensions: any) {
        this.loading = true;
        this.$store.dispatch("boxes/update", {
            id: this.box.id,
            box: {
                id: this.box.id,
                number: this.box?.number,
                sheets: dimensions.sheets,
                columns: dimensions.columns,
                lines: dimensions.lines,
                name: dimensions.name,
                tags: dimensions.newTags,
            },
        }).then((res) => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("actions.saved"),
            });
            this.dialog = false;
            this.loading = false;
            this.$emit("reset");
        }).catch((err) => {
            this.dialog = false;
            this.loading = false;
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private getTags(): void {
        this.$store.dispatch("tags/getAll", {
            query: {
                search: this.searchTags,
                lang: this.lang,
            },
        })
            .then((res) => {
                this.tags = res.tags;
            });
    }
    private removeTags(item): void {
        const index: number = this.currentDimensions.newTags.findIndex((i) => i.id === item.id);
        if (index >= 0) {
            this.currentDimensions.newTags.splice(index, 1);
        }
    }
    private removeTagDuplicates(completeList, duplicates): any[] | null {
        if (!completeList || !duplicates) {
            return null;
        }
        return completeList.filter((item: any) =>
            !duplicates.map((elem: any) => elem?.id)?.includes(item?.id));
    }
}
</script>
