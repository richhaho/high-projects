<template>
    <v-dialog
        max-width="510px"
        v-model="dialog"
        persistent
    >
        <v-card>
            <v-card-title>
                <span class="headline">
                    {{$t("relay.infoBalance.editInvoice.title")}}
                </span>
            </v-card-title>
            <v-card-text>
                <v-form
                    v-if="!pdfPath"
                    v-model="valid"
                >
                    <v-row>
                        <v-col cols="6" class="pb-0">
                            <v-text-field
                                max-width="100px"
                                v-bind:label="$t('relay.infoBalance.editInvoice.invoiceNumber') + ' *'"
                                v-model="invoice.customerInvoiceNumber"
                                hide-details
                                :rules="[rules.required]"
                            />
                        </v-col>
                    </v-row>
                    <v-col cols="6" class="px-0">
                        <v-radio-group
                            :mandatory="true"
                            v-model="withTva"
                            hide-details
                        >
                            <v-radio
                                :label="$t('relay.infoBalance.editInvoice.withTva')"
                                :value="true"
                            />
                            <v-radio
                                :label="$t('relay.infoBalance.editInvoice.withoutTva')"
                                :value="false"
                            />
                        </v-radio-group>
                    </v-col>
                    <v-row v-if="withTva">
                        <v-col cols="6" class="py-0">
                            <v-text-field
                                v-bind:label="$t('relay.infoBalance.editInvoice.tvaAmount') + ' *'"
                                v-model="invoice.tva"
                                type="number"
                                suffix="%"
                                :rules="[rules.required, rules.percent]"
                            />
                        </v-col>
                    </v-row>
                    <v-row v-else>
                        <v-col cols="12" class="pb-0">
                            <v-textarea
                                dense
                                hide-details
                                no-resize
                                outlined
                                height="100"
                                :placeholder="$t('relay.infoBalance.editInvoice.legalNotice')"
                                :rules="[rules.required]"
                                v-model="invoice.legalNotice"
                            />
                        </v-col>
                    </v-row>
                </v-form>
                <v-container v-else>
                    <v-row>
                        <p>{{$t("relay.infoBalance.editInvoice.afterCreate")}}</p>
                        <p>{{$t("relay.infoBalance.editInvoice.sendMyloby")}}</p>
                    </v-row>
                    <v-row justify="center">
                        <a
                            :href="getSrc(pdfPath)"
                            :title="$t('relay.infoBalance.editInvoice.seeInvoice')"
                            target="_blank"
                            class="lien btn_style"
                        >
                            <i class="icon-picto_factures"></i>
                            {{$t('relay.infoBalance.editInvoice.seeInvoice')}}
                        </a>
                    </v-row>
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    @click="close"
                    color="blue darken-1"
                    text
                >
                    {{$t(`actions.${pdfPath ? 'close' : 'cancel'}`)}}
                </v-btn>
                <v-btn
                    v-if="valid && !pdfPath"
                    @click="editInvoice"
                    color="orange darken-1"
                    text
                >
                    {{$t('actions.create')}}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>
<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import {formRules} from "@/utils/formRules";
import {getSrc} from "@/utils/misc";

@Component
export default class RelayEditInvoice extends Vue {
    @Prop({default: null})
    public relayId: number;

    @Prop({default: null})
    public lastInvoice: any;

    @Prop({default: false})
    public dialog: boolean;

    private rules: object = formRules;
    private valid: boolean = false;
    private withTva: boolean = true;
    private invoice: any = {
        customerInvoiceNumber: null,
        tva: null,
        legalNotice: null,
    };
    private pdfPath: string = null;
    private getSrc: (string) => string = getSrc;

    @Watch("withTva")
    public handlerTva(newVal) {
        if (newVal) {
            this.invoice.legalNotice = null;
        } else {
            this.invoice.tva = null;
        }
    }

    @Watch("lastInvoice", { immediate: true })
    public handlerLastInvoice(newVal) {
        if (newVal) {
            this.invoice.tva = newVal?.tva;
            this.invoice.legalNotice = newVal?.legalNotice;
        }
    }

    private editInvoice(): void {
        this.$store.dispatch("relays/createInvoice", {
            id: this.relayId,
            invoiceData: this.invoice,
        })
        .then((invoice) => {
            this.reset();
            this.pdfPath = invoice.pdfPath;
        })
        .catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: this.$i18n?.t("relay.infoBalance.editInvoice.existingInvoiceNumber"),
            });
        });
    }

    private reset() {
        this.$emit("reset");
        this.invoice = {
            customerInvoiceNumber: null,
            tva: this.lastInvoice?.tva,
            legalNotice: this.lastInvoice?.legalNotice,
        };
        this.pdfPath = null;
    }

    private close() {
        this.$emit("close");
        this.invoice = {
            customerInvoiceNumber: null,
            tva: this.lastInvoice?.tva,
            legalNotice: this.lastInvoice?.legalNotice,
        };
        this.pdfPath = null;
    }
}
</script>
