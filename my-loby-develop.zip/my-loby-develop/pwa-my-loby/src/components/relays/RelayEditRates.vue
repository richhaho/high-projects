<template>
    <v-dialog
        max-width="450px"
        v-model="dialog"
        persistent
    >
        <v-card>
            <v-card-title>
                <span class="headline">
                    {{$t("relay.infoBalance.editRates.title")}}
                </span>
            </v-card-title>
            <v-card-text>
                <v-form v-model="valid">
                    <v-row v-if="relay.type === 'FLOW'">
                        <v-col cols="8" class="pr-0">
                            <span>
                                {{$t('relay.infoBalance.editRates.dropFee') + ' *'}}
                            </span>
                        </v-col>
                        <v-col cols="3" class="px-0">
                            <v-text-field
                                v-model="relay.dropFee"
                                outlined
                                dense
                                reverse
                                hide-details
                                type="number"
                                :prefix="$t('currency.symbol')"
                                :rules="[rules.required, rules.positive]"
                            />
                        </v-col>
                    </v-row>
                    <v-row v-if="relay.type === 'LONG_TERM'">
                        <v-col cols="8" class="pr-0">
                            <span>
                                {{$t('relay.infoBalance.editRates.withdrawFee') + ' *'}}
                            </span>
                        </v-col>
                        <v-col cols="3" class="px-0">
                            <v-text-field
                                v-model="relay.withdrawFee"
                                outlined
                                dense
                                reverse
                                hide-details
                                type="number"
                                :prefix="$t('currency.symbol')"
                                :rules="[rules.required, rules.positive]"
                            />
                        </v-col>
                    </v-row>
                    <v-row v-if="relay.type === 'LONG_TERM'">
                        <v-col cols="8" class="pr-0">
                            <span>
                                {{$t('relay.infoBalance.editRates.floorSpaceFee') + ' *'}}
                            </span>
                        </v-col>
                        <v-col cols="3" class="px-0">
                            <v-text-field
                                v-model="relay.floorSpaceFee"
                                outlined
                                dense
                                reverse
                                hide-details
                                type="number"
                                :prefix="$t('currency.symbol')"
                                :rules="[rules.required, rules.positive]"
                            />
                        </v-col>
                    </v-row>
                </v-form>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    @click="$emit('close')"
                    color="blue darken-1"
                    text
                >
                    {{$t('actions.cancel')}}
                </v-btn>
                <v-btn
                    v-if="valid"
                    @click="saveRates"
                    color="orange darken-1"
                    text
                >
                    {{$t('actions.save')}}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>
<script lang="ts">
import {Component, Vue, Prop} from "vue-property-decorator";
import {formRules} from "@/utils/formRules";

@Component
export default class RelayEditInvoice extends Vue {
    @Prop({default: {}})
    public relay: any;

    @Prop({default: false})
    public dialog: boolean;

    @Prop({})
    public update: (relay) => void;

    private rules: object = formRules;
    private valid: boolean = false;

    public saveRates() {
        this.update(this.relay);
        this.$emit("close");
    }
}
</script>
