<template>
    <div>
        <h6 v-if="exceptionalClosuresItems.length || hasEditRight" class="mb-1">
            {{$tc('relay.exceptionalClosures.title', exceptionalClosuresItems.length)}}
        </h6>
        <v-row v-for="(closure, i) in exceptionalClosuresItems" :key="i" class="mb-1">
            <v-col class="grow py-0">
                <del v-if="isPassedClosure(closure)">
                    - {{$t('common.from')}}
                    {{closure.startDate | formatDateHour }}
                    {{$t('common.to')}}
                    {{closure.endDate | formatDateHour}}
                </del>
                <p v-else class="ma-0" :style="isCurrentClosure(closure) ? 'color: red;' : ''">
                    - {{$t('common.from')}}
                    {{closure.startDate | formatDateHour }}
                    {{$t('common.to')}}
                    {{closure.endDate | formatDateHour}}
                </p>
            </v-col>
            <v-col class="shrink py-0">
                <v-btn
                    v-if="hasEditRight"
                    type="button"
                    :outlined="isCurrentClosure(closure)"
                    :color="isCurrentClosure(closure) ? 'red' : 'default'"
                    @click="openRemoveExceptionalClosure(closure)"
                    icon
                    small
                    :title="$t('relay.exceptionalClosures.remove.title')"
                >
                    <v-icon small>delete</v-icon>
                </v-btn>
                <v-alert
                    v-else-if="isCurrentClosure(closure)"
                    color="red"
                    class="py-0 ma-0"
                    dense
                    outlined
                    text
                >
                    {{$t('actions.closed')}}
                </v-alert>
            </v-col>
        </v-row>
        <div v-if="hasEditRight">
            <button
                type="button"
                @click="addExceptionalClosureDialog = true"
                :title="$t('relay.exceptionalClosures.add.title')"
            >
                <i class="icon-picto_ajouter"></i>
                {{$t('relay.exceptionalClosures.add.title')}}
            </button>
        </div>
        <v-dialog
            v-model="addExceptionalClosureDialog"
            v-if="hasEditRight"
            persistent
            max-width="500px"
        >
            <v-card>
                <v-card-title>
                    <span class="headline">
                        {{$t('relay.exceptionalClosures.add.title')}}
                    </span>
                </v-card-title>
                <v-card-text class="py-0">
                    <v-container>
                        <v-row>
                            <v-alert
                                color="red"
                                class="mt-3"
                                outlined
                                dense
                                text
                            >
                                <p class="subtitle-2 mb-0">
                                    {{$t('relay.exceptionalClosures.add.details')}}
                                </p>
                            </v-alert>
                        </v-row>
                        <v-row>
                            <v-col cols="5" class="px-0">
                                <datetime
                                    :minute-step="10"
                                    :phrases="wording"
                                    class="date-input"
                                    id="startDate"
                                    type="datetime"
                                    v-model="currentExceptionalClosure.startDate"
                                >
                                    <label for="startDate" slot="before">
                                        {{ $t("common.startDate") }} :
                                    </label>
                                </datetime>
                            </v-col>
                            <v-col cols="2" class="py-8">
                                <v-row justify="center">
                                    <v-icon>arrow_right_alt</v-icon>
                                </v-row>
                            </v-col>
                            <v-col cols="5" class="px-0">
                                <datetime
                                :min-datetime="currentExceptionalClosure.startDate"
                                :minute-step="10"
                                :phrases="wording"
                                class="date-input"
                                id="endDate"
                                type="datetime"
                                v-model="currentExceptionalClosure.endDate"
                            >
                                <label for="endDate" slot="before">
                                    {{ $t("common.endDate") }} :
                                </label>
                            </datetime>
                            </v-col>
                        </v-row>
                        <v-divider></v-divider>
                        <v-row>
                            <p class="subtitle-2 my-2">
                                {{$t("relay.exceptionalClosures.add.confirm", {confirmationWord: creationConfirmationWord})}}
                            </p>
                        </v-row>
                        <v-row justify="center">
                            <v-col cols="4" class="px-0">
                                <v-text-field
                                    clearable
                                    outlined
                                    dense
                                    hide-details
                                    v-model="creationConfirmation"
                                />
                            </v-col>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="reset"
                        color="blue darken-1"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-btn
                        v-if="validClosure"
                        @click="addExceptionalClosure"
                        color="orange darken-1"
                        text
                    >
                        {{$t('actions.create')}}
                    </v-btn>
                    <v-spacer></v-spacer>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <v-dialog
            v-model="removeExceptionalClosureDialog"
            v-if="hasEditRight"
            persistent
            max-width="500px"
        >
            <v-card>
                <v-card-title>
                    <span class="headline">
                        {{$t('relay.exceptionalClosures.remove.title')}}
                    </span>
                </v-card-title>
                <v-card-text class="py-0">
                    <v-container>
                        <v-row>
                            <p class="subtitle-2">
                                {{$t("relay.exceptionalClosures.remove.details")}}
                            </p>
                        </v-row>
                        <v-row justify="center">
                            <p>
                                {{$t('common.from')}}
                                {{currentExceptionalClosure.startDate | formatDateHour }}
                                {{$t('common.to')}}
                                {{currentExceptionalClosure.endDate | formatDateHour}}
                            </p>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="reset"
                        color="blue darken-1"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-btn
                        @click="removeExceptionalClosure"
                        color="red darken-1"
                        text
                    >
                        {{$t('actions.delete')}}
                    </v-btn>
                    <v-spacer></v-spacer>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>
<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";
import {Datetime} from "vue-datetime";
import "vue-datetime/dist/vue-datetime.css";

@Component({
    components: {
        Datetime,
    },
})
export default class RelayExceptionalClosures extends Vue {
    @Prop({default: null})
    public closures: any;

    @Prop({default: false})
    public hasEditRight: boolean;

    private currentExceptionalClosure: any = {};
    private addExceptionalClosureDialog: boolean = false;
    private removeExceptionalClosureDialog: boolean = false;
    private creationConfirmation: string = null;

    get wording(): any {
        return {
            ok: this.$i18n.t("actions.next"),
            cancel: this.$i18n.t("actions.cancel"),
        };
    }

    get creationConfirmationWord(): string {
        return String(this.$t("relay.exceptionalClosures.add.confirmationWord"));
    }

    get validClosure(): boolean {
        return this.creationConfirmation?.toLowerCase() === this.creationConfirmationWord.toLowerCase()
            && this.currentExceptionalClosure.startDate
            && this.currentExceptionalClosure.endDate;
    }

    get exceptionalClosuresItems(): any[] {
        // Return all items for referents or admin
        // Return only future current and future items for classic users
        const closures: any[] = this.hasEditRight
            ? this.closures?.items || []
            : this.closures?.items?.filter((item) => new Date(item.endDate) > new Date()) || [];
        return closures.sort((a, b) => {
            if (new Date(a.startDate) < new Date(b.startDate)) { return -1; }
            if (new Date(a.startDate) > new Date(b.startDate)) { return 1; }
            return 0;
        });
    }

    private isPassedClosure(closure: any): boolean {
        return new Date() > new Date(closure?.endDate);
    }

    private isCurrentClosure(closure: any): boolean {
        return new Date() > new Date(closure?.startDate) && new Date() < new Date(closure?.endDate);
    }

    private reset(): void {
        this.currentExceptionalClosure = {};
        this.addExceptionalClosureDialog = false;
        this.removeExceptionalClosureDialog = false;
        this.creationConfirmation = null;
    }

    private addExceptionalClosure(): void {
        this.$emit("add-closure", this.currentExceptionalClosure);
        this.reset();
    }

    private openRemoveExceptionalClosure(item: any): void {
        this.currentExceptionalClosure = item;
        this.removeExceptionalClosureDialog = true;
    }

    private removeExceptionalClosure(): void {
        this.$emit("remove-closure", this.currentExceptionalClosure);
        this.reset();
    }
}
</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
    .date-input {
        max-width: 200px;
        padding: 8px 10px;
        font-size: 16px;
        border: solid 1px #ddd;
        color: #444;
    }
</style>