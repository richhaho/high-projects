<template>
    <div v-if="canGive(currentUser, currentKey) || canDrop(currentUser,currentKey)">
        <v-tooltip
            v-if="canGive(currentUser, currentKey)"
            top
        >
            <template v-slot:activator="{ on }">
                <v-btn
                    :disabled="disabled"
                    type="button"
                    class="action_button"
                    @click.stop="withdrawActionButton"
                    icon
                    v-on="on"
                >
                    <span>
                        <i class="icon-picto_retrait-agence mobile"></i>
                    </span>
                </v-btn>
            </template>
            <span>{{$t('key.actions.withdraw.button')}}</span>
        </v-tooltip>
        <v-tooltip
            v-else-if="canDrop(currentUser, currentKey)"
            top
        >
            <template v-slot:activator="{ on }">
                <v-btn
                    :disabled="disabled"
                    type="button"
                    class="action_button"
                    @click.stop="dropActionButton"
                    icon
                    v-on="on"
                >
                    <span>
                        <i class="icon-picto_depot-agence mobile"></i>
                    </span>
                </v-btn>
            </template>
            <span>{{$t('key.actions.dropB2B')}}</span>
        </v-tooltip>
        <v-dialog
            persistent
            max-width="500px"
            :fullscreen="mobile"
            :hide-overlay="mobile"
            v-model="handToHandDialog"
        >
            <v-card>
                <v-card-title>
                    <span v-show="!handToHandQrCode" class="headline">{{ $t('key.handToHand.selectUser') }}</span>
                </v-card-title>
                <v-card-text class="py-0 py-3">
                    <v-container class="py-0">
                        <v-row>
                            <v-col cols="12 pa-0">
                                <v-row justify="center">
                                    {{ $t('relay.dontFindGuest') }}
                                </v-row>
                                <v-row
                                    justify="center"
                                    class="mb-4"
                                >
                                    <span
                                        style="cursor: pointer; text-decoration: underline;"
                                        @click="openAddGuest"
                                    >
                                        {{ $t('relay.addGuest') }}
                                    </span>
                                </v-row>
                                <relay-key-add-guest
                                    v-if="addGuestModal"
                                    :mobile="mobile"
                                    :modal="addGuestModal"
                                    :current-key="currentKey"
                                    :loading="currentKey.loadingUsers"
                                    :search="search"
                                    @reset="addedGuest"
                                    @close="addGuestModal = false"
                                />
                                <v-autocomplete
                                    :item-text="itemStringified"
                                    item-value="id"
                                    :items="currentKey.users"
                                    :loading="currentKey.loadingUsers"
                                    append-icon
                                    solo
                                    :search-input.sync="search"
                                    :no-data-text="$t('key.handToHand.noUserFound')"
                                    v-bind:label="$t('actions.search')"
                                    v-model="keyGuest"
                                >
                                    <template v-slot:selection="data">
                                        <v-list-item-content style="overflow: initial !important;">
                                            <v-list-item-title
                                                v-html="data.item.displayName">
                                            </v-list-item-title>
                                            <v-list-item-subtitle
                                                v-html="data.item.company">
                                            </v-list-item-subtitle>
                                        </v-list-item-content>
                                    </template>
                                    <template v-slot:item="data">
                                        <v-list-item-content style="overflow: initial;">
                                            <v-list-item-title
                                                v-html="data.item.displayName">
                                            </v-list-item-title>
                                            <v-list-item-subtitle
                                                v-html="data.item.company">
                                            </v-list-item-subtitle>
                                        </v-list-item-content>
                                    </template>
                                </v-autocomplete>
                                <p v-if="keyGuest">
                                    {{ $t(`relay.giveKey.${defaultNotificationType || 'choice'}`) }}
                                </p>
                                <v-radio-group
                                    v-if="allowMail && allowPhone"
                                    v-model="notificationType"
                                    hide-details
                                    mandatory
                                    class="my-4"
                                >
                                    <v-radio
                                        v-if="allowPhone"
                                        :label="$t('invitation.reminder.sms')"
                                        key="sms"
                                        value="sms"
                                        color="orange"
                                    ></v-radio>
                                    <v-radio
                                        v-if="allowMail"
                                        :label="$t('invitation.reminder.mail')"
                                        key="email"
                                        value="email"
                                        color="orange"
                                    ></v-radio>
                                </v-radio-group>
                            </v-col>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn v-if="!handToHandQrCode"
                           @click="closeDialog"
                           color="white"
                           text
                    >
                        {{ $t('actions.cancel') }}
                    </v-btn>
                    <v-btn v-if="keyGuest && !handToHandQrCode && notificationType"
                           :disabled="!keyGuest"
                           :loading="loadHandToHand"
                           @click="selectGuestHandToHand"
                           color="warning"
                    >
                        {{ $t('actions.give') }}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <key-returning-date
            ref="returningDate"
            :displayChooseHour="displayChooseHour"
            v-if="displayChooseHour && canGuestChooseReturnHour"
            @validTime="validateTime"
            @cancel="displayChooseHour=false"
        />
        <qr-code-reader
            v-if="displayQrCodeReader"
            :action="droppingAction ? 'DROP' : 'WITHDRAW'"
            :location="currentKey.currentLocation"
            :key-picture="currentKey.picturePath"
            :key-description="currentKey.description"
            :read-qr-code="readQRCode"
            :mobile="mobile"
            @close="closeDialog"
            :display-qr-code-reader-modal="displayQrCodeReader"
            :qr-code-error="qrCodeReaderError"
        />
        <pin-code
            v-if="displayPinPad"
            :keyId="currentKey.id"
            :key-picture="currentKey.picturePath"
            :key-description="currentKey.description"
            :relayId="relayId"
            :relayType="relayType"
            :keyGuest="keyGuest"
            default-method="manualPin"
            @success="successCallback()"
            @failure="failureCallback('alerts.error.transactionDenied')"
            @valid-pin="withdrawKey"
            :mobile="mobile"
            :display-pin-pad="displayPinPad"
            @close="closeDialogPin"
        />
        <over-price-sms
            :dialog="acceptOverPrice"
            :loading="loadHandToHand"
            @accept="selectGuestHandToHand"
            @cancel="acceptOverPrice = false"
        ></over-price-sms>
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import QrCodeReader from "@/components/QrCodeReader.vue";
import {Getter} from "vuex-class";
import PinCode from "@/components/relays/PinCode.vue";
import SimpleDialog from "@/components/SimpleDialog.vue";
import KeyReturningDate from "@/components/keys/actions/KeyReturningDate.vue";
import RelayKeyAddGuest from "@/components/relays/RelayKeyAddGuest.vue";
import OverPriceSms from "@/components/OverPriceSms.vue";
import {lastItemOfArray} from "@/utils/misc";
import router from "@/router";
import {regex} from "@/utils/formRules";

@Component({
    components: {
        QrCodeReader,
        PinCode,
        SimpleDialog,
        KeyReturningDate,
        RelayKeyAddGuest,
        OverPriceSms,
    },
})
export default class RelayGiveKeyToGuest extends Vue {

    get currentRelay(): any {
        return this.currentKey?.currentLocation?.Box?.Relay;
    }

    get currentRelayType(): string {
        return this.currentRelay?.type;
    }

    get canGuestChooseReturnHour(): boolean {
        return this.currentRelay?.canGuestChooseReturnHour;
    }

    get keyGuestObject(): any {
        return this.currentKey?.users?.find((g) => g.id === this.keyGuest);
    }

    get allowMail(): boolean {
        return !!this.keyGuestObject?.email && !regex.validPhoneNumber.test(this.keyGuestObject.email);
    }

    get allowPhone(): boolean {
        return !!this.keyGuestObject?.phone;
    }

    get defaultNotificationType(): string {
        if (this.allowMail && !this.allowPhone) {
            return "email";
        }
        if (!this.allowMail && this.allowPhone) {
            return "sms";
        }
        return null;
    }

    @Prop({default: {}})
    public currentKey: any;

    @Prop({default: {}})
    public relay: any;

    @Prop({default: false})
    public mobile: boolean;

    @Prop({default: false})
    public disabled: boolean;

    @Prop({})
    public updateKeyUsers: (any) => Promise<any>;

    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;

    private displayChooseHour: boolean = false;
    private handToHandDialog: boolean = false;
    private keyGuest: number = null;
    private handToHandQrCode: string = null;
    private loadHandToHand: boolean = false;
    private displayQrCodeReader: boolean = false;
    private displayPinPad: boolean = false;
    private displayValidationModal: boolean = false;
    private token: string = "";
    private relayId: number = null;
    private relayType: string = null;
    private qrCodeReaderError: any = null;
    private estimatedEndDate: string = null;
    private droppingAction: boolean = false;
    private addGuestModal: boolean = false;
    private search: string = "";
    private acceptOverPrice: boolean = false;
    private notificationType: string = "sms";

    @Watch("keyGuest", {immediate: true})
    public handlerKeyGuest(): void {
        this.notificationType = this.defaultNotificationType || "sms";
    }

    private canGive = (user, key) => this.isKeyInRelay(key);
    private canDrop = (user, key) => !this.isKeyInRelay(key)
        && !this.userHasKey(user, key) && !this.isKeyInitialized(key)
        && !this.isKeyUnarchived(key)

    private isKeyInitialized = (key: any) => key?.status === "CREATED";

    private isKeyUnarchived = (key: any) => key?.status === "UNARCHIVED";

    private userHasKey = (user, key) => key?.KeyHolding?.find((kH) => !kH.endDate)?.userId === user?.id;

    private isKeyInRelay = (key: any) => key?.status === "IN_RELAY";

    private itemStringified = (item) => JSON.stringify(item);

    private selectGuestHandToHand(): Promise<any> {
        this.loadHandToHand = true;
        return this.$store.dispatch("keys/giveKeyToGuest", {
            keyId: this.currentKey.id,
            sourceRelayId: this.relay.id,
            targetUserId: this.keyGuest,
            notificationType: this.notificationType,
            acceptOverPrice: this.acceptOverPrice,
        }).then((res) => {
            this.handToHandQrCode = res;
            this.displayQrCodeReader = true;
            this.acceptOverPrice = false;
            this.loadHandToHand = false;
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$t("pin.guestReceivedPin"),
            });
        }).catch((err) => {
            switch (err?.response?.data?.error) {
                case "smsLimitReached":
                    this.acceptOverPrice = true;
                    break;
                case "freemium":
                    this.$store.commit("alerts/displayError", {
                        msg: this.$i18n.t("invitation.freemium"),
                    });
                    break;
                default:
                    this.$store.commit("alerts/displayError", {
                        msg: this.$t(`alerts.error.${err?.response?.data?.error || "default"}`),
                    });
                    break;
            }
            this.loadHandToHand = false;
        });
    }

    private openAddGuest(): void {
        this.addGuestModal = true;
    }

    private addedGuest(): void {
        this.updateKeyUsers(this.currentKey).then(() => {
            this.keyGuest = lastItemOfArray(this.currentKey.users)?.id;
        });
    }

    private closeDialog(): void {
        this.handToHandQrCode = null;
        this.keyGuest = null;
        this.handToHandDialog = false;
        this.resetQrCodeReader();
    }
    private closeDialogPin(): void {
        this.handToHandQrCode = null;
        this.displayPinPad = false;
    }

    private withdrawActionButton(): void {
        if (!this.currentKey?.users?.length) {
            this.updateKeyUsers(this.currentKey);
        }
        this.droppingAction = false;
        if (this.canGuestChooseReturnHour) {
            this.displayChooseHour = true;
        } else {
            this.handToHandDialog = true;
        }
    }

    private dropActionButton(): void {
        this.droppingAction = true;
        this.displayQrCodeReader = true;
    }

    private resetQrCodeReader(): void {
        this.qrCodeReaderError = null;
        this.displayQrCodeReader = false;
    }

    private validateTime(value): void {
        this.estimatedEndDate = (new Date(value)).toISOString().substr(0, 19);
        this.displayChooseHour = false;
        this.handToHandDialog = true;
    }

    private readQRCode(token) {
        this.token = token;
        this.qrCodeReaderError = null;
        return this.$store.dispatch("locations/qrCodeVerification", {
            token,
            keyId: this.currentKey.id,
            keyStatus: this.currentKey.status,
            estimatedEndDate: this.estimatedEndDate,
            dropFromRelay: this.droppingAction,
            giveToUserId: this.keyGuest,
            referentId: this.currentUser.id,
        }).then((res) => {
            this.handToHandDialog = false;
            if (res.dropped) {
                this.successCallback();
            } else if (res.validLocation) {
                if (this.droppingAction) {
                    this.dropKey();
                } else {
                    this.displayQrCodeReader = false;
                    this.displayPinPad = true;
                    this.relayId = res.relayId;
                    this.relayType = res.relayType;
                }
            } else {
                this.qrCodeReaderError = this.$i18n.t("alerts.error." + res.errorMessage || "default");
            }
        }).catch((err) => {
            this.qrCodeReaderError = this.$i18n.t(`alerts.error.${err?.response?.data?.error || "qrCodeNotFound"}`);
        });
    }

    private beforeDestroy() {
        this.resetQrCodeReader();
    }

    private withdrawKey(referent: any, way?: string): void {
        this.$store.dispatch("keys/withdraw", {
            keyId: this.currentKey.id,
            token: this.token,
            referentId: referent.id,
            keyToGuest: this.keyGuest,
            estimatedEndDate: this.estimatedEndDate,
            notificationType: this.notificationType,
        })
        .then(() => this.successCallback(way))
        .catch((err) => this.failureCallback(err));
    }

    private successCallback(way?: string): void {
        if (way === "qrCodePin") {
            this.displayValidationModal = true;
        } else {
            if (this.droppingAction) {
                this.$store.commit("alerts/displaySuccess", {
                    icon: "icon-picto_depot-agence",
                    msg: this.$i18n?.t("alerts.key.dropSuccess", {
                        key: this.currentKey?.name,
                        relay: this.relay?.name,
                    }),
                });
            } else {
                this.$store.commit("alerts/displaySuccess", {
                    icon: "icon-picto_retrait-agence",
                    msg: this.$i18n?.t("alerts.key.giveSuccess", {
                        key: this.currentKey?.name,
                        user: this.currentKey?.users?.find((e) => e.id === this.keyGuest)?.displayName,
                    }),
                });
            }
            this.dropKeyDone();
        }
    }

    private failureCallback(err?: string): void {
        this.$store.commit("alerts/displayError", {
            icon: "icon-picto_retrait-agence",
            msg: this.$i18n?.t(err || "alerts.error.default"),
        });
        this.dropKeyDone();
    }

    private dropKey(): void {
        this.$store.dispatch("keys/drop", {
            keyId: this.currentKey.id,
            token: this.token,
            referentId: this.currentUser.id,
            relayId: this.relay.id,
            holderId: this.currentKey.KeyHolding[0]?.userId,
            keyToGuest: this.currentKey.KeyHolding[0]?.userId,
        })
        .then(() => this.successCallback())
        .catch(() => this.failureCallback());
    }

    private dropKeyDone() {
        this.$emit("reset");
        this.closeDialog();
    }
}
</script>
