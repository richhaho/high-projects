<template>
    <div>
        <p class="tableau_titre">
            {{$t('relay.graphKey.title')}}
            <i class="icon-header_triangle"></i>
        </p>
        <div class="tableau">
            <div class="options">
                <div class="option_left">
                    <p class="titre">
                        <strong>{{$t('relay.graphKey.subtitle')}}</strong>
                    </p>
                </div>
            </div>
            <div class="row no-gutters">
                <div class="col-md-12 ">
                    <div class="statistiques_agence visiteurs mb-5">
                        <canvas id="bar-chart" style="max-width:800px; margin: auto"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import { Component, Prop, Vue, Watch } from "vue-property-decorator";
import Chart from "chart.js";

@Component({})
export default class RelayStat extends Vue {

    @Prop({default: null})
    public stats: any;
    public myPieChart: any;

    @Watch("stats", {deep: true})
    public handler() {
        this.myPieChart.data.datasets[0].data = this.stats.map((s) => s.count);
        this.myPieChart.update();
    }

    @Watch("$root.$i18n.locale")
    public onLangChanged(lang) {
        this.myPieChart.data.labels = this.stats.map((stat) => this.$i18n.t(`relay.graphKey.legend.${stat.type}`));
        this.myPieChart.update();
    }

    private mounted() {
        const barChart = document.getElementById("bar-chart") as HTMLCanvasElement;
        this.myPieChart = new Chart(barChart, {
            type: "doughnut",
            data: {
                labels: this.stats.map((stat) => this.$i18n.t(`relay.graphKey.legend.${stat.type}`)),
                datasets: [{
                    backgroundColor: [
                        "#3a9ca6",
                        "#7dbdc3",
                        "#9ecf99",
                        "#d291bc",
                        "#f9d67a",
                        "#c45850",
                        "#a30000",
                    ],
                }],
            },
            options: {
                legend: {
                    position: "left",
                    align: "start",
                },
            },
        });
        this.myPieChart.data.datasets[0].data = this.stats.map((s) => s.count);
        this.myPieChart.update();
    }

}
</script>