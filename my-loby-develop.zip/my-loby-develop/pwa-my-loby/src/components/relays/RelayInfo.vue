<template>
    <div v-if="relay">
        <p class="tableau_titre">{{ $t('relay.infoLoby.title') }} <i class="icon-header_triangle"></i></p>
        <div class="tableau">
            <div class="options">
                <div class="option_left">
                    <p class="titre">{{ $t('relay.createAt') }} {{ relay.createdAt | formatDateDay }}</p>
                </div>
                <div class="option_right">
                    <a @click="showEdit" class="option" v-if="hasRight">
                        <i class="icon-picto_editer"></i>
                        {{ $t('actions.edit') }}
                    </a>
                </div>
            </div>
            <div class="relais_row row no-gutters">
                <div class="col-md-6 first_col">
                    <div class="details">
                        <div class="row no-gutters">
                            <div class="col-sm-6">
                                <h6>{{ $t('relay.infoLoby.info') }}</h6>
                                <img
                                    v-if="relay.picturePath"
                                    width="100%"
                                    class="pb-3 pr-5"
                                    style="max-height: 150px; object-fit: contain"
                                    :src="getSrc(relay.picturePath)"
                                />
                                <p class="with_key">
                                    <span><i class="icon-picto_relais-agence"></i></span>
                                    <strong>{{ relay.name }}</strong>
                                    <br/>
                                    <a
                                        :href="relay.itinerary"
                                        target="_blank"
                                    >
                                        {{ relay.address }}
                                        <br/>
                                        {{ relay.zipCode }}, {{ relay.city }}
                                        <br/>
                                    </a>
                                    <br v-if="relay.phone1"/>
                                    <a v-if="relay.phone1" :href="`tel:${relay.phone1}`" style="color: #0c0733">
                                        <i class="icon-picto_telephone"></i> {{ relay.phone1 }}
                                    </a>
                                    <br v-if="relay.phone2"/>
                                    <a v-if="relay.phone2" :href="`tel:${relay.phone2}`" style="color: #0c0733">
                                        <i class="icon-picto_telephone"></i> {{ relay.phone2 }}
                                    </a>
                                    <br v-if="relay.email"/>
                                    <a v-if="relay.email" :href="`mailto:${relay.email}`" style="color: #0c0733">
                                        <i class="icon-picto_courrier"></i> {{ relay.email }}
                                    </a>
                                </p>
                                <!--                                <span class="reseau"><span><i class="icon-picto_wifi"></i> 4G</span> 3 codes promos en cours</span>-->
                            </div>
                            <div class="col-sm-6">
                                <relay-schedule
                                    :schedule="relay.companyOpeningHours"
                                />
                            </div>
                            <div class="col-sm-12 py-3">
                                <relay-exceptional-closures
                                    :closures="relay.exceptionalClosures"
                                    :hasEditRight="isReferent || isAdmin"
                                    @add-closure="addClosure"
                                    @remove-closure="removeClosure"
                                />
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 first_col">
                    <div class="details">
                        <div class="gestionnaire_relais">
                            <h6>{{ $t('relay.infoLoby.owner') }}</h6>
                            <img
                                v-if="owner.picturePath || defaultUserAvatar"
                                :src="getSrc(owner.picturePath) || defaultUserAvatar"
                                alt="" class="img_profil">
                            <strong>{{ owner.displayName }}</strong>
                            <p>
                                <span v-if="owner.job">{{ owner.job }} <br/></span>
                                <span
                                    v-if="owner.company">{{ $t('relay.infoLoby.company') }} : {{ owner.company }}</span>
                            </p>
                            <a v-if="owner.phone" :href="`tel:${owner.phone}`"><i
                                class="icon-picto_telephone"></i>{{ owner.phone }}</a>
                            <a v-if="owner.email" :href="`mailto:${owner.email}`"><i
                                class="icon-picto_courrier"></i>{{ owner.email }}</a>
                        </div>
                    </div>
                    <div v-if="referents && referents.length" class="col-sm-6">
                        <h6>{{ $t('relay.infoLoby.managers') }}</h6>
                        <user-list-avatar
                            :users="referents"
                        />
                    </div>
                </div>
                <div class="col-md-3" v-if="isAdmin || isReferent">
                    <div class="details">
                        <div class="code_relais">
                            <h6 v-if="isAdmin || isAgency && hasRight">{{ $t('relay.infoLoby.allCodes') }}</h6>
                            <h6 v-else>{{ $t('relay.infoLoby.myCode') }}</h6>
                            <div v-for="(pinCode, i) in pinCodes" :key="i" class="my-2">
                                <v-row>
                                    <span v-if="isAdmin || isAgency && hasRight">
                                        {{ pinCode.referentName }} :
                                    </span>
                                </v-row>
                                <v-row>
                                    <div class="le_code pointer" @click="toggleCodeDisplayed(i)">
                                        {{ displayedCodeIndex === i ? pinCode.pinCode : "****" }}
                                    </div>
                                    <div class="option_right ml-1">
                                        <a @click="showPinEdit(pinCode)" class="option">
                                            <i class="icon-picto_editer"></i>
                                        </a>
                                    </div>
                                    <v-tooltip top>
                                        <template v-slot:activator="{ on }">
                                            <a
                                                class="mx-1"
                                                :href="`${$store.state.baseURL}/api/relays/${relay.id}/my-qr-code/${pinCode.userId}`"
                                                target="_blank"
                                                v-on="on"
                                            >
                                                <v-icon>picture_as_pdf</v-icon>
                                            </a>
                                        </template>
                                        {{ $t('relay.infoLoby.myQrCode') }}
                                    </v-tooltip>
                                </v-row>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <v-dialog
            persistent
            max-width="910px"
            v-model="isEdit"
            v-if="isEdit">
            <v-card>
                <v-form v-model="valid">
                    <v-card-title>
                        <div class="contain_picto">
                            <i class="icon-picto_relais-agence"></i>
                        </div>
                        <span class="headline">{{ $t('relay.infoLoby.editInfo') }}</span>
                    </v-card-title>
                    <v-card-text class="pb-0">
                        <v-container class="pb-0">
                            <v-row>
                                <v-text-field :rules="[rules.required]" :label="$t('relay.name')"
                                              v-model="newInfo.name"></v-text-field>
                            </v-row>
                            <v-row>
                                <img
                                    v-if="newInfo.picturePath || uploadedImageSrc"
                                    :src="uploadedImageSrc || getSrc(relay.picturePath)"
                                    style="object-fit: contain; max-height: 150px; max-width: 250px"
                                />
                            </v-row>
                            <v-row v-if="newInfo.picturePath || uploadedImageSrc">
                                <v-btn
                                    @click="changeAvatar=!changeAvatar"
                                    icon
                                >
                                    <v-icon>
                                        edit
                                    </v-icon>
                                </v-btn>
                                <v-btn
                                    v-show="newInfo.picturePath || avatar"
                                    @click="deleteAvatar"
                                    icon
                                >
                                    <v-icon>
                                        delete
                                    </v-icon>
                                </v-btn>
                            </v-row>
                            <v-row>
                                <v-file-input
                                    v-if="(!newInfo.picturePath && !avatar) || changeAvatar"
                                    :rules="avatar ? [rules.avatar] : []"
                                    accept="image/png, image/jpeg, image/bmp"
                                    :placeholder="$t('user.uploadImage')"
                                    prepend-icon="photo"
                                    :label="$t('relay.infoLoby.picture')"
                                    v-model="avatar"
                                    @change="fileChange"
                                ></v-file-input>
                            </v-row>
                            <v-row>
                                <address-geo
                                    v-bind:address.sync="newInfo.address"
                                    v-bind:postcode.sync="newInfo.zipCode"
                                    v-bind:city.sync="newInfo.city"
                                    v-bind:country.sync="newInfo.country"
                                    v-bind:latitude.sync="newInfo.latitude"
                                    v-bind:longitude.sync="newInfo.longitude"
                                    v-bind:addressdisplayname.sync="newInfo.addressdisplayname"
                                    :rules="[rules.required]"
                                    :label="$t('form.companyAddress')+' *'"
                                ></address-geo>
                            </v-row>
                            <v-row>
                                <v-text-field :label="$t('form.companyPhone1')" v-model="newInfo.phone1"></v-text-field>
                            </v-row>
                            <v-row>
                                <v-text-field :label="$t('form.companyPhone2')" v-model="newInfo.phone2"></v-text-field>
                            </v-row>
                            <v-row>
                                <v-text-field :label="$t('form.companyEmail')" v-model="newInfo.email"></v-text-field>
                            </v-row>
                            <v-row v-if="manageStockActive">
                                <v-text-field
                                    :label="$t('form.minimumKeysNeeded')"
                                    v-model="newInfo.minimumKeysNeeded"
                                    type="number"
                                    @wheel="$event.target.blur()"
                                    :rules="[rules.positive, rules.requiredNumber]"
                                ></v-text-field>
                            </v-row>
                            <v-row>
                                <v-switch
                                    class="mx-4 mb-4"
                                    v-bind:label="$t('relay.authorizeTransit')"
                                    v-model="newInfo.isTransitAuthorized"
                                    hide-details
                                />
                            </v-row>
                            <v-row>
                                <v-switch
                                    class="mx-4 mb-4"
                                    v-bind:label="$t('relay.authorizeImmediateTransaction')"
                                    v-model="newInfo.isImmediateTransactionAuthorized"
                                    hide-details
                                />
                            </v-row>
                            <v-row v-if="isAgency">
                                <v-switch
                                    class="mx-4 mb-4"
                                    v-bind:label="$t('relay.authorizeDropByAnyone')"
                                    v-model="newInfo.isDropByAnyoneAuthorized"
                                    hide-details
                                />
                            </v-row>
                            <v-row v-if="isAgency || isAdmin">
                                <v-switch
                                    class="mx-4 mb-4"
                                    v-bind:label="$t('relay.canGuestChooseReturnHour')"
                                    v-model="newInfo.canGuestChooseReturnHour"
                                    hide-details
                                />
                            </v-row>
                            <v-row v-if="isAgency">
                                <v-switch
                                    class="mx-4 mb-4"
                                    v-bind:label="$t('relay.addTagAtDrop')"
                                    v-model="newInfo.canAddTagAtDrop"
                                    hide-details
                                />
                            </v-row>
                            <v-row v-if="canUseBooking">
                                <v-switch
                                    class="mx-4 mb-4"
                                    v-bind:label="$t('planning.authorizeReccurence')"
                                    v-model="newInfo.authorizeReccurence"
                                    hide-details
                                />
                            </v-row>

                            <v-row v-if="canUseBooking">
                                <v-switch
                                    class="mx-4 mb-4"
                                    v-bind:label="$t('planning.authorizeBookingRecall')"
                                    v-model="newInfo.authorizeBookingRecall"
                                    hide-details
                                />
                            </v-row>
                            <v-row v-if="canUseBooking">
                                <v-switch
                                    class="mx-4 mb-4"
                                    v-bind:label="$t('planning.retrieveOnlyBookedKey')"
                                    v-model="newInfo.retrieveOnlyBookedKey"
                                    hide-details
                                />
                            </v-row>
                            <v-row class="mt-4 mb-8">
                                <span class="input-title">{{ $t('form.companyOpeningHours') }}
                                    <a
                                        :title="$t('actions.openClose')"
                                        @click="displayHours = !displayHours"
                                        class="toggle_action"
                                    >
                                        <i class="icon-angle"></i>
                                    </a>
                                </span>
                                <v-expand-transition>
                                    <schedule-picker
                                        v-show="displayHours"
                                        class="ml-4"
                                        :company-opening-hours="newInfo.companyOpeningHours"
                                    />
                                </v-expand-transition>
                            </v-row>
                            <relay-add-referents
                                style="margin-bottom: 20px;"
                                v-if="isAgency"
                                :referents.sync="newInfo.referents"
                            />
                            <relay-add-managers
                                v-if="isAgency"
                                :managers.sync="newInfo.managers"
                            />
                            <relay-add-guests
                                v-if="isAgency"
                                :guests.sync="newInfo.guests"
                            />
                        </v-container>
                    </v-card-text>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn text @click="closeEdit" color="white">{{ $t('actions.cancel') }}</v-btn>
                        <v-btn
                            v-if="valid"
                            :disabled="!valid"
                            @click="save"
                            color="warning"
                        >{{ $t('actions.save') }}
                        </v-btn>
                    </v-card-actions>
                </v-form>
            </v-card>
        </v-dialog>
        <v-dialog
            persistent
            max-width="500px"
            v-model="isPinEdit"
            v-if="isPinEdit"
        >
            <v-card>
                <v-card-title>
                <span class="headline">
                    {{ $t('pin.edit') }}
                </span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-alert
                            v-if="error"
                            color="red"
                            outlined
                            text
                        >
                            {{ error }}
                        </v-alert>
                        <p>
                            {{ $t('pin.edit') }}
                        </p>
                        <v-form
                            v-model="valid"
                            @submit="validate"
                            onSubmit="return false;"
                        >
                            <v-text-field
                                :rules="[rules.pin]"
                                class="input-group--focused"
                                dense
                                outlined
                                inputmode="numeric"
                                pattern="[0-9]*"
                                :placeholder="$t('pin.enter')"
                                rounded
                                type="number"
                                v-model="newPinCode"
                                required
                            />
                        </v-form>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="closePinEdit"
                        color="white"
                        text
                    >
                        {{ $t('actions.cancel') }}
                    </v-btn>
                    <v-btn
                        v-if="newPinCode && valid"
                        @click="validate"
                        color="warning"
                        :loading="loading"
                    >
                        {{ $t('actions.send') }}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>
<script lang="ts">
import {Vue, Component, Prop, Watch} from "vue-property-decorator";
import RelaySchedule from "@/components/relays/RelaySchedule.vue";
import RelayExceptionalClosures from "@/components/relays/RelayExceptionalClosures.vue";
import {defaultUserAvatar} from "@/utils/constants";
import UserListAvatar from "@/components/users/UserListAvatar.vue";
import KeyManagersAutocomplete from "@/components/keys/KeyManagersAutocomplete.vue";
import SchedulePicker from "@/components/SchedulePicker.vue";
import {formRules} from "@/utils/formRules";
import RelayAddReferents from "@/components/relays/RelayAddReferents.vue";
import RelayAddGuests from "@/components/relays/RelayAddGuests.vue";
import RelayAddManagers from "@/components/relays/RelayAddManagers.vue";
import AddressGeo from "@/components/AddressGeo.vue";
import {getSrc, removeVuetifyFileInputBug} from "@/utils/misc";
import {Getter} from "vuex-class";
import {TranslateResult} from "vue-i18n";

@Component({
    components: {
        RelayAddReferents,
        SchedulePicker,
        KeyManagersAutocomplete,
        UserListAvatar,
        AddressGeo,
        RelaySchedule,
        RelayExceptionalClosures,
        RelayAddGuests,
        RelayAddManagers,
    },
})
export default class RelayInfo extends Vue {
    @Prop({default: null})
    public relay: any;

    @Prop({default: null})
    public owner: any;

    @Prop({})
    public update: (relay) => void;

    @Prop({default: false})
    public hasRight: boolean;

    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;
    private error: TranslateResult = null;

    private defaultUserAvatar: string = defaultUserAvatar;
    private getSrc: (picturePath: string) => string = getSrc;
    private removeVuetifyFileInputBug: (document: any) => void = removeVuetifyFileInputBug;
    private myCode: string = null;
    private displayedCodeIndex: number = null;
    private isEdit: boolean = false;
    private isPinEdit: boolean = false;
    private newInfo: any = null;
    private test: any = {};
    private valid: boolean = true;
    private rules: object = formRules;
    private changeAvatar: boolean = false;
    private avatar: any = null;
    private uploadedImageSrc: any = null;
    private uploadFile: boolean = false;
    private deleteFile: boolean = false;
    private pinCodeToChange: any = null;
    private newPinCode: string = null;
    private loading: boolean = false;
    private displayHours: boolean = false;

    get isAgency(): boolean {
        return this.relay?.type === "AGENCY";
    }

    get referents(): any[] {
        return this.relay.Referents?.filter((ref) => ref.id !== this.owner.id);
    }

    get managers(): any[] {
        return this.relay.Groups?.filter((group) => group.PresetUsers.role === "MANAGER");
    }

    get guests(): any[] {
        return this.relay.Groups?.filter((group) => group.PresetUsers.role === "GUEST");
    }

    get isReferent(): boolean {
        return this.relay?.Referents?.some((ref) => ref.id === this.currentUser?.id);
    }

    get pinCodes(): any[] {
        if (this.isAdmin || this.currentUser.masterOf.length) {
            return this.relay.Referents?.map((ref) => ({
                referentName: ref.displayName,
                pinCode: ref.UserRelay.pin,
                userId: ref.id,
            }));
        } else if (this.isReferent && !this.hasRight) {
            return [{
                referentName: this.currentUser.displayName,
                pinCode: this.myCode,
                userId: this.currentUser.id,
            }];
        }
        return [];
    }

    get manageStockActive() {
        return this.currentUser.company?.currentSubscription?.details?.options?.manageStock?.isActive;
    }

    get canUseBooking() {
        return this.currentUser.company?.currentSubscription?.details?.options?.allowBooking?.isActive;
    }

    private mounted(): void {
        if (this.isReferent) {
            this.getMyCode();
        }
    }

    private beforeUpdate(): void {
        this.removeVuetifyFileInputBug(document);
    }

    private getMyCode(): void {
        this.$store.dispatch("relays/getMyCode", {
            id: this.relay.id,
        }).then((res) => {
            this.myCode = res.pinCode;
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private toggleCodeDisplayed(index: number): void {
        this.displayedCodeIndex = this.displayedCodeIndex !== index ? index : null;
    }

    private async showEdit(): Promise<void> {
        this.newInfo = await JSON.parse(JSON.stringify(this.relay));
        this.newInfo = Object.assign({}, this.newInfo, {
            referents: this.referents,
            managers: this.managers,
            guests: this.guests,
        });
        this.isEdit = true;
    }

    private closeEdit(): void {
        this.newInfo = {};
        this.avatar = null;
        this.isEdit = false;
        this.displayHours = false;
    }

    private async showPinEdit(pinCode: any): Promise<void> {
        this.pinCodeToChange = pinCode;
        this.isPinEdit = true;
    }

    private closePinEdit(): void {
        this.pinCodeToChange = null;
        this.isPinEdit = false;
        this.newPinCode = null;
        this.error = null;
    }

    private save(): void {
        if (this.uploadFile) {
            const formData = new FormData();
            formData.append("file", this.avatar);
            formData.append("id", this.relay.id);
            formData.append("fileType", "relay-picture");
            this.$store.dispatch("files/upload", {formData});
            this.newInfo.picturePath = `/api/files/relays/${this.newInfo.id}/pictures/relay-picture`;
        }
        if (this.deleteFile) {
            this.$store.dispatch("files/delete", {id: this.relay.id, fileType: "relay-picture"});
        }
        this.newInfo.referents = this.newInfo.referents.map((ref) => ref.id);
        const defaultGuests = this.newInfo.guests?.map((ref) => ({id: ref.id, role: "GUEST"}));
        const defaultManagers = this.newInfo.managers?.map((ref) => ({id: ref.id, role: "MANAGER"}));
        this.newInfo.defaultManagers = [...defaultGuests, ...defaultManagers];
        delete this.newInfo.Boxes;
        delete this.newInfo.guests;
        delete this.newInfo.managers;
        this.update(this.newInfo);
        this.displayHours = false;
        this.closeEdit();
    }

    private fileChange(): void {
        if (this.avatar) {
            const fr = new FileReader();
            fr.readAsDataURL(this.avatar);
            fr.addEventListener("load", () => {
                this.uploadedImageSrc = fr.result;
            });
            this.uploadFile = true;
            this.deleteFile = false;
        } else {
            this.uploadedImageSrc = null;
        }
    }

    private addClosure(newClosure: any): void {
        this.newInfo = JSON.parse(JSON.stringify(this.relay));
        if (this.newInfo.exceptionalClosures?.items) {
            this.newInfo.exceptionalClosures.items.push(newClosure);
        } else {
            this.newInfo.exceptionalClosures = {
                items: [newClosure],
            };
        }
        this.update(this.newInfo);
        this.notifyExceptionalClosure(newClosure);
    }

    private notifyExceptionalClosure(newClosure: any): void {
        this.$store.dispatch("relays/notifyExceptionalClosure", {
            relayId: this.relay.id,
            exceptionalClosure: newClosure,
        }).then((res) => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("actions.saved"),
            });
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private removeClosure(oldClosure: any): void {
        this.newInfo = JSON.parse(JSON.stringify(this.relay));
        if (this.newInfo.exceptionalClosures?.items) {
            this.newInfo.exceptionalClosures.items = this.newInfo.exceptionalClosures.items
                .filter((closure) => closure.startDate !== oldClosure.startDate
                    && closure.endDate !== oldClosure.endDate);
            this.update(this.newInfo);
        }
    }

    private deleteAvatar(): void {
        this.avatar = null;
        this.uploadedImageSrc = null;
        this.newInfo.picturePath = null;
        this.deleteFile = true;
        this.uploadFile = false;
    }

    private validate(): void {
        if (this.newPinCode && this.valid) {
            this.error = null;
            this.loading = true;
            this.$store.dispatch("relays/pinExistance", {
                relayId: this.relay.id,
                pin: this.newPinCode,
            }).then((referent) => {
                if (referent.success) {
                    this.pinCodeToChange.newPinCode = this.newPinCode;
                    this.relay.referentsPinsChanged = this.pinCodeToChange;
                    this.update(this.relay);
                    if (this.isReferent) {
                        this.myCode = this.newPinCode;
                    }
                    this.loading = false;
                    this.closePinEdit();
                }
            }).catch((err) => {
                this.loading = false;
                if (this.isPinEdit) {
                    this.error = this.$i18n.t("alerts.error.pinExists");
                }
            });
        }
    }
}
</script>