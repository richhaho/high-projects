<template>
    <div>
        <v-dialog
            persistent
            v-model="modal"
            max-width="900px"
            :fullscreen="mobile"
            :hide-overlay="mobile"
        >
            <v-card>
                <v-card-title>
                    <span class="headline">
                        {{ $t('keysList.addGuest') }}
                    </span>
                </v-card-title>
                <v-card-text>
                    <v-container class="pb-0">
                        <v-col
                            v-if="loading"
                            cols="12"
                        >
                            <v-row
                                justify="center"
                                class="loading"
                            >
                                <v-progress-circular
                                    :width="3"
                                    color="#0c0733"
                                    indeterminate
                                />
                            </v-row>
                        </v-col>
                        <key-guests-autocomplete
                            v-else
                            :current-key="currentKey"
                            :edit="true"
                            :autocomplete-input="input"
                            ref="keyGuestsAutocomplete"
                            @invitation-change="updateIsAddButtonStatus"
                            @save="saveKey"
                        />
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="close"
                        color="white"
                        text
                    >
                        {{ $t('actions.cancel') }}
                    </v-btn>
                    <v-btn
                        v-if="isAddButtonEnabled || loadingAddGuest"
                        @click="addGuestFunction"
                        :loading="loadingAddGuest"
                        color="primary"
                    >
                        {{ $t('actions.add') }}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <over-price-sms
            :dialog="acceptOverPrice"
            :loading="loadingSendSms"
            @accept="saveKey"
            @cancel="close"
        ></over-price-sms>
    </div>
</template>

<script lang="ts">
import {Vue, Component, Prop, Watch} from "vue-property-decorator";
import OverPriceSms from "@/components/OverPriceSms.vue";
import KeyGuestsAutocomplete from "@/components/keys/KeyGuestsAutocomplete.vue";
import {Getter} from "vuex-class";

@Component({
    components: {
        OverPriceSms,
        KeyGuestsAutocomplete,
    },
})
export default class RelayKeyAddGuest extends Vue {

    @Prop({default: false})
    public modal: boolean;

    @Prop({default: null})
    public currentKey: any;

    @Prop({default: false})
    public loading: boolean;

    @Prop({default: null})
    public search: string;

    @Prop({default: false})
    public mobile: string;

    @Getter private currentUser: any;

    private acceptOverPrice: boolean = false;
    private isAddButtonEnabled: boolean = false;
    private loadingAddGuest: boolean = false;
    private loadingSendSms: boolean = false;
    private input: string = "";

    private mounted(): void {
        this.input = this.search;
    }

    private addGuestFunction(): void {
        this.loadingAddGuest = true;
        return (this.$refs.keyGuestsAutocomplete as HTMLFormElement)?.addGuest();
    }

    private saveKey(): void {
        this.loadingSendSms = true;
        this.$store.dispatch("keys/update", {
            key: this.currentKey,
            params: {
                newGuests: true,
                acceptOverPrice: this.acceptOverPrice,
            },
        })
        .then(() => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("actions.added"),
            });
            this.reset();
        })
        .catch((err) => {
            switch (err?.response?.data?.error) {
                case "smsLimitReached":
                    this.acceptOverPrice = true;
                    break;
                case "freemium":
                    this.$store.commit("alerts/displayError", {
                        msg: this.$i18n.t("invitation.freemium"),
                    });
                    break;
                default:
                    this.$store.commit("alerts/displayError", {
                        msg: this.$t(`alerts.error.${err?.response?.data?.error || "default"}`),
                    });
                    break;
            }
            this.loadingSendSms = false;
        });
    }

    private updateIsAddButtonStatus(newVal: boolean): void {
        this.isAddButtonEnabled = newVal;
    }

    private reset(): void {
        this.$emit("reset");
        this.close();
    }

    private close(): void {
        this.$emit("close");
        this.acceptOverPrice = false;
        this.loadingSendSms = false;
        this.loadingAddGuest = false;
        this.currentKey.newGuests = [];
    }
}
</script>