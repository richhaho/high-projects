<template>
    <div class="tableau mb-5">
        <div class="options">
            <div class="option_left">
                <button class="option" @click.stop="displayKeysFilter = !displayKeysFilter">
                    <i class="icon-picto_filtrer"></i>
                    {{ $t('actions.filter') }}
                </button>
                <div class="with_filters">
                    <ul class="filters" :class="{'d-block': displayKeysFilter}">
                        <li
                            v-for="(status, index) in keysStatus"
                            :key="index"
                        >
                            <label>
                                <p-check
                                    :value="status"
                                    v-model="pagination.select"
                                    class="p-default p-curve mt-2 p-bigger"
                                    color="primary"
                                />
                                {{ $t(`key.statusType.${status}`) }}
                            </label>
                        </li>
                    </ul>
                </div>
                <v-text-field
                    class="pa-0 ma-0 ml-4"
                    append-icon="search"
                    hide-details
                    single-line
                    v-bind:label="$t('actions.search')"
                    v-model="keysSearch"
                    @input="searchHandler"
                />
            </div>
            <div class="toggle_carte m-2" v-if="isMaster()">
                <label>{{ $t('key.accessToGuests') }}</label>
                <div class="onoffswitch">
                    <input type="checkbox"
                           v-model="relay.canReferentsProcessKeys"
                           name="carte" class="onoffswitch-checkbox" id="myonoffswitch"
                           @change="accesToGuestsHandler">
                    <label class="onoffswitch-label" for="myonoffswitch">
                        <span class="onoffswitch-inner"></span>
                        <span class="onoffswitch-switch"></span>
                    </label>
                </div>
            </div>
        </div>

        <!-- /.options -->
        <v-data-table
            :headers="headers"
            :hide-default-footer="totalKeys < pagination.itemsPerPage"
            :items="keys"
            :loading="loading"
            :options.sync="pagination"
            :search="pagination.search"
            :server-items-length="totalKeys"
            class="elevation-1"
        >
            <template v-slot:header.name="{ header }">{{ $t('key.name') }}</template>
            <template v-slot:header.owner="{ header }">{{ $t('key.owner') }}</template>
            <template v-slot:header.status="{ header }">{{ $t('key.status') }}</template>
            <template v-slot:header.location="{ header }">{{ $t('key.location') }}</template>
            <template v-slot:header.actions="{ header }">{{ 'Actions' }}</template>
            <template v-slot:item.owner="{ item }">
                {{ item.owner.displayName }}
            </template>
            <template v-slot:item.relay="{ item }">
                <v-btn
                    :to="{ name: 'relay' , params: { id: item.relayDisplayed.id } }"
                    class="v-btn--active text-none"
                    color="green"
                    rounded
                    target="_blank"
                    text
                    v-if="item.relayDisplayed"
                    x-small
                >
                    <v-icon left x-small>home</v-icon>
                    {{ item.relayDisplayed.name }}
                </v-btn>
            </template>
            <template v-slot:item.status="{ item }">
                <key-status v-if="isB2B" :currentKey="item"/>
                <div v-else>
                    <span v-if="item.status === 'IN_RELAY'">{{ $t("key.statusType.IN_RELAY") }}</span>
                    <span v-else>{{ $t("key.statusType.WITH_SOMEBODY") }}</span>
                </div>
            </template>
            <template v-slot:item.location="{ item }">
                <v-btn
                    :href="$store.state.baseURL ? `${$store.state.baseURL}/api/locations/${item.locationDisplayed.id}/generate-qr-code` :
                        `/locations/${item.locationDisplayed.id}/generate-qr-code`"
                    outlined
                    small
                    target="_blank"
                    v-if="item.locationDisplayed && currentUser && (currentUser.isAdmin || isMaster('INSURANCE'))"
                >{{ item.locationDisplayed.codeName }}
                </v-btn>
                <div v-else-if="item.locationDisplayed && !item.connectedBoxLocker">{{ item.locationDisplayed.codeName }}</div>
                <div v-else-if="item.locationDisplayed && item.connectedBoxLocker">{{ item.connectedBoxLocker }}</div>
            </template>
            <template v-slot:item.actions="{ item }">
                <v-row>
                    <key-guest-reminder
                        v-if="isKeyB2B(item)"
                        :keyId="item.id"
                        :users="item.users"
                        :loading="item.loadingUsers"
                        @get-key-users="updateKeyUsers(item)"
                    />
                    <relay-give-key-to-guest
                        v-if="accessToGuests && !isKeyInConnectedBox(item)"
                        :current-key="item"
                        :relay="relay"
                        :update-key-users="updateKeyUsers"
                        @reset="getKeys"
                    />
                    <relay-booked-key
                        v-if="item.currentBooking"
                        :current-key="item"
                    />
                </v-row>
            </template>
        </v-data-table>
    </div>
</template>

<script lang="ts">
import {Component, Vue, Prop, Watch} from "vue-property-decorator";
import KeyStatus from "@/components/keys/KeyStatus.vue";
import RelayGiveKeyToGuest from "@/components/relays/RelayGiveKeyToGuest.vue";
import RelayBookedKey from "@/components/relays/RelayBookedKey.vue";
import KeyGuestReminder from "@/components/keys/KeyGuestReminder.vue";
import {Getter} from "vuex-class";
import Timeout = NodeJS.Timeout;

export const DEBOUNCE_TIME_MILLI: number = 500;

@Component({
    components: {
        KeyStatus,
        RelayGiveKeyToGuest,
        KeyGuestReminder,
        RelayBookedKey,
    },
})
export default class RelayKeys extends Vue {

    get searchQuery() {
        this.pagination.search = this.getSearchQuery;
        return this.getSearchQuery;
    }

    get accessToGuests(): boolean {
        return !!this.relay?.canReferentsProcessKeys;
    }

    @Prop({default: {}})
    public relay: any;
    @Getter private currentUser: any;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isB2B: boolean;
    @Getter private getSearchQuery: string;

    private loading: boolean = true;
    private keys: any[] = [];
    private keysStatus: string[] = [];
    private displayKeysFilter: boolean = false;
    private timerId: Timeout = null;
    private keysSearch: string = null;
    private pagination: any = {
        sortDesc: [true],
        sortBy: ["updatedAt"],
        search: "",
        select: [],
        page: 1,
        itemsPerPage: 10,
    };
    private headers: any[] = [];
    private totalKeys: number = 0;
    private selectGuest: boolean = false;
    private currentKey: any = [];

    @Watch("pagination", {deep: true})
    public handler(val, oldVal) {
        this.loading = true;
        if (val.page === oldVal.page) {
            val.page = 1;
        }
        this.getKeys();
    }

    private mounted() {
        this.getKeysStatus();
        this.setHeaders();
    }

    private setHeaders() {
        if (this.isB2B) {
            // Agency -> All details
            this.headers = [
                {value: "name", sortable: true},
                {value: "owner", sortable: false},
                {value: "status", sortable: true},
                {value: "location", sortable: false},
                {value: "actions", sortable: false},
            ];
        } else {
            // Flow or Long term relay -> No details
            this.headers = [
                {value: "location", sortable: false},
                {value: "status", sortable: true},
            ];
        }
    }

    private accesToGuestsHandler() {
        this.$store.dispatch("relays/updateAccessStatus", {
            relayId: this.relay.id,
            status: this.relay.canReferentsProcessKeys,
        }).then(() => {
            this.$emit("reset");
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("actions.saved"),
            });
        });
    }

    private searchHandler(): void {
        this.loading = true;
        // cancel pending call
        clearTimeout(this.timerId);
        // delay new call
        this.timerId = setTimeout(() => {
            this.pagination.search = this.keysSearch || null;
        }, DEBOUNCE_TIME_MILLI);
    }

    private getKeys() {
        const query = Object.assign({}, this.pagination, {
            filter: {
                relay: {
                    id: this.relay.id,
                    type: this.relay.type,
                },
            },
        });
        const relayId = this.relay.id;
        this.$store.dispatch("relays/getKeys", {relayId, query}).then((res) => {
            this.totalKeys = res?.count;
            this.keys = res?.keys;
            this.keys.forEach((key: any) => {
                // Display either current location or reserved location if the key is not in relay
                key.locationDisplayed = this.isKeyB2B(key) ? key?.currentLocation :
                    (key?.currentLocation || key?.ReservedLocations?.[0]);
                // Display either current relay or main relay of the key (agency for b2b, first else)
                key.relayDisplayed = key?.currentLocation?.Box?.Relay
                    || key.Relays.find((relay) => relay.type === "AGENCY")
                    || key.Relays[0];
                key.loadingUsers = true;
                const acsesObject = key.AcsesObjects[0];
                if (acsesObject) {
                    key.connectedBoxLocker = acsesObject.name;
                }
                this.$set(key, "newGuests", []);
            });
            this.loading = false;
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private getKeyUsers(key: any): Promise<any[]> {
        return this.$store.dispatch("keys/getKeyUsers", {
            keyId: key.id,
        }).then((res) => {
            return res?.filter((user) =>
                // Remove the current user from the list of users
                user.id !== this.currentUser?.id
                // Remove guests with an upcoming (not valid right now) invitation
                && user.invitations?.some((i) => this.isValidAccess(i?.keyAccess)),
            ) || [];
        });
    }

    private updateKeyUsers(key: any): Promise<void | any[]> {
        return this.getKeyUsers(key).then((users) => {
            this.$set(key, "users", users);
            this.$set(key, "guests", users);
            this.$set(key, "newGuests", []);
            this.$set(key, "loadingUsers", false);
        });
    }

    private isValidAccess = (access: any) => (access.countAccessLeft === -1 || access.countAccessLeft >= 1)
        && (access.startDate === null || new Date(access.startDate) <= new Date())
        && (access.endDate === null || new Date(access.endDate) >= new Date())

    private isKeyB2B(key: any): boolean {
        return !!key?.Relays?.some((r: any) => r.type === "AGENCY");
    }

    private getKeysStatus() {
        return this.$store.dispatch("keys/getStatus").then((res) => {
            this.keysStatus = res.keysStatus;
        });
    }

    private popSelected(item: string) {
        this.pagination.select.splice(this.pagination.select.indexOf(item), 1);
    }

    private isKeyInConnectedBox(item) {
        return item?.status && item?.status === "IN_CONNECTED_BOX";
    }
}
</script>
