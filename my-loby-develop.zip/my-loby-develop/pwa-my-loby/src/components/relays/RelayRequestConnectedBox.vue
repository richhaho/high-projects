<template>
    <v-dialog
        persistent
        max-width="500px"
        v-model="dialog"
    >
        <template v-slot:activator="{ on }">
            <v-btn
                color="default"
                outlined
                v-on="on"
            >
                {{$t('box.requestConnected')}}
            </v-btn>
        </template>
        <v-card>
            <v-card-title>
                <span class="headline">
                    {{$t('box.requestConnected')}}
                </span>
            </v-card-title>
            <v-card-text>
                <v-container>
                    <p>
                        {{$t('box.requestOneDetails')}}
                    </p>
                    <v-form v-model="valid">
                        <v-text-field
                            :label="$t('box.locationsWantedNbrConnected')"
                            :rules="[rules.required, rules.strictlyPositive, rules.integer]"
                            type="number"
                            v-model="boxesWanted"
                        />
                    </v-form>
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    @click="dialog = false"
                    color="white"
                    text
                >
                    {{$t('actions.cancel')}}
                </v-btn>
                <v-btn
                    v-if="valid"
                    @click="requestConnectedBox()"
                    color="warning"
                >
                    {{$t('actions.send')}}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";
import {formRules} from "@/utils/formRules";

@Component({})
export default class RelayRequestNewBox extends Vue {
    @Prop({default: null})
    public relayId: any;

    private dialog: boolean = false;
    private valid: boolean = false;
    private rules: object = formRules;
    private boxesWanted: number = null;

    private requestConnectedBox() {
        this.$store.dispatch("relays/requestConnectedBox", {
            relayId: this.relayId,
            boxesWanted: this.boxesWanted,
        }).then((res) => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("actions.sent"),
            });
            this.dialog = false;
        }).catch((err) => {
            this.dialog = false;
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }
}
</script>
