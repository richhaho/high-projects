<template>
    <v-dialog
        max-width="500px"
        v-model="reserveLocationDialog"
    >
        <template v-slot:activator="{ on }">
            <v-btn
                color="default"
                class="my-4"
                outlined
                v-on="on"
            >
                {{$t('locations.reserve')}}
            </v-btn>
        </template>
        <v-card>
            <v-card-title>
                <span class="headline">{{$t('locations.reserve')}}</span>
            </v-card-title>
            <v-card-text class="py-0">
                <v-container>
                    <v-row>
                        <v-col cols="12 pa-0">
                            <v-autocomplete
                                item-value="id"
                                :loading="loadingSearch"
                                :items="insuranceCompanies"
                                :search-input.sync="searchInsuranceCompanies"
                                append-icon
                                clearable
                                @click:clear="locationsReservation.companyId = null"
                                flat
                                no-filter
                                hide-details
                                :no-data-text="$t('common.noResult')"
                                solo
                                v-bind:label="$t('company.search')"
                                v-model="locationsReservation.companyId"
                            >
                                <template v-slot:selection="data">
                                    <v-list-item-content>
                                        <v-list-item-title v-html="data.item.name"></v-list-item-title>
                                        <v-list-item-subtitle v-html="data.item.activitySector"></v-list-item-subtitle>
                                    </v-list-item-content>
                                </template>
                                <template v-slot:item="data">
                                    <v-list-item-content>
                                        <v-list-item-title v-html="data.item.name"></v-list-item-title>
                                        <v-list-item-subtitle v-html="data.item.activitySector"></v-list-item-subtitle>
                                    </v-list-item-content>
                                </template>
                            </v-autocomplete>
                            <v-text-field
                                type="number"
                                class="px-2"
                                :label="$t('locations.number')"
                                v-model="locationsReservation.number"
                            >
                            </v-text-field>
                        </v-col>
                    </v-row>
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn
                    @click="reserveLocationDialog = false"
                    color="white"
                    text
                >
                    {{$t('actions.cancel')}}
                </v-btn>
                <v-btn
                    v-if="locationsReservation.companyId && locationsReservation.number"
                    @click="reserveLocations"
                    color="warning"
                    text
                    :loading="loadingReservation"
                >
                    {{$t('actions.reserve')}}
                </v-btn>
                <v-spacer></v-spacer>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import {Vue, Component, Prop, Watch} from "vue-property-decorator";
import {Getter} from "vuex-class";
import Timeout = NodeJS.Timeout;

export const DEBOUNCE_TIME_MILLI: number = 500;

@Component
export default class RelayReserveLocations extends Vue {
    @Prop({default: null})
    public relay: any;

    @Getter private isAdmin: boolean;

    private reserveLocationDialog: boolean = false;
    private loadingSearch: boolean = false;
    private loadingReservation: boolean = false;
    private timerId: Timeout = null;
    private insuranceCompanies: any[] = [];
    private searchInsuranceCompanies: string = "";
    private locationsReservation: any = {
        companyId: null,
        number: null,
    };

    @Watch("searchInsuranceCompanies")
    public handlerSearchInsuranceCompanies(newVal: string, oldVal: string): void {
        if (newVal || !oldVal) {
            this.loadingSearch = true;
            // cancel pending call
            clearTimeout(this.timerId);
            // delay new call
            this.timerId = setTimeout(() => {
                this.getInsuranceCompanies().then(() => {
                    this.loadingSearch = false;
                });
            }, DEBOUNCE_TIME_MILLI);
        }
    }

    private getInsuranceCompanies(): Promise<any> {
        return this.$store.dispatch("companies/read", {
            query: {
                search: this.searchInsuranceCompanies,
                type: "insurance",
            },
        }).then((res: any) => {
            this.insuranceCompanies = res.rows;
        }).catch((err: any) => {
            this.$store.commit("alerts/displayError", {
                msg : err,
            });
        });
    }

    private reserveLocations(): void {
        this.loadingReservation = true;
        this.$store.dispatch("relays/reserveLocation", {
            relayId: this.relay.id,
            companyId: this.locationsReservation.companyId,
            locationsNumber: this.locationsReservation.number,
        }).then((res) => {
            this.reserveLocationDialog = false;
            this.$emit("reset");
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("locations.locationsReserved"),
            });
        }).catch((err) => {
            this.loadingReservation = false;
            this.$store.commit("alerts/displayError", {
                msg: this.$t(`locations.${err.response.data.error}`),
            });
        });
    }

}
</script>