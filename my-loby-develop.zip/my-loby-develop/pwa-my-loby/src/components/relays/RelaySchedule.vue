<template>
    <div v-if="!isLoading">
        <h6>{{$t('relay.infoLoby.schedule')}}</h6>
            <div v-for="(d, i) in orderedSchedule" :key="i" :style="d.today ?'font-weight: bold' : ''">
                {{$t(`day.${d.day}`)}}:
                <span v-for="(h, j) in d.hours" :key="j">
                    <span v-if="j===1">|</span>{{h}}
                </span>
                <span v-if="!d.hours.length">
                    {{$t('relay.infoLoby.closed')}}
                </span>
            </div>
    </div>
</template>
<script lang="ts">
import {Vue, Component, Prop, Watch} from "vue-property-decorator";
import { weekDays } from "@/utils/constants";

@Component({})
export default class RelaySchedule extends Vue {
    @Prop({default: null})
    public schedule: any;

    public isLoading: boolean = true;
    private orderedSchedule: any = [];

    @Watch("schedule", { deep: true })
    public handlerSelectedKeys() {
        this.isLoading = true;
        this.setSchedule();
    }

    private mounted() {
        this.orderedSchedule = [];
        this.setSchedule();
    }

    private setSchedule() {
        const days = Object.keys(this.schedule);
        const today = new Date();

        days.forEach((d, i) => {
            const weekDayIndex: number = Number(Object.keys(weekDays).find((key) => weekDays[key] === d));
            const day =  this.schedule[d];
            this.orderedSchedule[weekDayIndex] = {
                day: d,
                today: today.getDay() - 1 === weekDayIndex || today.getDay() === 0 && weekDayIndex === 6,
                hours: this.setHours(day),
            };
        });
        this.isLoading = false;
    }

    private setHours(day) {
        if (!day.isActive) {
            return [];
        } else if (day.continuous.isActive) {
            return [`${day.continuous.fromHours}-${day.continuous.toHours}`];
        } else {
            const hours = [];
            if (day.morning.isActive) {
                hours.push(`${day.morning.fromHours}-${day.morning.toHours}`);
            }
            if (day.evening.isActive) {
                hours.push(`${day.evening.fromHours}-${day.evening.toHours}`);
            }
            return hours;
        }
    }
}
</script>