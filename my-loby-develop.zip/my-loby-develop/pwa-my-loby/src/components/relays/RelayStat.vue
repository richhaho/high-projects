<template>
    <div>
        <p class="tableau_titre">STATISTIQUES <i class="icon-header_triangle"></i></p>
        <div class="tableau">
            <div class="options">
                <div class="option_left">
                    <p class="titre"><strong>Nombres de visiteurs</strong></p>
                </div>
                <div class="option_right">
                    <a href="#" class="option no_picto" title="Ajouter une clé">
                        Jour
                    </a>
                    <a href="#" class="option no_picto" title="Ajouter une clé">
                        Semaine
                    </a>
                    <a href="#" class="option no_picto active" title="Ajouter une clé">
                        Mois
                    </a>
                    <a href="#" class="option" title="Ajouter une clé">
                        <i class="icon-picto_exporter"></i>
                        Exporter
                    </a>
                </div>
            </div>
            <div class="row no-gutters">
                <div class="col-md-6">
                    <div class="statistiques_agence visiteurs">
                        <h1>
                            <strong>49</strong>Visiteurs
                        </h1>
                        <img src="img/layer_jaune.jpg" alt="" class="max_w">
                    </div>
                    <!-- /.statistiques_agence -->
                </div>
                <div class="col-md-6">
                    <div class="statistiques_agence code_promo">
                        <h1>
                            <strong>18</strong>Code promo utilisé
                        </h1>
                        <img src="img/layer_vert.jpg" alt="" class="max_w">
                    </div>
                    <!-- /.statistiques_agence -->
                </div>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import {Vue, Component, Prop} from "vue-property-decorator";

@Component({})
export default class RelayStat extends Vue {
    @Prop({default: null})
    public relay: any;

}
</script>