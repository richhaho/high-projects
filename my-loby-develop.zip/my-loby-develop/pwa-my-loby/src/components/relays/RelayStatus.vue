<template>
    <div>
        <p class="tableau_titre">{{$t('relay.status.title')}} <i class="icon-header_triangle"></i></p>
        <div class="tableau">
            <div class="options">
                <div class="option_left"></div>
                <div class="option_right">
                    <a class="option" @click="showEdit">
                        <i class="icon-picto_editer"></i>
                        {{$t('actions.edit')}}
                    </a>
                </div>
            </div>
            <v-row justify="center">
                <stepper
                    :steps="status"
                    :relay="relay"
                />
            </v-row>
        </div>
        <v-dialog
            persistent
            max-width="910px"
            v-model="isEdit" >
            <v-card>
                <v-card-title>
                    <div class="contain_picto">
                        <i class="icon-picto_factures"></i>
                    </div>
                    <span class="headline">{{$t('relay.modifyStatus')}}</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-row>
                            <v-select
                                :items="status"
                                :label="$t('form.status')"
                                v-model="newInfo.status"
                                item-value="value"
                            >
                                <template slot="selection" slot-scope="data">
                                    {{$t(data.item.label)}}
                                </template>
                                <template slot="item" slot-scope="data">
                                    {{$t(data.item.label)}}
                                </template>
                            </v-select>
                        </v-row>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn text @click="closeEdit" color="white">{{$t('actions.cancel')}}</v-btn>
                    <v-btn
                        @click="save"
                        color="warning"
                    >{{$t('actions.save')}}</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>

<script lang="ts">
import {Vue, Component, Prop, Watch} from "vue-property-decorator";
import Stepper from "@/components/Stepper.vue";
@Component({
    components: {Stepper},
})
export default class RelayStatus extends Vue {
    @Prop({default: null})
    public relay: any;

    @Prop({})
    public update: (relay) => void;

    private newInfo: any = {};
    private isEdit: boolean = false;

    get status() {
        const statusB2B: any = [
            {value: 0, label: "relay.status.AGENCY.0"},
            {value: 1, label: "relay.status.AGENCY.1"},
            {value: 2, label: "relay.status.AGENCY.2"},
        ];
        const statusB2C: any = [
            {value: 0, label: "relay.status.FLOW.0"},
            {value: 1, label: "relay.status.FLOW.1"},
            {value: 2, label: "relay.status.FLOW.2"},
            {value: 3, label: "relay.status.FLOW.3"},
            {value: 4, label: "relay.status.FLOW.4"},
        ];
        return this.isAgency ? statusB2B : statusB2C;
    }

    get isAgency(): boolean {
        return this.relay?.type === "AGENCY";
    }

    private async showEdit() {
        this.newInfo = await JSON.parse(JSON.stringify(this.relay));
        this.isEdit = true;
    }

    private closeEdit() {
        this.isEdit = false;
    }

    private save() {
        this.newInfo.referents = this.newInfo.Referents.map((ref) => ref.id);
        delete this.newInfo.Boxes;
        this.update(this.newInfo);
        this.closeEdit();
    }

}
</script>
