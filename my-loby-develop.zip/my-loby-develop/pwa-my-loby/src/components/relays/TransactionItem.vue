<template>
    <article v-if="transaction">
        <v-row>
            <v-col :cols="isMobile ? 12 : (showActions ? 4 : 6)" class="picture pa-0 d-flex justify-content-center transaction-picture">
                <img
                    :src="getSrc(transaction.key.picturePath) || defaultKeyPicture"
                />
            </v-col>
            <v-col :cols="isMobile ? 12 : (showActions ? 4 : 6)" class="bloc ma-0 py-4">
                <h5 v-if="isAgencyRef || isAdmin" class="mb-0 pb-0">
                    {{$t("relay.transactions.keysName")}} :
                    <strong>
                        {{transaction.key.name}}
                    </strong>
                </h5>
                <p v-if="isAgencyRef || isAdmin" class="mb-0">
                    {{$t("relay.transactions.keysDescription")}} :
                    {{transaction.key.description}}
                </p>
                <v-chip
                    small
                    class="mb-2"
                    color="#070a33"
                    outlined
                >
                    {{ transaction.relay.name}}
                </v-chip>
                <br>
                <p class="mb-0">
                    {{ $tc('box.locations', 1) }} :
                    <v-btn
                        :href="$store.state.baseURL ? `${$store.state.baseURL}/api/locations/${transaction.location.id}/generate-qr-code` :
                            `/locations/${transaction.location.id}/generate-qr-code`"
                        outlined
                        x-small
                        target="_blank"
                    >
                        {{ transaction.location.name }}
                    </v-btn>
                </p>
                <p class="mb-0">
                    {{ $t("relay.transactions.madeAt") }}
                    {{ transaction.createdAt | formatDate }}
                    {{ $t("common.by") }}
                    {{ transaction.user.name }}
                </p>
            </v-col>
            <v-col :cols="isMobile ? 12 : 4" v-if="showActions" class="pa-0" :class="isMobile ? 'd-flex justify-content-center transaction-btn-group-mobile' : 'transaction-btn-group'">
                <v-btn
                    @click="$emit('accept', transaction)"
                    color="#64B5F6"
                    height="50%"
                    x-large
                    tile
                    depressed
                    dark
                    style="font-size: 28px;"
                    :class="isMobile ? 'w-50' : ''"
                >
                    <v-icon x-large size="30px">check</v-icon>
                </v-btn>
                <v-btn
                    @click="$emit('decline', transaction)"
                    color="#FFB74D"
                    height="50%"
                    x-large
                    tile
                    depressed
                    dark
                    style="font-size: 28px;"
                    :class="isMobile ? 'w-50' : ''"
                >
                    <v-icon x-large>clear</v-icon>
                </v-btn>
            </v-col>
        </v-row>
    </article>
</template>
<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import {getSrc} from "@/utils/misc";
import {defaultKeyPicture} from "@/utils/constants";
import {Getter} from "vuex-class";

@Component
export default class TransactionItem extends Vue {
    @Prop({ default: null })
    public transaction: any;

    @Prop({ default: false })
    public showActions: boolean;

    @Getter private isAgencyRef: boolean;
    @Getter private isAdmin: boolean;
    @Getter private isMobile: boolean;

    private getSrc: (string) => string = getSrc;
    private defaultKeyPicture = defaultKeyPicture;
}
</script>