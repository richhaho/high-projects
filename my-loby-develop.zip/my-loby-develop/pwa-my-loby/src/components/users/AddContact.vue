<template>
    <v-row justify="center">
        <button v-if="!isMobile"
                type="button"
                class="option open_popup"
                @click="showDialog = true"
                :title="$t('contacts.add')"
        >
            <i style="color: #212529" class="icon-picto_ajouter"></i>
            {{$t('contacts.add')}}
        </button>
        <v-dialog
            persistent
            v-model="showDialog"
            max-width="510px"
            :fullscreen="isMobile"
            :hide-overlay="isMobile"
            :transition="isMobile ? 'dialog-bottom-transition' : ''"
        >
            <template v-slot:activator="{ on }" v-if="isMobile">
                <button
                    class="m-btn-round"
                    v-on="on"
                >
                    <i style="color: #212529" class="icon-picto_ajouter"></i>
                </button>
            </template>
            <v-card>
                <v-card-title>
                    <div class="contain_picto">
                        <i class="icon-picto_mes-contacts"></i>
                    </div>
                    <span class="headline">
                        {{$t('contacts.add')}}
                    </span>
                </v-card-title>
                <v-form
                    v-model="valid"
                >
                    <v-card-text>
                        <v-container class="py-0">
                            <v-row>
                                <v-col class="py-0">
                                    <v-text-field
                                        v-if="isB2B"
                                        v-bind:label="$t('user.mailOrPhone')+' *'"
                                        v-model="mainContact"
                                        :rules="[rules.required, rules.mainContact]"
                                    />
                                    <v-text-field
                                        v-else
                                        :label="$t('user.email')+' *'"
                                        :rules="[rules.email, rules.required]"
                                        v-model="newContact.email"
                                    />
                                    <v-text-field
                                        v-bind:label="$t('user.firstName')"
                                        v-model="newContact.firstName"
                                    />
                                    <v-text-field
                                        v-bind:label="$t('user.lastName')"
                                        v-model="newContact.lastName"
                                    />
                                    <v-text-field
                                        v-bind:label="$t('user.company')"
                                        v-model="newContact.specificCompanyName"
                                    />
                                    <v-text-field
                                        v-bind:label="$t('user.job')"
                                        v-model="newContact.job"
                                    />
                                    <v-text-field
                                        v-if="isB2B && isPhone"
                                        :label="$t('user.email')"
                                        :rules="[rules.email]"
                                        v-model="newContact.email"
                                    />
                                    <v-text-field
                                        v-if="!isB2B || isEmail"
                                        :label="$t('user.phone')"
                                        :rules="[rules.phone]"
                                        v-model="newContact.phone"
                                    />
                                </v-col>
                            </v-row>
                        </v-container>
                    </v-card-text>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn
                            @click="showDialog = false"
                            color="white"
                            text
                        >
                            {{$t('actions.cancel')}}
                        </v-btn>
                        <v-btn
                            v-if="valid"
                            :disabled="!valid"
                            :loading="loading"
                            @click="addContact"
                            color="warning"
                        >
                            {{$t('actions.add')}}
                        </v-btn>
                    </v-card-actions>
                </v-form>
            </v-card>
        </v-dialog>
        <over-price-sms
            :dialog="acceptOverPrice"
            :loading="loading"
            @accept="addContact"
            @cancel="acceptOverPrice = false"
        ></over-price-sms>
    </v-row>
</template>

<script lang="ts">
import {Component, Prop, Vue} from "vue-property-decorator";
import {regex, formRules} from "@/utils/formRules";
import {Getter} from "vuex-class";
import OverPriceSms from "@/components/OverPriceSms.vue";

@Component({
    components: {
        OverPriceSms,
    },
})
export default class AddContact extends Vue {

    @Prop({})
    public getUsers: () => void;

    @Prop({default: false})
    public isMobile: boolean;

    @Getter private isB2B: boolean;
    private rules: any = formRules;
    private showDialog: boolean = false;
    private newContact: any = {};
    private mainContact: string = null;
    private valid: boolean = true;
    private loading: boolean = false;
    private acceptOverPrice: boolean = false;

    get isEmail(): boolean {
        return regex.email.test(this.mainContact);
    }

    get isPhone(): boolean {
        return regex.validPhoneNumber.test(this.mainContact);
    }

    private init(): void {
        this.newContact = {};
        this.mainContact = "";
        this.showDialog = false;
        this.acceptOverPrice = false;
        this.loading = false;
    }

    private addContact(): void {
        if (this.isEmail) {
            this.newContact.email = this.mainContact;
        }
        if (this.isPhone) {
            this.newContact.phone = this.mainContact;
        }
        this.loading = true;
        this.$store.dispatch("users/addContact", {
            contact: this.newContact,
            acceptOverPrice: this.acceptOverPrice,
        }).then((res) => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$t("contacts.added", {
                    contactEmail: res?.data?.user2?.name || this.mainContact,
                }),
            });
            this.$emit("reset");
            this.init();
        }).catch((err) => {
            switch (err?.response?.data?.error) {
                case "smsLimitReached":
                    this.acceptOverPrice = true;
                    break;
                case "freemium":
                    this.$store.commit("alerts/displayError", {
                        msg: this.$i18n.t("invitation.freemium"),
                    });
                    break;
                default:
                    this.$store.commit("alerts/displayError", {
                        msg: this.$t(`alerts.error.${err?.response?.data?.error || "default"}`),
                    });
                    break;
            }
            this.loading = false;
        });
    }
}
</script>