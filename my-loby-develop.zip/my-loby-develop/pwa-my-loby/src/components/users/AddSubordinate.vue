<template>
    <v-row justify="center">
        <button v-if="!isMobile"
                type="button"
                class="option open_popup"
                @click="showDialog = true"
                :title="$t('management.add')"
        >
            <i style="color: #212529" class="icon-picto_ajouter"></i>
            {{$t('management.add')}}
        </button>
        <v-dialog
            persistent
            v-model="showDialog"
            max-width="510px"
            :fullscreen="isMobile"
            :hide-overlay="isMobile"
            :transition="isMobile ? 'dialog-bottom-transition' : ''"
        >
            <template v-slot:activator="{ on }" v-if="isMobile">
                <button
                    class="m-btn-round"
                    v-on="on"
                >
                    <v-icon color="#212529">person_add</v-icon>
                </button>
            </template>
            <v-card>
                <v-card-title class="px-5">
                    <div class="contain_picto">
                        <i class="icon-picto_mes-contacts"></i>
                    </div>
                    <span class="headline">
                        {{$t('management.add')}}
                    </span>
                </v-card-title>
                <v-form v-model="valid">
                    <v-card-text class="pt-0">
                        <v-container class="py-0">
                            <v-row>
                                <v-col class="pb-0">
                                    <v-text-field
                                        v-bind:label="$t('user.firstName')+' *'"
                                        v-model="newManager.firstName"
                                        :rules="[rules.required]"
                                    />
                                    <v-text-field
                                        v-bind:label="$t('user.lastName')+' *'"
                                        v-model="newManager.lastName"
                                        :rules="[rules.required]"
                                    />
                                    <v-text-field
                                        :label="$t('user.email')+' *'"
                                        :rules="[rules.required, rules.email]"
                                        v-model="newManager.email"
                                    />
                                    <v-text-field
                                        :label="$t('user.phone')"
                                        :rules="[rules.phone]"
                                        v-model="newManager.phone"
                                    />
                                    <v-text-field
                                        v-bind:label="$t('user.company')"
                                        v-model="newManager.specificCompanyName"
                                    />
                                    <v-text-field
                                        v-bind:label="$t('user.job')"
                                        v-model="newManager.job"
                                    />
                                </v-col>
                            </v-row>
                        </v-container>
                    </v-card-text>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn
                            @click="showDialog = false"
                            color="white"
                            text
                        >
                            {{$t('actions.cancel')}}
                        </v-btn>
                        <v-btn
                            v-if="valid"
                            :disabled="!valid"
                            :loading="loading"
                            @click="addManager"
                            color="warning"
                        >
                            {{$t('actions.add')}}
                        </v-btn>
                    </v-card-actions>
                </v-form>
            </v-card>
        </v-dialog>
    </v-row>
</template>

<script lang="ts">
import {Component, Prop, Vue} from "vue-property-decorator";
import {formRules} from "@/utils/formRules";

@Component
export default class AddSubordinate extends Vue {

    @Prop({default: false})
    public isMobile: boolean;

    private rules: object = formRules;
    private showDialog: boolean = false;
    private newManager: any = {};
    private valid: boolean = true;
    private loading: boolean = false;

    private init(): void {
        this.newManager = {};
        this.showDialog = false;
    }

    private addManager(): void {
        this.loading = true;
        this.$store.dispatch("users/addSubordinate", {
            subordinate: this.newManager,
        }).then((res) => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$t("management.added", {
                    managerName: this.newManager.firstName + " " + this.newManager.lastName,
                }),
            });
            this.$emit("reset");
            this.init();
            this.loading = false;
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: this.$t(`user.${err.response.data.error}`),
            });
            this.loading = false;
        });
    }
}
</script>