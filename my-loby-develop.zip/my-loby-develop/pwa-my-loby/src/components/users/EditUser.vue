<template>
    <v-row :justify="isMobile ? 'end': 'center'">
        <a v-if="canEditProfile" @click="editUserDialog = true"
           :class="isMobile ? 'action mr-4' : 'option'" :title="$t('actions.edit')">
            <i class="icon-picto_editer"></i>
            {{$t('actions.edit')}}
        </a>
        <!-- /.option -->
        <v-dialog
            persistent
            max-width="910px"
            v-model="editUserDialog"
            :fullscreen="isMobile"
            :hide-overlay="isMobile"
            :transition="isMobile ? 'dialog-bottom-transition' : ''">
            <v-card>
                <v-card-title>
                    <div class="contain_picto">
                        <i class="icon-picto_mes-contacts"></i>
                    </div>
                    <span class="headline">{{$t('actions.edit')}}</span>
                </v-card-title>
                <v-card-text class="pb-1">
                    <v-container class="pa-0">
                        <v-row>
                            <v-col cols="12 pa-0">
                                <v-form ref="user"
                                        v-if="user.email !== null"
                                        v-model="valid"
                                        class="ma-5"
                                >
                                    <v-row align="center" justify="center">
                                        <v-img
                                            :src="uploadedImageSrc || getSrc(user.picturePath) || defaultUserAvatar"
                                            aspect-ratio="1"
                                            max-height="150"
                                            max-width="150"
                                            style="border-radius: 50%;"
                                        >
                                            <template v-slot:placeholder>
                                                <v-row
                                                    align="center"
                                                    class="fill-height ma-0"
                                                    justify="center"
                                                >
                                                    <v-progress-circular color="grey"
                                                                         indeterminate></v-progress-circular>
                                                </v-row>
                                            </template>
                                        </v-img>
                                    </v-row>
                                    <v-row
                                        class="fill-height flex-column"
                                        justify="space-between"
                                    >
                                        <div class="align-self-center">
                                            <v-btn
                                                @click="changeAvatar=!changeAvatar"
                                                icon
                                            >
                                                <v-icon>
                                                    edit
                                                </v-icon>
                                            </v-btn>
                                            <v-btn
                                                v-show="user.picturePath"
                                                @click="deleteAvatar"
                                                icon
                                            >
                                                <v-icon>
                                                    delete
                                                </v-icon>
                                            </v-btn>
                                        </div>
                                    </v-row>
                                    <v-file-input
                                        v-show="changeAvatar"
                                        :rules="avatar ? [rules.avatar] : []"
                                        accept="image/png, image/jpeg, image/bmp"
                                        :placeholder="$t('user.uploadImage')"
                                        prepend-icon="photo"
                                        :label="$t('user.avatar')"
                                        v-model="avatar"
                                        @change="fileChange"
                                    ></v-file-input>
                                    <v-text-field
                                        v-bind:label="$t('user.firstName')"
                                        v-model="user.firstName"
                                    ></v-text-field>

                                    <v-text-field
                                        v-bind:label="$t('user.lastName')"
                                        v-model="user.lastName"
                                    ></v-text-field>

                                    <v-text-field
                                        :rules="[rules.email, rules.required]"
                                        v-bind:label="$t('user.email')"
                                        v-model="user.email"
                                    ></v-text-field>

                                    <v-text-field
                                        :rules="[rules.phone]"
                                        v-bind:label="$t('user.phone')"
                                        v-model="user.phone"
                                    ></v-text-field>

                                    <v-text-field
                                        v-bind:label="$t('user.company')"
                                        v-model="user.specificCompanyName"
                                    ></v-text-field>

                                    <v-text-field
                                        v-bind:label="$t('user.job')"
                                        v-model="user.job"
                                    ></v-text-field>

                                    <p
                                        v-if="user.createdAt"
                                        class="mb-0"
                                    >
                                        {{$t('user.createdAtSentence')}}
                                        {{user.createdAt | formatDate}}
                                    </p>

                                    <v-row justify="center" v-if="isAdmin">
                                        <v-switch
                                            class="ma-4"
                                            v-bind:label="$t('user.active')"
                                            v-model="user.activatedAt"
                                        ></v-switch>
                                    </v-row>
                                </v-form>
                            </v-col>
                        </v-row>
                    </v-container>
                </v-card-text>

                <v-card-actions>
                    <v-btn
                        v-if="isAdmin && !user.isAdmin"
                        @click="deleteUser"
                        color="error"
                    >{{$t('actions.delete')}}
                    </v-btn>
                    <v-spacer></v-spacer>
                    <v-btn
                        @click="reset"
                        color="white"
                        text
                    >
                        {{$t('actions.cancel')}}
                    </v-btn>
                    <v-btn
                        v-if="valid"
                        :loading="loading"
                        @click="save"
                        color="warning"
                    >
                        {{$t('actions.save')}}
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </v-row>
</template>
<script lang="ts">
import {Component, Prop, Vue} from "vue-property-decorator";
import {formRules} from "@/utils/formRules";
import {getSrc, removeVuetifyFileInputBug} from "@/utils/misc";
import {Getter} from "vuex-class";

@Component({})
export default class EditUser extends Vue {
    @Prop({default: {}})
    public user: any;

    @Prop({default: false})
    public canEditProfile: boolean;

    @Prop({default: false})
    public isMobile: boolean;

    @Prop({default: null})
    public defaultUserAvatar: any;

    @Getter private isAdmin: boolean;

    private getSrc: (picturePath: string) => string = getSrc;
    private removeVuetifyFileInputBug: (document: any) => void = removeVuetifyFileInputBug;
    private editUserDialog: boolean = false;
    private valid: boolean = true;
    private avatar: any = null;
    private uploadedImageSrc: any = null;
    private uploadFile: boolean = false;
    private changeAvatar: boolean = false;
    private deleteFile: boolean = false;
    private loading: boolean = false;
    private rules: object = formRules;

    private mounted(): void {
        this.reset();
    }

    private beforeUpdate(): void {
        this.removeVuetifyFileInputBug(document);
    }

    private reset() {
        this.avatar = null;
        if (this.avatar && this.uploadFile) {
            this.user.picturePath = this.uploadedImageSrc;
        }
        this.avatar = null;
        this.deleteFile = false;
        this.uploadFile = false;
        this.editUserDialog = false;
    }

    private fileChange() {
        if (this.avatar) {
            const fr = new FileReader();
            fr.readAsDataURL(this.avatar);
            fr.addEventListener("load", () => {
                this.uploadedImageSrc = fr.result;
            });
            this.uploadFile = true;
            this.deleteFile = false;
        } else {
            this.uploadedImageSrc = null;
        }
    }

    private save() {
        this.loading = true;
        let filePromise: Promise<any> = Promise.resolve();
        if (this.uploadFile) {
            this.user.picturePath = true;
            const formData = new FormData();
            formData.append("file", this.avatar);
            formData.append("id", this.user.id);
            formData.append("fileType", "profile-picture");
            filePromise = this.$store.dispatch("files/upload", {formData});
        } else if (this.deleteFile) {
            this.user.picturePath = false;
            filePromise = this.$store.dispatch("files/delete", {
                userId: this.user.id,
                fileType: "profile-picture",
            });
        } else {
            delete this.user.picturePath;
        }
        Promise.all([
            filePromise,
            this.$store.dispatch("users/updateUser", {
                id: this.$route.params.id,
                user: this.user,
            }),
        ]).then((res) => {
            this.$emit("user-updated");
            this.reset();
            this.loading = false;
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("actions.saved"),
            });
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private deleteUser() {
        if (confirm(this.$t("user.deleteConfirmation").toString())) {
            this.$store.dispatch("users/deleteUserById", {id: this.user.id})
            .then((res) => {
                this.reset();
            });
        }
    }

    private deleteAvatar() {
        this.avatar = null;
        this.uploadedImageSrc = null;
        this.user.picturePath = false;
        this.deleteFile = true;
        this.uploadFile = false;
    }
}
</script>