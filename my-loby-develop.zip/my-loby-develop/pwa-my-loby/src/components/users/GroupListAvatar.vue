<template>
    <div :style="canDelete ? 'margin-top:10px' : ''">
        <v-tooltip bottom v-for="(group, i) in groups.slice(0,5)" :key="i">
            <template v-slot:activator="{ on }">
                <v-btn
                    v-if="group.type === 'user' && !group.Users[0].isDemo && !canDelete"
                    :class="canDelete ? 'mr-2': 'mr-1'"
                    :to="{ name: 'user' , params: { id: group.Users[0].id } }"
                    color="transparent"
                    icon
                >
                    <v-avatar v-on="on" color="indigo" size="36">
                        <span class="white--text">{{group.Users[0].initials}}</span>
                    </v-avatar>
                </v-btn>
                <v-badge
                    :color="canDelete ? 'grey' : null"
                    content="x"
                    icon="mdi-lock"
                    :bordered="canDelete"
                    overlap
                    left
                    @click.native="removeGroup(group)"
                    v-else-if="canDelete || group.type !== 'user' || !group.type || group.Users[0].isDemo"
                >
                    <v-avatar
                        :class="canDelete ? 'mr-2': 'mr-1'"
                        v-on="on"
                        color="indigo"
                        size="36"
                    >
                        <i class="icon-picto_mes-contacts white--text"></i>
                    </v-avatar>
                </v-badge>
            </template>
            <span v-if="!group.type">{{group.email}}</span>
            <span v-else-if="group.type === 'user'">{{group.Users[0].displayName}}</span>
            <span v-else>{{group.name}}</span>
        </v-tooltip>
        <span v-if="groups.length > 5">+{{groups.length-5}}</span>
    </div>
</template>
<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
@Component({})
export default class GroupListAvatar extends Vue {
    @Prop({ default: [] })
    public groups: any;

    @Prop({default: null})
    public customDelete: (group) => void;

    @Prop({default: false})
    public canDelete: boolean;

    private removeGroup(group) {
        if (this.customDelete) {
            this.customDelete(group);
        }
    }
}
</script>