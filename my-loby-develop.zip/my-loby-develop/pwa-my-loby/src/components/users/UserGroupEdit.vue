<template>
    <v-dialog
        max-width="910px"
        v-model="displayDialog"
        persistent>
        <v-card>
            <v-card-title>
                <div class="contain_picto">
                    <i class="icon-picto_mes-contacts"></i>
                </div>
                <span class="headline">{{$t("userGroup.edit.title")}}</span>
            </v-card-title>
            <v-card-text >
                <v-container v-if="group && selectedUsers">
                    <v-row justify="center">
                        <v-col>
                            <v-row>
                                <v-text-field
                                    readonly
                                    v-bind:label="$t('userGroup.name')"
                                    v-model="group.name"
                                ></v-text-field>
                            </v-row>
                            <v-row>
                                <v-text-field
                                    readonly
                                    v-bind:label="$t('userGroup.description')"
                                    v-model="group.description"
                                ></v-text-field>
                            </v-row>
                            <v-row>
                                <v-combobox
                                    :items="removeDuplicates(users, selectedUsers)"
                                    :label="$t('group.users')"
                                    multiple
                                    hide-selected
                                    chips
                                    hide-no-data
                                    deletable-chips
                                    readonly
                                    v-model="selectedUsers"
                                ></v-combobox>
                            </v-row>
                            <v-row>
                            </v-row>
                        </v-col>
                    </v-row>
                </v-container>
            </v-card-text>
            <v-card-actions>
                <v-btn
                    color="error"
                    :loading="loadingDelete"
                    @click="deleteUserGroup"
                >
                    {{$t("actions.delete")}}
                </v-btn>
                <v-spacer></v-spacer>
                <v-btn
                    @click="closeEdit"
                    color="white"
                    text
                >
                    {{$t("actions.close")}}
                </v-btn>
                <v-btn
                    color="warning"
                    hidden
                    @click="updateUserGroup"
                >
                    {{$t("actions.save")}}
                </v-btn>
            </v-card-actions>
        </v-card>
    </v-dialog>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from "vue-property-decorator";
import {Getter} from "vuex-class";

@Component
export default class UserGroupEdit extends Vue {
    @Prop({})
    public group: {
        id: number,
        Users: any[],
    };

    @Prop({ default: false })
    public displayDialog: boolean;

    @Getter private isMaster: (type?: string) => boolean;
    @Getter private currentUser: any;

    private selectedUsers: any[] = [];
    private users: any[] = [];
    private loadingDelete: boolean = false;

    private mounted(): void {
        this.selectedUsers = this.selectableUsers(this.group.Users);
    }

    private updateUserGroup() {
        // TODO
    }

    private deleteUserGroup(): void {
        this.loadingDelete = true;
        if (confirm(this.$t("userGroup.deleteConfirmation").toString())) {
            this.$store.dispatch("groups/deleteById", {id: this.group.id})
                .then((res) => {
                    this.loadingDelete = false;
                    this.$emit("close");
                    this.$emit("reset");
                });
        } else {
            this.loadingDelete = false;
        }
    }

    private selectableUsers(users: any[]): any[] {
        return users?.map((user: any) => ({ text: user.displayName, value: user, ...user }));
    }

    private removeDuplicates(completeList, duplicates): any[] {
        return completeList.filter((item: any) =>
            !duplicates.map((elem: any) => elem?.id)?.includes(item?.id));
    }

    private closeEdit(): void {
        this.selectedUsers = null;
        this.$emit("close");
    }
}
</script>
