<template>
  <div v-if="users">
    <v-tooltip bottom v-for="(user, i) in users.slice(0,5)" :key="i">
      <template v-slot:activator="{ on }">
        <v-btn
          v-if="user.id && !user.isDemo"
          :to="{ name: 'user' , params: { id: user.id } }"
          color="transparent"
          icon
          style="margin-right: 5px"
        >
          <v-avatar v-on="on" :color="user.color" size="36">
              <span v-if="!user.picturePath" class="white--text">{{user.initials ? user.initials : "" }}</span>
              <img v-else :src="getSrc(user.picturePath)" />
          </v-avatar>
        </v-btn>
          <span  v-else style="margin-right: 5px">
               <v-avatar v-on="on" :color="user.color || 'indigo'" size="36">
                  <span class="white--text">{{user.initials ? user.initials : "" }}</span>
               </v-avatar>
          </span>
      </template>
      <span v-if="user.id && !user.isDemo">{{user.displayName}}</span>
      <span v-else>{{user.email}}</span>
    </v-tooltip>
    <v-avatar v-if="users.length > 5">+{{users.length-5}}</v-avatar>
  </div>
</template>
<script lang="ts">
import { Vue, Component, Prop } from "vue-property-decorator";
import {getSrc} from "@/utils/misc";
@Component({})
export default class UserListAvatar extends Vue {
  @Prop({ default: null })
  public users: any;

  private getSrc: (string) => string = getSrc;
}
</script>