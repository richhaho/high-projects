<template>
    <v-container fluid>
        <v-row class="folders_row groups_row">
            <v-col v-if="totalGroups === 0 && !loading">
                <p class="text-center"><strong>{{$t('title.noData')}}</strong></p>
            </v-col>
            <v-col v-else-if="!!totalGroups" :sm="4" :lg="3" :cols="12" :md="6" v-for="group in usersGroups" :key="group.id">
                <div class="article" @click="selectGroup(group)" :class="{'checked': checkIfSelected(group)}">
                    <div class="resume">
                        <div class="actions">
                            <a></a>
                            <a
                                @click="editGroup(group)"
                                title="Actions"
                                href="#"
                            >
                                <i class="icon-picto_menu"></i>
                            </a>
                        </div>
                        <!-- /.actions -->
                        <div><i class="icon-picto_dossier"></i></div>
                        <ul class="images_members">
                            <li v-for="user in group.Users">
                                <img v-if="user.picturePath" :src="getSrc(user.picturePath)" class="img-profil">
                                <img src="../../assets/images/defaultAvatarSmall.png" class="img-profil image-background">
                            </li>
                        </ul>
                        <p class="titre">{{group.name}} <strong>({{group.Users.length}})</strong></p>
                    </div>
                    <!-- /.resume -->
                    <!-- /.tags -->
                </div>
                <!-- /.article -->
            </v-col>
            <v-col v-else>
                <div class="text-center">
                    <v-progress-circular
                        indeterminate
                        color="#0c0733"
                    ></v-progress-circular>
                </div>
            </v-col>
        </v-row>
    </v-container>
</template>
<script lang="ts">
import {Component, Prop, Vue} from "vue-property-decorator";
import {getSrc} from "@/utils/misc";

@Component({})
export default class UsersMosaicView extends Vue {
    @Prop({default: []})
    public selectedGroups: any;

    @Prop({default: false})
    public loading: boolean;

    @Prop({default: []})
    public usersGroups: any;

    private getSrc: (string) => string = getSrc;

    get totalGroups() {
        return this.usersGroups.length;
    }

    private selectGroup(group) {
        this.$emit("select-group", group);
    }

    private editGroup(group) {
        this.$emit("edit-group", group);
    }

    private checkIfSelected(group) {
        return Boolean(this.selectedGroups.find((user) => user.id === group.id));
    }
}
</script>