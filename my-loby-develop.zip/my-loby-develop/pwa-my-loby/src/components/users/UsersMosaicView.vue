<template>
        <v-row class="articles_row">
            <v-col v-if="totalUsers === 0 && !loading">
                <p class="text-center mt-6"><strong>{{$t('title.noData')}}</strong></p>
            </v-col>
            <v-col v-else-if="!!totalUsers" :sm="4" :lg="3" :md="6" v-for="user in users" :key="user.id">
                <div class="article" @click.stop="selectContact(user)"
                     :class="{'checked': checkIfSelected(user)}">
                    <div class="image">
                        <img v-if="user.picturePath" :src="getSrc(user.picturePath)" height="70" width="70" alt="">
                        <img v-else src="../../assets/images/defaultAvatar.png" height="70" width="70" alt="">
                    </div>
                    <div class="resume">
                        <div class="actions">
                            <p-check class="p-default p-curve mt-2 p-bigger"
                                     :checked="checkIfSelected(user)"
                                     @click.stop="selectContact(user)" color="primary"></p-check>
                            <a href="#" title="Actions"><i class="icon-picto_menu"></i></a>
                        </div>
                        <!-- /.actions -->
                        <div class="infos">
                            <h5>{{user.displayName}}</h5>
                            <p class="subtitle-1 mb-0">{{user.specificCompanyName}}</p>
                            <span>{{user.job}}</span>
                        </div>
                        <!-- /.infos -->
                    </div>
                    <!-- /.resume -->
                    <div class="contacts mb-3">
                        <a :href="`tel:${user.phone}`" v-if="user.phone">
                            <i class="icon-picto_telephone"></i> {{user.phone}}
                        </a>
                        <a :href="`mailto:${user.email}`" v-if="user.email">
                            <i class="icon-picto_courrier"></i>{{user.email}}
                        </a>
                        <a href="#">
                            <i class="icon-picto_cle-partagees"></i> {{user.KeyHolding.length}}
                        </a>
                    </div>
                    <!-- /.contacts -->
                    <!-- /.tags -->
                </div>
                <!-- /.article -->
            </v-col>
            <v-col v-else>
                <div class="text-center">
                    <v-progress-circular
                        indeterminate
                        color="#0c0733"
                    ></v-progress-circular>
                </div>
            </v-col>
        </v-row>
</template>
<script lang="ts">
import {Component, Prop, Vue} from "vue-property-decorator";
import {getSrc} from "@/utils/misc";

@Component({})
export default class UsersMosaicView extends Vue {
    @Prop({default: []})
    public selectedUsers: any;

    @Prop({default: false})
    public loading: boolean;

    @Prop({default: []})
    public users: any;

    private getSrc: (string) => string = getSrc;

    get totalUsers() {
        return this.users.length;
    }

    private selectContact(contact) {
        this.$emit("select-contact", contact);
    }

    private checkIfSelected(contact) {
        return Boolean(this.selectedUsers.find((user) => user.id === contact.id));
    }
}
</script>