import Vue from "vue";
import i18n from "@/plugins/i18n";

Vue.filter("formatDate", (value: string) => {
  if (value) {
    return new Date(value).toLocaleString(i18n.locale);
  }
});

Vue.filter("formatShortDate", (value: string) => {
  if (value) {
    const options = {year: "numeric", month: "numeric", day: "numeric"};
    return new Date(value).toLocaleString(i18n.locale, options);
  }
});

Vue.filter("formatAnniversaryDate", (value: string) => {
  if (value) {
    const options = {year: "numeric", month: "long", day: "numeric"};
    return new Date(value).toLocaleString(i18n.locale, options);
  }
});

Vue.filter("formatDateDay", (value: string) => {
  if (value) {
    return new Date(value).toLocaleString(i18n.locale).split(" ")[0].replace(
      ",", "");
  }
});

Vue.filter("formatDateHour", (value: string) => {
  if (value) {
    const options: any = {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "numeric",
      minute: "2-digit",
    };
    return new Date(value).toLocaleString(i18n.locale, options);
  }
});
