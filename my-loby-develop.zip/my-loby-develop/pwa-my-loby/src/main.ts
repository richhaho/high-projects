import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store/index";
import i18n from "./plugins/i18n";
import "./filters";
import "./registerServiceWorker";
import vuetify from "./plugins/vuetify";
import "@babel/polyfill";
import PrettyCheckbox from "pretty-checkbox-vue";
import "roboto-fontface/css/roboto/roboto-fontface.css";
import "material-design-icons-iconfont/dist/material-design-icons.css";
import "./assets/scss/main.scss";
// @ts-ignore
import VueCountdownTimer from "vuejs-countdown-timer";

Vue.config.productionTip = false;
Vue.use(PrettyCheckbox);
Vue.use(VueCountdownTimer);
store.commit("setBaseURL", process.env.VUE_APP_API_ENDPOINT);
/* tslint:disable:no-console */
console.log(process.env);

new Vue({
  i18n,
  router,
  store,
  vuetify,
  render: (h) => h(App),
}).$mount("#app");
