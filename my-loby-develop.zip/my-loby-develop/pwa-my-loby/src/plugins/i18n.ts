import Vue from "vue";
import VueI18n from "vue-i18n";

Vue.use(VueI18n);

function loadLocaleTranslations() {
  const locales = require.context("../locales", true, /[A-Za-z0-9-_,\s]+\.json$/i);
  const messages = {};
  locales.keys().forEach((key) => {
    const matched = key.match(/([A-Za-z0-9-_]+)\./i);
    if (matched && matched.length > 1) {
      messages[matched[1]] = locales(key);
    }
  });
  return messages;
}

const BROWSER_LANG = window.navigator.language ? window.navigator.language.slice(0, 2) : null;
const DEFAULT_LANG = "fr";

export default new VueI18n({
  locale: BROWSER_LANG || DEFAULT_LANG,
  fallbackLocale: DEFAULT_LANG,
  messages: loadLocaleTranslations(),
  silentFallbackWarn: true,
});
