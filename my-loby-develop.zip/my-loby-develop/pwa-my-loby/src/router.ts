/* tslint:disable:no-console */
import Vue from "vue";
import Router, {Route} from "vue-router";
import Store from "@/store/index";
import axiosInstance from "@/utils/axiosInstance";

Vue.use(Router);

const router = new Router({
  mode: "history",
  base: process.env.BASE_URL,
  routes: [
    {
      path: "/",
      name: "home",
      redirect: () => {
        if (Store?.getters?.isInsuranceRef || Store?.getters?.isLobyRef) {
          return {name: "relays"};
        } else {
          return {name: "keys"};
        }
      },
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/redirect/:token",
      beforeEnter: async (to, from, next) => {
        const token = to?.params?.token;
        return Store.dispatch("shortUrls/getShortUrlObject", {token})
          .then((res) => {
            return router.replace({ path: res.url })
              .catch((err) => console.log(err));
          })
          .catch((err) => {
            return router.replace({ name: "notFound" });
          });
      },
    },
    {
      path: "/index.html",
      name: "home_index_html", // having this as home, was a raising a warning duplicate route name
      redirect: {name: "keys"},
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/keys",
      name: "keys",
      components:  {
        default : () => import(/* webpackChunkName: "DESKTOP_KEYS" */"./views/front-office/keys.vue"),
        mobile: () => import(/* webpackChunkName: "MOBILE_KEYS" */"./views/mobile/KeysMobile.vue"),
      },
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/keys/:id",
      name: "key",
      components:  {
        default : () => import(/* webpackChunkName: "DESKTOP_KEYS" */"./views/front-office/Key.vue"),
        mobile: () => import(/* webpackChunkName: "MOBILE_KEYS" */"./views/mobile/KeyMobile.vue"),
      },
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/relays",
      name: "relays",
      components: {
        default: () => import(/* webpackChunkName: "DESKTOP_RELAYS" */"./views/front-office/Relays.vue"),
        mobile: () => import(/* webpackChunkName: "MOBILE_RELAYS" */"./views/mobile/RelaysMobile.vue"),
      },
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/contacts",
      name: "contacts",
      components: {
        default: () => import(/* webpackChunkName: "DESKTOP_CONTACTS" */"./views/front-office/Users.vue"),
        mobile: () => import(/* webpackChunkName: "DESKTOP_CONTACTS" */"./views/mobile/UsersMobile.vue"),
      },
      meta: {
        isUser : true,
      },
    },
    {
      path: "/contacts/:id",
      name: "user",
      components: {
        default: () => import(/* webpackChunkName: "DESKTOP_CONTACT" */ "./views/front-office/User.vue"),
        mobile: () => import(/* webpackChunkName: "MOBILE_CONTACT" */ "./views/mobile/UserMobile.vue"),
      },
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/general-terms",
      name: "general-terms",
      components: {
        default: () => import(/* webpackChunkName: "GENERAL_TERMS" */ "./views/GeneralTerms.vue"),
        mobile: () => import(/* webpackChunkName: "GENERAL_TERMS" */ "./views/GeneralTerms.vue"),
      },
    },
    {
      path: "/register",
      name: "register",
      meta: {requiresLogout: true },
      components: {
        default: () => import(/* webpackChunkName: "register" */ "./views/Register.vue"),
        mobile: () => import(/* webpackChunkName: "register" */ "./views/Register.vue"),
      },
    },
    {
      path: "/relays-map",
      name: "relays-map",
      components: {
        default: () => import(/* webpackChunkName: "DESKTOP_RELAY_MAP" */"./views/front-office/RelaysMap.vue"),
        mobile: () => import(/* webpackChunkName: "MOBILE_RELAYS" */"./views/mobile/RelaysMobile.vue"),
      },
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/register-classic",
      name: "register-classic",
      meta: {
        requiresLogout: true,
      },
      components: {
        default:  () => import(/* webpackChunkName: "registerClassic" */ "./views/RegisterClassic.vue"),
        mobile:  () => import(/* webpackChunkName: "registerClassic" */ "./views/RegisterClassic.vue"),
      },
    },
    {
      path: "/login",
      name: "login",
      meta: {
        requiresLogout: true,
      },
      components: {
        default: () => import(/* webpackChunkName: "login" */"./views/login.vue"),
        mobile: () => import(/* webpackChunkName: "login" */"./views/login.vue"),
      },
    },
    {
      path: "/login/:token",
      name: "login-without-account",
      meta: {
        requiresLogout: true,
      },
      components: {
        default: () => import(/* webpackChunkName: "DESKTOP_LOGIN_TOKEN" */"./views/login.vue"),
        mobile: () => import(/* webpackChunkName: "MOBILE_LOGIN_TOKEN" */"./views/login.vue"),
      },
    },
    {
      path: "/my-profile",
      name: "my-profile",
      component: () => import(/* webpackChunkName: "my-profile" */"./views/login.vue"),
      meta: {
        isUser : true,
      },
    },
    {
      path: "/keys/import",
      name: "import-keys-preview",
      component: () => import("./views/b2b/import/PreviewKeys.vue"),
      meta: {
        isUser : true,
      },
    },
    {
      path: "/keys/import/key-locations",
      name: "key-locations",
      component: () => import("./views/b2b/import/KeyLocations.vue"),
      meta: {
        isUser : true,
      },
    },
    {
      path: "/keys/:keyid/give-hand-to-hand/:token",
      name: "key-hand-to-hand-scan",
      components: {
        default: () => import(/* webpackChunkName: "HAND_TO_HAND_SCAN" */"./views/front-office/HandToHand.vue"),
        mobile: () => import(/* webpackChunkName: "HAND_TO_HAND_SCAN" */"./views/front-office/HandToHand.vue"),
      },
      meta: {
        requiresAuth: true,
      },
    },
    {
      path: "/management",
      name: "management",
      component: () => import("./views/front-office/Users.vue"),
      meta: {
        isUser : true,
      },
    },
    {
      path: "/users/import",
      name: "import-users-preview",
      component: () => import("./views/b2b/import/PreviewUsers.vue"),
      meta: {
        isUser : true,
      },
    },
    {
      path: "/logs",
      name: "logs",
      component: () => import("./views/back-office/logs.vue"),
      meta: {
        isUser : true,
      },
    },
    // Form to create a Relay (with an owner)
    //  -> Create RELAY prospect and send REGISTER REQUEST mail to admin
    {
      path: "/prospect-relay",
      name: "prospect-relay",
      components: {
        default: () => import(/* webpackChunkName: "prospect1" */ "./views/Prospect.vue"),
        mobile: () => import(/* webpackChunkName: "prospect1" */ "./views/Prospect.vue"),
      },
      meta: {
        requiresLogout: true,
      },
    },
    // Form to get further informations about MyLoby
    //  -> Create INFO prospect and send INFO REQUEST mail to admin
    /*
    {
      path: "/prospect-info",
      name: "prospect-info",
      component: () => import("./views/Prospect.vue"),
      meta: {
        requiresLogout: true,
      },
    },
    */
    // Form to create a Company (with a master)
    //  -> Create COMPANY prospect
    {
      path: "/prospect-company",
      name: "prospect-company",
      components: {
        default: () => import(/* webpackChunkName: "prospect2" */ "./views/Prospect.vue"),
        mobile: () => import(/* webpackChunkName: "prospect2" */ "./views/Prospect.vue"),
      },
      meta: {
        requiresLogout: true,
      },
    },
    {
      path: "/relay/:id",
      name: "relay",
      components: {
        default: () => import(/* webpackChunkName: "DESKTOP_RELAY" */"./views/front-office/Relay.vue"),
        mobile: () => import(/* webpackChunkName: "MOBILE_RELAY" */"./views/mobile/RelayMobile.vue"),
      },
    },
    {
      path: "/relays/transactions",
      name: "relaysTransactions",
      component: () => import(/* webpackChunkName: "RELAY_TRANSACTIONS" */"./views/front-office/RelayTransactions.vue"),
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/relays/:id/invoices",
      name: "relayInvoices",
      component: () => import(/* webpackChunkName: "prospect2" */ "./views/front-office/Invoices.vue"),
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/companies/:id/invoices",
      name: "companyInvoices",
      component: () => import(/* webpackChunkName: "prospect2" */ "./views/front-office/Invoices.vue"),
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/payment",
      name: "/payment",
      component: () => import(/* webpackChunkName: "prospect2" */ "./views/front-office/Payment.vue"),
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/payment-method",
      name: "paymentMethod",
      components: {
        default: () => import(/* webpackChunkName: "prospect2" */ "./views/front-office/PaymentMethod.vue"),
        mobile: () => import(/* webpackChunkName: "prospect2" */ "./views/front-office/PaymentMethod.vue"),
      },
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/billing-activity",
      name: "billingActivity",
      component: () => import(/* webpackChunkName: "BILLING_ACTIVITY" */ "./views/front-office/BillingActivity.vue"),
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/planning",
      name: "planning",
      components: {
        default: () => import(/* webpackChunkName: "PLANNING" */ "./views/front-office/Planning.vue"),
        mobile: () => import(/* webpackChunkName: "MOBILE_PLANNING" */"./views/mobile/PlanningMobile.vue"),
      },
      meta: {
        requiresAuth : true,
      },
    },
    {
      path: "/admin",
      meta: {
        isAdmin: true,
      },
      component: () => import(/* webpackChunkName: "bo" */"./views/back-office/AdminWrapper.vue"),
      children: [
        {
          path: "",
          name: "admin",
          redirect: {name: "admin-users"},
          meta: {  isAdmin : true },
        },
        {
          path: "relays",
          name: "admin-relays",
          component: () => import(/* webpackChunkName: "relays" */"./views/front-office/Relays.vue"),
        },
        {
          path: "companies",
          name: "companies",
          component: () => import(/* webpackChunkName: "boCompanies" */"./views/back-office/Companies.vue"),
        },
        // Edit a company
        {
          path: "companies/:id",
          name: "company-edit",
          component: () => import(/* webpackChunkName: "boCompany" */"./views/back-office/Company.vue"),
        },
        {
          path: "users",
          name: "admin-users",
          component: () => import(/* webpackChunkName: "boUsers" */"./views/back-office/users.vue"),
        },
        {
          path: "relay",
          name: "admin-create-relay",
          component: () => import(/* webpackChunkName: "boRelay" */"./views/back-office/RelayCreate.vue"),
        },
        {
          path: "relay/:id",
          name: "admin-relay",
          component: () => import(/* webpackChunkName: "boRelay" */"./views/front-office/Relay.vue"),
        },
        // See the list of all prospects (INFO, RELAY, COMPANY)
        {
          path: "prospects",
          name: "prospects",
          component: () => import(/* webpackChunkName: "boProspects" */ "./views/back-office/prospects.vue"),
          meta: {
            isAdmin : true,
          },
        },
        // Edit a prospect
        {
          path: "prospects/:id",
          name: "prospect",
          component: () => import(/* webpackChunkName: "boProspect" */"./views/Prospect.vue"),
          meta: {
            isAdmin : true,
          },
        },
        {
          path: "logs",
          name: "admin-logs",
          component: () => import(/* webpackChunkName: "boLogs" */"./views/back-office/logs.vue"),
        },
        {
          path: "planning",
          name: "admin-planning",
          components: {
            default: () => import(/* webpackChunkName: "PLANNING" */ "./views/front-office/Planning.vue"),
            mobile: () => import(/* webpackChunkName: "MOBILE_PLANNING" */"./views/mobile/PlanningMobile.vue"),
          },
        },
      ],
    },
    {
      path: "/email/validate/:token",
      name: "email-validate",
      meta: {
        requiresLogout: true,
      },
      components:  {
        default: () => import(/* webpackChunkName: "accountValidate" */"./views/AccountValidation.vue"),
        mobile: () => import(/* webpackChunkName: "accountValidate" */"./views/AccountValidation.vue"),
      },
    },
    {
      path: "/email/password/:token",
      name: "email-password",
      meta: {
        requiresLogout: true,
      },
      components:  {
        default: () => import(/* webpackChunkName: "password" */"./views/Password.vue"),
        mobile: () => import(/* webpackChunkName: "password" */"./views/Password.vue"),
      },
    },
    {
      path: "/*",
      name: "notFound",
      components:  {
        default : () => import(/* webpackChunkName: "NOT_FOUND" */"./views/notFound.vue"),
        mobile: () => import(/* webpackChunkName: "NOT_FOUND" */"./views/notFound.vue"),
      },
    },
  ],
});

// Middleware to get current user
router.beforeEach((to: Route, from: Route, next: any) => {

  const nextFn = () => {
    Store.commit("updateSearch", "");
    if (to.matched.some((record) => record.meta.requiresAuth)) {
      if (Store?.state?.currentUser) {
        next();
      } else {
        next({name: "login"});
      }
    } else if (to.matched.some((record) => record.meta.isUser)) {
      if (!Store?.state?.currentUser) {
        next({name: "login"});
      } else if (!Store?.state?.currentUser?.isDemo ) {
        next();
      } else {
        next({name: "keys"});
      }
    } else if (to.matched.some((record) => record.meta.isMaster)) {
      // User should be master
      if (Store?.state?.currentUser?.masterOf?.length || Store?.state?.currentUser?.isAdmin) {
        next();
      } else {
        next({name: "home"});
      }
    } else if (to.matched.some((record) => record.meta.isAdmin)) {
      // User should be admin
      if (Store?.state?.currentUser?.isAdmin) {
        next();
      } else {
        next({name: "home"});
      }
    } else if (to.matched.some((record) => record.meta.requiresLogout)) {
      if (!Store?.state?.currentUser) {
        next();
      } else {
        next({name: "home"});
      }
    } else {
      next();
    }
  };
  if (Store?.state?.currentUser?.id) {
    nextFn();
  } else if (to.matched.some((record) => record.name === "redirect")) {
    nextFn();
  } else {
    axiosInstance.get("api/users/me").then((response) => {
      Store.commit("currentUser", response.data);
      nextFn();
    }).catch(() => {
      Store.commit("currentUser", null);
      nextFn();
    });
  }
});

export default router;
