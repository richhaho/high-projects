import Vue from "vue";
import Vuex from "vuex";
import files from "@/store/modules/files";
import lang from "@/store/modules/lang";
import users from "@/store/modules/users";
import prospects from "@/store/modules/prospects";
import alerts from "@/store/modules/alerts";
import logs from "@/store/modules/logs";
import auth from "@/store/modules/auth";
import token from "@/store/modules/token";
import relays from "@/store/modules/relays";
import boxes from "@/store/modules/boxes";
import keys from "@/store/modules/keys";
import locations from "@/store/modules/locations";
import groups from "@/store/modules/groups";
import tags from "@/store/modules/tags";
import companies from "@/store/modules/companies";
import nominatim from "@/store/modules/nominatim";
import plans from "@/store/modules/plans";
import subscriptions from "@/store/modules/subscriptions";
import invoices from "@/store/modules/invoices";
import payments from "@/store/modules/payments";
import paymentMethod from "@/store/modules/paymentMethod";
import shortUrls from "@/store/modules/shortUrls";
import bookings from "@/store/modules/bookings";

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    currentUser: undefined,
    importedUsers: [],
    baseURL: "",
    mobileMenuOpen: false,
    searchQuery: "",
    searchBar: true,
    isMobile: false,
  },
  mutations: {
    currentUser(state, user) {
      if (user) {
        state.currentUser = user;
      } else {
        state.currentUser = undefined;
      }
    },
    importedUsers(state, users) {
      state.importedUsers = users;
    },
    setBaseURL(state, baseURL) {
      state.baseURL = baseURL;
    },
    mobileMenu(state, hide = false) {
      if (hide) {
        state.mobileMenuOpen = false;
      } else {
        state.mobileMenuOpen = !state.mobileMenuOpen;
      }
    },
    updateSearch(state, query) {
      state.searchQuery = query;
    },
    displaySearchBar(state, shouldDisplaySearchBar) {
      state.searchBar = shouldDisplaySearchBar;
    },
    dispatchIsMobile(state, isMobile) {
      state.isMobile = isMobile;
    },
  },
  getters: {
    currentUser: (state): any => state?.currentUser,
    isAdmin: (state): boolean => state?.currentUser?.isAdmin,
    isDemo: (state): boolean => state?.currentUser?.isDemo,
    isB2B: (state): boolean => (state?.currentUser?.company?.type === "B2B"),
    isMaster: (state): (type?: string) => boolean => (type?: string): boolean => type
      ? state?.currentUser?.masterOf?.some((companies) => companies.type === type)
      : !!state?.currentUser?.masterOf?.length,
    isMobileMenuOpen: (state): boolean => state?.mobileMenuOpen,
    isInsuranceRef: (state): boolean => state.currentUser?.Relays?.some((r) => r.type === "LONG_TERM"),
    isAgencyRef: (state): boolean => state.currentUser?.Relays?.some((r) => r.type === "AGENCY"),
    isLobyRef: (state): boolean => state.currentUser?.Relays?.some((r) => r.type === "FLOW"),
    isDisplayed: (state): boolean => state?.searchBar,
    getSearchQuery: (state): string => state?.searchQuery,
    isMobile: (state): boolean => state.isMobile,
  },
  actions: {
    toggleMobileMenu({ commit }) {
      commit("mobileMenu");
    },
  },
  modules: {
    auth,
    files,
    lang,
    users,
    prospects,
    alerts,
    logs,
    token,
    relays,
    boxes,
    keys,
    groups,
    locations,
    tags,
    companies,
    nominatim,
    plans,
    subscriptions,
    invoices,
    payments,
    paymentMethod,
    shortUrls,
    bookings,
  },
});
