const state = {
    currentAlert: {
        displayed: false,
    },

};

const getters = {};

const mutations = {
    displayAlert(state, payload) {
      this.commit("alerts/hideAlert");
      state.currentAlert.msg = payload.msg || "";
      state.currentAlert.displayed = true;
      state.currentAlert.color = "#0c0733";
      state.currentAlert.icon = payload.icon;
      state.currentAlert.iconGroup = payload.iconGroup;
      state.currentAlert.timeDisplayed = payload.timeDisplayed || 0;
    },
    displayError(state, payload) {
      this.commit("alerts/hideAlert");
      state.currentAlert.msg = payload.msg || "Something bad happened";
      state.currentAlert.displayed = true;
      state.currentAlert.color = "red darken-1";
      state.currentAlert.icon = payload.icon;
      state.currentAlert.iconGroup = payload.iconGroup;
      state.currentAlert.timeDisplayed = payload.timeDisplayed || 0;
    },
    displaySuccess(state, payload) {
        this.commit("alerts/hideAlert");
        state.currentAlert.msg = payload.msg || "Success";
        state.currentAlert.displayed = true;
        state.currentAlert.color = "green";
        state.currentAlert.icon = payload.icon;
        state.currentAlert.iconGroup = payload.iconGroup;
        state.currentAlert.timeDisplayed = payload.timeDisplayed || 0;
    },
    hideAlert(state) {
      state.currentAlert = {};
    },
};

const actions = {};

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations,
};
