import axiosInstance from "@/utils/axiosInstance";
import router from "@/router";
import store from "@/store";

const state = {};

const getters = {};

const mutations = {};

const actions = {
  login({commit}, payload: {email: string, password: string}) {
    return axiosInstance.post(`api/auth/login`, {email: payload.email, password: payload.password})
      .then(async (response) => {
        store.commit("currentUser", response.data);
        return router.push(response.data.isAdmin ? {name: "admin"} : {name: "home"});
      });
  },
  loginWithToken({commit}, payload: {token: string}) {
    const config = {
      headers: {
        Authorization: `Bearer ${payload.token}`,
      },
    };
    return axiosInstance.post(`api/auth/login/token`,  {}, config)
      .then(async (response) => {
        store.commit("currentUser", response.data);
        return router.push({name: "keys"});
      });
  },
  forgottenPasswordFn({commit}, payload: {email: string}) {
    return axiosInstance.post(`api/auth/forgotten-password`, {email: payload.email});
  },
  logout({commit}, payload: {}) {
    return axiosInstance.get(`api/auth/logout`)
      .then(async () => {
        store.commit("currentUser", null);
        return router.push({name: "login"});
      });
  },
    updatePassword({commit}, payload: {token: number, password: object}) {
        return axiosInstance.put(`api/auth/update-password`, {token: payload.token, password: payload.password})
            .then((data) => data.data);
    },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
