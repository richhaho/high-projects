import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/bookings`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  create({commit}, payload: { booking: object }) {
    return axiosInstance.post(baseUrl, {booking: payload.booking}).then((data) => data.data);
  },
  update({commit}, payload: { id: number, booking: object, alertCreator: boolean}) {
    return axiosInstance.put(
      `${baseUrl}/${payload.id}`,
      {booking: payload.booking, alertCreator: payload.alertCreator},
      ).then((data) => data.data);
  },
  delete({commit}, payload: { id: number}) {
    return axiosInstance.delete(`${baseUrl}/${payload.id}`).then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
