import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/boxes`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  getById({commit}, payload: {id: number, query: object}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}`, {params: payload.query ? payload.query : {}})
      .then((data) => data.data);
  },
  getLocations({commit}, payload: {id: number, query: object}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}/locations`, {params: payload?.query || {}})
    .then((data) => data.data);
  },
  update({commit}, payload: {id: number, box: object}) {
    return axiosInstance.put(`${baseUrl}/${payload.id}`, {box: payload.box})
      .then((data) => data.data);
  },
  remove({commit}, payload: {id?: number, idList?: number[]}) {
    return axiosInstance.delete(`${baseUrl}/${payload.id}`, { params: payload.idList })
      .then((data) => data.data);
  },
  removeList({commit}, payload: {idList?: number[]}) {
    return axiosInstance.put(`${baseUrl}/remove-boxes`, { idList: payload.idList })
      .then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
