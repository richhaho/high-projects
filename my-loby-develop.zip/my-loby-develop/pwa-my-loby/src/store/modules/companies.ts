import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/companies`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  read({commit}, payload: {query: object}) {
    return axiosInstance.get(baseUrl, {params: payload?.query})
      .then((data) => data.data);
  },
  create({commit}, payload: {company: object}) {
    return axiosInstance.post(`${baseUrl}/`, {company: payload.company})
    .then((data) => data.data);
  },
  readById({commit}, payload: {id: number, options: any}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}`, {params: payload?.options})
    .then((data) => data.data);
  },
  countKeys({commit}, payload: {id: number}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}/count-keys`)
    .then((data) => data.data);
  },
  updateById({commit}, payload: {id: number, company: object}) {
    return axiosInstance.put(`${baseUrl}/${payload.id}`, {company: payload.company})
    .then((data) => data.data);
  },
  updateSubscription({commit}, payload: {id: number, subscription: object}) {
    return axiosInstance.put(`${baseUrl}/${payload.id}/subscription`, {subscription: payload.subscription})
    .then((data) => data.data);
  },
  getSubscriptions({commit}, payload: {id: number}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}/subscriptions`)
    .then((data) => data.data);
  },
  getInvoices({commit}, payload: {id: number, query: any}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}/invoices`, {params: payload?.query})
    .then((data) => data.data);
  },
  deleteById({commit}, payload: {id: number}) {
    return axiosInstance.delete(`${baseUrl}/${payload.id}`)
    .then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
