import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/files`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  upload({commit}, payload: { formData: FormData }) {
    return axiosInstance.post(baseUrl, payload.formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((data) => data.data);
  },
  getTokenFromQrCodeFormData({commit}, payload: { formData: FormData }) {
    return axiosInstance.post("http://api.qrserver.com/v1/read-qr-code/", payload.formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((data) => data.data);
  },
  getTokenFromQrCode({commit}, payload: { base64String: any }) {
    return axiosInstance.post(baseUrl + "/qr-code", payload)
    .then((data) => data.data);
  },
  delete({commit}, payload: { userId: number, fileType: string }) {
    return axiosInstance.delete(baseUrl, {data: payload})
      .then((data) => data.data);
  },
  parseImportFile({commit}, payload: { type: string, formData: FormData }) {
    return axiosInstance.post(`${baseUrl}/import/${payload.type}`, payload.formData,
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      .then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
