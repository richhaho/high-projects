import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/groups`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  deleteById({commit}, payload: { id: number }) {
    return axiosInstance.delete(`${baseUrl}/${payload.id}`).then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
