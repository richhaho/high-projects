import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/invoices`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  read({commit}, payload: {query: object}) {
    return axiosInstance.get(baseUrl, {params: payload?.query})
    .then((data) => data.data);
  },
  create({commit}, payload: {company: object}) {
    return axiosInstance.post(`${baseUrl}/`, {company: payload.company})
    .then((data) => data.data);
  },
  readById({commit}, payload: {id: number, options: any}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}`, {params: payload?.options})
    .then((data) => data.data);
  },
  updateById({commit}, payload: {id: number, invoice: object}) {
    return axiosInstance.put(`${baseUrl}/${payload.id}`, {invoice: payload.invoice})
    .then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
