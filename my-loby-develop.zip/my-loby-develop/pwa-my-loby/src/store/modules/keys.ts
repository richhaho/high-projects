import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/keys`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  getAll({commit}, payload: { query: object }) {
    return axiosInstance.get(baseUrl, {params: payload ? payload.query : {}}).
      then((data) => data.data);
  },
  getById({commit}, payload: { id: number, options: object }) {
    return axiosInstance.get(`${baseUrl}/${payload.id}`, {params: payload.options})
      .then((data) => data.data);
  },
  create({commit}, payload: { key: object }) {
    return axiosInstance.post(baseUrl, {key: payload.key}).then((data) => data.data);
  },
  updateSubscription({commit}, payload: { keyId: number, subscription: object }) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/subscription`, payload).
    then((data) => data.data);
  },
  cancelSubscription({commit}, payload: { keyId: number }) {
    return axiosInstance.delete(`${baseUrl}/${payload.keyId}/subscription`).
    then((data) => data.data);
  },
  getStatus({commit}) {
    return axiosInstance.get(`${baseUrl}/status`)
    .then((data) => data.data);
  },
  getKeyUsers({commit}, payload: { keyId: any}) {
    return axiosInstance.get(`${baseUrl}/${payload.keyId}/users`)
      .then((data) => data.data);
  },
  drop({commit}, payload: {
    keyId: number,
    token: number,
    referentId: number,
    relayId: number,
    holderId: number,
    keyToGuest: number,
  }) {
    return axiosInstance.put(`${baseUrl}/${payload.keyId}/drop`, {
      token: payload.token,
      referentId: payload.referentId,
      relayId: payload.relayId,
      holderId: payload.holderId,
      keyToGuest: payload.keyToGuest,
    }).
    then((data) => data.data);
  },
  dropOnConnected({commit}, payload: {
    keyId: number,
    referentId: number,
    relayId: number,
    holderId: number,
    keyToGuest: number,
    acsesObjectId: number,
    acsesBookingId: number,
  }) {
    return axiosInstance.put(`${baseUrl}/${payload.keyId}/drop-on-connected`, {
      referentId: payload.referentId,
      relayId: payload.relayId,
      holderId: payload.holderId,
      keyToGuest: payload.keyToGuest,
      acsesObjectId: payload.acsesObjectId,
      acsesBookingId: payload.acsesBookingId,
    }).
    then((data) => data.data);
  },
  withdraw({commit}, payload: {
    keyId: number,
    token: number,
    referentId: number,
    estimatedEndDate: string,
    keyToGuest?: number,
    notificationType?: string,
  }) {
    return axiosInstance.put(`${baseUrl}/${payload.keyId}/withdraw`, {
      token: payload.token,
      referentId: payload.referentId,
      estimatedEndDate: payload.estimatedEndDate,
      keyToGuest: payload.keyToGuest,
      notificationType: payload.notificationType,
    }).
    then((data) => data.data);
  },
  withdrawOnConnected({commit}, payload: {
    keyId: number,
    locationId: number,
    referentId: number,
    estimatedEndDate: string,
    keyToGuest?: number,
    acsesObjectId: number,
    acsesBookingId: number,
  }) {
    return axiosInstance.put(`${baseUrl}/${payload.keyId}/withdraw-on-connected`, {
      locationId: payload.locationId,
      referentId: payload.referentId,
      estimatedEndDate: payload.estimatedEndDate,
      keyToGuest: payload.keyToGuest,
      acsesObjectId: payload.acsesObjectId,
      acsesBookingId: payload.acsesBookingId,
    }).
    then((data) => data.data);
  },
  extendKeyHolding({commit}, payload: { keyId: number, newEstimatedEndDate: string }) {
    return axiosInstance.put(`${baseUrl}/${payload.keyId}/extend-key-holding`, {
      newEstimatedEndDate: payload.newEstimatedEndDate,
    }).
    then((data) => data.data);
  },
  transit({commit}, payload: { keyId: number, sourceUserId: number, targetRelayId: number }) {
    return axiosInstance.put(`${baseUrl}/${payload.keyId}/transit`, payload).
    then((data) => data.data);
  },
  retrieve({commit}, payload: { keyId: number, userId: number }) {
    return axiosInstance.put(`${baseUrl}/${payload.keyId}/retrieve`, payload).
    then((data) => data.data);
  },
  retrieveFromTransit({commit}, payload: { keyId: number, relayId: number }) {
    return axiosInstance.put(`${baseUrl}/${payload.keyId}/retrieve-transit`, {
      relayId: payload.relayId,
    }).
    then((data) => data.data);
  },
  reportMissing({commit}, payload: { keyId: number, relayId: number }) {
    return axiosInstance.put(`${baseUrl}/${payload.keyId}/report-missing`, {
      relayId: payload.relayId,
    }).
    then((data) => data.data);
  },
  createGroup({commit}, payload: { keys: any, keyGroupCreation: object }) {
    return axiosInstance.post(baseUrl + "/group",
      {
        keys: payload.keys.map((k: any) => k.id),
        keyGroupCreation: payload.keyGroupCreation,
      }).then((data) => data.data);
  },
  editGuestAccess({commit}, payload: {key: { id: number }, access: { id: number }, keyGroup: {id: number}}) {
    const { key, access, keyGroup } = payload;
    return axiosInstance.put(`${baseUrl}/${key.id}/access/${access.id}`, { access, keyGroup })
      .then((data) => data.data);
  },
  removeGuestAccess({commit}, payload: {key: { id: number }, access: { id: number }}) {
    const { key, access } = payload;
    return axiosInstance.delete(`${baseUrl}/${key.id}/access/${access.id}`)
      .then((data) => data.data);
  },
  removeManagementAccess({commit}, payload: {key: { id: number }, management: { id: number }, keyGroup: {id: number}}) {
    const { key, management, keyGroup } = payload;
    return axiosInstance.put(`${baseUrl}/${key.id}/management/${management.id}`, { keyGroup })
      .then((data) => data.data);
  },
  updateKeyGroup({commit}, payload: {keys: object[], group: { id: number }}) {
    const { keys, group } = payload;
    return axiosInstance.put(`${baseUrl}/group/${group.id}`, { keys, group })
      .then((response) => response.data);
  },
  update({commit}, payload: { key: any , params: any}) {
    return axiosInstance.put(`${baseUrl}/${payload.key.id}`, {key: payload?.key, params: payload?.params}).
      then((data) => data.data);
  },
  import({commit}, payload: {keys: object}) {
    return axiosInstance.post(`${baseUrl}/import`, {keys: payload.keys})
      .then((data) => data.data);
  },
  deleteById({commit}, payload: { id: number }) {
    return axiosInstance.delete(`${baseUrl}/${payload.id}`).then((data) => data.data);
  },
  cancelCreation({commit}, payload: { keyId: number }) {
    return axiosInstance.put(`${baseUrl}/${payload.keyId}/cancel-creation`).then((data) => data.data);
  },
  sendSms({commit}, payload: {
    keyId: number,
    sourceUserId: number,
    targetUserId: number,
    acceptOverPrice: boolean,
  }) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/send-sms`, {
        sourceUserId: payload.sourceUserId,
        targetUserId : payload.targetUserId,
        acceptOverPrice: payload.acceptOverPrice,
    })
    .then((data) => data.data);
  },
  smsVerification({commit}, payload: {
    keyId: number,
    pin: string,
    targetUserId: number,
    acceptOverPrice: boolean,
  }) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/sms-verification`,
      {pin: payload.pin, targetUserId : payload.targetUserId, acceptOverPrice: payload.acceptOverPrice})
    .then((data) => data.data);
  },
  giveHandToHand({commit}, payload: { keyId: number, sourceUserId: number, targetUserId: number }) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/give-hand-to-hand`,
      {sourceUserId: payload.sourceUserId, targetUserId : payload.targetUserId})
    .then((data) => data.data);
  },
  receivePinHandToHand({commit}, payload: { keyId: number, targetUserId: number }) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/receive-pin-hand-to-hand`,
      {targetUserId : payload.targetUserId})
    .then((data) => data.data);
  },
  cancelHandToHand({commit}, payload: { keyId: number, sourceUserId: number, targetUserId: number }) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/cancel-hand-to-hand`,
      {})
    .then((data) => data.data);
  },
  recoverHandToHand({commit}, payload: { keyId: number, token: string}) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/recover-hand-to-hand`,
      {token: payload.token})
    .then((data) => data.data);
  },
  unblock({commit}, payload: { keyId: number}) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/unblock`)
      .then((data) => data.data);
  },
  archive({commit}, payload: { keyId: number}) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/archive`)
      .then((data) => data.data);
  },
  invitationReminder({commit}, payload: {
    keyId: number,
    guest: any,
    notificationType: string,
    acceptOverPrice: boolean,
  }) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/invitation-reminder`,
      {
        guest: payload.guest,
        notificationType: payload.notificationType,
        acceptOverPrice: payload.acceptOverPrice,
      })
      .then((data) => data.data);
  },
  giveKeyToGuest({commit}, payload: {
    keyId: number,
    sourceRelayId: number,
    targetUserId: number,
    notificationType: string,
    acceptOverPrice: boolean,
  }) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/give-key-to-guest`, {
      sourceRelayId: payload.sourceRelayId,
      targetUserId : payload.targetUserId,
      notificationType : payload.notificationType,
      acceptOverPrice : payload.acceptOverPrice,
    })
      .then((data) => data.data);
  },
  createAcses({commit}, payload: {keyId: number, site: string}) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/${payload.site}/create-acses`).
    then((data) => data.data);
  },
  lockerNotOpen({commit}, payload: {
    keyId: number,
    acsesObjectId: number,
    acsesBookingId: number,
  }) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/locker-not-open`,
      {
        acsesObjectId: payload.acsesObjectId,
        acsesBookingId: payload.acsesBookingId,
      }).then((data) => data.data);
  },
  keyNotDeposited({commit}, payload: {keyId: number, acsesObjectId: number, acsesBookingId: number}) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/not-deposited`, {
      acsesObjectId: payload.acsesObjectId,
      acsesBookingId: payload.acsesBookingId,
    }).
    then((data) => data.data);
  },
  keyIsNotInside({commit}, payload: {
    keyId: number,
    acsesObjectId: number,
    acsesBookingId: number,
  }) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/not-inside`,
      {
        acsesObjectId: payload.acsesObjectId,
        acsesBookingId: payload.acsesBookingId,
      })
      .then((data) => data.data);
  },
  keyNotWithdrawn({commit}, payload: {keyId: number, acsesObjectId: number, acsesBookingId: number}) {
    return axiosInstance.post(`${baseUrl}/${payload.keyId}/not-withdrawn`, {
      acsesObjectId: payload.acsesObjectId,
      acsesBookingId: payload.acsesBookingId,
    }).
    then((data) => data.data);
  },
  readBooking({commit}, payload: {keyId: number, bookingId: string}) {
    return axiosInstance.get(`${baseUrl}/${payload.keyId}/read-acses-booking`, {params: {
        bookingId: payload?.bookingId,
    }})
    .then((data) => data.data);
  },
  deleteBooking({commit}, payload: {keyId: number, bookingId: string}) {
    return axiosInstance.delete(`${baseUrl}/${payload.keyId}/delete-acses-booking`).
    then((data) => data.data);
  },
  resetCodeBooking({commit}, payload: {keyId: number, acsesObjectId: number, acsesBookingId: number}) {
    return axiosInstance.put(
      `${baseUrl}/${payload.keyId}/reset-code-booking`,
      {
        acsesObjectId: payload.acsesObjectId,
        acsesBookingId: payload.acsesBookingId,
      }).then((data) => data.data);
  },
  getWithdrawAcses({commit}, payload: {keyId: number}) {
    return axiosInstance.get(`${baseUrl}/${payload.keyId}/get-withdraw-acses`).
    then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
