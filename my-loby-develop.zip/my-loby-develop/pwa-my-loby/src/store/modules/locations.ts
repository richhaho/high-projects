import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/locations`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  qrCodeVerification({commit}, payload: {
    token: string,
    keyId: number,
    keyStatus: string,
    estimatedEndDate: string,
    dropFromRelay: boolean,
    giveToUserId: number,
    referentId: number,
  }) {
    return axiosInstance.get(`${baseUrl}/${payload.token}/qr-code-reader`, {
      params: {
        keyId: payload.keyId,
        keyStatus: payload.keyStatus,
        estimatedEndDate: payload.estimatedEndDate,
        dropFromRelay: payload.dropFromRelay,
        giveToUserId: payload.giveToUserId,
        referentId: payload.referentId,
      },
    }).then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
