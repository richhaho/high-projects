import axiosInstance from "@/utils/axiosInstance";

const state = {};

const getters = {};

const mutations = {};

const actions = {
  getLogs({commit}, payload: {query: object}) {
    return axiosInstance.get(`api/logs`, {params: payload?.query})
      .then((data) => data.data);
  },
  getLogsTypes({commit}, payload: {query: object}) {
    return axiosInstance.get(`api/logs/types`, {params: payload?.query})
      .then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
