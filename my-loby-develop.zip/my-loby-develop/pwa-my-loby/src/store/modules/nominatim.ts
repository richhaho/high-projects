import axios from "axios";

const state = {};

const getters = {};

const mutations = {};

const actions = {
  searchByAddressName({commit}, payload: { search: string }) {
    const countryCodes: string = [
      "fr", // France
      "it", // Italy
      "pt", // Portugal
      "de", // Germany
      "es", // Spain
      "ch", // Switzerland
      "be", // Belgium
    ].join(",");
    return axios({
      method: "get",
      url: `https://nominatim.openstreetmap.org/search?format=json&countrycodes=${countryCodes}&addressdetails=1&limit=10&q=${encodeURIComponent(
        payload.search)}`,
    }).then(function(response) {
      return response.data;
    });

  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
