import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/payment-method`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  createOne({commit}, payload: {transaction: object, subscriptionId: number, orderId: number}) {
    return axiosInstance.post(baseUrl, {
      transaction: payload.transaction,
      subscriptionId: payload.subscriptionId,
      orderId: payload.orderId,
    }).
    then((data) => data.data);
  },
  updateOne({commit}, payload: {transaction: object, paymentMethodId: number}) {
    return axiosInstance.put(`${baseUrl}/${payload.paymentMethodId}`, {
      transaction: payload.transaction,
    }).
    then((data) => data.data);
  },
  getForm({commit},  payload: {query: object}) {
    return axiosInstance.get(`${baseUrl}/form`, {params: payload?.query})
    .then((data) => data.data);
  },
  getAll({commit}, payload: { query: object }) {
    return axiosInstance.get(baseUrl, {params: payload ? payload.query : {}}).
    then((data) => data.data);
  },
  deleteById({commit}, payload: {id: number}) {
    return axiosInstance.delete(`${baseUrl}/${payload.id}`)
      .then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
