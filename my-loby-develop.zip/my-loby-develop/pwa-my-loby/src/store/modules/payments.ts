import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/payments`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  createOne({commit}, payload: { subscriptionId: number, paymentMethodId: number }) {
    return axiosInstance.post(`${baseUrl}/`, {
      subscriptionId: payload.subscriptionId,
      paymentMethodId: payload.paymentMethodId,
    }).then((data) => data.data);
  },
  getForm({commit},  payload: {query: object}) {
    return axiosInstance.get(`${baseUrl}/form`, {params: payload ? payload.query : {}})
      .then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
