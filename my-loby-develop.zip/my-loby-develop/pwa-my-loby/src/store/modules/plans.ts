import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/plans`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  read({commit}, payload: {query: object}) {
    return axiosInstance.get(baseUrl, {params: payload?.query})
    .then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
