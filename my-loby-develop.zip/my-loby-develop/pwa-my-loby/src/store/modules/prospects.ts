import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/prospects`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
    getAll({commit}, payload: { query: object }) {
        return axiosInstance.get(baseUrl, {params: payload ? payload.query : {}})
            .then((data) => data.data);
    },
    getAllMasterB2B({commit}, payload: { query: object }) {
        return axiosInstance.get(baseUrl + "/masterB2B", {params: payload ? payload.query : {}})
            .then((data) => data.data);
    },
    getById({commit}, payload: { id: number }) {
        return axiosInstance.get(`${baseUrl}/${payload.id}`)
            .then((data) => data.data);
    },
    create({commit}, payload: { prospect: object }) {
        return axiosInstance.post(baseUrl, {prospect: payload.prospect})
            .then((data) => data.data);
    },
    update({commit}, payload: {  id: number, prospect: object }) {
        return axiosInstance.put(`${baseUrl}/${payload.id}`, {prospect: payload.prospect})
            .then((data) => data.data);
    },
    validate({commit}, payload: { id: number, prospect: object }) {
        return axiosInstance.post(baseUrl + "/" + payload.id + "/validate", payload)
            .then((data) => data);
    },
    decline({commit}, payload: { id: number, prospect: object, rejectionCause: string}) {
        return axiosInstance.post(baseUrl + "/" + payload.id + "/decline", payload)
            .then((data) => data);
    },
    startValidatePeriod({commit}, payload: { id: number, prospect: object, endTestPeriod: string}) {
        return axiosInstance.post(baseUrl + "/" + payload.id + "/startValidatePeriod", payload)
            .then((data) => data);
    },
};

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations,
};
