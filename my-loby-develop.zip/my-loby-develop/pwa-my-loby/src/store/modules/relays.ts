import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/relays`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
    getList({commit}, payload: {query: object}) {
      return axiosInstance.get(`${baseUrl}/list`, {params: payload ? payload.query : {}})
        .then((data) => data.data);
    },
    getAll({commit}, payload: {query: object}) {
      return axiosInstance.get(baseUrl, {params: payload ? payload.query : {}})
            .then((data) => data.data);
    },
    getForMap({commit}, payload: any) {
      return axiosInstance.get(`${baseUrl}/map`, {params: payload}).
        then((data) => data.data);
    },
    getById({commit}, payload: {id: number}) {
        return axiosInstance.get(`${baseUrl}/${payload.id}`)
            .then((data) => data.data);
    },
    getPresetUsersById({commit}, payload: {id: number}) {
        return axiosInstance.get(`${baseUrl}/${payload.id}/presetUsers`)
            .then((data) => data.data);
    },
    getMyCode({commit}, payload: {id: number}) {
        return axiosInstance.get(`${baseUrl}/${payload.id}/my-pin-code`)
            .then((data) => data.data);
    },
    getBalance({commit}, payload: {id: number}) {
        return axiosInstance.get(`${baseUrl}/${payload.id}/balance`)
            .then((data) => data.data);
    },
    getInvoices({commit}, payload: {id: number, query: any}) {
      return axiosInstance.get(`${baseUrl}/${payload.id}/invoices`, {params: payload?.query})
      .then((data) => data.data);
    },
    getTransactions({commit}) {
      return axiosInstance.get(`${baseUrl}/transactions`)
      .then((data) => data.data);
    },
    getTransactionByKeyId({commit}, payload: {keyId: number}) {
      return axiosInstance.get(`${baseUrl}/transactions/${payload.keyId}`)
      .then((data) => data.data);
    },
    acceptTransaction({commit}, payload: {keyId: number}) {
      return axiosInstance.put(`${baseUrl}/transactions/${payload.keyId}/accept`)
      .then((data) => data.data);
    },
    declineTransaction({commit}, payload: {keyId: number}) {
      return axiosInstance.put(`${baseUrl}/transactions/${payload.keyId}/decline`)
      .then((data) => data.data);
    },
    getKeyStatsById({commit}, payload: {id: number}) {
        return axiosInstance.get(`${baseUrl}/${payload.id}/keys-stats`)
            .then((data) => data.data);
    },
    update({commit},  payload: {id: number, relay: object}) {
        return axiosInstance.put(`${baseUrl}/${payload.id}`, {relay: payload.relay})
            .then((data) => data.data);
    },
    createRelay({commit}, payload: {relay: object, user: object}) {
        return axiosInstance.post(baseUrl, {relay: payload.relay, user: payload.user})
            .then((data) => data.data);
    },
    createInvoice({commit}, payload: {id: number, invoiceData: object}) {
        return axiosInstance.post(`${baseUrl}/${payload.id}/invoices`, {invoiceData: payload.invoiceData})
            .then((data) => data.data);
    },
    addBox({commit}, payload: {relayId: number, box: object}) {
        return axiosInstance.post(`${baseUrl}/${payload.relayId}/boxes`, {box: payload.box})
            .then((data) => data.data);
    },
    removeConnectedBoxes({commit}, payload: {relayId: number}) {
      return axiosInstance.delete(`${baseUrl}/${payload.relayId}/boxes-connected`)
          .then((data) => data.data);
    },
    getBoxes({commit}, payload: {id: number}) {
        return axiosInstance.get(`${baseUrl}/${payload.id}/boxes`)
            .then((data) => data.data);
    },
    requestNewBox({commit}, payload: {relayId: number, locationsWanted: number}) {
      return axiosInstance.post(`${baseUrl}/${payload.relayId}/new-box-request`, {
        locationsWanted: payload.locationsWanted,
      }).then((data) => data.data);
    },
    requestConnectedBox({commit}, payload: {relayId: number, boxesWanted: number}) {
      return axiosInstance.post(`${baseUrl}/${payload.relayId}/connected-box-request`, {
        boxesWanted: payload.boxesWanted,
      }).then((data) => data.data);
    },
    notifyExceptionalClosure({commit}, payload: {relayId: number, exceptionalClosure: any}) {
      return axiosInstance.post(`${baseUrl}/${payload.relayId}/closure-notification`, {
        exceptionalClosure: payload.exceptionalClosure,
      }).then((data) => data.data);
    },
    pinVerification({commit}, payload: {relayId: number, pin: string}) {
        return axiosInstance.post(`${baseUrl}/${payload.relayId}/pin`, {pin: payload.pin})
            .then((data) => data.data);
    },
    pinExistance({commit}, payload: {relayId: number, pin: string}) {
      return axiosInstance.post(`${baseUrl}/${payload.relayId}/pinExistance`, {pin: payload.pin})
        .then((data) => data.data);
    },
    pinVerificationToGuest({commit}, payload: {relayId: number, pin: number, guest: any}) {
      return axiosInstance.post(`${baseUrl}/${payload.relayId}/pinVerificationToGuest`,
        {pin: payload.pin, guest: payload.guest})
      .then((data) => data.data);
    },
    reserveLocation({commit}, payload: {
      relayId: number,
      keyId?: number,
      companyId?: number,
      locationsNumber?: number,
    }) {
        return axiosInstance.put(`${baseUrl}/${payload.relayId}/reservation`, payload)
            .then((data) => data.data);
    },
    getAvailableLocations({commit}, payload: {relayId: number}) {
        return axiosInstance.get(`${baseUrl}/${payload.relayId}/locations/available`)
            .then((data) => data.data);
    },
    getAvailableReservedLocations({commit}, payload: {relayId: number, companyId: number}) {
        return axiosInstance.get(`${baseUrl}/${payload.relayId}/companies/${payload.companyId}/locations`)
            .then((data) => data.data);
    },
    getKeys({commit}, payload: {relayId: number, query: object}) {
      return axiosInstance.get(`${baseUrl}/${payload.relayId}/keys`, {params: payload?.query})
      .then((data) => data.data);
    },
    getAlertKeys({commit}, payload: {relayId: number}) {
      return axiosInstance.get(`${baseUrl}/${payload.relayId}/alert-keys`)
      .then((data) => data.data);
    },
  updateAccessStatus({commit}, payload: {relayId: number , status: boolean}) {
    return axiosInstance.put(`${baseUrl}/${payload.relayId}/changeAccessToGuests` , {status: payload.status})
      .then((data) => data.data);
  },
};

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations,
};
