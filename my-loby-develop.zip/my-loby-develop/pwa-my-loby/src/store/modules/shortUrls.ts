import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/short-urls`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  getShortUrlObject({commit}, payload: {token: string}) {
    return axiosInstance.get(`${baseUrl}/${payload.token}`)
      .then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
