import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/subscriptions`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  read({commit}, payload: {query: object}) {
    return axiosInstance.get(baseUrl, {params: payload?.query})
    .then((data) => data.data);
  },
  createCompanySubscription({commit}, payload: {subscription: object}) {
    return axiosInstance.post(`${baseUrl}/company-subscription`, {subscription: payload.subscription})
    .then((data) => data.data);
  },
  readById({commit}, payload: {id: number, options: any}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}`, {params: payload?.options})
    .then((data) => data.data);
  },
  updateById({commit}, payload: {id: number, subscription: object}) {
    return axiosInstance.put(`${baseUrl}/${payload.id}`, {subscription: payload.subscription})
    .then((data) => data.data);
  },
  deleteById({commit}, payload: {id: number}) {
    return axiosInstance.delete(`${baseUrl}/${payload.id}`)
    .then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
