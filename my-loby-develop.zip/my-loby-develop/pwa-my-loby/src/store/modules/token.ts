import axiosInstance from "@/utils/axiosInstance";

const state = {};

const getters = {};

const mutations = {};

const actions = {
    getOne({commit}, payload: {token: string}) {
        return axiosInstance.get(`api/tokens/${payload.token}`)
            .then((data) => data.data);
    },
};

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations,
};
