import axiosInstance from "@/utils/axiosInstance";

const baseUrl = `api/users`;

const state = {};

const getters = {};

const mutations = {};

const actions = {
  getUsers({commit}, payload: {query: object}) {
    return axiosInstance.get(baseUrl, {params: payload ? payload.query : {}})
      .then((data) => data.data);
  },
  getContacts({commit}, payload: {query: object}) {
    return axiosInstance.get(`${baseUrl}/contacts`, {params: payload ? payload.query : {}})
      .then((data) => data.data);
  },
  addContact({commit}, payload: {contact: object, acceptOverPrice?: boolean}) {
    return axiosInstance.post(`${baseUrl}/contacts`, payload)
      .then((data) => data.data);
  },
  deleteContacts({commit}, payload: {contactsIds: number[]}) {
    return axiosInstance.post(`${baseUrl}/delete-contacts`, {contactsIds: payload?.contactsIds})
      .then((data) => data.data);
  },
  getSubordinates({commit}, payload: {query: object}) {
    return axiosInstance.get(`${baseUrl}/subordinates`, {params: payload ? payload.query : {}})
      .then((data) => data.data);
  },
  deleteSubordinates({commit}, payload: {subordinatesIds: number[]}) {
    return axiosInstance.post(`${baseUrl}/delete-subordinates`, {subordinatesIds: payload?.subordinatesIds})
    .then((data) => data.data);
  },
  addSubordinate({commit}, payload: {subordinate: object}) {
    return axiosInstance.post(`${baseUrl}/subordinates`, {subordinate: payload?.subordinate})
    .then((data) => data.data);
  },
  getContactsAndSubordinates({commit}, payload: {id: any}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}/contacts-subordinates`)
        .then((data) => data.data);
  },
  getLateKeys({commit}, payload: {id: number}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}/keys`, {params: {late: true}})
    .then((data) => data.data);
  },
  getKeysWithUsers({commit}, payload: {id: number, query: object}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}/keys-out-of-relay`, {params: payload?.query})
      .then((data) => data.data);
  },
  getKeysOutIn({commit}, payload: {id: number, query: object}) {
    if (!payload) {
      throw new Error("Payload can not be null.");
    }
    return axiosInstance.get(`${baseUrl}/${payload.id}/keys-out-and-in`, {params: payload.query})
      .then((data) => data.data);
  },
  getMyKeys({commit}, payload: {id: number, query: object}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}/keys`, {params: payload?.query})
        .then((data) => data.data);
  },
  countMySharedKeys({commit}, payload: {id: number, query: object}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}/count-shared-keys`)
      .then((data) => data.data);
  },
  getsKeyGroups({commit}, payload: {userId: number, query: any}) {
    return axiosInstance.get(`${baseUrl}/${payload.userId}/key-groups`, {params: payload ? payload.query : {}})
      .then((data) => data.data);
  },
  countManagedKeys({commit}, payload: {id: number}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}/count-managed-keys`)
    .then((data) => data.data);
  },
  getUserGroups({commit}, payload: { userId: number, query: any }) {
    return axiosInstance.get(`${baseUrl}/${payload.userId}/user-groups`, {params: payload ? payload.query : {}})
      .then((data) => data.data);
  },
  getPayments({commit}, payload: { userId: number, query: any }) {
    return axiosInstance.get(`${baseUrl}/${payload.userId}/payments`, {params: payload?.query})
      .then((data) => data.data);
  },
  getExistingByEmail({commit}, payload: { users: string[] }) {
    return axiosInstance.get(`${baseUrl}/exist/email`, {params: payload ? payload.users : {}})
      .then((data) => data.data);
  },
  getUserById({commit}, payload: { id: number, options: object }) {
    return axiosInstance.get(`${baseUrl}/${payload.id}`, {params: payload.options})
      .then((data) => data.data);
  },
  createUser({commit}, payload: { user: object }) {
    return axiosInstance.post(`${baseUrl}/`, {user: payload.user})
      .then((data) => data.data);
  },
  createGroup({commit}, payload: { users: any, userGroupCreation: object }) {
    return axiosInstance.post(`${baseUrl}/group`,
      {
        users: payload.users.map((k: any) => k.id),
        userGroupCreation: payload.userGroupCreation,
      }).then((data) => data.data);
  },
  importUsers({commit}, payload: {users: object, importType: string}) {
    return axiosInstance.post(`${baseUrl}/import`, {users: payload.users, importType: payload.importType})
      .then((data) => data.data);
  },
  updateUser({commit}, payload: {id: number, user: object}) {
    return axiosInstance.put(`${baseUrl}/${payload.id}`, {user: payload.user})
      .then((data) => data.data);
  },
  deleteUserById({commit}, payload: {id: number}) {
    return axiosInstance.delete(`${baseUrl}/${payload.id}`)
      .then((data) => data.data);
  },
  validate({commit}, payload: {id: any, token: object}) {
    return axiosInstance.post(`${baseUrl}/${payload.id}/validate`, {token: payload.token})
        .then((data) => data);
  },
  search({commit}, payload: {search: string}) {
    return axiosInstance.get(`${baseUrl}/search`, {params: payload})
        .then((data) => data.data);
  },
  getUserBookings({commit}, payload: {
    id: any,
    startDate: string,
    endDate: string,
    users: number[],
    keys: number[],
    from: string,
  }) {
    return axiosInstance.get(`${baseUrl}/${payload.id}/bookings`, {params: {
      startDate: payload.startDate,
      endDate: payload.endDate,
      users: payload.users,
      keys: payload.keys,
      from: payload.from,
    },
    }).then((data) => data.data);
  },
  getGuestAndManagedKeys({commit}, payload: {id: number, query: object}) {
    return axiosInstance.get(`${baseUrl}/${payload.id}/managed-guest-keys`, {params: payload?.query})
      .then((data) => data.data);
  },
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations,
};
