export const defaultUserAvatar = require("@/assets/images/defaultAvatar.png");

export const defaultUserGroupAvatar = require("@/assets/images/defaultUserGroupAvatar.png");

export const defaultKeyPicture = require("@/assets/images/defaultKey.png");

export const weekDays = [
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
  "sunday",
];

export const bookingColors = [
  "indigo",
  "orange",
  "deep-orange",
  "blue-grey",
  "deep-purple",
  "brown",
  "teal",
  "lime darken-4",
  "teal darken-4",
  "pink darken-4",
];
