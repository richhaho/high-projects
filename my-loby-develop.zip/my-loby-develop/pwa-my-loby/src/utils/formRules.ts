import i18n from "@/plugins/i18n";
import siret from "siret";

export const regex = {
  email: /.+@.+\..+/,
  uppercase: /^(?=.*[A-Z])/,
  lowercase: /^(?=.*[a-z])/,
  passwordLength: /^(?=.{8,})/,
  number: /^(?=.*[0-9])/,
  special: /^(?=.*?[^\w\s])/,
  validPhoneNumber: /^(?:\+|00)[\s.-]*(32|33)\s*[1-9](?:[\s.-]*\d{2}){4}$/,
};

export const formRules = {
  required: (v: string) => {
    return !!v || i18n.t("rules.required");
  },
  requiredNumber: (v: number) => {
    return !isNaN(v) || i18n.t("rules.required");
  },
  email: (v: string) => {
    return v ? regex.email.test(v) || i18n.t("rules.validEmail") : true;
  },
  mainContact: (v: string) => {
    return regex.email.test(v) || regex.validPhoneNumber.test(v) || i18n.t("rules.validEmailOrPhone");
  },
  uppercase: (v: string) => {
    return regex.uppercase.test(v) || i18n.t("rules.password.uppercase");
  },
  lowercase: (v: string) => {
    return regex.lowercase.test(v) || i18n.t("rules.password.lowercase");
  },
  length: (v: string) => {
    return regex.passwordLength.test(v) || i18n.t("rules.password.length");
  },
  number: (v: string) => {
    return regex.number.test(v) || i18n.t("rules.password.number");
  },
  special: (v: string) => {
    return regex.special.test(v) || i18n.t("rules.password.special");
  },
  terms: (v: string) => {
    return !!v || i18n.t("rules.terms");
  },
  phone: (v: string) => {
    return v ? regex.validPhoneNumber.test(v) || i18n.t("rules.phone") : true;
  },
  avatar: (v: {size: number}) => {
    const AVATAR_MAX_SIZE = 2000000; // in bytes
    return v.size < AVATAR_MAX_SIZE || i18n.t("rules.avatarSize", {maxSize: AVATAR_MAX_SIZE / 1000});
  },
  siret: (v: string) => {
    return (v && siret.isSIRET(v)) || i18n.t("rules.siret");
  },
  siren: (v: string) => {
    return (v && siret.isSIREN(v)) || i18n.t("rules.siren");
  },
  positive: (v: string) => {
    return !v || Number(v) >= 0 || i18n.t("rules.positive");
  },
  strictlyPositive: (v: string) => {
    return !v || Number(v) > 0 || i18n.t("rules.strictlyPositive");
  },
  percent: (v: string) => {
    return !v || (Number(v) >= 0 && Number(v) <= 100) || i18n.t("rules.percent");
  },
  integer: (v: string) => {
    return !v || Number.isInteger(Number(v)) || i18n.t("rules.integer");
  },
  multiplier: (v: string) => {
    return !v || (Number(v) >= 0) || i18n.t("rules.multiplier");
  },
  pin: (v: string) => {
    return !v || v.length === 4 || "";
  },
};
