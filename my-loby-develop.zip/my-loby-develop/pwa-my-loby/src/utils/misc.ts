export const getRandomColor = () => {
  const letters = "0123456789ABCDEF";
  let color = "#";
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
};

export const getSrc = (picturePath: string) => picturePath && typeof picturePath === "string"
  ? `${process.env.VUE_APP_API_ENDPOINT}${picturePath}`
  : null;

export const removeVuetifyFileInputBug: (document: any) => void = (document: any): void => {
  // TODO: Remove this function and all usages after Vuetify version update after correction of the bug
  // TODO: Follow the fixing of the bug: https://github.com/vuetifyjs/vuetify/issues/10832
  const inputs = document.querySelectorAll(".v-file-input input");
  [...inputs].forEach((input: any) => {
    input.remove();
  });
};

export const lastItemOfArray: (array: any[]) => any = (array: any[]): any => {
  return array?.[array?.length - 1];
};
