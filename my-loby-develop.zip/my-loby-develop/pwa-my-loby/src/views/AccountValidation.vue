<template>
    <section class="section">
        <v-container>
            <v-row justify="center">
                <v-col align="center" xl="4" lg="4" md="5" sm="6">
                    <v-alert
                            v-if="alertMessage"
                            :color="alertColor"
                            outlined
                            text>
                        {{$t(alertMessage)}}
                    </v-alert>
                    <v-btn color="primary" text outlined to="/login">{{ $t('login.btn') }}</v-btn>
                </v-col>
            </v-row>
        </v-container>
    </section>
</template>

<script lang="ts">
import {Component, Vue} from "vue-property-decorator";

@Component
export default class AccountValidation extends Vue {
    private alertColor: string = "";
    private alertMessage: string = "";
    private mounted() {
        const token = this.$route.params.token;
        this.getToken(token);
    }

    private getToken(token) {
        this.$store.dispatch("token/getOne", {token})
            .then((res) => {
                this.validateUser(res.User.id, res);
            })
            .catch((err) => {
                this.alertColor = "red";
                this.alertMessage = `account.token.${err.response.data.error}`;
            });
    }

    private validateUser(userId, token) {
        const user = { activatedAt: new Date() };
        this.$store.dispatch("users/validate", {id: userId, token})
            .then((res) => {
                this.alertColor = "green";
                this.alertMessage = "account.activated";
            })
            .catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg : err,
                });
            });
    }

}
</script>
