<template>
    <section class="section">
        <v-container class="py-0">
            <v-col id="title" cols="12">
                <h2>{{$t('cgv.title')}}</h2>
            </v-col>
            <v-col id="all" cols="12">
                <p class="mb-10" v-html="$t('cgv.all')"/>
            </v-col>
        </v-container>
    </section>
</template>

<script lang="ts">
import {Component, Vue} from "vue-property-decorator";

@Component
export default class GeneralTerms extends Vue {
    private mounted() {
        //
    }
}
</script>
