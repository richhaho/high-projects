<template>
    <section class="section">
        <v-container>
            <v-row justify="center">
                <h2>{{$t('account.changePassword')}}</h2>
            </v-row>
            <v-row justify="center">
                <v-col align="center" xl="3" lg="4" md="5" sm="6">
                    <v-alert
                            v-if="alertMessage"
                            :color="alertColor"
                            outlined
                            text>
                        {{$t(alertMessage)}}
                    </v-alert>
                    <v-form
                            v-if="!isSaved"
                            ref="form"
                            v-model="valid"
                            @submit="updatePassword"
                            onSubmit="return false;"
                    >
                        <v-text-field
                                :rules="passwordRulesSet"
                                class="input-group--focused"
                                :label="'* '+$t('user.password')"
                                v-model="form.password"
                                :readonly="readonly"
                                type="password"
                        >
                            <template v-slot:append>
                                <v-tooltip bottom right>
                                    <template v-slot:activator="{ on }">
                                        <v-icon v-on="on">info</v-icon>
                                    </template>
                                    <ul class="my-1">
                                        <li>{{$t('rules.password.length')}}</li>
                                        <li>{{$t('rules.password.uppercase')}}</li>
                                        <li>{{$t('rules.password.lowercase')}}</li>
                                        <li>{{$t('rules.password.number')}}</li>
                                        <li>{{$t('rules.password.special')}}</li>
                                    </ul>
                                </v-tooltip>
                            </template>

                        </v-text-field>
                        <v-btn
                                :disabled="!valid"
                                @click="updatePassword"
                                color="warning"
                                text
                        >
                            {{ $t('actions.save') }}
                        </v-btn>
                    </v-form>
                </v-col>
            </v-row>
            <v-row justify="center">
                <v-btn
                    color="warning"
                    text
                    to="/login"
                    v-if="isSaved"
                >
                    {{$t('link.login')}}
                </v-btn>
            </v-row>
        </v-container>
    </section>
</template>

<script lang="ts">
import {Component, Vue} from "vue-property-decorator";
import {formRules} from "@/utils/formRules";

@Component
export default class Password extends Vue {
    private alertColor: string = "";
    private alertMessage: string = "";
    private readonly: boolean = false;
    private isSaved: boolean = false;
    private rules: any = formRules;
    private valid: boolean = true;
    private token = null;
    private form: any = {
        password: "",
    };

    get passwordRulesSet(): any[] {
        return [
            this.rules.required,
            this.rules.length,
            this.rules.uppercase,
            this.rules.lowercase,
            this.rules.number,
            this.rules.special,
        ];
    }

    private mounted() {
        this.token = this.$route.params.token;
        this.getToken(this.token);
    }

    private getToken(token) {
        this.$store.dispatch("token/getOne", {token})
            .catch((err) => {
                this.readonly = true;
                this.alertColor = "red";
                this.alertMessage = `account.token.${err.response.data.error}`;
            });
    }

    private updatePassword() {
        this.$store.dispatch("auth/updatePassword", {token: this.token, password: this.form.password})
            .then((res) => {
                this.isSaved = true;
                this.alertColor = "green";
                this.alertMessage = "account.passwordSaved";
                this.form.password = "";
            }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

}
</script>
