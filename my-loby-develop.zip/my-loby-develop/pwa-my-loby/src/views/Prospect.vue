<template>
    <v-container v-if="isPageReady">
        <a
            @click="$router.go(-1)"
            class="fil_arianne"
        >
            <i class="icon-picto_retour"></i>
            {{$t('actions.back')}}
        </a>
        <v-row justify="center">
            <h3 class="text-center my-3">
                {{$t(`prospect.${prospectType}.mainTitle`)}}
            </h3>
        </v-row>
        <v-form
                ref="form"
                v-model="formValidation"
                class="mt-5"
        >
            <v-row>
                <v-col v-if="isAdmin || step === 1">
                    <h2
                        v-if="prospectType === 'RELAY' || prospectType === 'COMPANY'"
                        class="headline"
                    >
                        {{$t(`prospect.${prospectType}.userTitle`)}}
                    </h2>
                    <v-select
                            v-model="prospect.gender"
                            item-value="key" item-text="label"
                            :items="[{key : 'mr', label : $t('form.genderList.mr')}, {key : 'mrs', label : $t('form.genderList.mrs')}]"
                            :label="$t('form.gender')+' *'"
                            :rules="[rules.required]"
                            required
                    />
                    <v-text-field
                            v-model="prospect.lastName"
                            :rules="[rules.required]"
                            :label="$t('form.lastName')+' *'"
                            required
                    />
                    <v-text-field
                            v-model="prospect.firstName"
                            :rules="[rules.required]"
                            :label="$t('form.firstName')+' *'"
                            required
                    />
                    <v-text-field
                            v-if="prospectType === 'INFO'"
                            v-model="prospect.companyName"
                            :rules="[rules.required]"
                            :label="$t('form.company')+' *'"
                            required
                    />
                    <v-select
                            v-if="prospectType === 'INFO'"
                            v-model="prospect.activitySector"
                            item-value="key" item-text="label"
                            :items="activitySectorList"
                            :label="$t('form.activitySector')+' *'"
                            :rules="[rules.required]"
                            required
                    />
                    <v-text-field
                            v-model="prospect.job"
                            :rules="[rules.required]"
                            :label="$t('form.job')+' *'"
                            required
                    />
                    <v-text-field
                            v-model="prospect.city"
                            :label="$t('form.city')+' *'"
                            :rules="[rules.required]"
                    />
                    <v-text-field
                            v-model="prospect.country"
                            :label="$t('form.country')+' *'"
                            :rules="[rules.required]"
                    />
                    <v-text-field
                            v-model="prospect.zipCode"
                            :label="$t('form.zipCode')+' *'"
                            :rules="[rules.required]"
                    />
                    <v-text-field
                            v-model="prospect.phone"
                            :rules="[rules.required]"
                            :label="$t('form.phone')+' *'"
                            required
                    />
                    <v-text-field
                            v-model="prospect.email"
                            :rules="[rules.required, rules.email]"
                            :label="$t('form.email')+' *'"
                            required
                    />
                    <v-textarea
                            v-if="prospectType === 'INFO'"
                            v-model="prospect.request"
                            :rules="[rules.required]"
                            :label="$t('form.request')+' *'"
                            required
                    />
                </v-col>
                <v-col
                    cols="2"
                    v-if="isAdmin && (prospectType === 'RELAY' || prospectType === 'COMPANY')"
                    align="center"
                >
                    <v-divider vertical/>
                </v-col>
                <v-col
                    v-if="(isAdmin || step === 2) && (prospectType === 'RELAY' || prospectType === 'COMPANY')"
                >
                    <h2
                        class="headline"
                    >
                        {{$t(`prospect.${prospectType}.entityTitle`)}}
                    </h2>
                    <v-text-field
                            v-model="prospect.companyName"
                            :rules="[rules.required]"
                            :label="$t('form.companyName')+' *'"
                            required
                    />
                    <v-select
                        v-model="prospect.activitySector"
                        item-value="key" item-text="label"
                        :items="activitySectorList"
                        :label="$t('form.activitySector')+' *'"
                        :rules="[rules.required]"
                        required
                    />
                    <v-text-field
                            v-model="prospect.companyAddress"
                            :rules="[rules.required]"
                            :label="$t('form.companyAddress')+' *'"
                            required
                    />
                    <v-text-field
                            v-model="prospect.companyPhone1"
                            :rules="[rules.required]"
                            :label="$t('form.companyPhone1')+' *'"
                            required
                    />
                    <v-text-field
                            v-model="prospect.companyPhone2"
                            :label="$t('form.companyPhone2')"
                    />
                    <v-text-field
                            v-model="prospect.companyEmail"
                            :rules="[rules.required, rules.email]"
                            :label="$t('form.companyEmail')+' *'"
                            required
                    />
                    <v-text-field
                            v-model="prospect.companyZipCode"
                            :rules="[rules.required]"
                            :label="$t('form.companyZipCode')+' *'"
                            required
                    />
                    <v-text-field
                            v-model="prospect.companyCity"
                            :rules="[rules.required]"
                            :label="$t('form.companyCity')+' *'"
                            required
                    />
                    <v-text-field
                            v-model="prospect.companyCountry"
                            :rules="[rules.required]"
                            :label="$t('form.country')+' *'"
                            required
                    />
                    <!-- TODO: Add custom SIRET rule -->
                    <v-text-field
                            v-model="prospect.companySiret"
                            :rules="[rules.required]"
                            :label="$t('form.companySiret')+' *'"
                            required
                    />
                    <v-btn
                        v-if="prospectType === 'RELAY'"
                        outlined
                        class="mt-4"
                        @click="displayHours = !displayHours"
                        :title="$t('form.companyOpeningHours')"
                    >
                        {{$t('form.companyOpeningHours')+' *'}}
                    </v-btn>
                    <!--START OPENING HOURS-->
                    <v-col v-if="prospectType === 'RELAY'">
                        <schedulePicker
                            v-show="displayHours"
                            :company-opening-hours="prospect.companyOpeningHours"
                        />
                    </v-col>
                    <!--END OPENING HOURS-->
                </v-col>
            </v-row>
            <v-checkbox
                v-if="prospectType === 'INFO' || step === 2"
                v-model="prospect.legal"
                :rules="[rules.required]"
                required
            >
                <div slot="label">
                    {{$t('register.agreeToTerms')}}
                    <a
                        @click.stop
                        href="general-terms"
                        target="_blank"
                    >
                        {{$t('register.terms')}}
                    </a>
                </div>
            </v-checkbox>
            <v-row v-if="!isAdmin" justify="center">
                <v-btn
                    v-if="step === 1"
                    :disabled="!formValidation"
                    outlined
                    class="mb-4"
                    @click="createProspect"
                >
                    {{$t('actions.' + (prospectType === 'INFO' ? 'send' : 'saveAndContinue'))}}
                </v-btn>
                <v-btn
                    v-if="step === 2"
                    outlined
                    class="mx-4 mb-10"
                    @click="step = 1"
                >
                    {{$t('actions.back')}}
                </v-btn>
                <v-btn
                    v-if="step === 2"
                    :disabled="!formValidation"
                    outlined
                    class="mx-4 mb-10"
                    @click="save"
                >
                    {{$t('actions.send')}}
                </v-btn>
            </v-row>
            <div v-else>
                <!-- Select relay/company type -->
                <v-row justify="center">
                    <v-col cols="3">
                        <v-select
                            v-if="prospectType === 'RELAY'"
                            v-model="prospect.companyType"
                            item-value="key" item-text="label"
                            :disabled="!!(prospect.validationDate || prospect.startTestPeriodDate || prospect.declinationDate)"
                            :items="relayTypesList"
                            :label="$t('relay.type')+' *'"
                            :rules="[rules.required]"
                        />
                        <v-select
                            v-else-if="prospectType === 'COMPANY'"
                            v-model="prospect.companyType"
                            item-value="key" item-text="label"
                            :disabled="!!(prospect.validationDate || prospect.startTestPeriodDate || prospect.declinationDate)"
                            :items="companyTypesList"
                            :label="$t('company.type.title')+' *'"
                            :rules="[rules.required]"
                        />
                    </v-col>
                </v-row>
                <!-- Display validation date -->
                <v-row v-if="prospect.validationDate" justify="center">
                    {{$t('prospectList.validationDate')}} : {{prospect.validationDate  | formatDate}}
                </v-row>
                <!-- Display test period dates -->
                <v-row v-else-if="prospect.startTestPeriodDate">
                    {{$t('prospectList.testPeriodDate')}} : {{prospect.startTestPeriodDate | formatDate}} au
                    {{prospect.endTestPeriodDate | formatDate}}
                </v-row>
                <!-- Display declination date -->
                <v-row v-else-if="prospect.declinationDate" justify="center">
                    {{$t('prospectList.declinationDate')}} : {{prospect.declinationDate | formatDate}}
                    {{prospect.rejectionCause}}
                </v-row>
                <!-- Admin actions -->
                <v-row v-if=" !(prospect.validationDate || prospect.declinationDate)">
                    <!-- Update prospect data -->
                    <v-col cols="12" align="center">
                        <v-btn
                            :disabled="!formValidation"
                            @click="save"
                            color="info"
                        >
                            {{$t('actions.save')}}
                        </v-btn>
                        <v-divider class="mt-10"></v-divider>
                    </v-col>
                    <!-- Decline -->
                    <v-col align="end">
                        <v-btn
                            :disabled="!rejectionCause"
                            @click="decline"
                            color="error"
                        >
                            {{$t('prospectList.decline')}}
                        </v-btn>
                        <v-textarea
                            v-if="prospectType === 'RELAY' || prospectType === 'COMPANY'"
                            v-model="rejectionCause"
                            outlined
                            class="py-5"
                            :label="$t('form.rejectionCause')+' *'"
                        />
                    </v-col>
                    <!-- Start test period -->
                    <v-col
                        v-if="prospectType === 'COMPANY' && !prospect.startTestPeriodDate"
                        cols="4"
                        align="center"
                    >
                        <v-btn
                            :disabled="!formValidation || !isProspectEntityTyped"
                            @click="startValidatePeriod"
                            color="info"
                        >
                            {{$t('prospectList.startValidatePeriod')}}
                        </v-btn>
                        <!-- Date picker -->
                        <v-menu
                            ref="datePicker"
                            v-model="displayDatePicker"
                            :close-on-content-click="false"
                            :return-value.sync="endTestPeriod"
                            transition="scale-transition"
                            offset-y
                            min-width="290px"
                        >
                            <template v-slot:activator="{ on }">
                                <v-text-field
                                    v-model="endTestPeriod"
                                    :label="$t('prospectList.endTestPeriod')"
                                    prepend-icon="event"
                                    readonly
                                    class="py-6"
                                    v-on="on"
                                />
                            </template>
                            <v-date-picker
                                :locale="lang"
                                v-model="endTestPeriod"
                                no-title
                                scrollable
                            >
                                <v-spacer></v-spacer>
                                <v-btn
                                    text color="primary"
                                    @click="menu = false"
                                >
                                    {{$t('actions.cancel')}}
                                </v-btn>
                                <v-btn
                                    text color="primary"
                                    @click="$refs.datePicker.save(endTestPeriod)"
                                >
                                    {{$t('actions.validate')}}
                                </v-btn>
                                <v-spacer></v-spacer>
                            </v-date-picker>
                        </v-menu>
                    </v-col>
                    <!-- Validate -->
                    <v-col>
                        <v-btn
                            :disabled="!formValidation || !isProspectEntityTyped"
                            @click="validate"
                            color="success"
                        >
                            {{$t('prospectList.validate')}}
                        </v-btn>
                    </v-col>
                </v-row>
            </div>
        </v-form>
        <v-dialog
            max-width="500px"
            v-model="confirmModal"
            persistent
        >
            <v-card>
                <v-card-title>
                    <span class="headline">{{$t('prospect.formSent')}}</span>
                </v-card-title>
                <v-card-text>
                    <p class="my-3">{{$t("prospect.backAtYou")}}</p>
                    <p class="my-0">{{$t("prospect.seeYouSoon")}}</p>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <router-link
                        :to="{name: 'home'}"
                    >
                        <v-btn
                        @click=""
                        color="orange darken-1"
                        text
                        >
                            {{$t('actions.close')}}
                        </v-btn>
                    </router-link>
                    <v-spacer></v-spacer>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </v-container>
    <v-row v-else justify="center">
        <v-progress-circular
            indeterminate
            size="50"
        />
    </v-row>
</template>
<script lang="ts">
import SchedulePicker from "@/components/SchedulePicker.vue";
import {formRules} from "@/utils/formRules";
const openingHoursFieldDayFn = () => ({
    isActive: true,
    continuous: {
        isActive: true,
        fromHours: "09:00",
        toHours: "19:00",
    },
    morning: {
        isActive: false,
        fromHours: "09:00",
        toHours: "13:00",
    },
    evening: {
        isActive: false,
        fromHours: "15:00",
        toHours: "19:00",
    },
});

export default {
    name: "Prospect",
    components: {SchedulePicker},
    mounted() {
        if (this.$route.params.id) {
            this.getProspectById(this.$route.params.id);
        }
    },
    data() {
        return {
            prospect: {
                companyOpeningHours: {
                    monday: openingHoursFieldDayFn(),
                    tuesday: openingHoursFieldDayFn(),
                    wednesday: openingHoursFieldDayFn(),
                    thursday: openingHoursFieldDayFn(),
                    friday: openingHoursFieldDayFn(),
                    saturday: openingHoursFieldDayFn(),
                    sunday: openingHoursFieldDayFn(),
                },
            },
            step: 1,
            prospectId: null,
            rejectionCause: "",
            displayDatePicker: false,
            endTestPeriod: new Date().toISOString().substr(0, 10),
            displayHours: false,
            formValidation: false,
            confirmModal: false,
            rules: formRules,
        };
    },
    computed: {
        isAdmin(): boolean {
            return this.$store.getters.isAdmin;
        },
        isPageReady(): boolean {
            return !this.$route.params.id || !!this.prospect.id;
        },
        prospectType(): string {
            if (this.prospect.id) {
                return this.prospect.type;
            } else {
                switch (this.$router.currentRoute.name) {
                    case "prospect-info":
                        return "INFO";
                    case "prospect-relay":
                        return "RELAY";
                    case "prospect-company":
                        return "COMPANY";
                    default:
                        return "INFO";
                }
            }
        },
        activitySectorList(): object[] {
            const activitySectorList = this.getActivitySectorsByType(this.prospectType);
            activitySectorList.sort((a, b) => (a.label).localeCompare(b.label));
            activitySectorList.push({key: "Autre", label: this.$t("relay.activitySectors.other")});
            return activitySectorList;
        },
        relayTypesList(): object[] {
            return [
                {key: "FLOW", label: this.$t("relay.flow")},
                {key: "LONG_TERM", label: this.$t("relay.longTerm")},
            ];
        },
        companyTypesList(): object[] {
            return [
                {key: "B2B", label: this.$t("company.type.b2b")},
                {key: "INSURANCE", label: this.$t("company.type.insurance")},
            ];
        },
        isProspectEntityTyped(): boolean {
            // The relay or company of the prospect should be typed by the admin
            if (this.prospectType === "RELAY" || this.prospectType === "COMPANY") {
                return !!this.prospect.companyType;
            } else {
                return true;
            }
        },
        lang(): string {
            return this.$root.$i18n.locale;
        },
    },
    methods: {
        getProspectById(id: number): void {
            this.$store.dispatch("prospects/getById", {id})
            .then((prospect) => {
                this.prospect = prospect;
                this.rejectionCause = prospect.rejectionCause;
                if (prospect.endTestPeriod) {
                    this.endTestPeriod = prospect.endTestPeriod;
                }
            });
        },
        createProspect() {
            if (this.$refs.form.validate()) {
                this.prospect.type = this.prospectType;
                this.$store.dispatch("prospects/create", {
                    prospect: this.prospect,
                })
                    .then((res) => {
                        if (this.prospectType === "INFO") {
                            this.confirmModal = true;
                        } else {
                            this.$refs.form.resetValidation();
                            this.step = 2;
                            this.prospectId = res?.id;
                        }
                    })
                    .catch((err) => {
                        this.$store.commit("alerts/displayError", {
                            msg : err,
                        });
                    });
            }
        },
        save() {
            this.$store.dispatch("prospects/update", {
                id: this.$route.params.id || this.prospectId,
                prospect: this.prospect,
            })
            .then(() => {
                if (this.isAdmin) {
                    this.$store.commit("alerts/displaySuccess", {
                        msg: this.$i18n?.t("actions.saved"),
                    });
                    this.getProspectById(this.$route.params.id);
                } else {
                    this.confirmModal = true;
                }
            })
            .catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err.response.data.error,
                });
            });
        },
        decline() {
            this.$store.dispatch("prospects/decline", {
                id: this.$route.params.id,
                prospect: this.prospect,
                rejectionCause: this.rejectionCause,
            })
            .then(() => {
                this.$router.push({name: "prospects"});
            })
            .catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err.response.data.error,
                });
            });
        },
        startValidatePeriod() {
            const endTestPeriod = new Date(this.endTestPeriod.toISOString().substr(0, 10));
            this.$store.dispatch("prospects/startValidatePeriod", {
                id: this.$route.params.id,
                prospect: this.prospect,
                endTestPeriod,
            })
            .then(() => {
                this.$router.push({name: "prospects"});
            })
            .catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err.response.data.error,
                });
            });
        },
        validate() {
            this.$store.dispatch("prospects/validate", {
                id: this.$route.params.id,
                prospect: this.prospect,
            })
            .then(() => {
                this.$router.push({name: "prospects"});
            })
            .catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err.response.data.error,
                });
            });
        },
        getActivitySectorsByType(type: string): object[] {
            switch (type) {
                case "RELAY":
                    return [
                        {key: "Commerce", label: this.$t("relay.activitySectors.commerce")},
                        {key: "Conciergerie", label: this.$t("relay.activitySectors.conciergerie")},
                    ];
                case "COMPANY":
                    return [
                        {key: "Services à la personne", label: this.$t("company.activitySectors.personService")},
                        {key: "Agence de femme de ménage", label: this.$t("company.activitySectors.cleaningAgency")},
                        {
                            key: "Agence immobilière Gestion Locative",
                            label: this.$t("company.activitySectors.realEstateRentalAgency"),
                        },
                        {
                            key: "Agence immobilière Syndic de co-propriété",
                            label: this.$t("company.activitySectors.realEstateSyndicAgency"),
                        },
                        {key: "Groupe immobilier", label: this.$t("company.activitySectors.realEstateGroup")},
                        {key: "Bailleurs sociaux", label: this.$t("company.activitySectors.socialDonors")},
                        {key: "Property Management", label: this.$t("company.activitySectors.propertyManagement")},
                        {key: "Constructeur", label: this.$t("company.activitySectors.manufacturer")},
                        {key: "Maître d’oeuvre", label: this.$t("company.activitySectors.masterOfWork")},
                        {key: "Artisan", label: this.$t("company.activitySectors.craftsman")},
                        {key: "Assurance", label: this.$t("company.activitySectors.insurance")},
                        {key: "Conciergerie Airbnb", label: this.$t("company.activitySectors.airbnbService")},
                        {key: "Concessionnaire auto", label: this.$t("company.activitySectors.carDealer")},
                    ];
                default:
                    return [
                        ...this.getActivitySectorsByType("RELAY"),
                        ...this.getActivitySectorsByType("COMPANY"),
                    ];
            }
        },
    },
};
</script>
