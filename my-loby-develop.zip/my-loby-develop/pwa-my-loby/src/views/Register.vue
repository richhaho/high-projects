<template>
    <div class="register page-content">
        <v-row justify="center"class="mb-6" >
            <h2 class="text-center">
                {{$t('register.typeChoice')}}
            </h2>
        </v-row>
        <v-row justify="center">
            <router-link v-for="(option, i) in options" :to="option.link" :key="i">
                <div class="category-card">
                    <h3>{{$t(option.title)}}</h3>
                    <p>{{$t(option.description)}}</p>
                </div>
            </router-link>
        </v-row>
    </div>
</template>
<script lang="ts">
export default {
    name: "Register",
    data() {
        return {
            options: [
                {
                    title: "accountType.classicTitle",
                    description: "accountType.classicDescription",
                    link: "/register-classic",
                },
                {
                    title: "accountType.proTitle",
                    description: "accountType.proDescription",
                    link: "/prospect-company",
                },
            ],
        };
    },
};
</script>
