<template>
    <div class="register-classic page-content my-0">
        <a
            @click="$router.go(-1)"
            class="fil_arianne"
        >
            <i class="icon-picto_retour"></i>
            {{$t('actions.back')}}
        </a>
        <h2 class="text-center my-4">
            {{$t('register.signUp')}}
        </h2>
        <v-container class="register-form">
            <h3>{{$t('accountType.account')}} {{$t('accountType.classicTitle')}}</h3>
            <v-alert
                    v-if="alert"
                    :color="alertColor"
                    outlined
                    text>
                {{$t(alertMessage)}}
            </v-alert>
            <v-form v-model="valid">
                <v-text-field
                        :label="$t('user.username')"
                        v-model="user.username">
                </v-text-field>
                <v-text-field
                        :label="'* '+$t('user.email')"
                        :rules="[rules.required, rules.email]"
                        v-model="user.email">
                </v-text-field>
                <v-text-field
                        :label="$t('user.phone')"
                        v-model="user.phone"
                ></v-text-field>
                <v-text-field
                        type="password"
                        :label="'* '+$t('user.password')"
                        :rules="passwordRulesSet"
                        v-model="user.password">
                    <template v-slot:append>
                        <v-tooltip bottom right>
                            <template v-slot:activator="{ on }">
                                <v-icon v-on="on">info</v-icon>
                            </template>
                            <ul class="my-1">
                                <li>{{$t('rules.password.length')}}</li>
                                <li>{{$t('rules.password.uppercase')}}</li>
                                <li>{{$t('rules.password.lowercase')}}</li>
                                <li>{{$t('rules.password.number')}}</li>
                                <li>{{$t('rules.password.special')}}</li>
                            </ul>
                        </v-tooltip>
                    </template>
                </v-text-field>
                <v-checkbox
                        :rules="[rules.terms]"
                >
                    <div slot="label">
                        {{$t('register.agreeToTerms')}}
                        <a
                            @click.stop
                            href="general-terms"
                            target="_blank"
                        >
                            {{$t('register.terms')}}
                        </a>
                    </div>
                </v-checkbox>
                <v-row justify="center">
                    <v-btn
                        @click="createUser"
                        :disabled="!valid"
                        color="warning"
                        text
                        class="mr-4"
                    >
                        {{$t('register.validate')}}
                    </v-btn>
                </v-row>
            </v-form>
        </v-container>
    </div>
</template>
<script lang="ts">
import {Vue, Component} from "vue-property-decorator";
import {formRules} from "@/utils/formRules";

@Component
export default class RegisterClassic extends Vue {

    private rules: any = formRules;
    private valid: boolean = true;
    private alert: boolean = false;
    private alertColor: string = "";
    private alertMessage: string = "";
    private user: object = {
        username: null,
        phone: null,
        email: null,
        password: null,
    };

    get passwordRulesSet(): any[] {
        return [
            this.rules.required,
            this.rules.length,
            this.rules.uppercase,
            this.rules.lowercase,
            this.rules.number,
            this.rules.special,
        ];
    }

    private createUser() {
        this.$store.dispatch("users/createUser", {user: this.user})
            .then((res) => {
                this.alert = true;
                this.alertMessage = "register.created";
                this.alertColor = "green";
            })
            .catch((err) => {
                this.alert = true;
                this.alertMessage = `register.error.${err.response.data.type}`;
                this.alertColor = "red";
            });
    }
}
</script>
