<template>
    <section class="section">
        <v-row justify="center">
            <v-card max-width="500px">
                <v-card-title>
                    <v-text-field
                        append-icon="search"
                        hide-details
                        single-line
                        v-bind:label="$t('actions.search')"
                        v-model="search"
                    ></v-text-field>
                </v-card-title>
                <v-data-table
                    :custom-filter="searchCurrentValues"
                    :headers="headers"
                    :items="keyLocations"
                    :no-results-text="$t('key.notFound')"
                    :search="search"
                    disable-pagination
                    hide-default-footer
                    item-key="keyLocations.key.id"
                >
                    <template v-slot:item.key="{ item }">
                        <v-chip
                            :outlined="true"
                        >
                            {{item.key.name}}
                        </v-chip>
                    </template>
                    <template v-slot:item.location="{ item }">
                        <v-chip
                            :outlined="true"
                        >
                            {{item.location.codeName}}
                        </v-chip>
                    </template>
                </v-data-table>
                <v-row justify="center">
                    <v-btn
                        class="ma-3"
                        color="primary"
                        text
                        outlined
                        :to="{ name: 'keys' }">
                        {{$t('actions.close')}}
                    </v-btn>
                </v-row>
            </v-card>
        </v-row>
    </section>
</template>

<script lang="ts">
    import {Component, Vue} from "vue-property-decorator";
    import router from "@/router";

    @Component
    export default class KeyLocations extends Vue {

        private headers: any[] = [];
        private keyLocations: any[] = [];
        private search: string = "";

        private mounted() {
            this.headers = [
                {value: "key", text: this.$t("key.name"), sortable: false},
                {value: "location", text: this.$tc("box.locations"), sortable: false},
            ];
            const data: any = this.$route.params?.data;
            if (!data) {
                return router.push({name: "keys"});
            }
            this.keyLocations = data.keyLocations.filter((kL) => kL?.location);
        }

        private searchCurrentValues(value, search, item) {
            return (item.key.name.includes(search) || item.location.codeName.includes(search));
        }
    }
</script>
