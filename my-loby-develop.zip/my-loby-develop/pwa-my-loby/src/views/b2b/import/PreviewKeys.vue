<template>
    <section class="section">
        <v-card>
            <v-card-title>
                {{$t("import.keys.title")}} ({{currentKeys.length}})
                <v-dialog
                    persistent
                    max-width="800px" v-model="legendDialog">
                    <template v-slot:activator="{ on }">
                        <v-btn
                            :outlined="true"
                            @click="reset()"
                            class="ml-12 mt-1"
                            color="default"
                            text
                            v-on="on"
                        >
                            {{$t("import.legendTitle")}}
                        </v-btn>
                    </template>
                    <v-card>
                        <v-card-title>
                            <span class="headline">{{$t("import.legendTitle")}}</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container>
                                <v-row>
                                    <v-col align="center" class="pa-0" lg="4">
                                        <v-chip
                                            :outlined="true"
                                            color="red"
                                            text-color="red"
                                        >
                                            {{$t("import.legend.exemple")}}
                                        </v-chip>
                                    </v-col>
                                    <v-col align="center" class="pa-0" lg="8">
                                        <p class="mb-0">{{$t("import.legend.userActive")}}</p>
                                        <p>{{$t("import.legend.infoNotModified")}}</p>
                                    </v-col>
                                </v-row>
                                <v-row>
                                    <v-col align="center" class="pa-0" lg="4">
                                        <v-tooltip bottom>
                                            <template v-slot:activator="{ on }">
                                                <v-chip
                                                    :outlined="true"
                                                    color="blue"
                                                    text-color="blue"
                                                    v-on="on"
                                                >
                                                    {{$t("import.legend.exemple")}}
                                                </v-chip>
                                            </template>
                                            <span>Database Value</span>
                                        </v-tooltip>
                                    </v-col>
                                    <v-col align="center" class="pa-0" lg="8">
                                        <p class="mb-0">{{$t("import.legend.userNotActive")}}</p>
                                        <p class="mb-0">{{$t("import.legend.infoUpdated")}}</p>
                                        <p>{{$t("import.legend.databaseValue")}}</p>
                                    </v-col>
                                </v-row>
                                <v-row>
                                    <v-col align="center" class="pa-0" lg="4">
                                        <v-chip
                                            :outlined="true"
                                            close
                                            close-icon="settings_backup_restore"
                                            color="warning"
                                            text-color="warning"
                                        >
                                            {{$t("import.legend.exemple")}}
                                        </v-chip>
                                    </v-col>
                                    <v-col align="center" class="pa-0" lg="8">
                                        <p class="mb-0">{{$t("import.legend.valueModified")}}</p>
                                        <p>{{$t("import.legend.reset")}}</p>
                                    </v-col>
                                </v-row>
                                <v-row>
                                    <v-col align="center" class="pa-0" lg="4">
                                        <v-tooltip bottom>
                                            <template v-slot:activator="{ on }">
                                                <v-chip
                                                    :outlined="true"
                                                    close
                                                    close-icon="settings_backup_restore"
                                                    color="warning"
                                                    text-color="blue"
                                                    v-on="on"
                                                >
                                                    {{$t("import.legend.exemple")}}
                                                </v-chip>
                                            </template>
                                            <span>Database Value</span>
                                        </v-tooltip>
                                    </v-col>
                                    <v-col align="center" class="pa-0" lg="8">
                                        <p class="mb-0">{{$t("import.legend.userNotActive")}}</p>
                                        <p class="mb-0">{{$t("import.legend.valueModified")}}</p>
                                        <p class="mb-0">{{$t("import.legend.infoUpdatedModified")}}</p>
                                    </v-col>
                                </v-row>
                            </v-container>
                        </v-card-text>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn @click="close" color="white" text>{{$t("actions.close")}}</v-btn>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
                <v-dialog persistent max-width="500px" v-model="noAvailableLocationsDialog">
                    <v-card>
                        <v-card-title>
                            <v-row justify="center">
                                <span class="headline">{{$t("import.keys.notEnoughPlace")}}</span>
                            </v-row>
                        </v-card-title>
                        <v-card-text class="pb-0">
                            <v-container>
                                <v-row>
                                    <p>{{$tc("import.keys.noAvailableLocations")}}</p>
                                    <p>{{$tc("import.keys.importingInRelay", keysWithoutDuplicates.length)}}</p>
                                    <p>{{$tc("import.keys.availableLocationsCount", availableLocationsCount)}}</p>
                                </v-row>
                            </v-container>
                        </v-card-text>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn
                                @click="noAvailableLocationsDialog = false"
                                color="white"
                                text
                            >
                                {{$t('actions.cancel')}}
                            </v-btn>
                            <v-btn
                                :to="{ name: 'relay', params: {id: relayId} }"
                                color="warning"
                            >{{$t("import.keys.editRelay")}}</v-btn>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
                <v-dialog max-width="500px" v-model="noReservedLocationsDialog">
                    <v-card>
                        <v-card-title>
                            <v-row justify="center">
                                <span class="headline">{{$t("import.keys.notEnoughReservations")}}</span>
                            </v-row>
                        </v-card-title>
                        <v-card-text class="pb-0">
                            <v-container>
                                <v-row>
                                    <p>{{$tc("import.keys.noReservedLocations")}}</p>
                                    <p>{{$tc("import.keys.importingNumber", keysWithoutDuplicates.length)}}</p>
                                    <p>{{$tc("import.keys.reservedLocationsCount", reservedLocationsCount)}}</p>
                                </v-row>
                            </v-container>
                        </v-card-text>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn
                                @click="noReservedLocationsDialog = false"
                                color="white"
                                text
                            >
                                {{$t('actions.cancel')}}
                            </v-btn>
                            <v-btn
                                @click="noReservedLocationsDialog = false"
                                color="warning"
                            >
                                {{$t("actions.close")}}
                            </v-btn>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
                <restriction-dialog
                    v-if="currentUser && currentUser.companyId"
                    @close="isRestrictedOn = null"
                    :type="isRestrictedOn"
                />
                <v-spacer></v-spacer>
                <v-text-field
                    append-icon="search"
                    hide-details
                    single-line
                    v-bind:label="$t('actions.search')"
                    v-model="search"
                ></v-text-field>
                <v-spacer></v-spacer>
                <v-btn
                    :loading="saving"
                    @click="importKeys()"
                    class="mt-5"
                    color="primary"
                    dark
                >
                    {{$t("actions.save")}}
                </v-btn>
            </v-card-title>
            <v-data-table
                :custom-filter="searchCurrentValues"
                :headers="headers"
                :items="currentKeys"
                :loading="loading"
                :no-results-text="$t('key.notFound')"
                :search="search"
                class="elevation-1"
                disable-pagination
                hide-default-footer
                item-key="currentValues.name"
                :show-select="!this.isInsuranceImport"
                v-model="keysInRelay"
            >
                <template v-slot:top>
                    <span v-if="!isInsuranceImport">
                        {{$t("key.statusType.IN_RELAY")}}
                    </span>
                </template>
                <template v-slot:item.informations="{ item }">
                    <v-btn class="mr-2"
                           icon
                    >
                        <v-icon
                            @click="deleteKey(item)"
                        >
                            delete
                        </v-icon>
                    </v-btn>
                    <v-tooltip right>
                        <template v-slot:activator="{ on }">
                            <v-icon
                                color="grey"
                                v-on="on"
                                v-show="item.duplicate"
                            >
                                error
                            </v-icon>
                        </template>
                        <span>{{$t("import.keys.duplicated")}}</span>
                    </v-tooltip>
                </template>
                <template v-slot:item.name="{ item }">
                    <v-chip
                        :color="getChipColor(item)"
                        :outlined="true"
                        :text-color="getChipTextColor(item)"
                    >
                        {{item.currentValues.name}}
                    </v-chip>
                </template>
                <template v-slot:item.description="{ item }">
                    <v-chip
                        :color="getChipColor(item)"
                        :outlined="true"
                        :text-color="getChipTextColor(item)"
                    >
                        {{item.currentValues.description}}
                    </v-chip>
                </template>
                <template v-slot:item.keyManagers="{ item }">
                    <v-chip
                        :color="getChipColor(item, manager)"
                        :key="manager.email"
                        :outlined="true"
                        :text-color="getChipTextColor(item, manager)"
                        @click:close="removeManager(item, manager)"
                        close
                        v-for="manager in item.currentValues.keyManagers"
                    >
                        {{manager.email}}
                    </v-chip>
                </template>
            </v-data-table>
        </v-card>
    </section>
</template>
<script lang="ts">
import {Component, Vue} from "vue-property-decorator";
import {Getter} from "vuex-class";
import {canCreateMoreKeys, canUseManagers} from "plan-restrictions";
import RestrictionDialog from "@/components/RestrictionDialog.vue";

@Component({
    components: {
        RestrictionDialog,
    },
})
export default class PreviewKeys extends Vue {

    @Getter private currentUser: any;
    private currentKeys: any = [];
    private keysInRelay: any = [];
    private relayId: number = null;
    private headers: object[] = [];
    private search: string = "";
    private loading: boolean = false;
    private saving: boolean = false;
    private legendDialog: boolean = false;
    private availableLocationsCount: number = 0;
    private noAvailableLocationsDialog: boolean = false;
    private reservedLocationsCount: number = 0;
    private noReservedLocationsDialog: boolean = false;
    private companyKeysCount: number = null;
    private isRestrictedOn: string = null;
    private canUseManagers: (company: any) => boolean = canUseManagers;
    private canCreateMoreKeys: (
        company: any,
        existingKeysNbr: number,
        newKeysNbr: number,
    ) => boolean = canCreateMoreKeys;

    get keysWithoutDuplicates() {
        return this.currentKeys?.filter((k) => !k?.duplicate) || [];
    }
    get newKeysInRelay() {
        return this.keysWithoutDuplicates?.filter((k) => k?.currentValues?.status === "IN_RELAY") || [];
    }
    get isInsuranceImport() {
        return this.company?.type === "INSURANCE";
    }
    get company() {
        return this.connectedUser.masterOf?.[0];
    }

    private mounted() {
        this.headers = [
            {value: "informations", sortable: false},
            {value: "status", sortable: false},
            {value: "name", text: this.$t("key.name"), sortable: false},
            {value: "description", text: this.$t("key.description"), sortable: false},
        ];
        if (this.canUseManagers(this.currentUser?.company)) {
            this.headers.push({value: "keyManagers", text: this.$tc("key.keyManagers", null), sortable: false});
        }
        this.reset();
    }

    private reset(): void {
        if (!this.$route.params?.items?.length || !this.$route.params?.relayId) {
            this.$router.push({name: "keys"});
            return;
        }
        this.currentKeys = JSON.parse(JSON.stringify(this.$route.params.items || {}));
        this.relayId = parseInt(this.$route.params.relayId, 10);
        this.currentKeys.forEach((key) => {
            key.currentValues.relayId = this.relayId;
        });
        this.getCompanyKeysCount();
    }

    private searchCurrentValues(value, search, item) {
        return (
            item?.currentValues?.name?.toLowerCase().includes(search.toLowerCase())
            || item?.currentValues?.description?.toLowerCase().includes(search)
            || item?.currentValues?.keyManagers?.reduce((a, c) => a + c.email, "")?.toLowerCase().includes(search)
        );
    }

    private getChipColor(item: any, manager?: any): string {
        if (item.duplicate) {
            return "grey";
        } else if (manager && !manager.id) {
            return "red";
        } else {
            return "default";
        }
    }

    private getChipTextColor(item: any, manager?: any): string {
        if (item.duplicate) {
            return "grey";
        } else if (!manager?.id && item.importId === undefined) {
            return "red";
        } else {
            return "default";
        }
    }

    private deleteKey(key): void {
        if (confirm(this.$t("key.deleteImportKeyConfirmation").toString())) {
            const pos = this.currentKeys.map((k) => k.importId).indexOf(key.importId);
            this.currentKeys.splice(pos, 1);
        }
    }

    private removeManager(key, manager): void {
        if (confirm(this.$t("user.deleteConfirmation").toString())) {
            const pos = key.currentValues.keyManagers.map((m) => m.email).indexOf(manager.email);
            key.currentValues.keyManagers.splice(pos, 1);
        }
    }

    get canImportKeys() {
        return this.canCreateMoreKeys(
            this.currentUser.company,
            this.companyKeysCount,
            this.keysWithoutDuplicates.length,
        );
    }

    private getCompanyKeysCount() {
        this.$store.dispatch("companies/countKeys", {id: this.currentUser.companyId}).then((res) => {
            this.companyKeysCount = res;
        })
        .catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private importKeys(): void {
        this.currentKeys.forEach((key) => {
            key.currentValues.relayId = this.relayId;
            if (!this.isInsuranceImport) {
                key.currentValues.status = this.keysInRelay.map((k) => k.importId).includes(key.importId)
                    ? "IN_RELAY"
                    : "CREATED";
            } else {
                key.currentValues.status = "WITH_SOMEBODY";
            }
        });
        if (this.canImportKeys) {
            this.saving = true;
            if (!this.isInsuranceImport) {
                this.$store.dispatch("relays/getAvailableLocations", {relayId: this.relayId}).then((res) => {
                    this.availableLocationsCount = res.count;
                    if (this.keysWithoutDuplicates?.length) {
                        if (this.newKeysInRelay?.length <= this.availableLocationsCount) {
                            this.$store.dispatch("keys/import", {keys: this.keysWithoutDuplicates})
                            .then((data) => {
                                if (data.keyLocations?.length) {
                                    this.$router.push({name: "key-locations", params: {data}});
                                } else {
                                    this.$router.push({name: "keys"});
                                }
                            })
                            .catch((err) => {
                                this.saving = false;
                                this.$store.commit("alerts/displayError", {
                                    msg: this.$t("import.key.noFreeLocation"),
                                });
                            });
                        } else {
                            this.saving = false;
                            this.noAvailableLocationsDialog = true;
                        }
                    } else {
                        this.$router.push({name: "keys"});
                    }
                });
            } else {
                this.$store.dispatch("relays/getAvailableReservedLocations", {
                    relayId: this.relayId,
                    companyId: this.company.id,
                }).then((res) => {
                    this.reservedLocationsCount = res.count;
                    if (this.keysWithoutDuplicates?.length) {
                        if (this.keysWithoutDuplicates?.length <= this.reservedLocationsCount) {
                            this.$store.dispatch("keys/import", {keys: this.keysWithoutDuplicates})
                            .then((data) => {
                                this.$router.push({name: "keys"});
                            })
                            .catch((err) => {
                                this.saving = false;
                                this.$store.commit("alerts/displayError", {
                                    msg: this.$t("import.key.noFreeLocation"),
                                });
                            });
                        } else {
                            this.saving = false;
                            this.noReservedLocationsDialog = true;
                        }
                    } else {
                        this.$router.push({name: "keys"});
                    }
                });
            }
        } else {
            this.isRestrictedOn = "maxKeys";
        }
    }

    get connectedUser() {
        return this.$store.state.currentUser;
    }

    private close() {
        this.legendDialog = false;
    }
}
</script>
