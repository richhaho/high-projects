<template>
    <section class="section">
        <v-card>
            <v-card-title>
                {{$t('import.users.title')}} ({{currentUsers.length}})
                <v-dialog
                    persistent
                    max-width="800px" v-model="legendDialog">
                    <template v-slot:activator="{ on }">
                        <v-btn
                                @click="reset()"
                                class="ml-12 mt-1"
                                color="default"
                                text
                                :outlined="true"
                                v-on="on"
                        >
                            {{$t('import.legendTitle')}}
                        </v-btn>
                    </template>
                    <v-card>
                        <v-card-title>
                            <span class="headline">{{$t('import.legendTitle')}}</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container>
                                <v-row>
                                    <v-col align="center" lg="4" class="pa-0">
                                        <v-chip
                                                :outlined="true"
                                                color="red"
                                                text-color="red"
                                        >
                                            {{$t('import.legend.exemple')}}
                                        </v-chip>
                                    </v-col>
                                    <v-col align="center" lg="8" class="pa-0">
                                        <p class="mb-0">{{$t('import.legend.userActive')}}</p>
                                        <p>{{$t('import.legend.infoNotModified')}}</p>
                                    </v-col>
                                </v-row>
                                <v-row>
                                    <v-col align="center" lg="4" class="pa-0">
                                        <v-tooltip bottom>
                                            <template v-slot:activator="{ on }">
                                                <v-chip
                                                :outlined="true"
                                                color="blue"
                                                text-color="blue"
                                                v-on="on"
                                                >
                                                    {{$t('import.legend.exemple')}}
                                                </v-chip>
                                            </template>
                                            <span>Database Value</span>
                                        </v-tooltip>
                                    </v-col>
                                    <v-col align="center" lg="8" class="pa-0">
                                        <p class="mb-0">{{$t('import.legend.userNotActive')}}</p>
                                        <p class="mb-0">{{$t('import.legend.infoUpdated')}}</p>
                                        <p>{{$t('import.legend.databaseValue')}}</p>
                                    </v-col>
                                </v-row>
                                <v-row>
                                    <v-col align="center" lg="4" class="pa-0">
                                        <v-chip
                                                :outlined="true"
                                                close
                                                close-icon="settings_backup_restore"
                                                color="warning"
                                                text-color="warning"
                                        >
                                            {{$t('import.legend.exemple')}}
                                        </v-chip>
                                    </v-col>
                                    <v-col align="center" lg="8" class="pa-0">
                                        <p class="mb-0">{{$t('import.legend.valueModified')}}</p>
                                        <p>{{$t('import.legend.reset')}}</p>
                                    </v-col>
                                </v-row>
                                <v-row>
                                    <v-col align="center" lg="4" class="pa-0">
                                        <v-tooltip bottom>
                                            <template v-slot:activator="{ on }">
                                                <v-chip
                                                :outlined="true"
                                                close
                                                close-icon="settings_backup_restore"
                                                color="warning"
                                                text-color="blue"
                                                v-on="on"
                                                >
                                                    {{$t('import.legend.exemple')}}
                                        </v-chip>
                                            </template>
                                            <span>Database Value</span>
                                        </v-tooltip>
                                    </v-col>
                                    <v-col align="center" lg="8" class="pa-0">
                                        <p class="mb-0">{{$t('import.legend.userNotActive')}}</p>
                                        <p class="mb-0">{{$t('import.legend.valueModified')}}</p>
                                        <p class="mb-0">{{$t('import.legend.infoUpdatedModified')}}</p>
                                    </v-col>
                                </v-row>
                            </v-container>
                        </v-card-text>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn @click="close" color="white" text>{{$t('actions.close')}}</v-btn>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
                <v-spacer></v-spacer>
                <v-text-field
                        append-icon="search"
                        hide-details
                        single-line
                        v-bind:label="$t('actions.search')"
                        v-model="search"
                ></v-text-field>
                <v-spacer></v-spacer>
                <v-btn
                        @click="reset()"
                        class="mt-5 mr-5"
                        color="primary"
                        text
                >
                    {{$t('actions.reset')}}
                </v-btn>
                <v-btn
                        :loading="saving"
                        @click="importUsers()"
                        class="mt-5"
                        color="primary"
                        dark
                >
                    {{$t('actions.save')}}
                </v-btn>
            </v-card-title>
            <v-data-table
                    :headers="headers"
                    :items="currentUsers"
                    disable-pagination
                    hide-default-footer
                    :loading="loading"
                    :search="search"
                    :custom-filter="searchCurrentValues"
                    :no-results-text="$t('user.notFound')"
                    class="elevation-1"
            >
                <template v-slot:item.informations="{ item }">
                    <v-btn icon
                           class="mr-2"
                    >
                        <v-icon
                                @click="deleteUser(item)"
                        >
                            delete
                        </v-icon>
                    </v-btn>
                    <v-tooltip right>
                        <template v-slot:activator="{ on }">
                            <v-icon
                                    :class="JSON.stringify(item.importValues) !== JSON.stringify(item.currentValues) ? 'mr-2' : ''"
                                    color="grey"
                                    v-on="on"
                                    v-show="item.duplicate"
                            >
                                error
                            </v-icon>
                        </template>
                        <span>{{$t('import.userDuplicated')}}</span>
                    </v-tooltip>
                    <v-tooltip right>
                        <template v-slot:activator="{ on }">
                            <v-icon
                                    :class="JSON.stringify(item.importValues) !== JSON.stringify(item.currentValues) ? 'mr-2' : ''"
                                    color="red"
                                    v-on="on"
                                    v-show="!item.duplicate && item.databaseValues && item.databaseValues.activatedAt"
                            >
                                error
                            </v-icon>
                        </template>
                        <span>{{$t('import.userActivated')}}</span>
                    </v-tooltip>
                    <v-tooltip right>
                        <template v-slot:activator="{ on }">
                            <v-icon
                                    :class="JSON.stringify(item.importValues) !== JSON.stringify(item.currentValues) ? 'mr-2' : ''"
                                    color="blue"
                                    v-on="on"
                                    v-show="!item.duplicate && item.databaseValues && !item.databaseValues.activatedAt"
                            >
                                warning
                            </v-icon>
                        </template>
                        <span>{{$t('import.userNotActivated')}}</span>
                    </v-tooltip>
                    <v-tooltip right>
                        <template v-slot:activator="{ on }">
                            <v-btn
                                    color="warning"
                                    icon
                                    v-on="on"
                                    v-show="JSON.stringify(item.importValues) !== JSON.stringify(item.currentValues)"
                            >
                                <v-icon
                                        @click="resetUserProperty(item)"
                                >
                                    settings_backup_restore
                                </v-icon>
                            </v-btn>
                        </template>
                        <span>{{$t('actions.reset')}}</span>
                    </v-tooltip>
                </template>
                <template v-slot:item.firstName="{ item }">
                    <v-edit-dialog
                            :return-value.sync="item.currentValues.firstName"
                    >
                        <v-tooltip
                                top
                                :disabled="getDisabledTooltip(item, 'firstName')"
                        >
                            <template v-slot:activator="{ on }">
                                <v-chip
                                        :color="getChipColor(item, 'firstName')"
                                        :text-color="getChipTextColor(item, 'firstName')"
                                        :outlined="true"
                                        close-icon="settings_backup_restore"
                                        :close="item.importValues.firstName !== item.currentValues.firstName"
                                        @click:close="resetUserProperty(item, 'firstName')"
                                        v-on="on"
                                >
                                    {{item.currentValues.firstName}}
                                </v-chip>
                            </template>
                            <span>{{item.databaseValues ? item.databaseValues.firstName : ''}}</span>
                        </v-tooltip>
                        <template v-slot:input>
                            <v-text-field
                                    :disabled="item.duplicate || item.databaseValues && !!item.databaseValues.activatedAt"
                                    v-model="item.currentValues.firstName"
                                    :rules="[]"
                                    :label="$t('actions.edit')"
                                    single-line
                            ></v-text-field>
                        </template>
                    </v-edit-dialog>
                </template>
                <template v-slot:item.lastName="{ item }">
                    <v-edit-dialog
                            :return-value.sync="item.currentValues.lastName"
                    >
                        <v-tooltip
                                top
                                :disabled="getDisabledTooltip(item, 'lastName')"
                        >
                            <template v-slot:activator="{ on }">
                                <v-chip
                                        :color="getChipColor(item, 'lastName')"
                                        :text-color="getChipTextColor(item, 'lastName')"
                                        :outlined="true"
                                        close-icon="settings_backup_restore"
                                        :close="item.importValues.lastName !== item.currentValues.lastName"
                                        @click:close="resetUserProperty(item, 'lastName')"
                                        v-on="on"
                                >
                                    {{item.currentValues.lastName}}
                                </v-chip>
                            </template>
                            <span>{{item.databaseValues ? item.databaseValues.lastName : ''}}</span>
                        </v-tooltip>
                        <template v-slot:input>
                            <v-text-field
                                    :disabled="item.duplicate || item.databaseValues && !!item.databaseValues.activatedAt"
                                    v-model="item.currentValues.lastName"
                                    :rules="[]"
                                    :label="$t('actions.edit')"
                                    single-line
                            ></v-text-field>
                        </template>
                    </v-edit-dialog>
                </template>
                <template v-slot:item.email="{ item }">
                    <v-edit-dialog
                            :return-value.sync="item.currentValues.email"
                            @save="updateUserInfoByEmail(item)"
                    >
                        <v-chip
                                :close="item.importValues.email !== item.currentValues.email"
                                :text-color="item.duplicate ? 'grey' :
                                            item.databaseValues && item.databaseValues.activatedAt ? 'red' :
                                            item.databaseValues ? 'blue' :
                                            item.importValues.email !== item.currentValues.email ? 'warning' :
                                            'default'"
                                :color="item.duplicate ? 'grey' :
                                        item.importValues.email !== item.currentValues.email ? 'warning' :
                                        item.databaseValues && item.databaseValues.activatedAt ? 'red' :
                                        item.databaseValues ? 'blue' :
                                        'default'"
                                :outlined="true"
                                @click:close="resetUserProperty(item, 'email')"
                                close-icon="settings_backup_restore"
                        >
                            {{item.currentValues.email}}
                        </v-chip>
                        <template v-slot:input>
                            <v-text-field
                                    v-model="item.currentValues.email"
                                    :rules="[rules.email]"
                                    :label="$t('actions.edit')"
                                    single-line
                                    @input="checkDuplicates()"
                            ></v-text-field>
                        </template>
                    </v-edit-dialog>
                </template>
                <template v-slot:item.company="{ item }">
                    <v-edit-dialog
                            :return-value.sync="item.currentValues.company"
                    >
                        <v-tooltip
                                top
                                :disabled="getDisabledTooltip(item, 'company')"
                        >
                            <template v-slot:activator="{ on }">
                                <v-chip
                                        :color="getChipColor(item, 'company')"
                                        :text-color="getChipTextColor(item, 'company')"
                                        :outlined="true"
                                        close-icon="settings_backup_restore"
                                        :close="item.importValues.company !== item.currentValues.company"
                                        @click:close="resetUserProperty(item, 'company')"
                                        v-on="on"
                                >
                                    {{item.currentValues.company}}
                                </v-chip>
                            </template>
                            <span>{{item.databaseValues ? item.databaseValues.company : ''}}</span>
                        </v-tooltip>
                        <template v-slot:input>
                            <v-text-field
                                    :disabled="item.duplicate || item.databaseValues && !!item.databaseValues.activatedAt"
                                    v-model="item.currentValues.company"
                                    :rules="[]"
                                    :label="$t('actions.edit')"
                                    single-line
                            ></v-text-field>
                        </template>
                    </v-edit-dialog>
                </template>
                <template v-slot:item.job="{ item }">
                    <v-edit-dialog
                            :return-value.sync="item.currentValues.job"
                    >
                        <v-tooltip
                                top
                                :disabled="getDisabledTooltip(item, 'job')"
                        >
                            <template v-slot:activator="{ on }">
                                <v-chip
                                        :color="getChipColor(item, 'job')"
                                        :text-color="getChipTextColor(item, 'job')"
                                        :outlined="true"
                                        close-icon="settings_backup_restore"
                                        :close="item.importValues.job !== item.currentValues.job"
                                        @click:close="resetUserProperty(item, 'job')"
                                        v-on="on"
                                >
                                    {{item.currentValues.job}}
                                </v-chip>
                            </template>
                            <span>{{item.databaseValues ? item.databaseValues.job : ''}}</span>
                        </v-tooltip>
                        <template v-slot:input>
                            <v-text-field
                                    :disabled="item.duplicate || item.databaseValues && !!item.databaseValues.activatedAt"
                                    v-model="item.currentValues.job"
                                    :rules="[]"
                                    :label="$t('actions.edit')"
                                    single-line
                            ></v-text-field>
                        </template>
                    </v-edit-dialog>
                </template>
                <template v-slot:item.phone="{ item }">
                    <v-edit-dialog
                            :return-value.sync="item.currentValues.phone"
                    >
                        <v-tooltip
                                top
                                :disabled="getDisabledTooltip(item, 'phone')"
                        >
                            <template v-slot:activator="{ on }">
                                <v-chip
                                        :color="getChipColor(item, 'phone')"
                                        :text-color="getChipTextColor(item, 'phone')"
                                        :outlined="true"
                                        close-icon="settings_backup_restore"
                                        :close="item.importValues.phone !== item.currentValues.phone"
                                        @click:close="resetUserProperty(item, 'phone')"
                                        v-on="on"
                                >
                                    {{item.currentValues.phone}}
                                </v-chip>
                            </template>
                            <span>{{item.databaseValues ? item.databaseValues.phone : ''}}</span>
                        </v-tooltip>
                        <template v-slot:input>
                            <v-text-field
                                    :disabled="item.duplicate || item.databaseValues && !!item.databaseValues.activatedAt"
                                    v-model="item.currentValues.phone"
                                    :rules="[]"
                                    :label="$t('actions.edit')"
                                    single-line
                            ></v-text-field>
                        </template>
                    </v-edit-dialog>
                </template>
            </v-data-table>
        </v-card>
    </section>
</template>
<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";
import {formRules} from "@/utils/formRules";

@Component({
  components: {},
})
export default class PreviewUsers extends Vue {

  private currentUsers: any = [];
  private headers: object[] = [];
  private search: string = "";
  private loading: boolean = false;
  private saving: boolean = false;
  private rules: object = formRules;
  private legendDialog: boolean = false;

  private mounted() {
    this.headers = [
      {value: "informations", sortable: false},
      {value: "firstName", text: this.$t("user.firstName"), sortable: true},
      {value: "lastName", text: this.$t("user.lastName"), sortable: true},
      {value: "email", text: this.$t("user.email"), sortable: true},
      {value: "company", text: this.$t("user.company"), sortable: true},
      {value: "job", text: this.$t("user.job"), sortable: true},
      {value: "phone", text: this.$t("user.phone"), sortable: false},
    ];
    this.reset();
    if (!this.currentUsers || (this.currentUsers && this.currentUsers.length) === 0) {
      this.$router.push({name: "contacts"});
    }
  }

  private reset(): void {
    this.currentUsers = JSON.parse(JSON.stringify(this.$route.params.items));
  }

  // Reset one user property to the import value
  // If no property is specified, reset all user's properties to the import values
  private resetUserProperty(user: any, property?: string): void {
    if (property) {
      user.currentValues[property] = user.importValues[property];
      if (property === "email") {
        this.updateUserInfoByEmail(user);
      }
    } else {
      Object.keys(user.currentValues).forEach((prop) => {
        user.currentValues[prop] = user.importValues[prop];
      });
      this.updateUserInfoByEmail(user);
    }
  }

  // Called when the master edit a user's email inline : check for duplicates email in the import
  private checkDuplicates() {
    const usedMails = this.currentUsers.map((user) => user.currentValues.email);
    this.currentUsers.forEach((user) => {
      user.duplicate = usedMails.indexOf(user.currentValues.email) !== usedMails.lastIndexOf(user.currentValues.email);
      if (user.duplicate) {
        const firstOccurrence = usedMails.indexOf(user.currentValues.email);
        this.currentUsers[firstOccurrence].duplicate = false;
      }
    });
  }

  // Called when the master save a user's email inline : check for the new email backend
  private updateUserInfoByEmail(user: any): void {
    this.checkDuplicates();
    this.$store.dispatch("users/getExistingByEmail", {users: [user.currentValues.email]})
        .then((data) => user.databaseValues = data && data.users && data.users[0]  && data.users[0].userData ?
          data.users[0].userData : null);
  }

  private searchCurrentValues(value, search, item) {
    for (const key of Object.keys(item.currentValues)) {
      if (item.currentValues[key].includes(search)) {
        return true;
      }
    }
    return false;
  }

  private getChipColor(item: any, property: string): string {
    if (item.duplicate) {
      return "grey";
    } else if (item.databaseValues && !!item.databaseValues.activatedAt) {
      return "default";
    } else if (item.currentValues[property] !== item.importValues[property]) {
      return "warning";
    } else if (item.databaseValues && item.databaseValues[property] &&
      item.currentValues[property] !== item.databaseValues[property]) {
      return "blue";
    } else {
      return "default";
    }
  }

  private getChipTextColor(item: any, property: string): string {
    if (item.duplicate) {
      return "grey";
    } else if (item.databaseValues && !!item.databaseValues.activatedAt) {
      return "default";
    } else if (item.databaseValues && !!item.databaseValues[property] &&
      item.currentValues[property] !== item.databaseValues[property]) {
      return "blue";
    } else if (item.currentValues[property] !== item.importValues[property]) {
      return "warning";
    } else {
      return "default";
    }
  }

  private getDisabledTooltip(item: any, property: string): boolean {
    return (
      !(item.databaseValues && !item.databaseValues.activatedAt) ||
      !item.databaseValues[property] ||
      (item.currentValues[property] === item.databaseValues[property])
    );
  }

  private deleteUser(user): void {
    if (confirm(this.$t("user.deleteConfirmation").toString())) {
      const pos = this.currentUsers.map((u) => u.importId).indexOf(user.importId);
      this.currentUsers.splice(pos, 1);
    }
  }

  private importUsers(): void {
    this.saving = true;
    this.$store.dispatch("users/importUsers", {users: this.currentUsers, importType: this.$route.params.importType})
      .then((data) => {
        this.$router.push({name: this.$route.params.importType, params: {data}});
      });
  }

  private close() {
    this.legendDialog = false;
  }
}
</script>
