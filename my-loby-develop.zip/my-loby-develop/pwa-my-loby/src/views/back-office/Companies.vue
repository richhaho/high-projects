<template>
    <v-card>
        <v-card-title>
            {{$t('companies.title')}}
            <v-spacer></v-spacer>
            <v-text-field
                append-icon="search"
                hide-details
                single-line
                v-bind:label="$t('actions.search')"
                v-model="pagination.search"
            ></v-text-field>
        </v-card-title>
        <v-data-table
            :headers="headers"
            :items="rows"
            :loading="loading"
            :options.sync="pagination"
            :search="pagination.search"
            :server-items-length="pagination.totalItems"
            class="elevation-1"
        >
            <template v-slot:header.name="{ header }">
                {{ $t('company.name') }}
            </template>
            <template v-slot:header.siret="{ header }">
                {{ $t('company.siret') }}
            </template>
            <template v-slot:header.siren="{ header }">
                {{ $t('company.siren') }}
            </template>
            <template v-slot:header.createdAt="{ header }">
                {{ $t('company.createdAt') }}
            </template>
            <template v-slot:header.blockedAt="{ header }">
                {{ $t('company.blockedAt') }}
            </template>
            <template v-slot:item.createdAt="{ item }">
                {{item.createdAt | formatDate}}
            </template>
            <template v-slot:item.blockedAt="{ item }">
                <v-btn  v-if="item.blockedAt" color="red" class="v-btn--active text-none" text rounded>
                    {{item.blockedAt | formatDate}}
                </v-btn>
            </template>
            <template v-slot:item.action="{ item }">
                <v-btn
                    icon
                    :to="{ name: 'company-edit' , params: { id: item.id } }"

                >
                    <v-icon
                        small
                    >
                        edit
                    </v-icon>
                </v-btn>
            </template>
        </v-data-table>
    </v-card>
</template>
<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";

@Component({
    components: {},
})
export default class Companies extends Vue {

    private rows: object[] = [];
    private headers: object[] = [
        {value: "name", sortable: true},
        {value: "siret", sortable: true},
        {value: "siren", sortable: true},
        {value: "createdAt", sortable: true},
        {value: "blockedAt", sortable: true},
        {value: "action", sortable: false},
    ];
    private loading: boolean = false;

    private pagination: any = {
        sortDesc: [true],
        sortBy: ["updatedAt"],
        search: "",
        page: 1,
        itemsPerPage: 10,
        totalItems: 10,
    };

    @Watch("pagination", {deep: true})
    public handler() {
        this.getMainData();
    }

    private getMainData() {
        this.loading = true;
        return this.$store.dispatch("companies/read", {query: this.pagination}).then((res) => {
            this.rows = res.rows;
            this.pagination.totalItems = res.count;
            this.loading = false;
        }).catch((err) => {
            this.loading = false;
        });
    }

}
</script>
