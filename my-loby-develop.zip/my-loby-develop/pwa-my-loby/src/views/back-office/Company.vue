<template>
    <v-container v-if="company.id">
        <v-row>
            <v-col cols="2">
                <v-btn
                    class="mb-2"
                    color="grey"
                    text
                    :to="{ name: 'companies' }">
                    <v-icon left>{{arrowBack}}</v-icon>
                    {{$t('actions.back')}}
                </v-btn>
            </v-col>
            <v-col cols="8">
                <v-row justify="center" class="mb-3">
                    <span v-if="company.id">
                         <h2 class="text-center">{{ company.name }}</h2>
                        <v-btn  v-if="company.blockedAt" color="red" class="v-btn--active text-none" text rounded>
                            {{$t('company.blocked')}}{{ company.blockedAt | formatDate}}
                        </v-btn>
                    </span>
                    <h2 v-else>{{$t('company.create')}}</h2>
                </v-row>
            </v-col>
        </v-row>
        <div class="onglets_row">
            <a
                href="#"
                @click.prevent="changeTab('info')"
                :title="$t('company.info')"
                :class="{active: currentTab === 'info'}"
            >
                <div class="onglet">{{$t('company.info')}}</div>
            </a>
            <a
                href="#"
                @click.prevent="changeTab('subscription')"
                :title="$t('company.subscriptions', 0)"
                :class="{active: currentTab === 'subscription'}"
            >
                <div class="onglet">{{$tc('company.subscriptions', 0)}}</div>
            </a>
            <a
                href="#"
                @click.prevent="changeTab('invoicing')"
                :title="$t('company.invoicing')"
                :class="{active: currentTab === 'invoicing'}"
            >
                <div class="onglet">{{$t('company.invoicing')}}</div>
            </a>
        </div>
        <company-info
            v-if="currentTab === 'info'"
            :company="company"
            @edit="edit"
        />
        <company-subscription
            v-if="currentTab === 'subscription'"
            :company="company"
            :subscription="company.currentSubscription"
        />
        <company-invoicing
            v-if="currentTab === 'invoicing'"
            :company="company"
        />
    </v-container>
</template>
<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import { mdiArrowLeftCircle } from "@mdi/js";
import CompanyInfo from "@/components/company/CompanyInfo.vue";
import CompanySubscription from "@/components/company/CompanySubscription.vue";
import CompanyInvoicing from "@/components/company/CompanyInvoicing.vue";
import router from "@/router";

@Component({
    components: {
        CompanyInfo,
        CompanySubscription,
        CompanyInvoicing,
    },
})
export default class Company extends Vue {
    private arrowBack: any = mdiArrowLeftCircle;
    private currentTab: string = "info";
    private company: any = {
        name: "",
        subscription: null,
        type: "",
        activitySector: "",
        siret: "",
        siren: "",
        users: [],
        masterId: undefined,
    };

    private mounted() {
        if (this.$route.params.id) {
            this.getCompany();
        }
    }

    private getCompany() {
        return this.$store.dispatch("companies/readById", {
            id: this.$route.params.id,
            options: {
                master: true,
            },
        }).then((data) => {
            this.company = data;
            this.company.users = [data.master];
            this.company.masterId = data.master.id;
        });
    }

    private async changeTab(tab) {
        if (this.currentTab !== tab) {
            await this.getCompany();
            this.currentTab = tab;
        }
    }

    private edit(company: any) {
        this.$store.dispatch("companies/updateById", {id: company.id, company}).then((res) => {
            router.push({name: "companies"});
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: this.$t(`register.error.${err.response.data.type}`),
            });
        });
    }
}
</script>
