<template>
        <v-container >
            <v-row>
                <v-btn
                        class="mb-2"
                        color="grey"
                        text
                        :to="{ name: 'relays' }">
                    <v-icon left>{{arrowBack}}</v-icon>
                    {{$t('relay.back')}}
                </v-btn>
            </v-row>
            <v-row justify="center">
                <h2 v-if="!relay.type">{{$t('relay.create.default')}}</h2>
                <h2 v-else>{{$t(`relay.create.${relay.type}`)}}</h2>
            </v-row>
            <v-form v-model="valid">
                <v-row justify="center">
                    <v-col cols="3">
                        <v-select
                        v-model="relay.type"
                        item-value="key" item-text="label"
                        :items="relayTypesList"
                        :label="$t('relay.type')+' *'"
                        :rules="[rules.required]"
                    ></v-select>
                    </v-col>
                </v-row>
                <v-row>
                    <v-col>
                        <h2 class="headline">
                            {{$t(`prospect.RELAY.userTitle`)}}
                        </h2>
                        <v-text-field
                                v-model="user.lastName"
                                :rules="[rules.required]"
                                :label="$t('form.lastName')+' *'"
                        ></v-text-field>
                        <v-text-field
                                v-model="user.firstName"
                                :rules="[rules.required]"
                                :label="$t('form.firstName')+' *'"
                        ></v-text-field>
                        <v-text-field
                                v-model="user.company"
                                :rules="[rules.required]"
                                :label="$t('form.company')+' *'"
                        ></v-text-field>
                        <v-text-field
                                v-model="user.job"
                                :label="$t('form.job')"
                        ></v-text-field>
                        <v-text-field
                                v-model="user.phone"
                                :rules="[rules.required]"
                                :label="$t('form.phone')+' *'"
                        ></v-text-field>
                        <v-text-field
                                v-model="user.email"
                                :rules="[rules.required, rules.email]"
                                :label="$t('form.email')+' *'"
                        ></v-text-field>
                        <v-text-field
                                v-model="user.city"
                                :label="$t('form.city')"
                        ></v-text-field>
                    </v-col>
                    <v-col>
                        <h2 class="headline">
                            {{$t(`prospect.RELAY.entityTitle`)}}
                        </h2>
                                <v-text-field
                                        v-model="relay.name"
                                        :rules="[rules.required]"
                                        :label="$t('form.companyName')+' *'"
                                ></v-text-field>
                                <v-text-field
                                        v-model="relay.phone1"
                                        :rules="[rules.required]"
                                        :label="$t('form.companyPhone1')+' *'"
                                ></v-text-field>
                                <v-text-field
                                        v-model="relay.phone2"
                                        :label="$t('form.companyPhone2')"
                                ></v-text-field>
                                <v-text-field
                                        v-model="relay.email"
                                        :rules="[rules.required, rules.email]"
                                        :label="$t('form.companyEmail')+' *'"
                                ></v-text-field>
                                <address-geo
                                    v-bind:address.sync="relay.address"
                                    v-bind:postcode.sync="relay.zipCode"
                                    v-bind:city.sync="relay.city"
                                    v-bind:country.sync="relay.country"
                                    v-bind:latitude.sync="relay.latitude"
                                    v-bind:longitude.sync="relay.longitude"
                                    v-bind:addressdisplayname.sync="relay.addressdisplayname"
                                    :rules="[rules.required]"
                                    :label="$t('form.companyAddress')+' *'"
                                ></address-geo>
                                <v-text-field
                                        v-model="relay.siret"
                                        :rules="[rules.required]"
                                        :label="$t('form.companySiret')+' *'"
                                ></v-text-field>
                    </v-col>
                </v-row>
                <v-divider></v-divider>
                <v-row>
                    <v-col>
                        <v-radio-group
                                :label="$t('relay.storageIsNeededAdmin')"
                                v-model="relay.hasStorage"
                                hide-details
                        >
                            <v-radio name="active" :label="$t('actions.no')" :value="false"></v-radio>
                            <v-radio name="active" :label="$t('actions.yes')" :value="true" checked></v-radio>
                        </v-radio-group>
                    </v-col>
                    <v-col>
                        <p v-if="relay.hasStorage">{{$t('relay.storageOrganization')}}</p>
                        <v-container
                            v-if="relay.hasStorage"
                            v-for="(box, i) in relay.Boxes" :key="i"
                        >
                            <v-row>
                                <p class="mt-2 ml-3">
                                    {{$tc('box.number', i + 1, {number: i + 1})}}
                                </p>
                                <v-spacer></v-spacer>
                                <v-btn
                                    @click="removeOneBox(i)"
                                    icon
                                >
                                    <v-icon>
                                        delete
                                    </v-icon>
                                </v-btn>
                            </v-row>
                            <v-text-field
                                type="number"
                                :label="$t('relay.nbSheet')+' *'"
                                v-model="box.sheets"
                                :rules="[v => relay.hasStorage ? !!v || $t('rules.required') : null]"
                            >
                            </v-text-field>
                            <v-text-field
                                type="number"
                                :label="$t('relay.nbColumn')+' *'"
                                v-model="box.columns"
                                :rules="[v => relay.hasStorage ? !!v || $t('rules.required') : null]"
                            >
                            </v-text-field>
                            <v-text-field
                                type="number"
                                :label="$t('relay.nbRow')+' *'"
                                v-model="box.lines"
                                :rules="[v => relay.hasStorage ? !!v || $t('rules.required') : null]"
                            >
                            </v-text-field>
                        </v-container>
                        <v-btn
                            @click="addOneBox"
                            color="default"
                            class="mb-12"
                            outlined
                            text
                            v-if="relay.hasStorage"
                        >
                            {{$t('box.addOne')}}
                        </v-btn>
                    </v-col>
                </v-row>
                <v-row>
                    <v-subheader>
                        {{$t(`box.${relay.hasStorage ? 'moreLocationsWantedNbr' : 'locationsWantedNbr'}`)}} :
                    </v-subheader>
                    <v-text-field
                        outlined
                        dense
                        type="number"
                        class="mt-1"
                        style="max-width: 100px;"
                        :rules="[rules.positive]"
                        v-model="relay.locationsWanted"
                    />
                </v-row>
                <v-row>
                    <schedule-picker
                        :company-opening-hours="relay.companyOpeningHours"
                    />
                </v-row>
                <v-row justify="center">
                    <v-btn
                        :disabled="!isFormComplete"
                        :loading="loading"
                        outlined
                        @click="createRelay"
                    >
                        {{$t('actions.validate')}}
                    </v-btn>
                </v-row>
            </v-form>
        </v-container>
</template>
<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";
import router from "@/router";
import {formRules} from "@/utils/formRules";
import SchedulePicker from "@/components/SchedulePicker.vue";
import { mdiArrowLeftCircle } from "@mdi/js";
import AddressGeo from "@/components/AddressGeo.vue";

const openingHoursFieldDayFn = (relayType?: string) => {
        switch (relayType) {
            case "LONG_TERM":
                return {
                    isActive: true,
                    continuous: {
                        isActive: true,
                        fromHours: "00:00",
                        toHours: "00:00",
                    },
                    morning: {
                        isActive: false,
                        fromHours: "00:00",
                        toHours: "12:00",
                    },
                    evening: {
                        isActive: false,
                        fromHours: "14:00",
                        toHours: "00:00",
                    },
                };
            default:
                return {
                    isActive: true,
                    continuous: {
                        isActive: true,
                        fromHours: "09:00",
                        toHours: "18:00",
                    },
                    morning: {
                        isActive: false,
                        fromHours: "09:00",
                        toHours: "13:00",
                    },
                    evening: {
                        isActive: false,
                        fromHours: "15:00",
                        toHours: "19:00",
                    },
                };
        }
    };
@Component({
    components: {SchedulePicker, AddressGeo},
})
export default class RelayCreate extends Vue {
    private arrowBack: string = mdiArrowLeftCircle;
    private rules: object = formRules;
    private valid: boolean = true;
    private loading: boolean = false;
    private relay = {
        name: "",
        phone1: "",
        phone2: "",
        email: "",
        address: "",
        zipCode: "",
        city: "",
        country: "",
        latitude: "",
        longitude: "",
        addressdisplayname: "",
        siret: "",
        hasStorage: false,
        Boxes: [
            {
                sheets: null,
                columns: null,
                lines: null,
            },
        ],
        locationsWanted: null,
        sheets: 10,
        columnSheet: 10,
        rowSheet: 10,
        type: "",
        company: "",
        companyOpeningHours: {
            monday: openingHoursFieldDayFn(),
            tuesday: openingHoursFieldDayFn(),
            wednesday: openingHoursFieldDayFn(),
            thursday: openingHoursFieldDayFn(),
            friday: openingHoursFieldDayFn(),
            saturday: openingHoursFieldDayFn(),
            sunday: openingHoursFieldDayFn(),
        },
    };
    private user = {
        firstName: "",
        lastName: "",
        phone: "",
        email: "",
        job: "",
        city: "",
    };

    @Watch("relay.type")
    public handler() {
        Object.keys(this.relay.companyOpeningHours).forEach((day) => {
            this.relay.companyOpeningHours[day] = openingHoursFieldDayFn(this.relay.type);
        });
    }

    get relayTypesList() {
        return [
            {key: "FLOW", label: this.$t("relay.flow")},
            // {key: "AGENCY", label: this.$t("relay.agency")},
            {key: "LONG_TERM", label: this.$t("relay.longTerm")},
        ];
    }

    get isFormComplete(): boolean {
        return this.valid && /^(?=.*[0-9])/.test(this.relay?.address);
    }

    private createRelay() {
        this.loading = true;
        this.$store.dispatch("users/createUser", {user: this.user})
            .then((res) => {
                this.$store.dispatch("relays/createRelay", { relay: this.relay, user: res.user })
                    .then((res) => {
                        this.loading = false;
                        router.push({name: "relays"});
                    })
                    .catch((err) => {
                        this.$store.commit("alerts/displayError", {
                            msg : `register.error.${err.response.data.error}`,
                        });
                    });
            })
            .catch((err) => {
                this.loading = false;
                this.$store.commit("alerts/displayError", {
                    msg : this.$t(`register.error.${err.response.data.type}`),
                });
        });
    }

    private addOneBox() {
        this.relay.Boxes.push({
            sheets: null,
            columns: null,
            lines: null,
        });
    }

    private removeOneBox(i) {
        this.relay.Boxes.splice(i, 1);
    }
}
</script>
