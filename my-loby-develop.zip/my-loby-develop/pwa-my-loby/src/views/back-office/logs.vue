<template>
    <section class="section">
        <log-table
            :logs="logs"
            @get-logs="getLogs"
        />
    </section>
</template>
<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";
import LogTable from "@/components/logs/LogTable.vue";

@Component({
  components: {
      LogTable,
  },
})
export default class AdminLogs extends Vue {

  private logs: any = {};

  private getLogs(params?: any) {
    return this.$store.dispatch("logs/getLogs", {
        query: params,
    })
    .then((res) => {
        this.logs = res;
    });
  }
}
</script>
