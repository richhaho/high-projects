<template>
    <section class="section">
        <v-card>
            <v-card-title>
                {{$t('prospectList.title')}}
                <v-spacer></v-spacer>
                <v-text-field
                        append-icon="search"
                        hide-details
                        single-line
                        v-bind:label="$t('actions.search')"
                        v-model="pagination.search"
                ></v-text-field>
            </v-card-title>
            <v-data-table
                    :headers="headers"
                    :items="prospects"
                    :loading="loading"
                    :options.sync="pagination"
                    :search="pagination.search"
                    :server-items-length="totalProspects"
                    class="elevation-1"
            >
                <template v-slot:header.firstName="{ header }">
                    {{ $t('form.firstName') }}
                </template>
                <template v-slot:header.lastName="{ header }">
                    {{ $t('form.lastName') }}
                </template>
                <template v-slot:header.email="{ header }">
                    {{ $t('form.email') }}
                </template>
                <template v-slot:header.company="{ header }">
                    {{ $t('form.company') }}
                </template>
                <template v-slot:header.job="{ header }">
                    {{ $t('form.job') }}
                </template>
                <template v-slot:header.city="{ header }">
                    {{ $t('form.city') }}
                </template>
                <template v-slot:header.createdAt="{ header }">
                    {{ $t('form.createdAt') }}
                </template>
                <template v-slot:header.type="{ header }">
                    {{ $t('form.type') }}
                </template>
                <template v-slot:item.type="{ item }">
                    <v-chip
                            :color="item.validationDate ? '#10A807' : (item.declinationDate ? '#FF8C00' : '#E6E6E6')"
                    >
                        {{item.type}}
                    </v-chip>
                </template>
                <template v-slot:item.createdAt="{ item }">
                    {{ item.createdAt | formatDate}}
                </template>
                <template v-slot:item.action="{ item }">
                    <v-btn
                            :to="'/admin/prospects/' + item.id"
                            icon
                    >
                        <v-icon
                        >
                            edit
                        </v-icon>
                    </v-btn>
                </template>
            </v-data-table>
        </v-card>
    </section>
</template>
<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";

@Component({
  components: {},
})
export default class AdminLogin extends Vue {

  private prospects: object[] = [];
  private headers: object[] = [
    {value: "firstName", sortable: true},
    {value: "lastName", sortable: true},
    {value: "email", sortable: true},
    {value: "company", sortable: true},
    {value: "job", sortable: true},
    {value: "city", sortable: true},
    {value: "createdAt", sortable: true},
    {value: "type", sortable: true},
    {value: "action", sortable: false},
  ];
  private totalProspects: number = 0;
  private loading: boolean = true;

  private pagination: any = {
    sortDesc: [true],
    sortBy: ["updatedAt"],
    search: "",
    page: 1,
    itemsPerPage: 10,
    rowsPerPageItems: [1, 2, 4, 8, 16],
  };

  @Watch("pagination", { deep: true })
  public handler() {
    this.loading = true;
    this.getProspects().then(() => this.loading = false);
  }

  private getProspects() {
    return this.$store.dispatch("prospects/getAll", {query: this.pagination})
      .then((res) => {
        this.prospects = res.prospects;
        this.totalProspects = res.count;
      });
  }

}
</script>
