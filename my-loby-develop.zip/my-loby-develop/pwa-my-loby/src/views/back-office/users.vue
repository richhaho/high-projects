<template>
    <section class="section">
        <v-card class="mr-5">
            <v-card-title>
                {{$t('usersList.title')}}
                <v-spacer></v-spacer>
                <v-text-field
                        append-icon="search"
                        hide-details
                        single-line
                        v-bind:label="$t('actions.search')"
                        v-model="pagination.search"
                ></v-text-field>
                <v-spacer></v-spacer>
                <v-dialog
                    persistent
                    max-width="500px" v-model="dialog">
                    <template v-slot:activator="{ on }">
                        <v-btn class="mb-2" color="primary" text v-on="on">{{$t('usersList.createUser')}}</v-btn>
                    </template>
                    <v-card>
                        <v-card-title>
                            <span class="headline">{{$t('usersList.newUser')}}</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container>
                                <v-row>
                                    <v-text-field v-bind:label="$t('user.firstName')"
                                                  v-model="currentUser.firstName"></v-text-field>
                                </v-row>
                                <v-row>
                                    <v-text-field v-bind:label="$t('user.lastName')"
                                                  v-model="currentUser.lastName"></v-text-field>
                                </v-row>
                                <v-row>
                                    <v-text-field v-bind:label="$t('user.email')"
                                                  v-model="currentUser.email"></v-text-field>
                                </v-row>
                                <v-row>
                                    <v-text-field v-bind:label="$t('user.password')"
                                                  v-model="currentUser.password"></v-text-field>
                                </v-row>
                            </v-container>
                        </v-card-text>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn @click="close" color="white" text>{{$t('actions.cancel')}}</v-btn>
                            <v-btn
                                @click="createUser"
                                color="warning"
                                v-if="currentUser.email"
                            >{{$t('actions.create')}}</v-btn>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
            </v-card-title>
            <v-data-table
                    :headers="headers"
                    :items="users"
                    :loading="loading"
                    :options.sync="pagination"
                    :search="pagination.search"
                    :server-items-length="pagination.totalItems"
                    class="elevation-1"
            >
                <template v-slot:header.firstName="{ header }">
                    {{ $t('user.firstName') }}
                </template>
                <template v-slot:header.lastName="{ header }">
                    {{ $t('user.lastName') }}
                </template>
                <template v-slot:header.email="{ header }">
                    {{ $t('user.email') }}
                </template>
                <template v-slot:header.createdAt="{ header }">
                    {{ $t('user.createdAt') }}
                </template>
                <template v-slot:header.role="{ header }">
                    <v-row justify="center">
                        {{ $t('user.role') }}
                    </v-row>
                </template>
                <template v-slot:header.activatedAt="{ header }">
                    {{ $t('user.active') }}
                </template>
                <template v-slot:item.role="{ item }">
                    <v-row justify="center">
                        <v-chip
                            :text-color="item.role === 'classic' ? 'black' : 'white'"
                            :color="getRoleColor(item.role)"
                            class="pl-1"
                        >
                            <v-avatar left class="ma-1">
                                <i :class=getRoleIcon(item.role)></i>
                            </v-avatar>
                            {{$t(`usersList.roles.${item.role}`)}}
                        </v-chip>
                    </v-row>
                </template>
                <template v-slot:item.activatedAt="{ item }">
                    <v-chip
                            :color="item.activatedAt ? '#10A807' : '#BABABA'"
                    ></v-chip>
                </template>
                <template v-slot:item.createdAt="{ item }">
                    {{ item.createdAt | formatDate}}
                </template>
                <template v-slot:item.action="{ item }">
                    <v-tooltip top>
                        <template v-slot:activator="{ on }">
                            <v-btn
                                :to="{ name: 'user' , params: { id: item.id } }"
                                icon
                                v-on="on"
                            >
                                <v-icon small>account_box</v-icon>
                            </v-btn>
                        </template>
                        {{$t('usersList.seePage')}}<br>
                    </v-tooltip>
                    <v-tooltip top>
                        <template v-slot:activator="{ on }">
                            <v-btn
                                icon
                                v-if="!item.activatedAt && item.role !== 'demo'"
                                v-on="on"
                            >
                                <v-icon
                                    @click="sendReminder(item)"
                                    small
                                >
                                    email
                                </v-icon>
                            </v-btn>
                        </template>
                        {{$t('usersList.sendReminder')}}<br>
                    </v-tooltip>
                </template>
            </v-data-table>
        </v-card>
    </section>
</template>
<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";

@Component({
  components: {},
})
export default class AdminLogin extends Vue {

  private users: object[] = [];
  private headers: object[] = [
    {value: "firstName", sortable: true},
    {value: "lastName", sortable: true},
    {value: "email", sortable: true},
    {value: "createdAt", sortable: true},
    {value: "role", sortable: false},
    {value: "activatedAt", sortable: true},
    {value: "action", sortable: false},
  ];
  private currentUser: object = {
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    createdAt: "",
  };
  private dialog: boolean = false;
  private loading: boolean = true;

  private pagination: any = {
    sortDesc: [true],
    sortBy: ["updatedAt"],
    search: "",
    page: 1,
    itemsPerPage: 10,
    totalItems: 10,
    rowsPerPageItems: [1, 2, 4, 8, 16],
  };

  @Watch("pagination", { deep: true })
  public handler() {
    this.loading = true;
    this.getUsers().then(() => this.loading = false);
  }

  private reset() {
    this.getUsers();
  }

  private getUserRole(user: any): string {
      if (user.isAdmin) {
          return "admin";
      } else if (user.isDemo) {
          return "demo";
      } else if (user.ManagersRelations?.length) {
          return "master";
      } else if (user.Relays?.length) {
          return "referent";
      } else if (user.companyId) {
          return "manager";
      }
      return "classic";
  }

  private getRoleColor(role: string): string {
      switch (role) {
          case "admin": return "#DD2C00";
          case "demo": return "#FFA726";
          case "master": return "#9575CD";
          case "referent": return "#616161";
          case "manager": return "#42A5F5";
          case "classic": return "default";
          default: return "default";
      }
  }

  private getRoleIcon(role: string): string {
      switch (role) {
          case "admin": return "icon-picto_dossiers-favoris";
          case "demo": return "icon-picto_cartographie";
          case "master": return "icon-picto_company";
          case "referent": return "icon-picto_loby";
          case "manager": return "icon-picto_mes-contacts";
          case "classic": return "icon-picto_cle-partagees";
          default: return "";
      }
  }

  private getUsers() {
    return this.$store.dispatch("users/getUsers", {query: this.pagination})
      .then((res) => {
        this.users = res.users;
        this.users.forEach((user: any) => {
            user.role = this.getUserRole(user);
        });
        this.pagination.totalItems = res.count;
      });
  }

  private createUser() {
    this.$store.dispatch("users/createUser", {user: this.currentUser})
      .then((res) => {
        this.reset();
        this.close();
      });
  }

  private sendReminder(user) {
    if (confirm(this.$t("user.sendValidationEmail").toString())) {
        this.$store.dispatch("auth/forgottenPasswordFn", {email: user.email})
        .then((res) => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$t("user.validationMailSent") + user.email,
            });
        });
    }
  }

  private close() {
    this.dialog = false;
  }
}
</script>
