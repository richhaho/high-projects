<template>
    <div class="main-content-display">
        <div class="middle_part flex-grow-1">
            <div class="mots_cles">{{$t('payment.title')}}</div>
            <div class="tableau">
                <div class="options">
                    <div class="option_left">
                    </div>
                    <div class="option_right">
                        <button
                            type="button"
                            class="option"
                            @click="printPayments"
                            :title="$t('actions.print')"
                        >
                            <i class="icon-picto_factures"></i>
                            {{$t('actions.print')}}
                        </button>
                    </div>
                </div>
                <v-data-table
                    :headers="headers"
                    :items="payments"
                    :loading="loading"
                    :options.sync="pagination"
                    :server-items-length="totalItems"
                    :no-data-text="$t('payment.noData')"
                    class="printable-section"
                >
                    <template v-slot:header.createdAt="{ header }">{{ $t('payment.date') }}</template>
                    <template v-slot:header.status="{ header }">{{ $t('payment.status.title') }}</template>
                    <template v-slot:header.key="{ header }">{{ $t('payment.key') }}</template>
                    <template v-slot:header.subscription="{ header }">{{ $t('payment.subscription') }}</template>
                    <template v-slot:header.paymentMethod="{ header }">{{ $t('payment.paymentMethod') }}</template>
                    <template v-slot:header.amount="{ header }">{{ $t('payment.amount') }}</template>
                    <template v-slot:item.createdAt="{ item }">
                        {{ item.createdAt | formatShortDate }}
                    </template>
                    <template v-slot:item.status="{ item }">
                        <v-chip
                            :color="getStatusColor(item.status)"
                            class="pl-2 pr-3"
                            small
                            text-color="white"
                        >
                            <v-icon
                                class="mr-1"
                                small
                            >
                                {{ getStatusIcon(item.status) }}
                            </v-icon>
                            {{ $t(`payment.status.${item.status}`) }}
                        </v-chip>
                    </template>
                    <template v-slot:item.key="{ item }">
                        {{ item.Subscription && item.Subscription.Key ? item.Subscription.Key.name : null}}
                    </template>
                    <template v-slot:item.subscription="{ item }">
                        {{ item.Subscription && item.Subscription.Plan.name ? $t(`plan.${item.Subscription.Plan.name}.name`) : null}}
                    </template>
                    <template v-slot:item.paymentMethod="{ item }">
                        <span v-if="item.Subscription && item.Subscription.PaymentMethod">
                            {{ item.Subscription.PaymentMethod.cardNumber }}
                        </span>
                        <v-chip
                            v-else
                            small
                            outlined
                        >
                            {{ $t("actions.deleted") }}
                        </v-chip>
                    </template>
                    <template v-slot:item.amount="{ item }">
                        {{ item.amount }} {{$t('currency.symbol')}}
                    </template>
                </v-data-table>
            </div>
        </div>
        <div class="right_part mb-7">
        </div>
    </div>
</template>
<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";
import {Getter} from "vuex-class";

@Component
export default class BillingActivity extends Vue {
    @Getter private currentUser: any;

    private payments: any[] = [];
    private headers: object[] = [
        {value: "createdAt", sortable: false},
        {value: "status", sortable: false},
        {value: "key", sortable: false},
        {value: "subscription", sortable: false},
        {value: "paymentMethod", sortable: false},
        {value: "amount", sortable: false},
    ];
    private pagination: any = {
        page: 1,
        itemsPerPage: 15,
    };
    private totalItems: number = 0;
    private loading: boolean = false;

    @Watch("pagination", { deep: true })
    public handler(): void {
        this.getPayments();
    }

    private getPayments(): Promise<any> {
        this.loading = true;
        return this.$store.dispatch("users/getPayments", {
            userId: this.currentUser.id,
            query:  this.pagination,
        }).then((res: { rows: any[], count: number }) => {
            this.totalItems = Number(res?.count);
            this.payments = res?.rows || [];
            this.loading = false;
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private printPayments() {
        // to print all payments
        this.pagination.itemsPerPage = -1;
        this.getPayments().then(() =>  window.print());

    }

    private getStatusColor(status: string): string {
        switch (status) {
            case "CREATED": return "blue";
            case "PAID": return "green";
            case "ERROR": return "red";
            default: return "default";
        }
    }

    private getStatusIcon(status: string): string {
        switch (status) {
            case "CREATED": return "send";
            case "PAID": return "check";
            case "ERROR": return "priority_high";
            default: return "";
        }
    }
}
</script>