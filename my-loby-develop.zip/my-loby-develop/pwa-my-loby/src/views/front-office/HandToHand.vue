<template>
    <v-container>
        <qr-code-reader
            action="HAND_TO_HAND"
            :read-qr-code="readQRCode"
            :display-qr-code-reader-modal="true"
            :mobile="true"
            :location="key.currentLocation"
            :key-picture ="key.picturePath"
            :key-description = "key.description"
            :qr-code-error="qrCodeReaderError"
            @close="$router.push({name: 'keys'})"
        />
    </v-container>
</template>
<script lang="ts">
import {Component, Prop, Vue} from "vue-property-decorator";
import QrCodeReader from "@/components/QrCodeReader.vue";

@Component({
    components: {QrCodeReader},
})
export default class HandToHand extends Vue {
    private keyId: number = null;
    private token: string = null;
    private key: any = {};
    private qrCodeReaderError: any = null;

    private mounted() {
        this.keyId = Number(this.$route.params.keyid);
        this.token = this.$route.params.token;
        this.getKeyById();
    }

    private readQRCode(token) {
        this.qrCodeReaderError = null;
        return this.$store.dispatch("keys/recoverHandToHand", {token, keyId: this.keyId}).then((res) => {
            if (res.status === "OK") {
                this.$store.commit("alerts/displaySuccess", {
                    iconGroup: "icon-picto_recevoir-main-a-main",
                    msg: this.$i18n?.t("alerts.key.retrieveSuccess", {key: this.key.name}),
                });
                this.$router.push({name: "keys"});
            } else {
                this.$store.commit("alerts/displayError", {
                    iconGroup: "icon-picto_recevoir-main-a-main",
                    msg: this.$i18n?.t(`alerts.error.${res.status}`),
                });
                this.$router.push({name: "keys"});
            }
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private getKeyById() {
        return this.$store.dispatch("keys/getById", {
            id: this.keyId,
            options: {
                picture: true,
            },
        })
        .then((key) => {
            this.key = key;
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

}
</script>
