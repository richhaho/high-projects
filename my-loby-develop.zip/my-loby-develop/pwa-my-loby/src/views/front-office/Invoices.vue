<template>
    <div class="main-content-display invoices-view">
        <div class="middle_part">
            <div class="mots_cles">{{$t(`nav.invoices`)}}</div>
            <div class="row" v-if="invoices.length">
                <div class="col-md-6" v-for="invoice in displayedInvoices" :key="invoice.id">
                    <div class="tableau">
                        <div class="equipement_details">
                            <i class="icon-picto_mosaique"></i>
                            <p>
                                <strong class="w-auto">
                                    {{$t('invoices.invoice')}}
                                    N°{{invoice.invoiceNumber || invoice.customerInvoiceNumber}}
                                </strong>
                            </p>
                            <p>
                                <strong class="w-auto">{{$t('invoices.billingPeriod')}}</strong>
                                : {{$t('invoices.from')}}
                                {{invoice.startDate | formatDateDay }}
                                {{$t('invoices.to')}}
                                {{invoice.endDate | formatDateDay}}
                            </p>
                            <p>
                                <strong class="w-auto">{{$t('invoices.totalAmount')}}</strong>
                                : {{ $t("currency.price", {price: invoice.totalPrice}) }}
                            </p>
                            <p v-if="invoice.dueDate">
                                <strong class="w-auto">{{$t('invoices.dueDate')}}</strong>
                                : {{invoice.dueDate | formatDateDay}}
                            </p>
                            <a
                                :href="getSrc(invoice.pdfPath)"
                                target="_blank"
                                class="lien btn_style no_picto"
                            >
                                {{$t('invoices.seeThePdf')}}
                            </a>
                        </div>
                        <!-- /.equipement_details -->
                    </div>
                    <!-- /.tableau -->
                </div>
                <!-- /.col-md-6 -->
            </div>
            <div v-else class="text-center">
                <p>
                    {{$t('invoices.nothingYet')}}
                </p>
            </div>
            <!-- /.row -->
            <div class="text-center mt-5">
                <button
                    v-if="maxInvoicesDisplayed && invoices.length > maxInvoicesDisplayed"
                    @click="displayAllInvoices"
                    class="btn_style no_picto"
                >
                    {{$t('invoices.displayAll')}}
                </button>
            </div>
        </div>
        <div class="right_part p-0">
        </div>
    </div>
</template>
<script lang="ts">
import {Component, Vue} from "vue-property-decorator";
import {getSrc} from "@/utils/misc";

export const MAX_INVOICES_AT_FIRST: number = 4;

@Component({})
export default class Invoices extends Vue {
    private entityId: number = null;
    private invoiceType: string = null;
    private invoices: object[] = [];
    private maxInvoicesDisplayed: number = MAX_INVOICES_AT_FIRST;
    private getSrc: (string) => string = getSrc;

    get displayedInvoices() {
        return this.maxInvoicesDisplayed
            ? this.invoices.slice(0, this.maxInvoicesDisplayed)
            : this.invoices;
    }

    private mounted() {
        this.invoiceType = this.$route.path.split("/")?.[1];
        this.reset();
    }

    private reset() {
        this.entityId = Number(this.$route.params.id);
        this.getInvoices();
    }

    private getInvoices() {
        return this.$store.dispatch(`${this.invoiceType}/getInvoices`, {id: this.entityId}).
            then((invoices) => {
                this.invoices = invoices.rows;
            }).
            catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err,
                });
            });
    }

    private displayAllInvoices() {
        this.maxInvoicesDisplayed = 0;
    }
}
</script>