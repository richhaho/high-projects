<template>
    <div class="main-content-display key-view">
        <div v-if="fullScreen" class="fullScreen">
            <img :src="getSrc(key.picturePath)+'?timestamp='+timestampKeyImage || defaultKeyPicture"
                style="object-fit: cover" alt="key picture"/>
            <div class="darkBanner">
                <button class="topRight" v-on:click="fullScreen = false"> {{ $t('actions.close') }}</button>
            </div>
        </div>
        <div class="middle_part">
            <router-link :to="{name: 'keys', params: {tab: 'myKeys'}}" :title="$t('keysList.myKeys')"
                         class="fil_arianne" v-if="isAdmin ||  isManager(currentUser,key)">
                <i class="icon-picto_retour"></i>
                {{ $t('keysList.myKeys') }} | {{ key.name }}
            </router-link>
            <router-link :to="{name: 'keys', params: {tab: 'sharedKeys'}}" :title="$t('keysList.sharedKeys')"
                         class="fil_arianne" v-else>
                <i class="icon-picto_retour"></i>
                {{ $t('keysList.sharedKeys') }} | {{ key.name }}
            </router-link>
            <div class="onglets_row">
                <a :title="$t('key.key')" class="active">
                    <div class="onglet">{{ $t('key.key') }}</div>
                </a>
            </div>

            <v-dialog
                persistent
                v-if="isManager(currentUser, key) || isAdmin"
                v-model="editKeyInfoDialog"
                width="910px"
            >
                <v-card>
                    <v-form v-model="validEditKeyInfoForm">
                        <v-card-title>
                            <span class="headline">{{ $t('actions.edit') }}</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container>
                                <v-row>
                                    <v-img
                                        v-if="uploadedImageSrc || getSrc(key.picturePath)"
                                        :src="uploadedImageSrc || getSrc(key.picturePath)"
                                        alt="uploadedImage"
                                        style="object-fit: cover; height: 80px; max-width: 80px; border-radius: 50%;"
                                    >
                                        <template v-slot:placeholder>
                                            <v-row align="center" class="fill-height ma-0" justify="center">
                                                <v-progress-circular color="grey" indeterminate></v-progress-circular>
                                            </v-row>
                                        </template>
                                    </v-img>
                                    <v-file-input
                                        class="pa-5"
                                        :label="$t('key.picture')"
                                        :placeholder="$t('user.uploadImage')"
                                        @change="fileChange"
                                        accept="image/png, image/jpeg, image/bmp ,image/heif, image/heic"
                                        prepend-icon="photo"
                                        v-model="avatar"
                                    ></v-file-input>
                                </v-row>
                                <v-row>
                                    <v-text-field
                                        v-bind:label="$t('key.name')"
                                        v-model="key.name"
                                    ></v-text-field>
                                </v-row>
                                <v-row>
                                    <v-text-field
                                        v-bind:label="$t('key.description')"
                                        v-model="key.description"
                                    ></v-text-field>
                                </v-row>
                                <v-row>
                                    <span>Tags</span>
                                    <v-col cols="12 pa-0" v-if="key.newTags && key.newTags.length > 0">
                                        <v-chip-group
                                            active-class="primary--text"
                                            column
                                            multiple
                                        >
                                            <v-chip :key="i"
                                                    @click:close="removeTags(tag)"
                                                    :close="true"
                                                    v-for="(tag, i) in key.newTags"
                                            >
                                                {{ tag[lang] }}
                                            </v-chip>
                                        </v-chip-group>
                                    </v-col>
                                    <v-col cols="12 pa-0">
                                        <v-autocomplete
                                            :search-input.sync="searchTags"
                                            v-model="key.newTags"
                                            :items="removeTagDuplicates(tags, key.newTags)"
                                            multiple
                                            append-icon
                                            hide-no-data
                                            no-filter
                                            chips
                                            prepend-inner-icon="flag"
                                            :label="$t('keysList.addTags')"
                                        >
                                            <template v-slot:selection="data">
                                            </template>
                                            <template v-slot:item="data">
                                                <v-list-item-content>
                                                    <v-list-item-title>{{ data.item[lang] }}</v-list-item-title>
                                                </v-list-item-content>
                                            </template>
                                        </v-autocomplete>
                                    </v-col>
                                </v-row>
                                <v-row cols="12 pa-0">
                                    <v-autocomplete
                                        :item-text="itemStringified"
                                        item-value="id"
                                        :items="isKeyB2B ? agencyRelays : flowRelays"
                                        :search-input.sync="searchAllRelays"
                                        :loading="loadingRelays"
                                        append-icon
                                        flat
                                        :no-data-text="$t('keysList.noRelayFound')"
                                        prepend-icon="near_me"
                                        solo
                                        hide-details
                                        :readonly="currentRelay(key) && currentRelay(key).id === key.relayId"
                                        :clearable="!currentRelay(key) || currentRelay(key).id !== key.relayId"
                                        v-bind:label="$t('actions.search')"
                                        v-model="key.relayId"
                                    >
                                        <template v-slot:selection="data">
                                            <v-list-item-content style="overflow: initial;">
                                                <v-list-item-title
                                                    v-html="data.item.name">
                                                </v-list-item-title>
                                                <v-list-item-subtitle
                                                    v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city">
                                                </v-list-item-subtitle>
                                            </v-list-item-content>
                                        </template>
                                        <template v-slot:item="data">
                                            <v-list-item-content :aria-disabled="!data.item.available">
                                                <v-list-item-title
                                                    v-html="data.item.name">
                                                </v-list-item-title>
                                                <v-list-item-subtitle
                                                    v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city">
                                                </v-list-item-subtitle>
                                            </v-list-item-content>
                                        </template>
                                    </v-autocomplete>
                                </v-row>
                            </v-container>
                        </v-card-text>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn
                                @click="close"
                                color="white"
                                text
                            >
                                {{ $t('actions.cancel') }}
                            </v-btn>
                            <v-btn
                                v-if="key.Relays && key.name && validEditKeyInfoForm"
                                :disabled="!key.Relays && !key.name"
                                @click="saveKey(key, {info: true, relays: true})"
                                color="warning"
                                :loading="loadingKey"
                            >
                                {{ $t('actions.save') }}
                            </v-btn>
                        </v-card-actions>
                    </v-form>
                </v-card>
            </v-dialog>

            <restriction-dialog
                v-if="currentUser && currentUser.companyId"
                @close="isRestrictedOn = null"
                :type="isRestrictedOn"
            />

            <div class="tableau" id="main_details">
                <div class="options">
                    <div class="option_left">
                        <p class="light_text">{{ $t('key.createdOn') }}: {{ key.createdAt | formatDate }}</p>
                    </div>
                    <!-- /.option_left -->
                    <div class="option_right">
                        <button
                            type="button"
                            v-if="isManager(currentUser, key) || isAdmin"
                            class="option open_popup"
                            @click="editKeyInfoDialog = true"
                            :disabled="(!isAdmin && isCompanyBlocked(key)) || isArchived"
                        >
                            <i class="icon-picto_editer"></i>
                            {{ $t('actions.edit') }}
                        </button>
                        <key-archive
                            v-if="hasArchiveRight"
                            :update-data="reset"
                            :current-key="key"
                        />
                        <!-- /.option -->
                    </div>
                    <!-- /.option_right -->
                </div>
                <!-- /.options -->
                <v-row class="mx-0">
                    <v-col :cols="12" :md="4" class="profil_infos">
                        <div class="numero_cle_mission">
                            <div v-on:click="fullScreen = true">
                                <image-key-renderer :key="componentKey" :picturePath="key.picturePath ? key.picturePath+'?timestamp='+timestampKeyImage : this.avatar" />
                            </div>
                            <div>
                                <p class="mb-2">
                                    <strong>{{ key.name }}</strong><br>
                                    {{ $t('key.status') }} :
                                    <key-status :currentKey="key" v-if="key"/>
                                </p>
                                <p v-if="key.locationDisplayed && isAdmin">
                                    {{ $tc('box.locations', 1) }} :
                                    <v-btn
                                        class="ml-2"
                                        :href="$store.state.baseURL ? `${$store.state.baseURL}/api/locations/${key.locationDisplayed.id}/generate-qr-code` :
                            `/locations/${key.locationDisplayed.id}/generate-qr-code`"
                                        outlined
                                        small
                                        target="_blank"
                                    >
                                        {{ displayCodeName(key) }}
                                    </v-btn>
                                </p>
                                <p v-else-if="key.locationDisplayed && !key.connectedBoxLocker">
                                    {{ $tc('box.locations', 1) }} n°{{ displayCodeName(key) }}
                                </p>
                                <p v-else-if="key.locationDisplayed && key.connectedBoxLocker">
                                    {{ $tc('box.locations', 1) }} n°{{ key.connectedBoxLocker }}
                                </p>
                                <div v-if="key.estimatedEndDate">
                                    <v-alert
                                        class="pa-1 my-0"
                                        :color="lateKey(key.estimatedEndDate) || endCountdown ? 'red' : 'blue'"
                                        dense
                                        outlined
                                        text
                                    >
                                        <p
                                            v-if="!lateKey(key.estimatedEndDate) && !endCountdown"
                                            class="px-2 my-0 subtitle-2"
                                        >
                                            {{$t('countDown.remaining')}} :
                                            <vue-countdown-timer
                                                :start-time="getTime()"
                                                :end-time="getTime(key.estimatedEndDate)"
                                                :interval="1000"
                                                @end_callback="endCountdown = true"
                                            >
                                                <template slot="countdown" slot-scope="scope">
                                                    <v-row justify="center">
                                                        <b>
                                                            {{showDays(key.estimatedEndDate) ? scope.props.days + ":" : ""}}{{scope.props.hours}}:{{scope.props.minutes}}:{{scope.props.seconds}}
                                                        </b>
                                                    </v-row>
                                                </template>
                                            </vue-countdown-timer>
                                        </p>
                                        <p
                                            v-else
                                            class="px-2 my-0 subtitle-2"
                                        >
                                            {{$t('countDown.late')}} {{ getDifference(key.estimatedEndDate) }}
                                        </p>
                                    </v-alert>
                                    <v-row justify="center">
                                        <div class="option_right mt-3" v-if="isCurrentUserHolder || isManager(currentUser, key)">
                                            <button type="button"
                                                    @click="displayChooseHour = true"
                                                    class="option"
                                                    :title="$t('key.extendHoldingDuration')">
                                                <i class="icon-picto_ajouter"></i>
                                                {{ $t('key.extendHoldingDuration') }}
                                            </button>
                                        </div>
                                    </v-row>
                                    <key-returning-date
                                        ref="returningDate"
                                        :displayChooseHour="displayChooseHour"
                                        v-if="displayChooseHour"
                                        :initalDate="key.estimatedEndDate"
                                        @validTime="validateTime"
                                        @cancel="displayChooseHour = false"
                                    />
                                </div>
                            </div>
                        </div>
                    </v-col>
                    <v-col :cols="12" :md="8" class="more_infos">
                        <p v-if="key.description">{{key.description}}</p>
                        <v-row v-if="isKeyBooked(key)">
                            <v-alert
                                dense
                                text
                                color="warning"
                                :title="`${$t('booking.keyIsBooked.descriptionDate')} ${currentKeyBooking}`"
                            >
                                <v-icon small>lock</v-icon>
                                {{$t('booking.keyIsBooked.mobileTitle')}}
                            </v-alert>
                        </v-row>
                        <v-row v-if="isCompanyBlocked(key)">
                            <v-alert
                                dense
                                text
                                color="error"
                            >
                                {{$t('key.blocked')}}
                            </v-alert>
                        </v-row>
                        <v-row v-if="isArchived">
                            <v-alert
                                dense
                                text
                                color="warning"
                            >
                                {{$t(archivedText)}}
                            </v-alert>
                        </v-row>
                        <v-row v-if="key.hasAllRights">
                            <v-alert
                                dense
                                text
                                color="success"
                            >
                                {{$t('key.unblocked')}}
                            </v-alert>
                        </v-row>
                        <v-row v-if="isAdmin">
                            <change-status
                                :currentKey="key"
                                :update-data="reset"
                            />
                            <key-unblock
                                v-if="key.archivedAt && !isKeyB2B && !isKeyInsurance"
                                :update-data="reset"
                                :current-key="key"
                            />
                        </v-row>
                        <v-row v-else-if="connectedUserHasKeyAccess(key, currentUser)">
                            <key-withdraw
                                class="mb-2"
                                :currentKey="key"
                                :disabled="isCompanyBlocked(key) || isArchived"
                                :update-data="reset"
                            />
                            <key-withdraw-connected
                                class="mb-2"
                                :currentKey="key"
                                :disabled="isCompanyBlocked(key) || isArchived"
                                :update-data="reset"
                            />
                            <key-drop-agency
                                class="mb-2"
                                :currentKey="key"
                                :disabled="isCompanyBlocked(key) || isArchived"
                                :update-data="reset"
                            />
                            <key-drop-connected
                                class="mb-2"
                                :currentKey="key"
                                :disabled="isCompanyBlocked(key) || isArchived"
                                :update-data="reset"
                            />
                            <hand-to-hand
                                class="mb-2"
                                :currentKey="key"
                                :disabled="isCompanyBlocked(key) || isArchived"
                                :update-data="reset"
                            />
                            <receive-key
                                class="mb-2"
                                :currentKey="key"
                                :disabled="isCompanyBlocked(key) || isArchived"
                                :update-data="reset"
                            />
                            <key-drop-my-loby
                                v-if="(!isKeyB2B && !isKeyInsurance) || (keyAdditionalRelays && keyAdditionalRelays.length  > 0)"
                                class="mb-2"
                                :currentKey="key"
                                :disabled="isCompanyBlocked(key) || isArchived"
                                :update-data="reset"
                            />
                            <key-transit
                                class="mb-2"
                                :currentKey="key"
                                :disabled="isCompanyBlocked(key) || isArchived"
                                :update-data="reset"
                            />
                            <key-retrieve
                                class="mb-2"
                                :currentKey="key"
                                :disabled="isCompanyBlocked(key) || isArchived"
                                :update-data="reset"
                            />
                        </v-row>
                        <div class="tags mt-5" v-if="key.Tags && key.Tags.length > 0">
                            <span class="strong mr-2">Tags :</span>
                            <button type="button" v-for="(tag,i) in key.Tags" :key="i">{{tag[lang]}}</button>
                        </div>
                    </v-col>
                </v-row>
            </div>
            <!-- /.tableau -->
            <key-subscription
                v-if="!isKeyB2B && (isManager(currentUser, key) || isAdmin)"
                :currentKey="key"
                @reset="reset"
            />
            <p class="tableau_titre">
                {{$tc('key.keyManagers', 0)}}
                <a @click.prevent="displayKeyManagers = !displayKeyManagers" :title="$t('actions.openClose')"
                   class="toggle_action"
                   :class="{'open' : !displayKeyManagers}">
                    <i class="icon-angle"></i>
                </a>
            </p>
            <v-dialog
                persistent
                v-if="(isMaster() && canManageUser) || isAdmin || isManager(currentUser, key)"
                v-model="addManager"
                width="910px"
            >
                <v-card>
                    <v-card-title>
                        <span class="headline">{{$t('key.addManagers')}}</span>
                    </v-card-title>
                    <v-card-text>
                        <v-container>
                            <key-managers-autocomplete
                                :currentKey="key"
                                :edit="true"
                                :disableDelete="true"
                                @save="saveKey">
                            </key-managers-autocomplete>
                        </v-container>
                    </v-card-text>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn
                            :disabled="!key.newKeyManagers || !key.newKeyManagers.length "
                            @click="saveKey(key,{newKeyManagers: true})"
                            color="warning"
                        >
                            {{$t('actions.save')}}
                        </v-btn>
                        <v-btn
                            @click="addManager = false, key.newKeyManagers = []"
                            color="white"
                            text
                        >
                            {{$t('actions.cancel')}}
                        </v-btn>
                    </v-card-actions>
                </v-card>
            </v-dialog>
            <v-expand-transition>
                <div id="tableau_responsable" class="tableau" v-if="displayKeyManagers">
                    <div class="options" v-if="isMaster() || isAdmin || isManager(currentUser, key)">
                        <div class="option_left">
                            <!-- /.option -->
                        </div>
                        <!-- /.option_left -->
                        <div class="option_right">
                            <button type="button"
                                    v-if="isManager(currentUser, key) || isAdmin"
                                    :disabled="!isAdmin && (isCompanyBlocked(key) || isArchived)"
                                    @click="openAddManagerModal()"
                                    class="option"
                                    :title="$t('key.addManagers')"
                            >
                                <i class="icon-picto_ajouter"></i>
                                {{$t('key.addManagers')}}
                            </button>
                            <!-- /.option -->
                        </div>
                        <!-- /.option_right -->
                    </div>
                    <!-- /.options -->
                    <v-data-table
                        :headers="keyManagersHeaders"
                        :expanded.sync="expandedManager"
                        :items="uniqueKeyManagers"
                        :loading="loadingKeyManagers"
                        :options.sync="keyManagersPagination"
                        :search="keyManagersPagination.search"
                        :server-items-length="keyManagersPagination.totalItems"
                        :show-expand="isManager(currentUser, key) || isAdmin"
                        class="elevation-1"
                        :hide-default-footer="key.keyManagers &&key.keyManagers.length < 10"
                        item-key="key"
                    >
                        <template v-slot:item.name="{ item }">
                            <div
                                v-if="item.name || item.Users[0]"
                            >
                                {{ item.name || item.Users[0].displayName }}
                            </div>
                        </template>
                        <template v-slot:item.profile="{ item }">
                            <span v-if="isOwnerInGroup(item, key)">{{$t('key.owner')}}</span>
                            <span v-else-if="item.creatorId">{{$t('key.managersGroup')}}</span>
                            <span v-else>{{$t('key.manager')}}</span>
                        </template>
                        <template v-slot:item.keyGroupName="{ item }">
                            <custom-chip-link
                                v-if="item.keyGroupName"
                                type="keyGroup"
                                :id="item.keyGroupId"
                                :text="item.keyGroupName"
                            />
                            <p v-else>
                                -
                            </p>
                        </template>
                        <template v-slot:expanded-item="{ item }" >
                            <td colspan="5">
                                <v-row class="content" v-if="item.type === 'subordinates'">
                                    <div class="d-flex justify-space-between">
                                        <user-list-avatar
                                            :users="item.Users"
                                        />
                                    </div>
                                </v-row>
                                <v-row class="content">
                                    <p>
                                        {{$t('key.managerCreatedAt')}}
                                        {{item.invitations[0].keyAccess.createdAt | formatDate }}
                                    </p>
                                </v-row>
                            </td>
                        </template>
                        <template v-slot:item.action="{ item }">
                            <v-btn
                                @click="item.keyGroupName ? confirmDeleteFromKeyGroup(item) : removeManager(item)"
                                icon
                                v-if="(isMaster() || isManager(currentUser, key)) && !isOwnerInGroup(item, key) && !isHolderInGroup(item, key) && !isCompanyBlocked(key) && !isArchived"
                            >
                                <v-icon
                                    small
                                >
                                    delete
                                </v-icon>
                            </v-btn>
                        </template>
                    </v-data-table>
                </div>
            </v-expand-transition>

            <simple-dialog
                :dialog="deleteFromKeyGroupConfirmationDialog"
                :title="$t('keysList.deleteManager')"
                :text="$t('keysList.deleteManagerFromGroupConfirm', {keyGroup: deletedManager.keyGroupName})"
                :actions="['cancel', 'confirm']"
                @cancel="closeDeleteConfirmationDialog"
                @confirm="removeManager(deletedManager)"
            />

            <p class="tableau_titre">
                {{ $tc('key.guests', 0) }}
                <a class="toggle_action"
                   @click.prevent="displayGuests = !displayGuests"
                   :title="$t('actions.openClose')"
                   :class="{'open': !displayGuests}">
                    <i class="icon-angle"></i>
                </a>
            </p>
            <v-expand-transition>
                <div id="invities" v-if="displayGuests" class="tableau">
                    <!-- Add guest modal -->
                    <v-dialog
                        persistent
                        v-if="isManager(currentUser, key) || isAdmin"
                        v-model="addGuest"
                        width="910px"
                    >
                        <v-card>
                            <v-card-title>
                                <span class="headline">{{ $t('keysList.addGuest') }}</span>
                            </v-card-title>
                            <v-card-text>
                                <v-container>
                                    <key-guests-autocomplete
                                        :currentKey="key"
                                        :edit="true"
                                        ref="keyGuestsAutocomplete"
                                        @invitation-change="updateIsAddButtonStatus"
                                        @save="saveKey(key, {
                                            newGuests: true,
                                            acceptOverPrice: false,
                                            noreset: !!key.newGuests[0].phone
                                        })">
                                    </key-guests-autocomplete>
                                </v-container>
                            </v-card-text>
                            <v-card-actions>
                                <v-spacer></v-spacer>
                                <v-btn
                                    @click="addGuest = false"
                                    color="white"
                                    text
                                >
                                    {{ $t('actions.cancel') }}
                                </v-btn>
                                <v-btn
                                    @click="addGuestFunction()"
                                    v-if="isAddButtonEnabled || loadingAddGuest || acceptOverPrice"
                                    :loading="loadingAddGuest"
                                    color="primary"
                                >
                                    {{ $t('actions.add') }}
                                </v-btn>
                            </v-card-actions>
                        </v-card>
                    </v-dialog>
                    <div class="options" v-if="isManager(currentUser,key) || isAdmin">
                        <div class="option_left">
                            <!-- /.option -->
                        </div>
                        <!-- /.option_left -->
                        <div class="option_right">
                            <button type="button"
                                    class="option"
                                    :disabled="(!isAdmin && isCompanyBlocked(key)) || isArchived"
                                    @click="openAddGuestModal()">
                                <i class="icon-picto_ajouter"></i>
                                {{ $t('key.addGuests') }}
                            </button>
                            <!-- /.option -->
                        </div>
                        <!-- /.option_right -->
                    </div>
                    <!-- /.options -->
                    <v-data-table
                        v-if="key"
                        :expanded.sync="expandedGuest"
                        :headers="guestsHeaders"
                        :items="key.guests"
                        :loading="loadingGuestManagers"
                        :no-data-text="$t('key.noGuests')"
                        :options.sync="keyGuestsPagination"
                        :search="keyGuestsPagination.search"
                        :server-items-length="keyGuestsPagination.totalItems"
                        class="elevation-1"
                        show-expand
                        :hide-default-footer="key.guests && key.guests.length < 10"
                        item-key="key"
                    >
                        <template v-slot:item.name="{ item }">
                            <div
                                v-if="item.name || item.Users[0]"
                            >
                                {{ item.name || item.Users[0].displayName }}
                            </div>
                        </template>
                        <template v-slot:item.profile="{ item }">
                            {{ $t(`key.guest.type.${invitationType(groupHighestInvitation(item))}`) }}
                        </template>
                        <template v-slot:item.access="{ item }">
                            <div v-if="displayAccessDates(item)">
                                <p>{{ $t('key.guest.from') }}
                                    {{ groupHighestInvitation(item).keyAccess.startDate | formatDate }}</p>
                                <p>{{ $t('key.guest.to') }}
                                    {{ groupHighestInvitation(item).keyAccess.endDate | formatDate }}</p>
                            </div>
                            <p v-else>
                                -
                            </p>
                        </template>
                        <template v-slot:item.accessCount="{ item }">
                            {{ item.invitations ? item.invitations.length : 0 }}
                        </template>
                        <template v-slot:item.keyGroupName="{ item }">
                            <v-btn
                                v-if="item.keyGroupName"
                                class="v-btn--active text-none"
                                color="blue"
                                rounded
                                target="_blank"
                                text
                                x-small
                            >
                                <v-icon left x-small>vpn_key</v-icon>
                                {{ item.keyGroupName }}
                            </v-btn>
                            <p v-else>
                                -
                            </p>
                        </template>
                        <template v-slot:item.accessGivedBy="{ item }">
                            <div
                                v-for="(granter,i) in distinctGranter(item.invitations)"
                                class="my-1"
                            >
                                <user-list-avatar
                                    :key="i"
                                    :users="[granter]"
                                />
                            </div>
                        </template>
                        <template v-slot:expanded-item="{ item }">
                            <td colspan="8">
                                <v-row class="content" v-if="item.type === 'subordinates' || item.type === 'contacts'">
                                    <div class="d-flex justify-space-between">
                                        <user-list-avatar
                                            :users="item.Users"
                                        />
                                    </div>
                                </v-row>
                                <v-row class="content">
                                    <p> {{ $t('key.guest.createdAt') }}{{
                                            item.invitations[0].keyAccess.createdAt | formatDate
                                        }}</p>
                                </v-row>
                            </td>
                        </template>
                        <template v-slot:item.action="{ item }">
                            <v-row>
                                <v-btn
                                    v-if="(!!item.connectedUserInvitation || isManager(currentUser, key)) && !isCompanyBlocked(key) && !isArchived"
                                    icon
                                    @click="openEditGuest(item)"
                                    :title="$t('key.guest.editInvitation')"
                                >
                                    <v-icon
                                        small
                                    >
                                        edit
                                    </v-icon>
                                </v-btn>
                                <key-guest-reminder
                                    v-if="isManager(currentUser, key) && !isArchived"
                                    :keyId="key.id"
                                    :users="item.Users"
                                />
                            </v-row>
                        </template>
                    </v-data-table>
                    <over-price-sms
                        :dialog="acceptOverPrice"
                        :loading="loadingAddGuest"
                        @accept="saveKey(key,{newGuests:true, acceptOverPrice:true})"
                        @cancel="acceptOverPrice=false;key.newGuests = [];"
                    ></over-price-sms>
                </div>
            </v-expand-transition>

            <p class="tableau_titre">
                {{$t('key.associatedRelays')}}
                <a
                    :title="$t('actions.openClose')"
                    @click.prevent="displayAssociatedRelays = !displayAssociatedRelays"
                    class="toggle_action"
                    :class="{'open': !displayAssociatedRelays}"
                >
                    <i class="icon-angle"></i>
                </a>
            </p>
            <v-expand-transition>
                <div id="tableau_relais_associes" class="tableau" v-if="displayAssociatedRelays">
                    <v-row no-gutters class="relais_row">
                        <v-col v-if="keyReferenceRelay">
                            <div class="options">
                                <div class="option_left">
                                    <p class="titre">
                                        <strong>
                                            {{$t(keyReferenceRelay.type === 'AGENCY' ? 'key.agencyRelayInfo' : 'key.lobyInfo')}}
                                        </strong>
                                    </p>
                                </div>
                                <!-- /.option_left -->
                                <div class="option_right">
                                    <button
                                        v-if="isManager(currentUser, key) || isAdmin"
                                        type="button"
                                        class="option"
                                        :disabled="(!isAdmin && isCompanyBlocked(key)) || isArchived || key.status === 'IN_RELAY' || key.status === 'IN_TRANSIT'"
                                        @click="replaceReferenceRelay = true"
                                    >
                                        <i class="icon-picto_editer"></i>
                                        {{$t('actions.edit')}}
                                    </button>
                                    <!-- /.option -->
                                </div>
                                <!-- /.option_right -->
                            </div>
                            <div class="details">
                                <key-relays
                                    :relays="[keyReferenceRelay]"
                                />
                            </div>
                            <!-- /.details -->
                        </v-col>
                        <v-col v-if="isKeyB2B && canAssociateFlowRelay">
                            <div class="options">
                                <div class="option_left">
                                    <p class="titre"><strong>{{$t('key.lobyInfo')}}</strong></p>
                                </div>
                                <!-- /.option_left -->
                                <div class="option_right">
                                    <button
                                        v-if="isKeyB2B && (isManager(currentUser, key) || isAdmin)"
                                        type="button"
                                        class="option"
                                        :disabled="(!isAdmin && isCompanyBlocked(key)) || isArchived"
                                        @click="addAdditionalRelay = true"
                                    >
                                        <i class="icon-picto_ajouter"></i>
                                        {{$t('actions.add')}}
                                    </button>
                                    <!-- /.option -->
                                </div>
                                <!-- /.option_right -->
                            </div>
                            <div class="details">
                                <key-relays
                                    v-if="keyAdditionalRelays && keyAdditionalRelays.length  > 0"
                                    :relays="keyAdditionalRelays"
                                    :canDeleteRelay="isManager(currentUser, key) || isAdmin"
                                    @remove-relay="confirmRemoveRelay"
                                />
                                <div class="info_relais_agence text-center" v-else>
                                    <h6>{{ $t('relay.noAssociatedFlow') }}</h6>
                                </div>
                            </div>
                            <!-- /.details -->
                        </v-col>
                    </v-row>
                </div>
            </v-expand-transition>
            <v-dialog max-width="700px" v-model="replaceReferenceRelay" persistent>
                <v-card>
                    <v-card-title>
                        <span class="headline">{{ $t(isKeyB2B ? 'key.replaceReferenceAgency' : 'key.replaceReferenceRelay') }}</span>
                    </v-card-title>
                    <v-card-text>
                        <v-container>
                            <span>
                                {{$t(isKeyB2B ? 'keysList.chooseAgencyRelay': 'keysList.chooseFlowRelay')}}
                            </span>
                            <v-col cols="12 pa-0">
                                <v-autocomplete
                                    :item-text="itemStringified"
                                    item-value="id"
                                    :items="isKeyB2B ? agencyRelays : flowRelays"
                                    :search-input.sync="searchAllRelays"
                                    :loading="loadingRelays"
                                    append-icon
                                    flat
                                    :no-data-text="$t('keysList.noRelayFound')"
                                    prepend-icon="near_me"
                                    solo
                                    hide-details
                                    :readonly="currentRelay(key) && currentRelay(key).id === key.relayId"
                                    :clearable="!currentRelay(key) || currentRelay(key).id !== key.relayId"
                                    v-bind:label="$t('actions.search')"
                                    v-model="key.relayId"
                                >
                                    <template v-slot:selection="data">
                                        <v-list-item-content style="overflow: initial;">
                                            <v-list-item-title
                                                v-html="data.item.name">
                                            </v-list-item-title>
                                            <v-list-item-subtitle
                                                v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city">
                                            </v-list-item-subtitle>
                                        </v-list-item-content>
                                    </template>
                                    <template v-slot:item="data">
                                        <v-list-item-content :aria-disabled="!data.item.available">
                                            <v-list-item-title
                                                v-html="data.item.name">
                                            </v-list-item-title>
                                            <v-list-item-subtitle
                                                v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city">
                                            </v-list-item-subtitle>
                                        </v-list-item-content>
                                    </template>
                                </v-autocomplete>
                            </v-col>
                        </v-container>
                    </v-card-text>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn @click="closeReplaceReferenceRelay" color="white" text>
                            {{ $t("actions.cancel") }}
                        </v-btn>
                        <v-btn
                            v-if="key.relayId && isReferentRelayReplaced"
                            color="warning"
                            :loading="loadingKey"
                            @click="saveKey(key, {relays: true})"
                        >
                            {{ $t("actions.confirm") }}
                        </v-btn>
                        <v-spacer></v-spacer>
                    </v-card-actions>
                </v-card>
            </v-dialog>
            <v-dialog max-width="700px" v-model="addAdditionalRelay" persistent>
                    <v-card>
                        <v-card-title>
                            <span class="headline">{{ $t('key.addAdditionalRelay') }}</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container>
                                <span>
                                    {{ $tc('key.flowRelays', 0) }}
                                </span>
                            <v-col cols="12 pa-0">
                                <v-autocomplete
                                    return-object
                                    :items="removeDuplicates(flowRelays, key.Relays)"
                                    :search-input.sync="searchAllRelays"
                                    :loading="loadingRelays"
                                    no-filter
                                    append-icon
                                    flat
                                    clearable
                                    hide-details
                                    :no-data-text="$t('keysList.noRelayFound')"
                                    prepend-icon="add"
                                    solo
                                    v-bind:label="$t('keysList.searchFlowRelay')"
                                    v-model="additionalRelay"
                                >
                                    <template v-slot:selection="data">
                                        <v-list-item-content :aria-disabled="!data.item.available"
                                                             style="overflow: initial;">
                                            <v-list-item-title
                                                v-html="data.item.name">
                                            </v-list-item-title>
                                            <v-list-item-subtitle
                                                v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city">
                                            </v-list-item-subtitle>
                                        </v-list-item-content>
                                    </template>
                                    <template v-slot:item="data">
                                        <v-list-item-content :aria-disabled="!data.item.available">
                                            <v-list-item-title
                                                v-html="data.item.name">
                                            </v-list-item-title>
                                            <v-list-item-subtitle
                                                v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city">
                                            </v-list-item-subtitle>
                                        </v-list-item-content>
                                    </template>
                                </v-autocomplete>
                            </v-col>
                        </v-container>
                    </v-card-text>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn @click="closeAddAdditionalRelay" color="white" text>
                            {{ $t("actions.cancel") }}
                        </v-btn>
                        <v-btn
                            v-if="key.relayId"
                            color="warning"
                            :loading="loadingKey"
                            @click="confirmAddAdditionalRelay"
                        >
                            {{ $t("actions.confirm") }}
                        </v-btn>
                        <v-spacer></v-spacer>
                    </v-card-actions>
                </v-card>
            </v-dialog>
            <simple-dialog
                :dialog="deleteRelayDialog"
                :title="$t('key.removeRelay.title')"
                :text="$t('key.removeRelay.text', {relayName: deletedRelay.name})"
                :actions="['cancel', 'confirm']"
                @cancel="closeRemoveRelayDialog"
                @confirm="removeRelay(deletedRelay)"
            />

            <log-table
                :collapsible-title="true"
                :logs="logs"
                @get-logs="getLogs"
            />
            <br/>
        </div>
        <!-- Edit guest modal -->
        <edit-guest-access
            v-if="editGuestDialog"
            :editGuestDialog="editGuestDialog"
            :currentKey="key"
            :guest="editGuest"
            @close="close"
            @reset="reset"
            @save="saveKey">
        </edit-guest-access>
        <!-- /.middle_part -->
        <div class="right_part">
            <last-logs
                :loading="loadingLogs"
                :logs="lastLogs"
            />
        </div>
    </div>
</template>
<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";
import SimpleDialog from "@/components/SimpleDialog.vue";
import EditGuestAccess from "@/components/keys/EditGuestAccess.vue";
import KeyTransit from "@/components/keys/actions/KeyTransit.vue";
import KeyRetrieve from "@/components/keys/actions/KeyRetrieve.vue";
import HandToHand from "@/components/keys/actions/HandToHand.vue";
import ReceiveKey from "@/components/keys/actions/ReceiveKey.vue";
import KeyWithdraw from "@/components/keys/actions/KeyWithdraw.vue";
import KeyWithdrawConnected from "@/components/keys/actions/KeyWithdrawConnected.vue";
import KeyDropMyLoby from "@/components/keys/actions/KeyDropMyLoby.vue";
import KeyDropAgency from "@/components/keys/actions/KeyDropAgency.vue";
import KeyDropConnected from "@/components/keys/actions/KeyDropConnected.vue";
import KeyStatus from "@/components/keys/KeyStatus.vue";
import KeyRelays from "@/components/keys/KeyRelays.vue";
import KeyManagersAutocomplete from "@/components/keys/KeyManagersAutocomplete.vue";
import KeyGuestsAutocomplete from "@/components/keys/KeyGuestsAutocomplete.vue";
import KeyGuestReminder from "@/components/keys/KeyGuestReminder.vue";
import LastLogs from "@/components/logs/LastLogs.vue";
import LogTable from "@/components/logs/LogTable.vue";
import OverPriceSms from "@/components/OverPriceSms.vue";
import {formRules} from "@/utils/formRules";
import {defaultKeyPicture, defaultUserAvatar} from "@/utils/constants";
import {Getter} from "vuex-class";
import ChangeStatus from "@/components/keys/actions/ChangeStatus.vue";
import {getSrc, removeVuetifyFileInputBug} from "@/utils/misc";
import KeySubscription from "@/components/keys/KeySubscription.vue";
import RestrictionDialog from "@/components/RestrictionDialog.vue";
import router from "@/router";
import {canUseManagers, canUseFlowRelays, canAddMoreUserToKey} from "plan-restrictions";
import KeyUnblock from "@/components/keys/actions/KeyUnblock.vue";
import UserListAvatar from "@/components/users/UserListAvatar.vue";
import KeyArchive from "@/components/keys/actions/KeyArchive.vue";
import CustomChipLink from "@/components/CustomChipLink.vue";
import Timeout = NodeJS.Timeout;
import {TranslateResult} from "vue-i18n";
import moment from "moment";
import KeyReturningDate from "@/components/keys/actions/KeyReturningDate.vue";
import imageCompression from "browser-image-compression";
import ImageKeyRenderer from "@/components/ImageKeyRenderer.vue";
import heic2any from "heic2any";

export const DEBOUNCE_TIME_MILLI: number = 500;

@Component({
    components: {
        SimpleDialog,
        UserListAvatar,
        KeyArchive,
        KeyUnblock,
        KeySubscription,
        ChangeStatus,
        EditGuestAccess,
        KeyStatus,
        KeyManagersAutocomplete,
        KeyGuestsAutocomplete,
        LastLogs,
        LogTable,
        KeyRelays,
        KeyTransit,
        KeyRetrieve,
        KeyDropMyLoby,
        KeyDropAgency,
        KeyDropConnected,
        KeyWithdraw,
        KeyWithdrawConnected,
        HandToHand,
        ReceiveKey,
        RestrictionDialog,
        CustomChipLink,
        KeyReturningDate,
        KeyGuestReminder,
        OverPriceSms,
        ImageKeyRenderer,
    },
})
export default class Key extends Vue {
    @Getter private currentUser: any;
    @Getter private isB2B: boolean;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isAdmin: boolean;
    private canUseManagers: (company: any) => boolean = canUseManagers;
    private canUseFlowRelays: (company: any) => boolean = canUseFlowRelays;
    private canAddMoreUserToKey: (
        company: any,
        existingKeyUsersNbr: number,
        newKeyUsersNbr: number,
    ) => boolean = canAddMoreUserToKey;
    private isRestrictedOn: string = null;
    private isAddButtonEnabled: boolean = false;
    private rules: object = formRules;
    private defaultUserAvatar: string = defaultUserAvatar;
    private defaultKeyPicture: string = defaultKeyPicture;
    private getSrc: (picturePath: string) => string = getSrc;
    private removeVuetifyFileInputBug: (document: any) => void = removeVuetifyFileInputBug;
    private token: string = null;
    private keyId: number = null;
    private key: any = {};
    private loadingLogs: boolean = false;
    private loadingAddGuest: boolean = false;
    private logs: any = {};
    private lastLogs: any = {};
    private editKeyInfoDialog: boolean = false;
    private validEditKeyInfoForm: boolean = false;
    private avatar: any = null;
    private uploadedImageSrc: any = null;
    private tags: any = [];
    private searchTags: string = null;
    private flowRelays: any[] = [];
    private loadingRelays: boolean = false;
    private loadingKey: boolean = false;
    private timerId: Timeout = null;
    private guests: object = [];
    private expandedGuest: object = [];
    private expandedManager: object = [];
    private addGuest: boolean = false;
    private guestAdd: boolean = false;
    private addManager: boolean = false;
    private editGuest: any = {};
    private editGuestDialog: boolean = false;
    private relayId: number = null;
    private searchAllRelays: string = null;
    private agencyRelays: any[] = [];
    private displayKeyManagers: boolean = true;
    private displayGuests: boolean = true;
    private displayAssociatedRelays: boolean = true;
    private keyManagersHeaders: object[] = [];
    private guestsHeaders: object[] = [];
    private loadingKeyManagers: boolean = false;
    private loadingGuestManagers: boolean = false;
    private deletedManager: any = {};
    private deleteFromKeyGroupConfirmationDialog: boolean = false;
    private deletedRelay: any = {};
    private deleteRelayDialog: boolean = false;
    private replaceReferenceRelay: boolean = false;
    private addAdditionalRelay: boolean = false;
    private additionalRelay: any = null;
    private keyManagersPagination: any = {
        sortDesc: [false],
        sortBy: [""],
        search: "",
        select: [],
        page: 1,
        itemsPerPage: 10,
        totalItems: 10,
    };
    private keyGuestsPagination: any = {
        sortDesc: [false],
        sortBy: [""],
        search: "",
        select: [],
        page: 1,
        itemsPerPage: 10,
        totalItems: 10,
    };
    private loading: boolean = false;
    private displayChooseHour: boolean = false;
    private endCountdown: boolean = false;
    private acceptOverPrice: boolean = false;
    private invitationReminder: boolean = false;
    private guestToReinvite: any = null;
    private componentKey: number = 0;
    private timestampKeyImage: any = Date.now();
    private heicFile: any = null;
    private fullScreen: boolean = false;

    get lang(): string {
        return this.$root.$i18n.locale;
    }

    get uniqueKeyManagers(): any[] {
        return this.key?.keyManagers;
        /* Old methods
        .reduce((a: any[], c: any) => {
            // Get unique managers groups
            const uniqueUserGroup = this.key.keyManagers.filter((userGroup) => !userGroup.creatorId);
            // Get unique managers ids
            const uniqueUserIds = uniqueUserGroup
                .reduce((acc, uG) => acc.concat(uG.Users), [])
                .map((user) => user.id);
            // Do not return unique managers invited through a key group if
            if (!c.keyGroupId || !uniqueUserIds.includes(c.Users[0].id)) {
                a.push(c);
            }
            return a;
        }, []) || [];
        */
    }

    get canManageUser(): boolean {
        return this.canUseManagers(this.currentUser?.company);
    }

    get canAssociateFlowRelay(): boolean {
        return this.canUseFlowRelays(this.currentUser?.company);
    }

    get disableMoreUsers(): boolean {
        const usersNbrInGroup: (accessGroup: any[]) => number = (accessGroup: any[]) =>
            accessGroup.reduce((a, c) => a + c?.Users?.length || 1, 0) || 0;
        return !this.canAddMoreUserToKey(
            this.currentUser?.company,
            usersNbrInGroup(this.key?.keyManagers) + usersNbrInGroup(this.key?.guests),
            // +1 to prevent manager from selecting more users than authorized
            usersNbrInGroup(this.key?.newKeyManagers) + usersNbrInGroup(this.key?.newGuests) + 1,
        );
    }

    get isArchived(): boolean {
        return !!this.key?.archivedAt && !this.key.hasAllRights;
    }

    get archivedText(): string {
        if (this.isAdmin) {
            return "key.archived";
        } else if (!this.isManager(this.currentUser, this.key)) {
            return "key.archivedGuest";
        } else if (this.isKeyB2B || this.isKeyInsurance) {
            return "key.archived";
        } else if (this.key.Subscription?.[0]?.status === "ERROR") {
            return "key.archivedB2CDefaultPayment";
        } else {
            return "key.archivedB2C";
        }
    }

    get hasArchiveRight(): boolean {
        return ((this.isKeyB2B || this.isKeyInsurance) && this.isManager(this.currentUser, this.key));
    }

    get isCurrentUserHolder(): boolean {
        return this.key.holder ? this.key.holder.id === this.currentUser?.id : false;
    }

    get isReferentRelayReplaced(): boolean {
        return this.key?.relayId?.id !== this.keyReferenceRelay?.id;
    }

    get userHasKey() {
        return this.key?.KeyHolding?.find((kH) => !kH.endDate)?.userId === this.currentUser?.id;
    }

    get isKeyInsurance(): boolean {
        return this.key?.company?.type === "INSURANCE";
    }

    get isKeyB2B(): boolean {
        return this.key?.company?.type === "B2B";
    }

    get keyReferenceRelay(): any {
        return this.key?.Relays?.find((relay) => relay.type === "AGENCY") || this.key?.Relays?.[0];
    }

    get keyAdditionalRelays(): any[] {
        return this.removeDuplicates(this.key?.Relays, [this.keyReferenceRelay])?.filter((relay) => relay.type === "FLOW");
    }

    @Watch("searchTags")
    public handlerSearchTags(): void {
        this.getTags();
    }

    @Watch("searchAllRelays", {deep: true})
    public handlerSearchRelays(newVal: string): void {
        if (newVal) {
            this.searchRelays();
        }
    }

    @Watch("keyManagersPagination", {deep: true})
    public handlerKeyManagersPagination(): void {
        if (this.key?.id) {
            this.getKeyById();
        }
    }

    @Watch("keyGuestsPagination", {deep: true})
    public handlerKeyGuestsPagination(): void {
        if (this.key?.id) {
            this.getKeyById();
        }
    }

    private lateKey = (date) => moment(new Date(date), "YYYY-MM-DDTHH:mm:ss")
        .isBefore(moment().format("YYYY-MM-DDTHH:mm:ss"))

    private getTime = (date) => date
        ? moment(new Date(date), "YYYY-MM-DD HH:mm:ss").valueOf()
        : moment().valueOf()

    // whether or not show days in countdown
    private showDays = (date) => Math.abs(moment(new Date(date), "YYYY-MM-DD HH:mm:ss").valueOf() - moment().valueOf())
        > 24 * 60 * 60 * 1000

    private getDifference(date): string {
        date = new Date(date);
        const a = moment(date, "YYYY-MM-DD hh:mm");
        const b = moment();
        const diffDays = b.diff(a, "days");
        const diffHours = b.diff(a, "hours");
        const diffMinutes = b.diff(a, "minutes");
        if (diffMinutes < 60) {
            return diffMinutes % 60 + " " + String(this.$tc("countDown.minutes", diffMinutes));
        } else if (diffHours < 24) {
            return diffHours % 24 + " " + String(this.$tc("countDown.hours", diffHours)) + ", "
                + diffMinutes % 60 + " " + String(this.$tc("countDown.minutes", diffMinutes));
        } else {
            return diffDays + " " + String(this.$tc("countDown.days", diffDays)) + ", "
                + diffHours % 24 + " " + String(this.$tc("countDown.hours", diffHours)) + ", "
                + diffMinutes % 60 + " " + String(this.$tc("countDown.minutes", diffMinutes));
        }
    }

    // extend holding key
    private validateTime(date) {
        this.displayChooseHour = false;
        this.$store.dispatch("keys/extendKeyHolding", {
            keyId: this.key.id,
            newEstimatedEndDate: (new Date(date)).toISOString().substr(0, 19),
        }).then(() => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("alerts.key.addTimeSuccess", {
                    key: this.key?.name,
                    time: moment(date).format("DD/MM/YYYY HH:mm"),
                }),
            });
            this.reset();
        });
    }

    private isKeyBooked = (key) => key.currentBooking ?
        moment().isAfter(moment(key.currentBooking.startDate))
        && moment().isBefore(moment(key.currentBooking.endDate)) : false

    private itemStringified = (item) => JSON.stringify(item);

    // check if one of the user of one of the groups is master
    private isMasterInGroup = (group) => group?.Users?.some((u) => u?.masterOf?.length);

    // check if one of the user of one of the management groups match the current user
    private isManager = (user, key) => key?.keyManagers
        ?.some((g) => g?.Users?.some((u) => u.id === user?.id))

    // check if one of the user of one of the guests groups match the current user
    private isGuest = (user, key) => key?.guests
        ?.some((g) => g?.Users?.some((u) => u.id === user?.id))

    private isOwnerInGroup = (group, key) => group?.Users?.some((u) => key?.ownerId === u?.id);

    private isHolderInGroup = (group, key) => group?.Users?.some((u) => key?.holder?.id === u?.id);

    private distinctGranter(invitations: any[]): any[] {
        return invitations.reduce((a: any[], c: any) => {
            const duplicatedGranter: boolean = a
                .map((granter) => granter.id)
                .includes(c.keyAccess.granter.id);
            if (!duplicatedGranter) {
                a.push(c.keyAccess.granter);
            }
            return a;
        }, []);
    }

    private displayAccessDates = (group) => this.invitationType(this.groupHighestInvitation(group)) === "timeLimited"
        || this.invitationType(this.groupHighestInvitation(group)) === "timeAndCountLimited"

    private currentRelay = (key) => key?.currentLocation?.Box.Relay;

    private updateIsAddButtonStatus(newVal: boolean): void {
        this.isAddButtonEnabled = newVal;
    }

    private addGuestFunction(): void {
        this.guestAdd = true;
        this.loadingAddGuest = true;
        return (this.$refs.keyGuestsAutocomplete as HTMLFormElement)?.addGuest();
    }

    private groupHighestInvitation = (group) =>
        group?.invitations?.filter((i) => !i.countLimited && !i.timeLimited)?.[0]
        || group?.invitations?.filter((i) => !i.countLimited)?.[0]
        || group?.invitations?.filter((i) => !i.timeLimited)?.[0]
        || group?.invitations?.[0]

    private isValidAccess = (access: any) => (access.countAccessLeft === -1 || access.countAccessLeft >= 1)
        && (access.startDate === null || new Date(access.startDate) <= new Date())
        && (access.endDate === null || new Date(access.endDate) >= new Date())

    private connectedUserHasKeyAccess = (key, user) => this.isManager(user, key)
        || this.userHasKey
        || key.guests
            ?.filter((guestGroup) => guestGroup.Users.map((user) => user?.id).includes(user?.id))
            ?.filter((guestGroup) => guestGroup.invitations.some((invitation) =>
                this.isValidAccess(invitation.keyAccess)))
            ?.length

    private displayCodeName(key) {
        if (key.backupId) {
            let codeName;
            try {
                const s = key.locationDisplayed.codeName.split("-");
                codeName = s[s.length - 1];
            } catch {
                codeName = "";
            }
            return codeName;
        } else {
            return key.locationDisplayed.codeName;
        }
    }

    private isCompanyBlocked: (any) => boolean = (key: any) => key?.company && !!key.company.blockedAt;

    private invitationType = (i) => {
        if (!i) {
            return null;
        }
        if (!i.countLimited && !i.timeLimited) {
            return "unlimited";
        }
        if (i.countLimited && i.timeLimited) {
            return "timeAndCountLimited";
        }
        if (i.countLimited) {
            return "countLimited";
        }
        if (i.timeLimited) {
            return "timeLimited";
        }
    }

    private mounted(): void {
        this.keyId = Number(this.$route.params.id);
        if (isNaN(this.keyId)) {
            router.push({name: "keys"});
        }
        this.reset();
    }

    private beforeUpdate(): void {
        this.removeVuetifyFileInputBug(document);
    }

    private reset() {
        this.close();
        this.keyManagersHeaders = [
            {value: "name", text: this.$tc("key.user", 1), sortable: true},
            {value: "profile", text: this.$t("key.guest.profile"), sortable: true},
            {value: "keyGroupName", text: this.$t("key.guest.keyGroup"), sortable: true},
            {value: "data-table-expand"},
            {value: "action", sortable: false},
        ];
        this.guestsHeaders = [
            {value: "name", text: this.$tc("key.user", 1), sortable: true},
            {value: "profile", text: this.$t("key.guest.profile"), sortable: true},
            {value: "access", text: this.$t("key.guest.access"), sortable: true},
            {value: "accessCount", text: this.$t("key.guest.accessCount"), sortable: true},
            {value: "keyGroupName", text: this.$t("key.guest.keyGroup"), sortable: true},
            {value: "accessGivedBy", text: this.$t("key.guest.accessGivedBy"), sortable: false},
            {value: "data-table-expand"},
            {value: "action", sortable: false},
        ];
        this.forceImageKeyRender();
        this.getKeyById().then(() => {
            this.getLogs();
            this.getRelays();
            this.getTags();
        });
    }

    private getKeyById(): Promise<void> {
        this.loading = true;
        return this.$store.dispatch("keys/getById", {
            id: this.keyId,
            options: {
                picture: true,
                relays: true,
                reservedLocation: true,
                owner: true,
                company: true,
                holder: true,
                keyManagers: true,
                guests: true,
                currentLocation: true,
                ongoingSubscriptions: true,
            },
        })
            .then((key) => {
                key.relayId = key?.Relays?.find((relay) => relay.type === "AGENCY") || key?.Relays?.[0];
                key.Relays = key?.Relays?.map((relay) => ({
                    value: relay?.id,
                    ...relay,
                }));
                key.newKeyManagers = [];
                key.guests.forEach((g, index) => {
                    g.key = index;
                    g.connectedUserInvitation = g.invitations?.[0];
                    if (g.invitations[0].keyAccess.keyGroup.name) {
                        g.keyGroupName = g.invitations[0].keyAccess.keyGroup.name;
                        g.keyGroupId = g.invitations[0].keyAccess.keyGroup.id;
                    }
                });
                key.keyManagers.forEach((g, index) => {
                    g.key = index;
                    if (g.invitations[0].keyAccess.keyGroup.name) {
                        g.keyGroupName = g.invitations[0].keyAccess.keyGroup.name;
                        g.keyGroupId = g.invitations[0].keyAccess.keyGroup.id;
                    }
                });
                key.newGuests = [];
                key.newTags = key.Tags;
                key.locationDisplayed = key?.company?.type === "B2B" ? key?.currentLocation :
                    (key?.currentLocation || key?.ReservedLocations?.[0]);
                const acsesObject = key.AcsesObjects[0];
                if (acsesObject) {
                    key.connectedBoxLocker = acsesObject.name;
                }
                this.key = key;
                this.key.estimatedEndDate = key.KeyHolding[0]?.estimatedEndDate;
            }).catch((err) => {
                if (err.response?.data?.error !== "Unauthorized") {
                    this.$store.commit("alerts/displayError", {
                        msg: this.$t(`alerts.error.${err?.response?.data?.error || "default"}`),
                    });
                }
                router.push({name: "keys"});
            });
    }

    private async saveKey(key: any, params?: any): Promise<void> {
        this.loadingKey = true;
        this.loadingAddGuest = true;
        if (this.uploadedImageSrc) {
            const options = {
                maxSizeMB: 1,
                useWebWorker: true,
            };
            let compressedFile: any = null;
            if (!this.heicFile) {
                compressedFile = await imageCompression(this.avatar, options);
            }
            const formData = new FormData();
            formData.append("file", compressedFile ? compressedFile : this.heicFile);
            formData.append("id", this.key.id.toString());
            formData.append("fileType", "key-picture");
            await this.$store.dispatch("files/upload", {formData});
        }
        key.picturePath = `/api/files/keys/${key.id}/pictures/key-picture`;
        key.Tags = key.newTags.map((t) => t?.id);
        if (Number.isInteger(key.relayId)) {
            key?.Relays?.push({id: key.relayId});
        }
        delete key.logs;
        this.$store.dispatch("keys/update", {
            key,
            params: params || {
                info: true,
                newKeyManagers: true,
                newGuests: true,
                relays: true,
                acceptOverPrice: false,
            },
        })
            .then(() => {
                this.reset();
                this.acceptOverPrice = false;
                this.loadingKey = false;
                this.loadingAddGuest = false;
                this.timestampKeyImage = Date.now();
                if (params.newKeyManagers === true) {
                    this.$store.commit("alerts/displaySuccess", { icon: "icon-picto_cle-partagees", msg: this.$t("key.managerAdd")});
                } else if (this.guestAdd === true) {
                    this.$store.commit("alerts/displaySuccess", { icon: "icon-picto_cle-partagees", msg: this.$t("key.guestAdd")});
                } else {
                    this.$store.commit("alerts/displaySuccess", {
                        icon: "icon-picto_cle-partagees",
                        msg: this.$i18n?.t("alerts.key.editionSuccess"),
                    });
                }
            })
            .catch((err) => {
                switch (err?.response?.data?.error) {
                    case "smsLimitReached":
                        this.acceptOverPrice = true;
                        break;
                    case "freemium":
                        this.$store.commit("alerts/displayError", {
                            msg: this.$i18n.t("invitation.freemium"),
                        });
                        break;
                    default:
                        this.reset();
                        this.$store.commit("alerts/displayError", {
                            msg: this.$t(`alerts.error.${err?.response?.data?.error || "default"}`),
                        });
                        break;
                }
                this.loadingAddGuest = false;
            });
    }

    private getLogs(params?: any): void {
        if (this.keyId) {
            if (!params) {
                this.loadingLogs = true;
            }
            this.$store.dispatch("logs/getLogs", {
                query: {
                    currentPage: "key",
                    entityId: this.keyId,
                    entityType: "key",
                    ...params,
                },
            }).then((res) => {
                if (!params) {
                    this.lastLogs = res;
                    this.loadingLogs = false;
                } else {
                    this.logs = res;
                }
            });
        }
    }

    private getRelays(): Promise<void> {
        const p: Array<Promise<any>> = [
            this.$store.dispatch("relays/getAll", {
                query: {
                    search: this.searchAllRelays,
                    type: "FLOW",
                    available: true,
                    itemsPerPage: 10,
                },
            }),
        ];
        if (this.isB2B || this.isAdmin) {
            p.push(this.$store.dispatch("relays/getList", {
                query: {
                    search: this.searchAllRelays,
                    type: "AGENCY",
                    available: true,
                    itemsPerPage: 10,
                },
            }));
        }
        return Promise.all(p).then((res) => {
            this.flowRelays = res[0]?.relays || [];
            this.agencyRelays = res[1]?.relays || [];
        });
    }

    private searchRelays(): void {
        this.loadingRelays = true;
        // cancel pending call
        clearTimeout(this.timerId);
        // delay new call
        this.timerId = setTimeout(() => {
            this.getRelays().then(() => {
                this.loadingRelays = false;
            });
        }, DEBOUNCE_TIME_MILLI);
    }

    private getTags(): void {
        this.$store.dispatch("tags/getAll", {
            query: {
                search: this.searchTags,
                lang: this.lang,
            },
        })
            .then((res) => {
                this.tags = res.tags;
            });
    }

    private removeTags(item): void {
        const index = this.key.newTags.findIndex((i) => i.id === item.id);
        if (index >= 0) {
            this.key.newTags.splice(index, 1);
        }
    }

    private removeTagDuplicates(completeList, duplicates): any[] | null {
        if (!completeList || !duplicates) {
            return null;
        }
        return completeList.filter((item: any) =>
            !duplicates.map((elem: any) => elem?.id)?.includes(item?.id));
    }

    private removeManager(manager: any): void {
        if (confirm(this.$t("key.deleteManagerConfirmation").toString())) {
            this.$store.dispatch("keys/removeManagementAccess", {
                key: this.key,
                management: manager?.invitations?.[0],
                keyGroup: {id: manager.keyGroupName ? manager.invitations[0].keyAccess.keyGroup.id : null},
            })
                .then(() => {
                    this.reset();
                })
                .catch((err) => {
                    this.$store.commit("alerts/displayError", {
                        msg: this.$t(`alerts.error.${err?.response?.data?.error || "default"}`),
                    });
                })
                .finally(() => {
                    this.closeDeleteConfirmationDialog();
                });
        }
    }

    private closeReplaceReferenceRelay(): void {
        this.replaceReferenceRelay = false;
        this.key.relayId = this.keyReferenceRelay;
    }

    private closeAddAdditionalRelay(): void {
        this.addAdditionalRelay = false;
        this.additionalRelay = null;
    }

    private confirmAddAdditionalRelay(): void {
        this.key.Relays.push(this.additionalRelay);
        this.saveKey(this.key, {relays: true});
    }

    private confirmRemoveRelay(relay: any): void {
        this.deletedRelay = relay;
        this.deleteRelayDialog = true;
    }

    private closeRemoveRelayDialog(): void {
        this.deletedRelay = {};
        this.deleteRelayDialog = false;
    }

    private removeRelay(relay: any): void {
        this.remove(this.key.Relays, relay);
        this.saveKey(this.key);
        this.closeRemoveRelayDialog();
    }

    private async fileChange(): Promise<void> {
        this.loadingKey = true;
        this.heicFile = null;
        if (this.avatar) {
            if (this.avatar.type === "image/heif" || this.avatar.type === "image/heic") {
                const blob = this.avatar as Blob;
                this.heicFile = await heic2any({blob});
                const fr = new FileReader();
                fr.readAsDataURL(this.heicFile as Blob);
                fr.addEventListener("load", () => {
                    this.uploadedImageSrc = fr.result;
                });
            } else {
                const fr = new FileReader();
                fr.readAsDataURL(this.avatar);
                fr.addEventListener("load", () => {
                    this.uploadedImageSrc = fr.result;
                });
            }
        } else {
            this.uploadedImageSrc = null;
        }
        this.loadingKey = false;
    }

    private updateTags(): void {
        this.key.tags.push(...this.searchTags.split(","));
        this.searchTags = "";
    }

    private openEditGuest(item: any): void {
        this.close();
        this.editGuest = {...item};
        this.editGuestDialog = true;
    }

    private removeDuplicates(completeList, duplicates): any[] | null {
        if (!completeList || !duplicates) {
            return null;
        }
        return completeList.filter((item: any) =>
            !duplicates.map((elem: any) => elem?.id)?.includes(item?.id));
    }

    private remove(list, item): void {
        const pos = list.map((u) => u.id).indexOf(item.id);
        list.splice(pos, 1);
    }

    private openAddManagerModal(): void {
        if (!this.canManageUser) {
            this.isRestrictedOn = "canUseManagers";
        } else if (this.disableMoreUsers) {
            this.isRestrictedOn = "maxUsersPerKey";
        } else {
            this.addManager = true;
        }
    }

    private openAddGuestModal(): void {
        if (this.disableMoreUsers) {
            this.isRestrictedOn = "maxUsersPerKey";
        } else {
            this.addGuest = true;
        }
    }

    private close(): void {
        this.addGuest = false;
        this.editGuestDialog = false;
        this.editKeyInfoDialog = false;
        this.key.newTags = this.key.Tags;
        this.addManager = false;
        this.closeReplaceReferenceRelay();
        this.closeAddAdditionalRelay();
    }

    private confirmDeleteFromKeyGroup(item): void {
        this.deletedManager = item;
        this.deleteFromKeyGroupConfirmationDialog = true;
    }

    private closeDeleteConfirmationDialog(): void {
        this.deletedManager = {};
        this.deleteFromKeyGroupConfirmationDialog = false;
    }

    private resendInvitation(item: any): void {
        this.guestToReinvite = Object.assign({}, item );
        this.invitationReminder = true;
    }

    private forceImageKeyRender() {
        this.componentKey += 1;
    }
    get currentKeyBooking(): string {
        if (!this.key || !this.key.currentBooking) {
            return "";
        }
        const startDate = this.key.currentBooking.startDate;
        const endDate = this.key.currentBooking.endDate;
        const parseStartDate = moment(startDate).format("YYYY-MM-DD HH:mm");
        const parseEndDate = moment(endDate).format("YYYY-MM-DD HH:mm");
        return parseStartDate + "  -  " + parseEndDate;
    }
}
</script>