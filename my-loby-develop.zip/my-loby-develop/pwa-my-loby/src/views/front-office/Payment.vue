<template>
    <div class="card-selection">
        <template v-if="newCard">
            <div v-if="success" class="card-success">
                <div class="icon-container">
                    <v-icon color="#4caf50">done</v-icon>
                </div>
                <p>{{$t('card.success')}}</p>
            </div>
            <div id="myPaymentForm" v-show="!loading">
            </div>
            <div class="loading" v-if="loading">
                <v-progress-circular
                    :width="3"
                    color="#0c0733"
                    indeterminate
                ></v-progress-circular>
            </div>
        </template>
        <div v-if="!newCard && subscriptionId">
            <v-radio-group v-model="selectedPayment" :mandatory="false" width="100%">
                <v-radio v-for="(pM, i) in paymentMethods" :key="i" :value="pM.id">
                    <v-card slot="label" style="width: 100%; max-width: 400px">
                        <v-card-text>
                            <v-row>
                                <v-col cols="2">
                                    {{pM.effectiveBrand}}
                                </v-col>
                                <v-col cols="7">
                                    {{pM.cardNumber}}
                                </v-col>
                                <v-col cols="3">
                                    {{pM.expirationDate}}
                                </v-col>
                            </v-row>
                        </v-card-text>
                    </v-card>
                </v-radio>
            </v-radio-group>
            <div class="button">
                <button
                    type="button"
                    class="option open_popup"
                    @click="displayNewCard"
                    :title="$t('keysList.create')"
                >
                    <i class="icon-picto_ajouter"></i>
                    {{$t('card.addNew.title')}}
                </button>
            </div>
        </div>
    </div>
</template>

<script lang="ts">
import {Component, Prop, Vue, Watch} from "vue-property-decorator";
import {Getter} from "vuex-class";
import KRGlue from "@lyracom/embedded-form-glue";

export const WAIT_UX_MILLI: number = 2000;
export const PAYZEN_ENDPOINT: string = process.env.VUE_APP_PAYZEN_ENDPOINT;
export const PAYZEN_PUBLIC_KEY: string = process.env.VUE_APP_PAYZEN_PUBLIC_KEY;

@Component({
    components: {},
})
export default class Payment extends Vue {
    @Prop({default: null})
    public keyId: number;

    @Prop({default: null})
    public paymentMethodId: string;

    @Prop({default: null})
    public subscription: any;

    @Getter private currentUser: any;

    private paymentMethods: any = [];
    private newCard: boolean = false;
    private subscriptionId: number = null;
    private selectedPayment: string = null;
    private success: boolean = false;
    private loading: boolean = true;
    private isSubmit: boolean = false;

    @Watch("selectedPayment", { deep: true })
    public  handlerSelectedPayment() {
        this.$emit("update:payment-method-id", this.selectedPayment);
    }

    private mounted() {
        if (this.keyId) {
            this.$store.dispatch("keys/getById", {  id: this.keyId, options: {}})
            .then((key) => {
                this.subscriptionId = key.Subscription[0]?.id;
                this.selectedPayment = key.Subscription[0]?.paymentMethodId;
                this.$emit("update:subscription", key.Subscription[0]?.id);
                this.getPaymentMethod();
            });
        } else {
            this.newCard = true;
            this.initForm();
        }
    }

    private displayNewCard() {
        this.selectedPayment = null;
        this.newCard = true;
        this.initForm(this.subscriptionId);
    }

    private getPaymentMethod() {
        return this.$store.dispatch("paymentMethod/getAll", {
            query: {
                params: {
                    userId: this.currentUser.id,
                },
            },
        }).then((data) => {
            this.paymentMethods = data.paymentMethod.filter((pM) => pM.status !== "ERROR");
            if (this.paymentMethods.length === 0) {
                this.displayNewCard();
            }
        });
    }

    private async initForm(subscriptionId: number = null) {

        let form: any = null;
        if (this.paymentMethodId && !this.keyId) {
            // Card replacement
            form = await this.$store.dispatch("paymentMethod/getForm", {
                query: {
                    paymentMethodId: this.paymentMethodId,
                },
            });
        } else {
            // New card
            form = await this.$store.dispatch("payments/getForm", {
                query: {
                    subscriptionId,
                },
            });
        }

        KRGlue.loadLibrary(PAYZEN_ENDPOINT, PAYZEN_PUBLIC_KEY) /* Load the remote library */
            .then(({KR}) => KR.setFormConfig({
                    "formToken": form.formToken,
                    "kr-language": "fr-FR",
                }),
            )
            .then(({KR}) => KR.addForm("#myPaymentForm"))
            .then(({KR, result}) => KR.showForm(result.formId))
            .then(({KR}) => KR.onFormReady(() => {this.loading = false; }))
            .then(({KR}) =>  KR.onSubmit((response) => {
                if (!this.isSubmit) {
                    this.isSubmit = true;
                    const isNewKey: boolean = !this.paymentMethodId || !!this.keyId;
                    let p: Promise<any> = null;
                    if (!isNewKey) {
                        // Card replacement
                        p = this.$store.dispatch("paymentMethod/updateOne", {
                            paymentMethodId : this.paymentMethodId,
                            transaction: response.clientAnswer.transactions[0],
                        });
                    } else {
                        // New card
                        p = this.$store.dispatch("paymentMethod/createOne", {
                            transaction: response.clientAnswer.transactions[0],
                            subscriptionId,
                            orderId: response.clientAnswer.orderDetails.orderId,
                        });
                    }
                    return p.then(() => {
                        this.success = true;
                        if (isNewKey) {
                            this.$store.commit("alerts/displaySuccess", {
                                icon: "icon-picto_cle-partagees",
                                msg: this.$i18n?.t("alerts.key.creationSuccess"),
                            });
                        }
                        KR.removeForms();
                        setTimeout(() => {
                                this.$emit("close");
                            }, WAIT_UX_MILLI,
                        );
                    });
                }
                }),
            )
            .then(({KR}) => {
                return KR.onError((error) => {
                    // If form has expired
                    if (error.errorCode === "PSP_108") {
                        setTimeout(() => {
                            document.location.reload();
                            },  WAIT_UX_MILLI,
                        );
                    }
                });
            });

    }

    private beforeDestroy() {
        // If payzen library was loaded
        if (this.newCard) {
            document.location.reload();
        }
    }
}
</script>
