<template>
    <div class="main-content-display">
        <div class="middle_part flex-grow-1">
            <div class="tableau">
                <div class="options">
                    <div class="option_left">
                    </div>
                    <div class="option_right">
                        <button
                            type="button"
                            class="option open_popup"
                            @click="modalAction = 'addNew'"
                            :title="$t('keysList.create')"
                        >
                            <i class="icon-picto_ajouter"></i>
                            {{$t('card.addNew.title')}}
                        </button>
                    </div>
                </div>
                <v-data-table
                        :headers="headers"
                        :items="paymentsMethod"
                    >
                    <template v-slot:header.effectiveBrand="{ header }">{{ $t('card.type') }}</template>
                    <template v-slot:header.cardNumber="{ header }">{{ $t('card.number') }}</template>
                    <template v-slot:header.expirationDate="{ header }">{{ $t('card.expiration') }}</template>
                    <template v-slot:header.subscriptions="{ header }">{{ $t('card.subscriptions') }}</template>
                    <template v-slot:header.actions="{ header }">{{ $t('card.actions') }}</template>
                    <template v-slot:item.effectiveBrand="{ item }">
                        <span :class="{'archived': item.status === 'ERROR' }">
                            {{item.effectiveBrand}}
                        </span>
                    </template>
                    <template v-slot:item.cardNumber="{ item }">
                        <span :class="{'archived': item.status === 'ERROR' }">
                            {{item.cardNumber}}
                        </span>
                    </template>
                    <template v-slot:item.expirationDate="{ item }">
                        <span :class="{'archived': item.status === 'ERROR' }">
                            {{item.expirationDate}}
                        </span>
                    </template>
                    <template v-slot:item.subscriptions="{ item }">
                        <span :class="{'archived': item.status === 'ERROR' }">
                            {{item.Subscription.length}}
                        </span>
                    </template>
                    <template v-slot:item.actions="{item}">
                        <v-btn v-if="item.Subscription.length === 0" @click="deleteCard(item)" icon>
                            <v-icon small>delete</v-icon>
                        </v-btn>
                        <v-btn v-if="item.Subscription.length > 0" @click="displayCardReplacement(item)" icon>
                            <v-icon small>edit</v-icon>
                        </v-btn>
                    </template>
                </v-data-table>
            </div>
        </div>
        <div class="right_part mb-7">
        </div>
        <v-dialog
            persistent
            max-width="910px"
            v-model="displayModal"
            v-if="modalAction"
            :fullscreen="isMobile"
            :hide-overlay="isMobile"
            :transition="isMobile ? 'dialog-bottom-transition' : ''"
        >
            <v-card>
                <v-card-title>
                     <span class="headline">{{$t(`card.${modalAction}.title`)}}</span>
                </v-card-title>
                <v-card-text class="pa-5">
                    <p class="subtitle-2">
                        {{$t(`card.${modalAction}.details`)}}
                    </p>
                    <payment
                        :paymentMethodId="cardToReplaceId"
                        @close="closeDialog"
                    />
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn @click="modalAction = null" color="white" text>{{$t('actions.cancel')}}</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import {Getter} from "vuex-class";
import Payment from "@/views/front-office/Payment.vue";

@Component({
    components: {Payment},
})
export default class PaymentMethod extends Vue {
    @Getter private currentUser: any;

    @Getter private isMobile: boolean;

    private paymentsMethod: any = [];
    private displayModal: boolean = true;
    private modalAction: string = null;
    private cardToReplaceId: number = null;

    private headers = [
        { value: "effectiveBrand", sortable: false},
        { value: "cardNumber", sortable: false },
        { value: "expirationDate", sortable: false },
        {value: "subscriptions", sortable: false},
        {value: "actions", sortable: false},
    ];
    private mounted() {
        this.getPayments();
    }

    private getPayments() {
        if (this.currentUser) {
            this.$store.dispatch("paymentMethod/getAll", {
                query: {
                    params: {
                            userId: this.currentUser.id,
                            subscriptions: true,
                        },
                    },
            }).then((data) => {
                this.paymentsMethod = data.paymentMethod;
            });
        }
    }

    private deleteCard(card) {
        if (confirm(this.$t("card.deleteConfirmation").toString())) {
            this.$store.dispatch("paymentMethod/deleteById", {id: card.id}).then((res) => {
                this.getPayments();
            });
        }
    }

    private displayCardReplacement(card: any) {
        this.cardToReplaceId = card.id;
        this.modalAction = "replace";
    }

    private closeDialog() {
        this.modalAction = null;
        this.getPayments();
    }
}
</script>