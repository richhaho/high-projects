<template>
    <div class="main-content-display">
        <div class="middle_part flex-grow-1">
            <router-link
                v-if="currentUser && (isAdmin || isMaster() || currentUser.Relays.length > 1)"
                class="fil_arianne gris"
                :to="{ name: 'relays' }">
                <i class="icon-picto_retour"></i>
                {{$t('relay.myRelays')}}
            </router-link>
            <div class="onglets_row">
                <a
                    @click.prevent="tab = 'myRelay'"
                    :title="$t('relay.relay')"
                    :class="{active: tab === 'myRelay'}"
                >
                    <div class="onglet">{{$t('relay.relay')}}</div>
                </a>
                <a
                    @click="tab = 'equipment'"
                    :title="$t('relay.equipment')"
                    :class="{active: tab === 'equipment'}"
                >
                    <div class="onglet">{{$t('relay.equipment')}}</div>
                </a>
                <a
                    href="#"
                    @click="tab = 'keys'"
                    :title="$t('relay.keys')"
                    :class="{active: tab === 'keys'}"
                >
                    <div class="onglet">{{$t('relay.keystogive')}} / {{$t('relay.keystodrop')}}</div>
                </a>
            </div>
            <div v-if="tab === 'myRelay' && relay">
                <relay-status
                    v-if="isAdmin"
                    :relay="relay"
                    :update="updateRelay"
                />
                <relay-stat
                    v-if="isAgency"
                    v-show="false"
                />
                <relay-alert-keys
                    v-if="isAgency"
                    :relay="relay"
                    :update-data="reset"
                />
                <relay-graph-key
                    v-if="isAgency && statCount > 0"
                    :stats="relayKeysStats"
                />
                <relay-balance
                    v-if="isFlow || isLongTerm"
                    :relay="relay"
                    :balanceInfo="balanceInfo"
                    :update="updateRelay"
                    @reset="reset"
                />
                <relay-info
                    :has-right="hasEditRight"
                    :owner="owner"
                    :relay="relay"
                    :update="updateRelay"
                />
                <relay-bank-info
                    v-if="isFlow || isLongTerm"
                    :has-right="hasEditRight"
                    :relay="relay"
                    :update="updateRelay"
                />
                <log-table
                    :logs="logs"
                    @get-logs="getLogs"
                />
            </div>
            <div v-if="tab === 'equipment' && relay">
                <v-row v-if="canReserveLocationsForCompany" class="justify-center">
                    <relay-reserve-locations
                        :relay="relay"
                        @reset="reset"
                    />
                </v-row>
                <div class="row" v-if="relayBoxes && relayBoxes.length">
                    <div v-for="(box, i) in relayBoxes" :key="i" class="col-md-6">
                        <relay-box
                            :box="box"
                            :index="i"
                            :minimumKeys="relay.minimumKeysNeeded"
                            @reset="reset"
                        />
                    </div>
                </div>
                <v-row class="py-5 d-flex justify-content-center">
                    <div class="ma-3">
                        <relay-create-or-edit-box
                            :relayBoxes="relayBoxes"
                            @reset="reset"
                        />
                    </div>
                    <div class="ma-3">
                        <relay-request-new-box
                            :relayId="relay.id"
                        />
                    </div>
                    <div class="ma-3">
                        <relay-request-connected-box
                            :relayId="relay.id"
                        />
                    </div>
                </v-row>
            </div>
            <div v-if="tab === 'keys' && relay">
                <relay-keys
                    :relay="relay"
                    @reset="reset"
                />
            </div>
        </div>
        <div class="right_part no_padding">
        </div>
    </div>
</template>
<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";
import router from "@/router";
import SchedulePicker from "@/components/SchedulePicker.vue";
import RelayInfo from "@/components/relays/RelayInfo.vue";
import RelayStat from "@/components/relays/RelayStat.vue";
import RelayGraphKey from "@/components/relays/RelayGraphKey.vue";
import RelayBalance from "@/components/relays/RelayBalance.vue";
import RelayBankInfo from "@/components/relays/RelayBankInfo.vue";
import RelayKeys from "@/components/relays/RelayKeys.vue";
import RelayAlertKeys from "@/components/relays/RelayAlertKeys.vue";
import LogTable from "@/components/logs/LogTable.vue";
import RelayBox from "@/components/relays/RelayBox.vue";
import RelayCreateOrEditBox from "@/components/relays/RelayCreateOrEditBox.vue";
import RelayRequestNewBox from "@/components/relays/RelayRequestNewBox.vue";
import RelayRequestConnectedBox from "@/components/relays/RelayRequestConnectedBox.vue";
import {Getter} from "vuex-class";
import RelayStatus from "@/components/relays/RelayStatus.vue";
import RelayReserveLocations from "@/components/relays/RelayReserveLocations.vue";

const openingHoursFieldDayFn = () => ({
    isActive: true,
    continuous: {
        isActive: true,
        fromHours: "09:00",
        toHours: "18:00",
    },
    morning: {
        isActive: false,
        fromHours: "00:20",
        toHours: "00:00",
    },
    evening: {
        isActive: false,
        fromHours: "00:20",
        toHours: "00:00",
    },
});

@Component({
    components: {
        RelayStatus,
        RelayBox,
        RelayCreateOrEditBox,
        RelayRequestNewBox,
        RelayRequestConnectedBox,
        LogTable,
        RelayBankInfo,
        RelayBalance,
        RelayStat,
        RelayInfo,
        RelayGraphKey,
        RelayKeys,
        RelayAlertKeys,
        SchedulePicker,
        RelayReserveLocations,
    },
})
export default class Relay extends  Vue {
    @Getter private currentUser: any;
    @Getter private isMobileMenuOpen: boolean;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isAdmin: boolean;
    private relay: any = null;
    private relayBoxes: any[] = [];
    private balanceInfo: any = null;
    private referents: object[] = [];
    private tab: string = "myRelay";
    private logs: any = {};
    private hasEditRight: boolean = false;
    private insuranceCompanies: any[] = [];
    private searchInsuranceCompanies: string = "";
    private relayKeysStats: any[] = [];

    @Watch("searchInsuranceCompanies")
    public handlerSearchInsuranceCompanies() {
        this.getInsuranceCompanies();
    }

    get owner(): any {
        return this.relay?.Referents?.find((ref) => ref.UserRelay.isOwner);
    }

    get isOwner(): boolean {
        return this.currentUser?.id === this.owner?.id;
    }

    get statCount() {
        let count: number = 0;
        this.relayKeysStats.map((s) => {
            count += s.count;
        });
        return count;
    }

    private mounted() {
        this.reset();
    }

    private reset() {
        if (this.$route.params.id) {
            this.getRelay(this.$route.params.id);
        }
    }

    get isAgency(): boolean {
        return this.relay?.type === "AGENCY";
    }

    get isFlow(): boolean {
        return this.relay?.type === "FLOW";
    }

    get isLongTerm(): boolean {
        return this.relay?.type === "LONG_TERM";
    }

    get canReserveLocationsForCompany(): boolean {
        return this.isAdmin && this.isLongTerm && this.relay.status === 4;
    }

    private getInsuranceCompanies() {
        return this.$store.dispatch("companies/read", {
            query: {
                search: this.searchInsuranceCompanies,
                type: "insurance",
            },
        }).then((res) => {
            this.insuranceCompanies = res.rows;
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private updateRelay(relay) {
        return this.$store.dispatch("relays/update", {id: relay.id, relay}).then((res) => {
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("actions.saved"),
            });
            this.reset();
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private getRelay(id) {
        if (this.relay) {
            this.relay.picturePath = null;
        }
        this.$store.dispatch("relays/getById", {id}).then((relay) => {
            this.relay = relay;
            if ((this.isFlow || this.isLongTerm) && (this.isAdmin || this.isOwner)) {
                this.getRelayBalanceInfo(this.$route.params.id);
            }
            if (this.hasRight(relay.Referents)) {
                this.$store.dispatch("relays/getKeyStatsById", {id: relay.id}).then(
                    (data) => {
                        this.relayKeysStats = data;
                    },
                );
                this.$store.dispatch("relays/getBoxes", {id: relay.id}).then(
                    (data) => {
                        this.relayBoxes = data?.rows || [];
                    },
                );
            } else {
                return router.push({name: "home"});
            }
        }).catch(() => router.push({name: "home"}));
    }

    private getLogs(params?: any) {
        if (this.relay?.id) {
            this.$store.dispatch("logs/getLogs", {
                query: {
                    currentPage: "relay",
                    entityId: this.relay.id,
                    entityType: "relay",
                    ...params,
                },
            }).then((res) => {
                this.logs = res;
            });
        }
    }

    private getRelayBalanceInfo(id) {
        this.$store.dispatch("relays/getBalance", {id}).then((res) => {
            this.balanceInfo = res;
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private hasRight(referents) {
        let found: boolean = false;

        if (!this.currentUser) {
            return false;
        }
        if (this.currentUser.isAdmin) {
            this.hasEditRight = true;
            return true;
        }
        referents.map((ref) => {
            if (ref.id === this.currentUser.id) {
                found = true;
                if (ref.UserRelay.isOwner) {
                    this.hasEditRight = true;
                }
            }
        });
        return found;
    }
}
</script>
