<template>
    <div class="main-content-display relaysmap-view">
        <div class="middle_part">
            <div class="mots_cles mb-3">{{ $t(`relay.transactions.${currentTab}`) }}</div>
            <v-col cols="11" class="onglets_row pa-0">
                <a
                    href="#"
                    @click.prevent="changeTab('transactions')"
                    :title="$t('contacts.contacts')"
                    :class="{active: currentTab === 'transactions'}"
                >
                    <div class="onglet">{{$t('relay.transactions.transactions')}}</div>
                </a>
                <a
                    href="#"
                    @click.prevent="changeTab('keys')"
                    :title="$t('relay.transactions.keys')"
                    :class="{active: currentTab === 'keys'}"
                >
                    <div class="onglet">{{$t('relay.transactions.keys')}}</div>
                </a>
            </v-col>
            <v-row v-if="currentTab === 'transactions'" class="fill-height">
                <v-col cols="5">
                    <p class="tableau_titre mt-0">
                        {{$t('relay.transactions.drop.title')}}
                    </p>
                    <v-row v-if="dropTransactions.length" class="ma-0">
                        <v-col cols="12" v-for="(transaction, index) in dropTransactions" :key="index">
                            <transaction-item
                                :transaction="transaction"
                                :show-actions="true"
                                @accept="accept"
                                @decline="decline"
                            />
                        </v-col>
                    </v-row>
                    <p v-else>
                        {{$t('relay.transactions.drop.noData')}}
                    </p>
                </v-col>
                <v-col cols="1" align="center" class="pa-0">
                    <v-divider vertical></v-divider>
                </v-col>
                <v-col cols="5">
                    <p class="tableau_titre mt-0">
                        {{$t('relay.transactions.withdraw.title')}}
                    </p>
                    <v-row v-if="withdrawTransactions.length">
                        <v-col cols="12" v-for="(transaction, index) in withdrawTransactions" :key="index">
                            <transaction-item
                                :transaction="transaction"
                                :show-actions="true"
                                @accept="accept"
                                @decline="decline"
                            />
                        </v-col>
                    </v-row>
                    <p v-else>
                        {{$t('relay.transactions.withdraw.noData')}}
                    </p>
                </v-col>
            </v-row>
            <v-row v-else-if="currentTab === 'keys'">
                <v-col cols="11">
                    <keys-with-users/>
                </v-col>
            </v-row>
        </div>
    </div>
</template>
<script lang="ts">
import {Component, Vue} from "vue-property-decorator";
import TransactionItem from "@/components/relays/TransactionItem.vue";
import KeysWithUsers from "@/components/keys/KeysWithUsers.vue";

const REFRESH_TIME_MILLI: number = 3000;

@Component({
    components: {
        TransactionItem,
        KeysWithUsers,
    },
})
export default class RelayTransactions extends Vue {
    private currentTab: string = null;
    private transactions: any = [];
    private intervalId: any = null;

    get dropTransactions(): any[] {
        return this.transactions.filter((t) => t.type === "DROP").sort((a, b) => a.createdAt - b.createdAt);
    }

    get withdrawTransactions(): any[] {
        return this.transactions.filter((t) => t.type === "WITHDRAW").sort((a, b) => a.createdAt - b.createdAt);
    }

    private mounted(): void {
        this.changeTab("transactions");
    }

    private changeTab(tab) {
        this.currentTab = tab;
        if (this.currentTab !== "transactions") {
            clearInterval(this.intervalId);
        } else {
            this.getRelaysTransactions();
            this.intervalId = setInterval(() => this.getRelaysTransactions(), REFRESH_TIME_MILLI);
        }
    }

    private getRelaysTransactions(): void {
        this.$store.dispatch("relays/getTransactions").then((data) => {
            this.transactions = data;
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private accept(transaction: any): void {
        this.$store.dispatch("relays/acceptTransaction", {
            keyId: transaction.key.id,
        }).then(() => {
            this.getRelaysTransactions();
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("relay.transactions.accepted"),
            });
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private decline(transaction: any): void {
        this.$store.dispatch("relays/declineTransaction", {
            keyId: transaction.key.id,
        }).then(() => {
            this.getRelaysTransactions();
            this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("relay.transactions.declined"),
            });
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
    }

    private beforeDestroy(): void {
        clearInterval(this.intervalId);
    }
}
</script>
