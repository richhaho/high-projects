<template>
    <div class="main-content-display">
        <div class="middle_part flex-grow-1">
            <div class="mots_cles">
                <span>{{$t('relay.listTitle')}}</span>
            </div>
            <div class="onglets_row" v-if="isAdmin">
                <a @click.prevent="changeTab('AGENCY')"
                    :class="{active: currentTab === 'AGENCY'}"
                >
                    <div class="onglet">{{$t('relay.agency')}}</div>
                </a>
                <a @click.prevent="changeTab('FLOW')"
                    :class="{active: currentTab === 'FLOW'}"
                >
                    <div class="onglet">{{$t('relay.flow')}}</div>
                </a>
                <a @click.prevent="changeTab('LONG_TERM')"
                    :class="{active: currentTab === 'LONG_TERM'}"
                >
                    <div class="onglet">{{$t('relay.longTerm')}}</div>
                </a>
            </div>
            <div class="tableau">
                <div class="options">
                    <div class="option_left">
                        <v-text-field
                            append-icon="search"
                            hide-details
                            single-line
                            v-bind:label="$t('actions.search')"
                            v-model="pagination.search"
                        ></v-text-field>
                    </div>
                    <div class="option_right">
                        <button
                            v-if="isAdmin || isMaster('B2B')"
                            type="button"
                            class="option open_popup"
                            @click="openRelayCreation()"
                        >
                            <i class="icon-picto_ajouter"></i>
                            {{$t('actions.create')}}
                        </button>
                    </div>
                </div>
                <v-data-table
                    :headers="headers"
                    :hide-default-footer="totalRelays < pagination.itemsPerPage"
                    :items="relays"
                    :no-data-text="$t(`relay.noData.${pagination.type || 'DEFAULT'}`)"
                    :options.sync="pagination"
                    :search="pagination.search"
                    :server-items-length="totalRelays"
                    class="elevation-1 hover-pointer"
                    @click:row="clickRow"
                >
                    <template v-slot:header.name="{ header }">
                        {{ $t('form.name') }}
                    </template>
                    <template v-slot:header.Referents="{ header }">
                        {{ $t('form.referents') }}
                    </template>
                    <template v-slot:header.address="{ header }">
                        {{ $t('form.address') }}
                    </template>
                    <template v-slot:header.status="{ header }">
                        {{ $t('form.status') }}
                    </template>
                    <template v-slot:header.createdAt="{ header }">
                        {{ $t('form.createdAt') }}
                    </template>
                    <template v-slot:item.address="{ item }">
                        {{ item.address }}{{ item.city ? ', '+item.city : '' }}{{ item.country ? ', '+item.country : '' }}
                    </template>
                    <template v-slot:item.status="{ item }">
                        {{  $t(getStatus(item))}}
                    </template>
                    <template v-slot:item.createdAt="{ item }">
                        {{ item.createdAt | formatShortDate}}
                    </template>
                    <template v-slot:item.Referents="{ item }">
                        <user-list-avatar :users="item.Referents"/>
                    </template>
                </v-data-table>
            </div>
        </div>
        <div class="right_part">
        </div>
        <restriction-dialog
            @close="isRestrictedOn = null"
            :type="isRestrictedOn"
        />
        <relay-create
            :show.sync="showCreate"
            :update-data="getRelays"
        />
    </div>
</template>

<script lang="ts">
import {Vue, Watch, Component} from "vue-property-decorator";
import RelayCreate from "@/components/relays/RelayCreate.vue";
import UserListAvatar from "@/components/users/UserListAvatar.vue";
import RestrictionDialog from "@/components/RestrictionDialog.vue";
import {Getter} from "vuex-class";
import {canCreateMoreRelays} from "plan-restrictions";

@Component({
    components: {
        RelayCreate,
        UserListAvatar,
        RestrictionDialog,
    },
})

export default class Relay extends  Vue {
    @Getter private currentUser: any;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isAdmin: boolean;
    private loading: boolean = true;
    private relays: object[] = [];
    private relayType: string = null;
    private pagination: any = {};
    private totalRelays: number = 0;
    private headers: object[] = [
        {value: "name", sortable: true},
        {value: "Referents", sortable: false},
        {value: "address", sortable: true},
        {value: "status", sortable: true},
        {value: "createdAt", sortable: true},
    ];
    private showCreate: boolean = false;
    private currentTab: string = "AGENCY";
    private isRestrictedOn: string = null;
    private canCreateMoreRelays: (
        company: any,
    ) => boolean = canCreateMoreRelays;

    @Watch("pagination", { deep: true })
    public handlerPagination(val, oldVal) {
        if (val.page === oldVal.page) {
            val.page = 1;
        }
        this.loading = true;
        this.getRelays().then(() => this.loading = false);
    }

    @Watch("currentTab", { immediate: true })
    public handlerCurrentTab() {
        this.pagination = {
            page: 1,
            itemsPerPage: 10,
            type: this.isAdmin ? this.currentTab : null,
            userId: this.isAdmin ? null : this.currentUser.id,
            nonActivated:  this.isAdmin,
        };
    }

    private mounted() {
        this.setPageType(this.$router.currentRoute.name);
    }

    get canCreateRelay(): boolean {
        return (this.currentUser?.company?.Subscriptions?.length && this.totalRelays < 1)
            || this.canCreateMoreRelays(this.currentUser?.company);
    }

    private openRelayCreation(): void {
        if (this.isAdmin) {
            if (this.currentTab === "AGENCY") {
                this.showCreate = true;
            } else {
                this.$router.push({name: "admin-create-relay"});
            }
        } else if (this.isMaster("B2B")) {
            if (this.canCreateRelay) {
                this.showCreate = true;
            } else {
                this.isRestrictedOn = "canCreateMoreRelays";
            }
        } else {
            // No one else is able to create relays
        }
    }

    private clickRow(item) {
        return this.$router.push({name: "relay", params: {id: item.id}});
    }

private getStatus(relay) {
    return `relay.status.${relay.type}.${relay.status}`;
}

private getRelays() {
    return this.$store.dispatch("relays/getAll", {query: this.pagination})
        .then((res) => {
            this.relays = res.relays;
            this.totalRelays = res.count;
        })
        .catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
        });
}

    private setPageType(routeName: string) {
        switch (routeName) {
            case "admin-relays-agency":
                this.relayType = this.pagination.type = "AGENCY";
                break;
            case "admin-relays-flow":
                this.relayType = this.pagination.type = "FLOW";
                break;
            case "admin-relays-long-term":
                this.relayType = this.pagination.type = "LONG_TERM";
                break;
            default:
                break;
        }
    }

    private changeTab(tab) {
        this.currentTab = tab;
        this.pagination.type = tab;
    }
}
</script>
