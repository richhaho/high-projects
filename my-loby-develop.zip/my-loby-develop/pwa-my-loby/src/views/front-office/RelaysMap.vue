<template>
    <div class="main-content-display relaysmap-view">
        <div class="middle_part">
            <div class="mots_cles mb-0">{{$t(`keysList.myKeys`)}}</div>
            <div class="relais_liste">
                <div class="toggle_carte">
                    <label>{{$t('relaysMap.displayMap')}}</label>
                    <div class="onoffswitch">
                        <input type="checkbox"
                               v-model="pickedDisplayMap"
                               name="carte" class="onoffswitch-checkbox" id="myonoffswitch" checked>
                        <label class="onoffswitch-label" for="myonoffswitch">
                            <span class="onoffswitch-inner" @click="displayMapFn()"></span>
                            <span class="onoffswitch-switch"  @click="displayMapFn()"></span>
                        </label>
                    </div>
                </div>
                <div class="tableau">
                    <v-row no-gutters>
                        <v-col :cols="12"  v-bind:class="{ 'col-lg-6': mapDisplayed, 'col-lg-12': !mapDisplayed }">
                            <div class="options">
                                <div class="option_left">
                                        <v-row>
                                            <address-geo
                                                :relay-map="true"
                                                v-bind:latitude.sync="addressSearch.latitude"
                                                v-bind:longitude.sync="addressSearch.longitude"
                                                :label="$t('actions.searchAddress')"
                                            ></address-geo>
                                        </v-row>
                                </div>
                            </div>
                            <div class="les_relais">
                                <form class="form_relais_inner" v-if="isB2B">
                                    <label>{{$t('relaysMap.displayOnlyAgencies')}}</label>
                                    <div class="onoffswitch">
                                        <input
                                            type="checkbox"
                                            name="agencesswitch"
                                            v-model="pickedOnlyAgency"
                                            class="onoffswitch-checkbox"
                                            id="agencesswitch"
                                            checked
                                        >
                                        <label class="onoffswitch-label" for="agencesswitch">
                                            <span class="onoffswitch-inner"></span>
                                            <span class="onoffswitch-switch"></span>
                                        </label>
                                    </div>
                                </form>
                                <v-row class="row_forced">
                                    <v-col :cols="12" v-for="(relay, index) in currentPageRelays" @click="selectRelay(relay)" :key="index">
                                        <article v-bind:class="{ selected: selectedRelayId === relay.id }">
                                            <v-row>
                                                <v-col cols="4" class="picture">
                                                    <img v-if="relay.picturePath" :src="getSrc(relay.picturePath)"/>
                                                </v-col>
                                                <v-col cols="8" class="bloc">
                                                    <v-row>
                                                        <v-col cols="8" class="pb-0">
                                                            <p class="mb-0 pb-0">
                                                                <strong>
                                                                    {{relay.name}}
                                                                </strong>
                                                            </p>
                                                        </v-col>
                                                        <v-col cols="4" class="distance pb-0">
                                                            <v-btn
                                                                v-if="relay.distance && hasSearchAddress"
                                                                :href="relay.itinerary"
                                                                target="_blank"
                                                                class="v-btn--active text-none"
                                                                color="green"
                                                                rounded
                                                                text
                                                                x-small
                                                            >
                                                                <v-icon left x-small>near_me</v-icon>
                                                                {{displayDistance(relay.distance)}}
                                                            </v-btn>
                                                        </v-col>
                                                    </v-row>
                                                    <v-row>
                                                        <v-col cols="12" class="pt-0">
                                                            <p class="mb-0">
                                                                <v-chip v-if="relay.type === 'AGENCY'"
                                                                        x-small chip
                                                                        class="my-1"
                                                                        color="#070a33"
                                                                        text-color="white"
                                                                >
                                                                    {{$t('relaysMap.agencyRelay')}}
                                                                </v-chip>
                                                                <v-chip v-if="isB2B && relay.type === 'FLOW'"
                                                                        x-small chip
                                                                        class="my-1"
                                                                        color="#070a33"
                                                                        outlined
                                                                >
                                                                    {{$t('relaysMap.flowRelay')}}
                                                                </v-chip>
                                                                <br/>
                                                                {{relay.address}}
                                                                <br/>
                                                                {{relay.zipCode}}
                                                                {{relay.city}}
                                                            </p>
                                                            <relay-closed
                                                                :closures="relay.exceptionalClosures"
                                                                messagePath="relay.currentlyClosed"
                                                            ></relay-closed>
                                                            <!--<span class="reseau"><span><i class="icon-picto_editer"></i> 4G</span> 3 codes promos en cours</span>-->
                                                            <button
                                                                v-if="canCreateKey && isRelayCorrectType(relay)"
                                                                class="btn_style orange"
                                                                @click="showCreateDialog = true"
                                                            >
                                                                <i class="icon-picto_cle-partagees"></i>
                                                                {{$t('relaysMap.assignKey')}}
                                                            </button>
                                                        </v-col>
                                                    </v-row>
                                                </v-col>
                                            </v-row>
                                        </article>
                                    </v-col>
                                    <key-create
                                        v-if="canCreateKey"
                                        :show.sync="showCreateDialog"
                                        :canUseManagers="canUseManagers"
                                        :selectedRelay="selectedRelay"
                                        @update-data="showCreateDialog = false"
                                    />
                                </v-row>
                                <v-row>
                                    <v-pagination
                                        color="#0c0733"
                                        v-model="pagination.page"
                                        :length="countPages"
                                        :total-visible="7"
                                    ></v-pagination>
                                </v-row>
                            </div>
                            <!-- /.les_relais -->
                        </v-col>
                        <v-col :cols="12" :md="6" v-if="mapDisplayed" style="min-height: 700px">
                            <!--map here-->
                            <l-map
                                ref="map"
                                :zoom="zoom"
                                :center="center"
                                style="height: 100%; width: 100%; max-height: 800px">
                                <l-tile-layer :url="url"></l-tile-layer>
                                <l-marker
                                    v-for="(relay,index) in mapableRelay"
                                    @click="selectRelay(relay)"
                                    :lat-lng="getLatLng(relay.latitude, relay.longitude)"
                                    :key="index"
                                    style="margin-left: 500px;"
                                >
                                </l-marker>
                            </l-map>
                        </v-col>
                    </v-row>
                </div>
                <!-- /.tableau -->
            </div>
            <!-- /.relais_liste -->
        </div>

        <div class="right_part no_padding">
            <section v-if="selectedRelay">
                <div class="bloc titre_bloc">
                    <p>
                        <i class="icon-picto_cle-partagees"></i>
                        <span class="titre_bloc_right_text">
                            <span class="strong">{{selectedRelay.name}}</span>
                        <br>
                        <span>{{selectedRelay.address}}</span>
                        </span>
                    </p>
                </div>
            </section>


            <section class="horaires" v-if="selectedRelay">
                <div class="bloc">
                    <h6>{{$t('relay.schedule')}}</h6>
                    <p>
                        <span v-bind:class="{ today: day === 1 }">{{$t('day.monday')}} {{displaySchedule(selectedRelay.companyOpeningHours.monday)}}</span><br/>
                        <span v-bind:class="{ today: day === 2 }">{{$t('day.tuesday')}} {{displaySchedule(selectedRelay.companyOpeningHours.tuesday)}}</span><br/>
                        <span v-bind:class="{ today: day === 3 }">{{$t('day.wednesday')}} {{displaySchedule(selectedRelay.companyOpeningHours.wednesday)}}</span><br/>
                        <span v-bind:class="{ today: day === 4 }">{{$t('day.thursday')}} {{displaySchedule(selectedRelay.companyOpeningHours.thursday)}}</span><br/>
                        <span v-bind:class="{ today: day === 5 }">{{$t('day.friday')}} {{displaySchedule(selectedRelay.companyOpeningHours.friday)}}</span><br/>
                        <span v-bind:class="{ today: day === 6 }">{{$t('day.saturday')}} {{displaySchedule(selectedRelay.companyOpeningHours.saturday)}}</span><br/>
                        <span v-bind:class="{ today: day === 0 }">{{$t('day.sunday')}} {{displaySchedule(selectedRelay.companyOpeningHours.sunday)}}</span><br/>
                    </p>
                </div>
            </section>
        </div>
    </div>
</template>
<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";
import {LMap, LMarker, LPopup, LTileLayer} from "vue2-leaflet";
import {canCreateMoreKeys, canUseFlowRelays, canUseManagers} from "plan-restrictions";
/*MAP*/
import { Icon } from "leaflet";
import "leaflet/dist/leaflet.css";
import {Getter} from "vuex-class";
import AddressGeo from "@/components/AddressGeo.vue";
import {getSrc} from "@/utils/misc";
import RelayClosed from "@/components/relays/RelayClosed.vue";
import KeyCreate from "@/components/keys/KeyCreate.vue";

delete (Icon as any).Default.prototype._getIconUrl;
Icon.Default.mergeOptions({
    iconUrl: require("./../../../public/img/marker-icon.png"),
    iconRetinaUrl: require("./../../../public/img/marker-icon-2x.png"),
    iconSize: [20, 20],
});
/*END MAP*/

declare var L: any;
@Component({
    components: {
        LMap,
        LTileLayer,
        LMarker,
        LPopup,
        AddressGeo,
        RelayClosed,
        KeyCreate,
    },
})
export default class Relays extends Vue {

    get mapableRelay() {
        return this.displayedRelay.filter((r: any) => r.longitude && r.latitude);
    }

    get displayedRelay() {
        return this.pickedOnlyAgency ? this.relays.filter((r: any) => r.type === "AGENCY") : this.relays;
    }

    get currentPageRelays() {
        return this.displayedRelay.slice((this.pagination.page - 1) * this.pagination.perPage,
            this.pagination.page * this.pagination.perPage);
    }

    get countRelays() {
        return this.displayedRelay.length;
    }

    get countPages() {
        return Math.ceil(this.countRelays / this.pagination.perPage);
    }

    get isCompanyBlocked(): boolean {
        return !!this.currentUser?.company?.blockedAt;
    }

    get canCreateKey(): boolean {
        return !this.isCompanyBlocked && !this.disableKeyCreation;
    }

    @Getter private currentUser: any;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isB2B: boolean;
    private relays: any = [];
    private zoom = 6;
    private mapDisplayed = true;
    private center = this.getLatLng(46.227638, 2.213749);
    private url = "http://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png";
    private selectedRelayId = null;
    private day = new Date().getDay();
    private pickedDisplayMap: boolean = false;
    private pickedOnlyAgency: boolean = false;
    private canUseFlowRelays: (company: any) => boolean = canUseFlowRelays;
    private addressSearch: any = {
        longitude: "",
        latitude: "",
    };
    private hasSearchAddress: boolean = false;
    private selectedRelay: any = null;
    private pagination: any = {
        page: 1,
        perPage: 3,
    };
    private canUseManagers: (company: any) => boolean = canUseManagers;
    private canCreateMoreKeys: (
        company: any,
        existingKeysNbr: number,
        newKeysNbr: number,
    ) => boolean = canCreateMoreKeys;
    private disableKeyCreation: boolean = true;
    private showCreateDialog: boolean = false;
    private getSrc: (string) => string = getSrc;

    private isRelayCorrectType(relay: any): boolean {
        return !this.currentUser?.companyId || relay?.type === "AGENCY";
    }

    @Watch("addressSearch", {deep: true})
    private async searchHandler() {
        this.pagination.page = 1;
        if (this.addressSearch.latitude && this.addressSearch.longitude) {
            this.hasSearchAddress = true;
            this.getRelaysDistance();
            await (this.$refs.map as any)?.mapObject.setView(
                this.getLatLng(this.addressSearch.latitude, this.addressSearch.longitude), 13);
        } else {
            this.hasSearchAddress = false;
            this.sortRelays();
        }
    }

    @Watch("pickedOnlyAgency", {deep: true})
    private relayHandler() {
        this.pagination.page = 1;
        this.selectedRelay = null;
        this.selectedRelayId = null;
    }

    @Watch("selectedRelayId", {deep: true})
    private selectedRelayHandler() {
        this.getRelayDetails();
    }

    private mounted() {
        this.restrictKeyCreation(this.currentUser);
        this.getListRelays();
    }

    private getLatLng(latitude, longitude) {
        return L.latLng(latitude, longitude);
    }

    private displayMapFn() {
        this.mapDisplayed = this.pickedDisplayMap;
    }

    private selectRelay(relay) {
        this.selectedRelayId = relay.id;
        (this.$refs.map as any)?.mapObject.setView(this.getLatLng(relay.latitude, relay.longitude), 13);
        const popup = L.popup()
        .setLatLng(this.getLatLng(relay.latitude, relay.longitude))
        .setContent(`<h4>${relay.name}</h4>${relay.address}, ${relay.zipCode}, ${relay.city}`)
        .openOn((this.$refs.map as any)?.mapObject);
    }

    private getListRelays() {
        return this.$store.dispatch("relays/getForMap").then((data) => {
            this.relays = data.relays;
            this.sortRelays();
            setTimeout(function() { window.dispatchEvent(new Event("resize")); });
        });
    }
    private getRelayDetails() {
        return this.$store.dispatch("relays/getById", {id: this.selectedRelayId })
            .then((res) => {
              this.selectedRelay = res;
        });
    }

    private restrictKeyCreation(user: any) {
        if (user.companyId) {
            Promise.all([
                this.$store.dispatch("companies/countKeys", {id: user.companyId}),
                this.$store.dispatch("users/countManagedKeys", {id: user.id}),
            ])
            .then(([companyCountKeys, userCountKeys]) => {
                // A company cannot create more keys than the max of its plan
                const companyCannotCreateKeys: boolean = !this.canCreateMoreKeys(user.company, companyCountKeys, 1);
                // A manager cannot create keys if he doesn't manage at least one yet
                const userCannotCreateKeys: boolean = !this.isMaster() && userCountKeys === 0;
                this.disableKeyCreation = companyCannotCreateKeys || userCannotCreateKeys;
            })
            .catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err,
                });
            });
        } else {
            this.disableKeyCreation = false;
        }
    }

    private displaySchedule(day) {
        if (day.isActive) {
            if (day.continuous.isActive) {
                return `${day.continuous.fromHours} - ${day.continuous.toHours}`;
            } else if (day.morning.isActive && day.evening.isActive) {
                return `${day.morning.fromHours} - ${day.morning.toHours} / ${day.evening.fromHours} - ${day.evening.toHours}`;
            }
        }
    }

    private getDistance(lat1, lon1, lat2, lon2) {
        const R = 6371;
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180 ) * Math.cos(lat2 * Math.PI / 180 ) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const d = R * c;
        return d;
    }

    private displayDistance(d) {
        if (d > 1) { return Math.round(d) + "km"; } else if (d <= 1) { return Math.round(d * 1000) + "m"; }
        return d;
    }

    private getRelayDistance(relay) {
        if (this.addressSearch.latitude && this.addressSearch.longitude) {
            return this.getDistance(this.addressSearch.latitude, this.addressSearch.longitude,
                relay.latitude, relay.longitude );
        }
        return null;
    }

    private async getRelaysDistance() {
        this.relays = await this.relays.map((r) => {
            r.distance = this.getRelayDistance(r);
            return r;
        });
        this.sortRelays();
    }

    private sortRelays() {
        if (this.hasSearchAddress) {
            this.relays = this.relays.sort(this.compareRelay("distance"));
        } else {
            this.relays = this.relays.sort(this.compareRelay("name"));
        }
    }

    private compareRelay(prop) {
        return (a, b) => {
            if ( a[prop] < b[prop] ) {
                return -1;
            }
            if ( a[prop] > b[prop] ) {
                return 1;
            }
            return 0;
        };
    }

}
</script>
