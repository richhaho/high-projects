<template>
    <div class="main-content-display profile_page hidden-xs-only" v-if="user">
        <div class="middle_part">
            <router-link
                v-if="isAdmin"
                :to="{name: 'admin-users'}"
                :title="$t('nav.users')"
                class="fil_arianne"
            >
                <i class="icon-picto_retour"></i>
                {{$t('nav.users')}}
            </router-link>
            <router-link
                v-else
                :to="{name: 'contacts'}"
                :title="$t('nav.my_contacts')"
                class="fil_arianne"
            >
                <i class="icon-picto_retour"></i>
                {{$t('nav.my_contacts')}}
            </router-link>


            <div class="tableau">
                <div class="options">
                    <div class="option_left">
                        <p class="light_text">{{$t('user.createdAtSentence')}} : {{user.createdAt | formatDate}}</p>
                    </div>
                    <!-- /.option_left -->
                    <div class="option_right">
                        <edit-user
                            :user="user"
                            :can-edit-profile="canEditProfile"
                            :default-user-avatar="defaultUserAvatar"
                            @user-updated="reset"
                        ></edit-user>
                    </div>
                    <!-- /.option_right -->
                </div>
                <!-- /.options -->
                <v-row>
                    <v-col :cols="12" :md="12" class="profil_infos">
                        <div class="resume_wrap">
                            <div class="image mb-2 mt-1">
                                <img
                                    :src="getSrc(user.picturePath) || defaultUserAvatar"
                                    alt="userAvatar"
                                    class="img"
                                >
                            </div>
                            <p v-if="user.firstName && user.lastName">
                                {{user.firstName}}
                                <br>
                                <span class="strong">{{user.lastName}}</span>
                            </p>
                            <p v-else>
                                <span class="strong">{{user.displayName}}</span>
                            </p>
                            <!--<div class="id">#12983451</div>-->
                        </div>
                        <div class="liste_info">
                            <p>{{$t('user.profileType')}} :
                                <span class="strong" v-if="user.isAdmin">Admin</span>
                                <span class="strong" v-else-if="user.masterOf && !!user.masterOf.length">Master</span>
                                <span class="strong" v-else>User</span>
                            </p>
                            <p v-if="user.specificCompanyName">
                                {{$t('form.company')}} : <span class="strong"> {{user.specificCompanyName}}</span>
                                <span v-if="user.job"> ({{user.job}})</span>
                            </p>
                            <p v-else-if="user.company">
                                {{$t('form.company')}} : <span class="strong"> {{user.company.name}}</span>
                                <span v-if="user.job"> ({{user.job}})</span>
                            </p>
                            <!--<p>{{user.phone}}</p>-->
                            <p v-if="user.company">{{$t('company.siret')}} : <span class="strong">{{user.company.siret}}</span></p>
                        </div>
                    </v-col>
                    <!-- TODO replace this with actual tags or something else
                    <v-col :cols="12" :md="6" class="col-lg-6 more_infos">
                        <div class="tags">
                            <span class="strong mr-3">Tags :</span>
                            <a v-for="(tag, i) in tags">{{tag[lang]}}</a>
                        </div>
                    </v-col>
                    -->
                </v-row>
            </div>
            <!-- /.tableau -->

            <p class="tableau_titre">{{$t('user.keysAssigned')}}
                <i class="icon-header_triangle"></i>
            </p>
            <div class="onglets_row">
                <a
                    @click.prevent="pagination.tab = 'myKeys'"
                    v-if="!isDemo"
                    :title="isMyPage ? $t('keysList.myKeys') : $t('keysList.hisKeys')"
                    :class="{active: pagination.tab === 'myKeys'}"
                >
                    <div class="onglet">{{isMyPage ? $t('keysList.myKeys') : $t('keysList.hisKeys')}}</div>
                </a>
                <a
                    @click.prevent="pagination.tab = 'sharedKeys'"
                    :title="$t('keysList.sharedKeys')"
                    :class="{active: pagination.tab === 'sharedKeys'}"
                >
                    <div class="onglet">{{$t('keysList.sharedKeys')}}</div>
                </a>
            </div>
            <div class="tableau">
                <div class="options">
                    <div class="option_left">
                        <button class="option" @click.stop="displayKeysFilter = !displayKeysFilter">
                            <i class="icon-picto_filtrer"></i>
                            {{$t('actions.filter')}}
                        </button>
                        <div class="with_filters">
                            <ul class="filters" :class="{'d-block': displayKeysFilter}">
                                <li v-for="(status, index) in keysStatus" :key="index">
                                    <label>
                                        <p-check :value="status" v-model="pagination.select"
                                                 class="p-default p-curve mt-2 p-bigger"
                                                 color="primary"></p-check>
                                        {{$t(`key.statusType.${status}`)}}
                                    </label>
                                </li>
                            </ul>
                        </div>
                        <!-- /.option -->
                    </div>
                    <!-- /.option -->
                    <!-- /.option_left -->
                    <div class="option_right">
                        <!-- TODO: include createKey modal
                        <a v-if="user.id === currentUser.id"
                            class="option"
                           :title="$t('keysList.create')" v-if="!isDemo">
                            <i class="icon-picto_editer"></i>
                            {{$t('keysList.create')}}
                        </a>
                        -->
                        <!-- /.option -->
                    </div>
                    <!-- /.option_right -->
                </div>
                <!-- /.options -->

                <v-data-table
                    :headers="headers"
                    :hide-default-footer="totalKeys < pagination.itemsPerPage"
                    :items="keys"
                    :loading="loading"
                    :no-data-text="$t(`keysList.noDataContact.${pagination.tab}`)"
                    :options.sync="pagination"
                    :server-items-length="totalKeys"
                    class="elevation-1 hover-pointer"
                    v-model="selectedKeys"
                    @click:row="clickRow"
                >
                    <template v-slot:header.name="{ header }">{{ $t('key.name') }}</template>
                    <template v-slot:header.owner="{ header }">{{ $t('key.owner') }}</template>
                    <template v-slot:header.relay="{ header }">{{ $t('key.relay') }}</template>
                    <template v-slot:header.status="{ header }">{{ $t('key.status') }}</template>
                    <template v-slot:header.userCount="{ header }">{{ $t('key.userCount') }}</template>
                    <template v-slot:header.location="{ header }">{{ $t('key.location') }}</template>
                    <template
                        v-slot:item.owner="{ item }"
                    >{{ item.owner.displayName }}
                    </template>
                    <template v-slot:item.userCount="{ item }">
                        {{ keyUsersNbr(item) }}
                    </template>
                    <template v-slot:item.relay="{ item }">
                        {{ keyRelayName(item) }}
                    </template>
                    <template v-slot:item.status="{ item }">
                        <key-status :currentKey="item"/>
                    </template>
                    <template v-slot:item.location="{ item }">
                        <v-btn
                            v-if="item.currentLocation && isAdmin"
                            :href="$store.state.baseURL ? `${$store.state.baseURL}/api/locations/${item.currentLocation.id}/generate-qr-code` :
                            `/locations/${item.currentLocation.id}/generate-qr-code`"
                            outlined
                            small
                            target="_blank"
                        >{{ item.currentLocation.codeName }}
                        </v-btn>
                        <div v-else-if="item.currentLocation">{{ item.currentLocation.codeName }}</div>
                    </template>
                </v-data-table>
            </div>
            <log-table
                :logs="logs"
                @get-logs="getLogs"
            />
        </div>
        <!-- /.middle_part -->
        <div class="right_part no_padding">
            <last-logs
                :loading="loadingLogs"
                :logs="lastLogs"
            />
        </div>
        <!-- /.right_part -->
    </div>
</template>
<script lang="ts">
import LastLogs from "@/components/logs/LastLogs.vue";
import LogTable from "@/components/logs/LogTable.vue";
import KeyStatus from "@/components/keys/KeyStatus.vue";
import EditUser from "@/components/users/EditUser.vue";
import {defaultUserAvatar} from "@/utils/constants";
import {Component, Vue, Watch} from "vue-property-decorator";
import router from "@/router";
import {Getter} from "vuex-class";
import {getSrc} from "@/utils/misc";

Component.registerHooks([
    "beforeRouteUpdate",
]);

@Component({
    components: {
        LastLogs,
        KeyStatus,
        LogTable,
        EditUser,
    },
})
export default class User extends Vue {
    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;
    @Getter private isDemo: boolean;
    @Getter private isB2B: boolean;
    private defaultUserAvatar: string = defaultUserAvatar;
    private getSrc: (string) => string = getSrc;
    private userId: number = null;
    private user: any = {};
    private logs: any = {};
    private loadingLogs: boolean = false;
    private lastLogs: any = {};
    private tags: any = [];
    private searchTags: string = null;
    private pagination: any = {
        sortDesc: [false],
        sortBy: [""],
        search: "",
        select: [],
        page: 1,
        itemsPerPage: 10,
        tab: "myKeys",
    };
    private totalKeys: number = 0;
    private headers: object[] = [];
    private logsHeaders: object[] = [];
    private loading: boolean = false;
    private keysStatus: string[] = [];
    private keys: object[] = [];
    private displayKeysFilter: boolean = false;
    private selectedKeys: object[] = [];

    @Watch("pagination", {deep: true})
    public handlerPagination(): void {
        if (this.pagination.search) {
            this.pagination.page = 1;
        }
        this.getKeys();
    }

    get lang(): string {
        return this.$root.$i18n.locale;
    }

    get isMyPage(): boolean {
        return this.currentUser?.id === this.user?.id;
    }

    get canEditProfile(): boolean {
        // Only if this is the current user's page, or the current user is Admin
        return this.isMyPage || this.isAdmin;
    }

    private beforeRouteUpdate(to, from, next): void {
        // Refetch data for new user since component is not re-rendered
        this.userId = to.params?.id;
        this.pagination = {
            sortDesc: [false],
            sortBy: [""],
            search: "",
            select: [],
            page: 1,
            itemsPerPage: 10,
            tab: "myKeys",
        };
        Promise.all([
            this.getUserById(),
            this.getLogs(this.pagination),
            this.getLogs(),
            this.getKeysStatus(),
        ]).then(() => next());
    }

    private mounted(): void {
        this.userId = Number(this.$route.params.id);
        this.reset();
    }

    private reset(): void {
        this.loading = true;
        this.headers = [
            {value: "name", sortable: false},
            {value: "owner", sortable: false},
            {value: "relay", sortable: false},
            {value: "status", sortable: true},
            {value: "userCount", sortable: false},
            {value: "location", sortable: false},
        ];
        this.logsHeaders = [
            {value: "Event", sortable: false},
            {value: "Date", sortable: false},
        ];
        Promise.all([
            this.getUserById(),
            this.getLogs(),
            this.getKeysStatus(),
        ]).then(() => (this.loading = false));
    }

    private getUserById(): Promise<void> {
        return this.$store.dispatch("users/getUserById", {
            id: this.userId,
            options: {
                logs: true,
                masterOf: true,
                company: true,
            },
        })
            .then((user) => {
                this.user = user;
            }).catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err,
                });
            });
    }

    private getLogs(params?: any): void {
        if (this.userId) {
            if (!params) {
                this.loadingLogs = true;
            }
            this.$store.dispatch("logs/getLogs", {
                query: {
                    currentPage: "user",
                    entityId: this.userId,
                    entityType: "user",
                    ...params,
                },
            }).then((res) => {
                if (!params) {
                    this.lastLogs = res;
                    this.loadingLogs = false;
                } else {
                    this.logs = res;
                }
            });
        }
    }

    private getKeys(): Promise<void> {
        const query = Object.assign({}, this.pagination, {
            subscriptions: !this.isB2B && !this.isAdmin,
        });
        const p: Array<Promise<any>> = [
            this.$store.dispatch("users/getMyKeys", {
                id: this.userId,
                query,
            }),
        ];
        if (this.pagination.tab === "sharedKeys") {
            p.push(this.$store.dispatch("users/getLateKeys", { id: this.userId }));
        }
        return Promise.all(p).then((res) => {
            if (res?.[0]?.keys && res?.[1]?.keys) {
                this.keys = res[1].keys.concat(res[0].keys);
            } else if (res?.[0]?.keys) {
                this.keys = res[0].keys;
            }
            this.keys.forEach((key: any) => {
                key.relayId = key?.Relays?.filter((r) => r.type === "AGENCY")?.[0]?.id;
                key.newKeyManagers = [];
                key.newGuests = [];
            });
            this.totalKeys = this.keys?.length || 0;
        });
    }

    private getKeysStatus(): Promise<void> {
        return this.$store.dispatch("keys/getStatus").then((res) => {
            this.keysStatus = res.keysStatus;
        });
    }

    private clickRow(item) {
        return this.$router.push({name: "key", params: {id: item.id}});
    }

    private deleteUser(): void {
        if (confirm(this.$t("user.deleteConfirmation").toString())) {
            this.$store.dispatch("users/deleteUserById", {id: this.$route.params.id})
                .then((res) => router.push({name: "admin-users"}));
        }
    }

    // To get number of users and not number of accesses
    private usersNbrInGroup: (accesses: any[]) => number = (accesses: any[]) =>
        accesses?.reduce((a, c) => {
            // Count users in each group
            c?.Users?.forEach((user) => {
                if (a.every((userId) => userId !== user.id)) {
                    // Count each user only once
                    a.push(user.id);
                }
            });
            return a;
        }, [])?.length || 0

    private keyUsersNbr: (key: any) => number = (key: any) =>
        this.usersNbrInGroup(key?.keyManagers) + this.usersNbrInGroup(key?.guests)

    private keyRelayName: (key: any) => string = (key: any) => key?.Relays?.[0]?.name || "";
}
</script>
