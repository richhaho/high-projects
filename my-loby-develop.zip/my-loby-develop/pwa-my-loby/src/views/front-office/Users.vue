<template>
        <div class="main-content-display contacts-view">
            <div class="middle_part flex-grow-1">
                <!--
                <a href="#" :title="$t('nav.my_contacts')" class="fil_arianne">
                    <i class="icon-picto_retour"></i>
                    {{$t('nav.my_contacts')}}
                </a>
                -->
                <div class="mots_cles">{{$t(`contacts.${currentTab}`)}}</div>
                <div class="onglets_row">
                    <a
                        href="#"
                        @click.prevent="changeTab('contacts')"
                        :title="$t('contacts.contacts')"
                        :class="{active: currentTab === 'contacts'}"
                    >
                        <div class="onglet">{{$t('contacts.contacts')}}</div>
                    </a>
                    <a
                        v-if="isMaster()"
                        href="#"
                        @click.prevent="canManageUser ? changeTab('management') : isRestrictedOn = 'canUseManagers'"
                        :title="$t('contacts.management')"
                        :class="{active: currentTab === 'management'}"
                    >
                        <div class="onglet">{{$t('contacts.management')}}</div>
                    </a>
                    <a
                        href="#"
                        @click.prevent="changeTab('groups')"
                        :title="$t('contacts.groups')"
                        :class="{active: currentTab === 'groups'}"
                    >
                        <div class="onglet">{{$t('contacts.groups')}}</div>
                    </a>
                </div>
                <restriction-dialog
                    v-if="connectedUser && connectedUser.companyId"
                    @close="isRestrictedOn = null"
                    :type="isRestrictedOn"
                />
                <v-dialog max-width="910px" v-model="groupDialog" persistent>
                    <v-card>
                        <v-card-title>
                            <div class="contain_picto">
                                <i class="icon-picto_dossier"></i>
                            </div>
                            <span class="headline">{{$t('list.createGroup')}}</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container>
                                <v-row class="mt-5" justify="center">
                                    <v-col>
                                        <v-row>
                                            <v-text-field
                                                v-bind:label="$t('group.name')"
                                                v-model="userGroupForm.name"
                                            />
                                        </v-row>
                                        <v-row>
                                            <v-text-field
                                                v-bind:label="$t('group.description')"
                                                v-model="userGroupForm.description"
                                            />
                                        </v-row>
                                        <v-row>
                                            <span class="input-title">{{$t('group.type')}}</span>
                                            <v-radio-group
                                                @onchange="handlerNewGroupType"
                                                v-model="userGroupType"
                                                :disabled="userGroupForm.disabled"
                                            >
                                                <v-radio
                                                    :label="$t('contacts.contacts')"
                                                    value="contacts"
                                                ></v-radio>
                                                <v-radio
                                                    :label="$t('contacts.management')"
                                                    value="subordinates"
                                                ></v-radio>
                                            </v-radio-group>
                                        </v-row>
                                        <v-row v-if="userGroupForm.disabled">
                                            <span class="input-title">{{$t('usersList.title')}}</span>
                                            <v-list-item two-line v-for="selectedUser in selectedUsers">
                                                <v-list-item-content>
                                                    <v-list-item-title>{{selectedUser.firstName}}
                                                        {{selectedUser.lastName}}
                                                    </v-list-item-title>
                                                    <v-list-item-subtitle>{{selectedUser.email}}</v-list-item-subtitle>
                                                </v-list-item-content>
                                            </v-list-item>
                                        </v-row>
                                        <v-row v-else>
                                            <v-autocomplete
                                                :items="userGroupSelectable"
                                                :search-input.sync="userGroupSearch"
                                                hide-details
                                                hide-selected
                                                hide-no-data
                                                :label="$t('group.users')"
                                                :no-data-text="$t('group.noUserFound')"
                                                append-icon
                                                prepend-inner-icon="add"
                                                chips
                                                deletable-chips
                                                multiple
                                                v-model="userGroupUsers"
                                            ></v-autocomplete>
                                        </v-row>
                                    </v-col>
                                </v-row>
                            </v-container>
                        </v-card-text>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn @click="close" color="white" text>{{$t('actions.close')}}</v-btn>
                            <v-btn
                                v-if="userGroupForm.name && userGroupUsers.length"
                                @click="createUserGroup"
                                color="warning"
                            >{{$t('actions.create')}}</v-btn>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
                <users-group
                    v-if="currentTab === 'groups'"
                    :loading="loading"
                    :total-users="totalUsers"
                    :users-groups="usersGroups"
                    @selected-groups="selectGroup"
                    @open-create-dialog="displayCreateUserGroupDialog"
                    @reset="reset"
                    class="scroll-list"
                />
                <div class="tableau" v-else>
                    <div class="options">
                        <div class="option_left">
                            <a href="#" class="option view-switcher" title="" @click.prevent="mosaicView = !mosaicView">
                                <i class="icon-picto_mosaique" v-if="mosaicView"></i>
                                <v-icon v-else size="30px">list</v-icon>
                            </a>
                            <v-text-field
                                class="pa-0 ma-0 ml-4"
                                append-icon="search"
                                hide-details
                                single-line
                                v-bind:label="$t('actions.search')"
                                v-model="userSearch"
                                @input="searchHandler"
                            />
                            <!-- /.option -->
                        </div>
                        <!-- /.option_left -->
                        <div class="option_right">
                            <!--
                            <a href="#" class="option" :title="$t('actions.export')">
                                <i class="icon-picto_exporter"></i>
                                {{$t('actions.export')}}
                            </a>
                            -->
                            <import-modal
                                v-if="isMaster() || isB2B"
                                :title="currentTab === 'contacts' ? $t('contacts.importContacts') : $t('usersList.importUsers')"
                                :type="this.currentTab"
                            />
                            <add-contact
                                v-if="currentTab === 'contacts'"
                                :getUsers="getContacts"
                                @reset="reset()"
                            />
                            <add-subordinate
                                v-else-if="currentTab === 'management'"
                                @reset="reset()"
                            />
                            <!-- /.option -->
                        </div>
                        <!-- /.option_right -->
                    </div>
                    <!-- /.options -->
                    <!-- .article_row -->
                    <users-mosaic-view
                        v-if="mosaicView"
                        :selected-users="selectedUsers"
                        :users="users"
                        :loading="loading"
                        v-on:select-contact="selectContact"
                        class="scroll-list"
                    />
                    <v-data-table
                        :headers="headers"
                        :items="users"
                        :loading="loading"
                        :options.sync="pagination"
                        :search="pagination.search"
                        :server-items-length="totalUsers"
                        class="elevation-1 hover-pointer"
                        show-select
                        v-model="selectedUsers"
                        v-else
                        @click:row="clickRow"
                    >
                        <template v-slot:header.firstName="{ header }">
                            {{ $t('user.firstName') }}
                        </template>
                        <template v-slot:header.lastName="{ header }">
                            {{ $t('user.lastName') }}
                        </template>
                        <template v-slot:header.email="{ header }">
                            {{ $t('user.email') }}
                        </template>
                        <template v-slot:header.company="{ header }">
                            {{ $t('user.company') }}
                        </template>
                        <template v-slot:header.job="{ header }">
                            {{ $t('user.job') }}
                        </template>
                        <template v-slot:header.city="{ header }">
                            {{ $t('user.city') }}
                        </template>
                        <template v-slot:header.phone="{ header }">
                            {{ $t('user.phone') }}
                        </template>
                        <template v-slot:header.createdAt="{ header }">
                            {{ $t('user.createdAt') }}
                        </template>
                        <template v-slot:header.activatedAt="{ header }">
                            {{ $t('user.active') }}
                        </template>
                        <template v-slot:item.createdAt="{ item }">
                            {{ item.createdAt | formatDate}}
                        </template>
                        <template v-slot:item.activatedAt="{ item }">
                            <v-chip
                                :color="item.activatedAt ? '#10A807' : '#BABABA'"
                            />
                        </template>
                    </v-data-table>
                </div>
            </div>
            <div class="right_part" :class="{'right_part_groups': type === 'userGroups'}">
               <div>
                   <list-detail
                       :selected-items="selectedUsers"
                       :type="type"
                   ></list-detail>
               </div>
                <input type="hidden" :value="searchQuery">
                <list-select-overlay
                    v-if="type === 'users'"
                    :selected-items="selectedUsers"
                    :select-all="selectAllUsers"
                    :cancel="deselectAllUsers"
                    :delete-items="currentTab === 'management' ? deleteManagers : deleteContacts"
                    :create-group="displayCreateUserGroupDialog"
                />
               </div>
        </div>
</template>
<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";
import ListSelectOverlay from "@/components/list/ListSelectOverlay.vue";
import ListDetail from "@/components/list/ListDetail.vue";
import ImportModal from "@/components/import/ImportModal.vue";
import ImportResults from "@/components/import/ImportResults.vue";
import UsersMosaicView from "@/components/users/UsersMosaicView.vue";
import UsersGroup from "@/views/front-office/UsersGroup.vue";
import AddContact from "@/components/users/AddContact.vue";
import AddSubordinate from "@/components/users/AddSubordinate.vue";
import RestrictionDialog from "@/components/RestrictionDialog.vue";
import {Getter} from "vuex-class";
import {canUseManagers} from "plan-restrictions";
import Timeout = NodeJS.Timeout;

export const DEBOUNCE_TIME_MILLI: number = 500;

@Component({
      components: {
          ListSelectOverlay,
          ListDetail,
          ImportModal,
          ImportResults,
          UsersGroup,
          UsersMosaicView,
          AddContact,
          AddSubordinate,
          RestrictionDialog,
      },
  })
  export default class Users extends Vue {
      @Getter private isMaster: (type?: string) => boolean;
      @Getter private isB2B: boolean;
      private connectedUser: any = {};
      private selectedUsers: any[] = [];
      private users: object[] = [];
      private headers: object[] = [];
      private currentUser: object = {
          firstName: "",
          lastName: "",
          email: "",
          password: "",
          createdAt: "",
      };
      private statsDialog: boolean = false;
      private groupDialog: boolean = false;
      private loading: boolean = false;
      private timerId: Timeout = null;
      private userSearch: string = null;
      private stats: any = null;
      private userGroupForm: any = {};
      private usersGroups: object[] = [];
      private pagination: any = {
          sortDesc: [true],
          sortBy: ["updatedAt"],
          search: "",
          page: 1,
          itemsPerPage: 20,
          keys: true,
      };
      private currentTab: string = "contacts";
      private mosaicView: boolean = true;
      private selected: number[] = [];
      private type: string = "users";
      private canUseManagers: (company: any) => boolean = canUseManagers;
      private isRestrictedOn: string = null;
      private userGroupSearch: string = "";
      private userGroupSelectable: any = [];
      private userGroupType: string = null;
      private userGroupUsers: any[] = [];
      private totalUsers: number = 0;

      @Watch("pagination", {deep: true, immediate: true})
      public handler() {
          this.reset();
      }
      @Watch("userGroupSearch")
      public handlerSearch() {
          this.getSelectableUserGroup();
      }
      @Watch("userGroupType")
      public handlerNewGroupType(val, oldVal) {
          if (!this.selectedUsers?.length) {
              this.userGroupUsers = [];
          }
          this.getSelectableUserGroup();
      }
      @Watch("userGroupUsers")
      public handlerNewGroupUsers(newVal: any[]) {
          this.userGroupForm.users = newVal;
      }

      private searchHandler(): void {
          this.loading = true;
          // cancel pending call
          clearTimeout(this.timerId);
          // delay new call
          this.timerId = setTimeout(() => {
              this.pagination.search = this.userSearch;
          }, DEBOUNCE_TIME_MILLI);
      }

      private mounted() {
          this.connectedUser = this.$store.state.currentUser;
          this.headers = [
              {value: "firstName", sortable: true},
              {value: "lastName", sortable: true},
              {value: "email", sortable: true},
              {value: "company", sortable: true},
              {value: "job", sortable: true},
              {value: "city", sortable: true},
              {value: "phone", sortable: true},
          ];
          this.statsDialog = !!this.$route.params.data;
          this.stats = this.$route.params.data;
          if (this.$route.params.tab) {
              this.currentTab = this.$route.params.tab;
          }
          this.scroll();
      }

      get searchQuery() {
          const query = this.$store.getters.getSearchQuery;
          this.pagination.search = query;
          return query;
      }

      get canManageUser() {
          return this.canUseManagers(this.connectedUser?.company);
      }

      private changeTab(tab) {
          if (this.currentTab !== tab) {
              this.selectedUsers = [];
              this.type = "users";
          }
          this.currentTab = tab;
          this.totalUsers = 0;
          this.pagination = {
              sortDesc: [true],
              sortBy: ["updatedAt"],
              search: "",
              page: 1,
              itemsPerPage: 20,
              keys: true,
          };
          this.reset();
      }

    private clickRow(item) {
        return this.$router.push({name: "user", params: {id: item.id}});
    }

      private reset(pagination?: any): void {
          this.users = [];
          this.usersGroups = [];
          this.loading = true;
          this.fetchData(pagination || this.pagination).then((res) => {
              if (this.currentTab === "groups") {
                  this.usersGroups = res.list;
              } else {
                  this.users = res.users?.filter((user) => !!user?.id);
              }
              this.totalUsers = res.count;
              this.loading = false;
          });
          this.close();
      }

      private fetchData(pagination: any): Promise<any> {
          switch (this.currentTab) {
              case "contacts":
                  return this.getContacts(pagination);
              case "management":
                  return this.getSubordinates(pagination);
              case "groups":
                  return this.getUserGroups(pagination);
              default:
                  return Promise.resolve();
          }
      }

      private getContacts(pagination: any): Promise<any> {
          return this.$store.dispatch("users/getContacts", {query: pagination});
      }

      private getSubordinates(pagination: any): Promise<any> {
          return this.$store.dispatch("users/getSubordinates", {query: pagination});
      }

      private getUserGroups(pagination: any): Promise<any> {
          return this.$store.dispatch("users/getUserGroups", {
              query: pagination,
              userId: this.$store.state.currentUser.id,
          });
        }

      private scroll(): void {
          window.onscroll = () => {
              const listElm = document.querySelector(".scroll-list");
              if (listElm?.clientHeight <= (document.documentElement.scrollTop + window.innerHeight)
                  && !this.loading) {
                  if (this.totalUsers > Math.max(this.users?.length, this.usersGroups?.length)) {
                      this.loading = true;
                      this.fetchData({
                          ...this.pagination,
                          page: this.pagination.page + 1,
                      }).then((res) => {
                          if (this.currentTab === "groups") {
                              res.list?.filter((group) => !!group?.id)?.forEach((group) => {
                                  this.usersGroups.push(group);
                              });
                          } else {
                              res.users?.filter((user) => !!user?.id)?.forEach((user) => {
                                  this.users.push(user);
                              });
                          }
                          this.totalUsers = res.count;
                          this.loading = false;
                      });
                  }
              }
          };
      }

      private createUser() {
          this.$store.dispatch("users/createUser", {user: this.currentUser})
              .then((res) => {
                  this.reset();
              });
      }

    private deleteContacts() {
      if (confirm(this.$tc("contacts.deleteConfirmation", this.selectedUsers.length).toString())) {
          this.$store.dispatch("users/deleteContacts", {
              contactsIds: this.selectedUsers.map((user: any) => user.id),
          }).then((res) => {
              this.reset();
          }).catch((err) => {
              this.$store.commit("alerts/displayError", {
                  msg: err,
              });
          });
      }
    }

    private deleteManagers() {
      if (confirm(this.$tc("management.deleteConfirmation", this.selectedUsers.length).toString())) {
          this.$store.dispatch("users/deleteSubordinates", {
              subordinatesIds: this.selectedUsers.map((user: any) => user.id),
          }).then((res) => {
              this.reset();
          }).catch((err) => {
              this.$store.commit("alerts/displayError", {
                  msg: err,
              });
          });
      }
    }

      private selectAllUsers() {
        this.selectedUsers = this.users;
      }

      private deselectAllUsers() {
          this.selectedUsers = [];
      }

      private displayCreateUserGroupDialog() {
          this.selectedUsers = this.selectedUsers.filter((u) => u?.hasOwnProperty("email"));
          this.groupDialog = true;
          this.userGroupType = this.currentTab === "management" ? "subordinates" : "contacts";
          this.userGroupForm.disabled = !!this.selectedUsers.length && !this.selectedUsers?.[0]?.Users;
          this.userGroupUsers = this.selectedUsers.length ? this.selectedUsers : [];
      }

      private createUserGroup() {
          const group = Object.assign(this.userGroupForm,  {
              type: this.userGroupType,
          });
          this.$store.dispatch("users/createGroup", {
              users: this.userGroupUsers,
              userGroupCreation: group,
          })
              .then((res) => {
                  this.currentTab = "groups";
                  this.reset();
                  this.$store.commit("alerts/displaySuccess", {
                      msg : this.$i18n.t("actions.created"),
                  });
              });
      }

      private close() {
          this.statsDialog = false;
          this.groupDialog = false;
          this.userGroupForm = {};
          this.userGroupSelectable = [];
          this.userGroupSearch = "";
          this.userGroupType = null;
          this.deselectAllUsers();
      }

      private selectContact(contact) {
          const selectedUsers = this.selectedUsers.slice(0);
          if (selectedUsers.includes(contact)) {
              const index = selectedUsers.findIndex((item) => {
                  const user: any = item;
                  return user.id === contact.id;
              });
              selectedUsers.splice(index, 1);
              this.selectedUsers = selectedUsers;
          } else {
              selectedUsers.push(contact);
              this.selectedUsers = selectedUsers;
          }
      }

      private selectGroup(selectedGroups) {
          const selected = selectedGroups;
          if (!selected) {
              this.selectedUsers = selected;
              this.type = "users";
          } else {
              this.selectedUsers = selected;
              this.type = "userGroups";
          }
      }

    private getSelectableUserGroup() {
        if (this.userGroupType === "contacts") {
            this.$store.dispatch("users/getContacts", {
                query: {
                    search: this.userGroupSearch,
                },
            }).then((res) => this.userGroupSelectable = res.users.map((u) => {
                if (u) {
                    return { text: u.displayName, value: u, ...u };
                }
            }));
        } else {
            this.$store.dispatch("users/getSubordinates", {
                query: {
                    search: this.userGroupSearch,
                },
            }).then((res) => this.userGroupSelectable = res.users.map((u) => {
                if (u) {
                    return { text: u.displayName, value: u, ...u };
                }
            }));
        }
    }
  }
</script>