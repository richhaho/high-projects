<template>
    <div>
        <div class="tableau">
            <div class="options">
                <div class="option_left">
                    <!--
                    <v-select
                        v-model="pagination.select"
                        :items="[]"
                        :label="$t('actions.filter')"
                        multiple
                        chips
                        clearable
                    >
                        <template v-slot:item="{ item }">{{ $t('key.statusType.' + item) }}</template>
                        <template v-slot:selection="{ item }">
                            <v-chip
                                color="lightgrey"
                                text-color="grey darken-3"
                                close
                            >{{ $t('key.statusType.' + item) }}
                            </v-chip>
                        </template>
                    </v-select>
                    -->
                    <a href="#" class="option view-switcher" title="" @click.prevent="mosaicView = !mosaicView">
                        <i class="icon-picto_mosaique" v-if="mosaicView"></i>
                        <v-icon v-else size="30px">list</v-icon>
                    </a>
                    <!-- /.option -->
                </div>
                <!-- /.option_left -->
                <div class="option_right">
                    <!--
                    <a href="#" class="option" :title="$t('actions.export')">
                        <i class="icon-picto_exporter"></i>
                        {{$t('actions.export')}}
                    </a>
                    -->
                    <button
                        type="button"
                        class="option open_popup"
                        @click="openCreate()"
                        :title="$t('list.createGroup')"
                    >
                        <i class="icon-picto_ajouter"></i>
                        {{$t('list.createGroup')}}
                    </button>
                    <!-- /.option -->
                </div>
                <!-- /.option_right -->
            </div>
            <!-- /.options -->
            <!-- .article_row -->
            <users-group-mosaic-view
                v-if="mosaicView"
                :selected-groups="selectedGroups"
                :users-groups="usersGroups"
                :loading="loading"
                @select-group="selectGroup"
                @edit-group="openEditUserGroup"
            ></users-group-mosaic-view>
            <v-data-table
                v-else
                :headers="headers"
                :items="usersGroups"
                :loading="loading"
                :options.sync="pagination"
                :search="pagination.search"
                :server-items-length="totalUsers"
                class="elevation-1"
                @click:row="selectGroup"
            >
                <!--HEADER-->
                <template v-slot:header.name="{ header }">
                    {{ $t('group.name') }}
                </template>
                <template v-slot:header.users="{ header }">
                    {{ $t('group.users') }}
                </template>
                <template v-slot:header.updateDate="{ header }">
                    {{ $t('group.modificationDate') }}
                </template>
                <template v-slot:header.action="{ header }">
                    {{ $t("actions.action") }}
                </template>
                <!--ROW-->
                <template v-slot:item.name="{ item }">
                    {{ item.name}}
                </template>
                <template v-slot:item.updateDate="{ item }">
                    {{ item.updatedAt | formatDate}}
                </template>
                <template v-slot:item.users="{ item }">
                    <user-list-avatar :users="item.Users"/>
                </template>
                <template v-slot:item.action="{ item }">
                    <v-btn icon @click="openEditUserGroup(item)">
                        <v-icon small>
                            edit
                        </v-icon>
                    </v-btn>
                </template>
            </v-data-table>
            <user-group-edit
                v-if="editGroup"
                :group="editGroup"
                :display-dialog="displayEditUserGroupDialog"
                @close="closeEditUserGroup"
                @reset="$emit('reset')"
            ></user-group-edit>
        </div>
    </div>
</template>
<script lang="ts">
import {Component, Prop, Vue, Watch} from "vue-property-decorator";
import ListDetail from "@/components/list/ListDetail.vue";
import UserListAvatar from "@/components/users/UserListAvatar.vue";
import UsersGroupMosaicView from "@/components/users/UsersGroupMosaicView.vue";
import UserGroupEdit from "@/components/users/UserGroupEdit.vue";
import {mdiArrowLeftCircle} from "@mdi/js";
import router from "@/router";

@Component({
  components: {
    ListDetail,
    UserListAvatar,
    UsersGroupMosaicView,
    UserGroupEdit,
  },
})
export default class UsersGroup extends Vue {
  @Prop({default: 0})
  public totalUsers: number;

  @Prop({default: []})
  public usersGroups: object[];

  @Prop({default: false})
  public loading: boolean;

  private selectedGroups: object[] = [];
  private editGroup: object = null;
  private pagination: any = {
    sortDesc: [false],
    sortBy: [""],
    search: "",
    page: 1,
    itemsPerPage: 20,
  };
  private headers: object[] = [
    {value: "name", sortable: true},
    {value: "users", sortable: true},
    {value: "updateDate", sortable: true},
    {value: "action", sortable: false},
  ];
  private arrowBack: string = mdiArrowLeftCircle;
  private mosaicView: boolean = true;
  private displayEditUserGroupDialog: boolean = false;

  @Watch("pagination", {deep: true, immediate: true})
  public handler() {
    this.$emit("reset", this.pagination);
  }

  @Watch("usersGroups", {immediate: true})
  public handlerGroups() {
      if (this.$route.params?.groupId) {
          this.selectedGroups = [
              this.usersGroups.find((g: any) => g.id === this.$route.params.groupId),
          ];
          this.$emit("selected-groups", this.selectedGroups);
      }
  }

  private mounted() {
    this.$store.commit("displaySearchBar", false);
  }

  private beforeDestroy() {
      this.$store.commit("displaySearchBar", true);
  }

  private selectGroup(data) {
      let selected = this.selectedGroups.splice(0);
      if (selected.length < 1) {
          selected.push(data);
      } else if (selected.includes(data)) {
          selected = [];
      } else {
          selected = [];
          selected.push(data);
      }
      this.selectedGroups = selected;

      this.$emit("selected-groups", this.selectedGroups);
  }

  private openEditUserGroup(group) {
      this.editGroup =  {...group};
      this.displayEditUserGroupDialog = true;
  }

  private closeEditUserGroup() {
      this.editGroup = null;
      this.displayEditUserGroupDialog = false;
  }

  private openCreate() {
    this.$emit("open-create-dialog");
  }
}
</script>