<template>
    <div class="tableau key-groups">
        <div class="options">
            <div class="option_left"></div>
            <div class="option_right">
                <button
                    type="button"
                    class="option open_popup"
                    @click="toggleCreateKeyGroups"
                    :title="$t('keysList.createGroup')"
                >
                    <i class="icon-picto_ajouter"></i>
                    {{$t('keysList.createGroup')}}
                </button>
            </div>
        </div>
        <v-data-table
            :headers="headers"
            :hide-default-footer="totalItems < pagination.itemsPerPage"
            :items="keyGroups"
            :loading="loading"
            :no-data-text="$t('keysList.noData.groups')"
            :options.sync="pagination"
            :search="pagination.search"
            :server-items-length="totalItems"
            class="elevation-1"
            @click:row="handleClickRow"
        >
            <!--HEADER-->
            <template v-slot:header.name="{ header }">
                {{ $t('keyGroup.name') }}
            </template>
            <template v-slot:header.updateDate="{ header }">
                {{ $t('keyGroup.updateDate') }}
            </template>
            <template v-slot:header.nbKeys="{ header }">
                {{ $t('keyGroup.nbKeys') }}
            </template>
            <template v-slot:header.action="{ header }">
                {{ $t("actions.action") }}
            </template>
            <!--ROW-->
            <template v-slot:item.name="{ item }">
                {{ item.name}}
            </template>
            <template v-slot:item.updateDate="{ item }">
                {{ item.updatedAt | formatDate}}
            </template>
            <template v-slot:item.nbKeys="{ item }">
                {{ item.Keys.length}}
            </template>
            <template v-slot:item.action="{ item }">
                <v-btn icon @click="openEditKeyGroup(item)">
                    <v-icon
                        small>
                        edit
                    </v-icon>
                </v-btn>
                <v-btn icon
                       @click="deleteKeyGroup(item)">
                    <v-icon small>
                        delete
                    </v-icon>
                </v-btn>
            </template>
        </v-data-table>
        <input type="hidden" :value="searchQuery">
        <key-groups-creation
            :selected-keys="selectedKeys"
            :close="toggleCreateKeyGroups"
            :display-create-key-group-dialog="displayCreateKeyGroupDialog"
            :select-key-input="true"
            :re-render="reset"
        ></key-groups-creation>
        <key-groups-edit
            v-if="editGroup"
            :group="editGroup"
            :close="toggleEditKeyGroups"
            :display-edit-key-group-dialog="displayEditKeyGroupDialog"
            :re-render="reset"
        ></key-groups-edit>
    </div>
</template>
<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";
import router from "@/router";
import KeyGroupsCreation from "@/components/keys/KeyGroupsCreation.vue";
import KeyGroupsEdit from "@/components/keys/KeyGroupsEdit.vue";

@Component({
    components: { KeyGroupsCreation, KeyGroupsEdit },
})
export default class KeyGroup extends Vue {

    private keyGroups: object[] = [];
    private selectedGroup: any = null;
    private editGroup: any = null;
    private headers: object[] = [
        {value: "name", sortable: true},
        {value: "nbKeys", sortable: false},
        {value: "creator", sortable: true},
        {value: "updateDate", sortable: true},
        { value: "action", sortable: false },
    ];
    private loading: boolean = false;

    private selectedKeys: object[] = [];
    private pagination: any = {
        sortDesc: [false],
        sortBy: [""],
        search: "",
        page: 1,
        itemsPerPage: 10,
    };
    private totalItems: number = 0;
    private displayCreateKeyGroupDialog: boolean = false;
    private displayEditKeyGroupDialog: boolean = false;

    get searchQuery() {
        const query = this.$store.getters.getSearchQuery;
        this.pagination.search = query;
        return query;
    }

    @Watch("pagination", {deep: true, immediate: false})
    public handler() {
        if (this.pagination.search) {
            this.pagination.page = 1;
        }
        if (!this.loading) {
            this.reset();
        }
    }

    private mounted() {
        this.reset().then(() => {
            if (this.$route.params?.groupId) {
                this.selectedGroup = this.keyGroups.find((g: any) => g.id === this.$route.params.groupId);
                this.$emit("current-group", this.selectedGroup);
            }
        });
    }

    private handleClickRow(data) {
        this.selectedGroup = JSON.parse(JSON.stringify(data));
        this.$emit("current-group", this.selectedGroup);
    }

    private reset(): Promise<any> {
        this.loading = true;
        this.selectedKeys = [];
        this.editGroup =  null;
        this.selectedGroup = null;
        this.$emit("current-group", null);
        return this.getKeyGroup().then(() => this.loading = false);
    }

    private getKeyGroup() {
        const query = Object.assign(
            {},
            this.pagination,
            { logs: true},
        );
        return this.$store.dispatch("users/getsKeyGroups",
            {query, userId: this.$store.state.currentUser.id}).then((res) => {
            this.totalItems = res.count;
            this.keyGroups = res.list;
            this.keyGroups.forEach((keyGroup: any) => {
                keyGroup.keyManagers = keyGroup?.keyManagers?.map((m) => ({ ...m }));
                keyGroup.newKeyManagers = [];
                keyGroup.guests = keyGroup?.guests?.map((g) => ({ ...g }));
                keyGroup.newGuests = [];
            });
        });
    }

    private toggleCreateKeyGroups() {
        this.displayCreateKeyGroupDialog = !this.displayCreateKeyGroupDialog;
    }

    private toggleEditKeyGroups() {
        if (this.displayEditKeyGroupDialog) {
            this.editGroup = null;
        }
        this.displayEditKeyGroupDialog = !this.displayEditKeyGroupDialog;
    }
    private openEditKeyGroup(group) {
        this.selectedGroup =  {...group};
        this.editGroup = Object.assign({deletedGuests: [], deletedManagers: []}, group );
        this.displayEditKeyGroupDialog = true;
    }
    private deleteKeyGroup(key) {
        if (confirm(this.$t("keyGroup.deleteConfirmation").toString())) {
        this.$store.dispatch("groups/deleteById", {id: key.id})
            .then((res) => {
            this.reset();
            });
        }
    }
}
</script>
