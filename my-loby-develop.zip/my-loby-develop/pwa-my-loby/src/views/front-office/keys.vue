<template>
    <div class="main-content-display">
        <div class="middle_part flex-grow-1 mb-5">
            <div class="mots_cles">{{ $t(`keysList.${pagination.tab}`) }}</div>
            <div class="onglets_row">
                <a
                    @click.prevent="changeTabs('myKeys')"
                    v-if="!isDemo && (myKeysCount > 0 || sharedKeysCount === 0)"
                    :title=" $t('keysList.myKeys')"
                    :class="{active: pagination.tab === 'myKeys'}"
                >
                    <div class="onglet">{{ isAdmin ? $t('keysList.allKeys') : $t('keysList.myKeys') }}</div>
                </a>
                <a
                    v-if="!isAdmin && (sharedKeysCount > 0 || isDemo)"
                    :disabled="true"
                    :style="isDemo ? 'flex-basis: 100%;' : ''"
                    @click="changeTabs('sharedKeys')"
                    :title="$t('keysList.sharedKeys')"
                    :class="{active: pagination.tab === 'sharedKeys'}"
                >
                    <div class="onglet">{{ $t('keysList.sharedKeys') }}</div>
                </a>
                <a
                    v-if="!isDemo"
                    @click="changeTabs('groups')"
                    :title="$t('keysList.groups')"
                    :class="{active: pagination.tab === 'groups'}"
                >
                    <div class="onglet">{{ $t('keysList.groups') }}</div>
                </a>
            </div>
            <div v-if="pagination.tab === 'groups'">
                <key-group @current-group="selectGroup"></key-group>
            </div>
            <div class="tableau" v-else>
                <div class="options">
                    <div class="option_left">
                        <button class="option" @click.stop="displayKeysFilter = !displayKeysFilter">
                            <i class="icon-picto_filtrer"></i>
                            {{ $t('actions.filter') }}
                        </button>
                        <div class="with_filters">
                            <ul class="filters" :class="{'d-block': displayKeysFilter}">
                                <li
                                    v-for="(status, index) in keysStatus"
                                    :key="index"
                                >
                                    <label>
                                        <p-check
                                            :value="status"
                                            v-model="pagination.select"
                                            class="p-default p-curve mt-2 p-bigger"
                                            color="primary"
                                        />
                                        {{ $t(`key.statusType.${status}`) }}
                                    </label>
                                </li>
                            </ul>
                        </div>
                        <v-text-field
                            class="pa-0 ma-0 ml-4"
                            append-icon="search"
                            hide-details
                            single-line
                            v-bind:label="$t('actions.search')"
                            v-model="keysSearch"
                            @input="searchHandler"
                        />
                    </div>
                    <div class="option_right">
                        <import-modal
                            :disabled="isCompanyBlocked || disableKeyCreation"
                            v-if="isMaster() && pagination.tab === 'myKeys'"
                            :title="$t('keysList.importKeys')"
                            type="keys"
                        />
                        <button
                            type="button"
                            v-if="pagination.tab === 'myKeys' || pagination.tab === 'sharedKeys'"
                            class="option open_popup"
                            :disabled="isCompanyBlocked"
                            @click="disableKeyCreation ? isRestrictedOn = 'maxKeys' : showCreateDialog = true"
                            :title="$t('keysList.create')"
                        >
                            <i class="icon-picto_ajouter"></i>
                            {{ $t('keysList.create') }}
                        </button>
                    </div>
                </div>
                <div class="toggle_carte m-2" v-if="pagination.tab === 'myKeys'">
                    <label>{{ $t('keysList.showArchived') }}</label>
                    <div class="onoffswitch">
                        <input type="checkbox"
                               v-model="showArchivedKeys"
                               @change="updateShowArchivedKey"
                               name="carte" class="onoffswitch-checkbox" id="myonoffswitch" checked>
                        <label class="onoffswitch-label" for="myonoffswitch">
                            <span class="onoffswitch-inner"></span>
                            <span class="onoffswitch-switch"></span>
                        </label>
                    </div>
                </div>
                <v-data-table
                    :headers="headers"
                    :hide-default-footer="totalKeys < pagination.itemsPerPage"
                    :items="keys"
                    :loading="loading"
                    :no-data-text="$t(`keysList.noData.${pagination.tab}`)"
                    :options.sync="pagination"
                    :search="pagination.search"
                    :server-items-length="totalKeys"
                    class="elevation-1 hover-pointer"
                    show-select
                    v-model="selectedKeys"
                    @click:row="clickRow"
                    :footer-props="{
                    'items-per-page-options': [10, 25,50]
                     }"
                >
                    <template v-slot:header.name="{ header }">{{ $t('key.name') }}</template>
                    <template v-slot:header.owner="{ header }">{{ $t('key.owner') }}</template>
                    <template v-slot:header.Relays="{ header }">{{ $t('key.relay') }}</template>
                    <template v-slot:header.status="{ header }">{{ $t('key.status') }}</template>
                    <template v-slot:header.userCount="{ header }">
                        <div class="text-center">
                            {{ $tc('key.user', 0) }}
                        </div>
                    </template>
                    <template v-slot:header.location="{ header }">
                        <div class="text-center">
                            {{ $t('key.location') }}
                        </div>
                    </template>
                    <template v-if="pagination.tab === 'myKeys'" v-slot:header.action="{ header }">
                        <div class="text-center">
                            {{ $t('key.action') }}
                        </div>
                    </template>
                    <template v-slot:item.name="{ item }">
                        <span :class="{'archived':item.archivedAt && !item.hasAllRights }">{{ item.name }}</span>
                    </template>
                    <template v-slot:item.owner="{ item }">
                        <span :class="{'archived':item.archivedAt && !item.hasAllRights }">{{
                                item.owner.displayName
                            }}</span>
                    </template>
                    <template v-slot:item.userCount="{ item }">
                        <div class="text-center" :class="{'archived':item.archivedAt && !item.hasAllRights}">
                            {{ keyUsersNbr(item) }}
                        </div>
                    </template>
                    <template v-slot:item.Relays="{ item }">
              <span :class="{'archived':item.archivedAt && !item.hasAllRights}">
                  {{ renderRefRelay(item) }}
              </span>
                    </template>
                    <template v-slot:item.status="{ item }">
              <span :class="{'archived':item.archivedAt && !item.hasAllRights}">
                <key-status :currentKey="item"/>
              </span>
                    </template>
                    <template v-slot:item.action="{ item }">
                        <v-row class="text-center">
                            <v-btn
                                v-if="isManager(currentUser, item) && !item.archivedAt && !item.hasAllRights && !isCompanyKeyBlocked(item)"
                                @click.stop="openQuickAddGuest(item)" icon
                            >
                                <v-icon small>person_add</v-icon>
                            </v-btn>
                            <div
                                v-if="!item.archivedAt && !item.hasAllRights && !isCompanyKeyBlocked(item) && isBookedKeyAvailable(item)"
                            >
                                <list-key-item
                                    :item="item"
                                    :update-data="getKeys"
                                />
                            </div>
                            <div>
                                <relay-booked-key
                                    v-if="item.currentBooking"
                                    :current-key="item"
                                />
                            </div>
                        </v-row>
                    </template>
                    <template v-slot:item.location="{ item }">
                        <div class="text-center" :class="{'archived':item.archivedAt && !item.hasAllRights}">
                            <v-btn
                                v-if="item.locationDisplayed && currentUser && (currentUser.isAdmin || isMaster('INSURANCE')) && !item.connectedBoxLocker"
                                :href="$store.state.baseURL ? `${$store.state.baseURL}/api/locations/${item.locationDisplayed.id}/generate-qr-code` :
                                `/locations/${item.locationDisplayed.id}/generate-qr-code`"
                                outlined
                                small
                                target="_blank"
                            >{{ displayCodeName(item) }}
                            </v-btn>
                            <div v-else-if="item.locationDisplayed && !item.connectedBoxLocker">{{ displayCodeName(item) }}</div>
                            <div v-else-if="item.locationDisplayed
                            && currentUser && (currentUser.isAdmin || isMaster('INSURANCE')) && item.connectedBoxLocker">
                                {{ item.connectedBoxLocker }}
                            </div>
                            <div v-else-if="item.locationDisplayed && item.connectedBoxLocker">{{ item.connectedBoxLocker }}</div>
                        </div>
                    </template>
                </v-data-table>
            </div>

            <import-results :dialog="statsDialog" :stats="stats" @close="close" type="keys"/>

            <key-groups-creation
                :key-group-creation="keyGroupCreation"
                :selected-keys="selectedKeys"
                :user="currentUser"
                :close="close"
                :create-key-group-fn="createKeyGroupFn"
                :display-create-key-group-dialog="displayCreateKeyGroupDialog"
            ></key-groups-creation>
            <key-create
                v-if="canCreateKey"
                :show.sync="showCreateDialog"
                @update-data="reset"
            />
            <restriction-dialog
                v-if="currentUser && currentUser.companyId"
                @close="isRestrictedOn = null"
                :type="isRestrictedOn"
            />

            <v-dialog max-width="910px" v-model="quickAddGuestDialog" persistent>
                <v-card>
                    <v-card-title>
                        <span
                            class="headline">
                            {{ $t('keysList.' + (isMaster() && canManageUser ? 'quickAddManager' : 'quickAddGuest')) }}
                        </span>
                    </v-card-title>
                    <v-card-text>
                        <v-container>
                            <key-managers-autocomplete
                                v-if="isMaster() && canManageUser"
                                :currentKey="currentKey"
                                :edit="true"
                                :disableDelete="true"
                            />
                            <key-guests-autocomplete
                                v-else
                                :currentKey="currentKey"
                                :edit="true"
                                ref="keyGuestsAutocomplete"
                                @invitation-change="updateIsAddButtonStatus"
                                @save="saveKey"
                            />
                        </v-container>
                    </v-card-text>

                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn @click="close()" color="white" text>{{ $t('actions.close') }}</v-btn>
                        <v-btn
                            v-if="currentKey.newKeyManagers && currentKey.newKeyManagers.length "
                            @click="saveKey"
                            color="warning"
                        >
                            {{ $t('actions.save') }}
                        </v-btn>
                        <v-btn
                            @click="addGuestFunction()"
                            v-if="isAddButtonEnabled || loadingAddGuest"
                            :loading="loadingAddGuest"
                            color="primary"
                        >
                            {{ $t('actions.add') }}
                        </v-btn>
                    </v-card-actions>
                </v-card>
            </v-dialog>

            <v-dialog max-width="910px" v-model="usersDialog" persistent>
                <v-card>
                    <v-card-title>
            <span
                class="headline"
            >{{ $tc('usersList.title', usersList && usersList.length ? currentKey.keyManagers.length : 0) }}</span>
                    </v-card-title>
                    <v-card-text>
                        <v-container>
                            <v-row v-for="user in usersList" :key="user" align="center">
                                <v-col class="pa-0">
                                    <v-btn
                                        :to="{ name: 'user' , params: { id: JSON.parse(user).id } }"
                                        color="transparent"
                                        icon
                                    >
                                        <v-avatar class="ma-2" size="30">
                                            <img :src="getSrc(JSON.parse(user).picturePath) || defaultUserAvatar" alt/>
                                        </v-avatar>
                                    </v-btn>
                                    {{ JSON.parse(user).displayName }}
                                </v-col>
                                <v-col class="pa-0" align="right">
                                    {{ JSON.parse(user).Company.name }}
                                    <v-btn
                                        v-if="!isOwner(JSON.parse(user), currentKey) && !isHolder(JSON.parse(user), currentKey)"
                                        @click="remove(usersList, user)"
                                        icon
                                    >
                                        <v-icon small>delete</v-icon>
                                    </v-btn>
                                </v-col>
                            </v-row>
                        </v-container>
                    </v-card-text>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn @click="usersDialog = false" color="white" text>{{ $t('actions.close') }}</v-btn>
                    </v-card-actions>
                </v-card>
            </v-dialog>
            <key-selected
                v-if="!isDemo"
                :selected-keys="selectedKeys"
                :select-all="selectAllKeys"
                :cancel="deselectAllKeys"
                :deleteKeys="deleteMultipleKeys"
                :createKeyGroup="displayCreateKeyGroupDialogFn"
            ></key-selected>
        </div>
        <div class="right_part mb-7">
            <key-detail :selected-keys="selectedKeys"></key-detail>
            <key-group-detail :selected-group="currentGroup" v-if="currentGroup"></key-group-detail>
        </div>
    </div>
</template>
<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";
import KeyDetail from "@/components/keys/KeyDetail.vue";
import KeyGroupDetail from "@/components/keys/KeyGroupDetail.vue";
import KeySelected from "@/components/keys/KeySelected.vue";
import KeyStatus from "@/components/keys/KeyStatus.vue";
import KeyGroupsCreation from "@/components/keys/KeyGroupsCreation.vue";
import ImportModal from "@/components/import/ImportModal.vue";
import ImportResults from "@/components/import/ImportResults.vue";
import KeyManagersAutocomplete from "@/components/keys/KeyManagersAutocomplete.vue";
import KeyGuestsAutocomplete from "@/components/keys/KeyGuestsAutocomplete.vue";
import {formRules} from "@/utils/formRules";
import {defaultKeyPicture, defaultUserAvatar} from "@/utils/constants";
import {Getter} from "vuex-class";
import KeyCreate from "@/components/keys/KeyCreate.vue";
import {getSrc} from "@/utils/misc";
import KeyGroup from "@/views/front-office/keyGroups.vue";
import RestrictionDialog from "@/components/RestrictionDialog.vue";
import {canCreateMoreKeys, canUseManagers} from "plan-restrictions";
import Timeout = NodeJS.Timeout;
import ListKeyItem from "@/components/list/ListKeyItem.vue";
import moment from "moment";
import RelayBookedKey from "@/components/relays/RelayBookedKey.vue";

export const DEBOUNCE_TIME_MILLI: number = 500;

@Component({
    components: {
        KeyCreate,
        KeySelected,
        KeyStatus,
        KeyGroupsCreation,
        KeyDetail,
        KeyManagersAutocomplete,
        KeyGuestsAutocomplete,
        ImportModal,
        ImportResults,
        KeyGroup,
        KeyGroupDetail,
        RestrictionDialog,
        ListKeyItem,
        RelayBookedKey,
    },
})
export default class Keys extends Vue {
    @Getter private currentUser: any;
    @Getter private isDemo: boolean;
    @Getter private isB2B: boolean;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isAdmin: boolean;

    private rules: object = formRules;
    private defaultUserAvatar: string = defaultUserAvatar;
    private defaultKeyPicture: string = defaultKeyPicture;
    private canUseManagers: (company: any) => boolean = canUseManagers;
    private canCreateMoreKeys: (
        company: any,
        existingKeysNbr: number,
        newKeysNbr: number,
    ) => boolean = canCreateMoreKeys;
    private disableKeyCreation: boolean = true;
    private isRestrictedOn: string = null;
    private getSrc: (string) => string = getSrc;
    private keys: object[] = [];
    private usersList: object[] = [];
    private headers: object[] = [];
    private currentKey: any = {};
    private currentGroup: any = null;
    private keyGroupCreation: any = {
        name: "",
    };
    private uploadedImageSrc: any = null;
    private statsDialog: boolean = false;
    private displayCreateKeyGroupDialog: boolean = false;
    private quickAddGuestDialog: boolean = false;
    private quickBookedKeyDialog: boolean = false;
    private usersDialog: boolean = false;
    private loading: boolean = false;
    private loadingAddGuest: boolean = false;
    private isAddButtonEnabled: boolean = false;
    private timerId: Timeout = null;
    private keysSearch: string = null;
    private csvFile: any = null;
    private stats: any = null;
    private pagination: any = {
        sortDesc: [true],
        sortBy: ["updatedAt"],
        search: "",
        select: [],
        page: 1,
        itemsPerPage: 10,
        tab: "myKeys",
    };
    private totalKeys: number = 0;
    private contacts: any = [];
    private searchContacts: string = null;
    private quickGuest: any = null;
    private selectedKeys: object[] = [];
    private keysStatus: string[] = [];
    private displayKeysFilter: boolean = false;
    private showCreateDialog: boolean = false;
    private showArchivedKeys: boolean = false;
    private sharedKeysCount: number = 0;
    private myKeysCount: number = 0;
    private tabHasChanged: boolean = false;

    @Watch("pagination.tab")
    public handlerPaginationTab(val, oldVal) {
        if (val !== "groups") {
            if (val !== oldVal) {
                this.tabHasChanged = true;
                if (this.keysSearch !== null) {
                    this.keysSearch = null;
                }
                this.pagination = {
                    sortDesc: [true],
                    sortBy: ["updatedAt"],
                    search: "",
                    select: [],
                    page: 1,
                    itemsPerPage: 10,
                    tab: val,
                };
            }
            this.reset();
        }
    }

    @Watch("pagination.page")
    public handlerPaginationPage(val, oldVal) {
        this.handlerPaginationTabChanged(val, oldVal);
    }

    @Watch("pagination.itemsPerPage")
    public handlerPaginationItemsPerPage(val, oldVal) {
        this.handlerPaginationTabChanged(val, oldVal);
    }

    @Watch("pagination.search")
    public handlerPaginationSearch(val, oldVal) {
        this.handlerPaginationTabChanged(val, oldVal);
    }

    @Watch("pagination.select")
    public handlerPaginationSelect(val, oldVal) {
        this.handlerPaginationTabChanged(JSON.stringify(val), JSON.stringify(oldVal));
    }

    @Watch("pagination.sortBy")
    public handlerPaginationSortBy(val, oldVal) {
        this.handlerPaginationTabChanged(val, oldVal);
    }

    @Watch("pagination.sortDesc")
    public handlerPaginationSortDesc(val, oldVal) {
        this.handlerPaginationTabChanged(val, oldVal);
    }

    private handlerPaginationTabChanged(val, oldVal): void {
        if (val !== oldVal && this.tabHasChanged === false) {
            this.reset();
        }
    }

    private updateShowArchivedKey(): void {
        this.reset();
    }

    private searchHandler(): void {
        this.loading = true;
        // cancel pending call
        clearTimeout(this.timerId);
        // delay new call
        this.timerId = setTimeout(() => {
            this.pagination.search = this.keysSearch || null;
        }, DEBOUNCE_TIME_MILLI);
    }

    get lang() {
        return this.$root.$i18n.locale;
    }

    // check if one of the user of one of the management groups match the current user
    private isManager = (user, key) => key?.keyManagers
        ?.some((g) => g?.Users?.some((u) => u.id === user?.id)) || key.ownerId === user?.id

    private isOwner = (user, key) => key?.ownerId === user?.id;

    private isHolder = (user, key) => key?.holder?.id === user?.id;

    get isCompanyBlocked() {
        return !!this.currentUser?.company?.blockedAt;
    }

    get canCreateKey(): boolean {
        return !this.isCompanyBlocked && !this.disableKeyCreation; // && this.canCreateKeyB2B;
    }

    get canCreateKeyB2B(): boolean {
        return !this.isB2B || this.isMaster() || !!this.keys?.length;
    }

    get currentKeyManagers() {
        if (!this.currentKey || !this.currentKey.keyManagers) {
            return [];
        }
        return this.currentKey.keyManagers.map((manager) => ({
            ...manager,
            displayName: manager.Users.reduce((acc, u) => {
                return acc + " " + u.displayName;
            }, ""),
        }),
        );
    }

    // To get number of users and not number of accesses
    private usersNbrInGroup: (accesses: any[]) => number = (accesses: any[]) =>
        accesses?.reduce((a, c) => {
            // Count users in each group
            c?.Users?.forEach((user) => {
                if (a.every((userId) => userId !== user.id)) {
                    // Count each user only once
                    a.push(user.id);
                }
            });
            return a;
        }, [])?.length || 0

    private keyUsersNbr: (key: any) => number = (key: any) =>
        this.usersNbrInGroup(key?.keyManagers) + this.usersNbrInGroup(key?.guests)

    private restrictKeyCreation(user: any) {
        if (user.companyId) {
            this.$store.dispatch("companies/countKeys", {id: user.companyId}).then((res) => {
                this.disableKeyCreation = !this.canCreateMoreKeys(user.company, res, 1);
            })
                .catch((err) => {
                    this.$store.commit("alerts/displayError", {
                        msg: err,
                    });
                });
        } else {
            this.disableKeyCreation = false;
        }
    }

    get canManageUser() {
        return this.canUseManagers(this.currentUser?.company);
    }

    private currentRelay = (key) => key?.currentLocation?.Box.Relay;

    private isKeyB2B = (key: any) => key?.Relays?.some((r) => r.type === "AGENCY");

    private mounted() {
        this.headers = [
            {value: "name", sortable: true},
            {value: "owner", sortable: false},
            {value: "Relays", sortable: false},
            {value: "status", sortable: true},
            {value: "userCount", sortable: false},
            {value: "location", sortable: false},
            {value: "action", sortable: false},
        ];
        this.statsDialog = !!this.$route.params.data;
        this.stats = this.$route.params.data;
        this.getKeysStatus();
        if (this.$route.params.tab && !this.isDemo) {
            this.pagination.tab = this.$route.params.tab;
        }
        if (this.isDemo) {
            this.pagination.tab = "sharedKeys";
        }
        this.reset();
    }

    private changeTabs(tab) {
        if (!this.isDemo) {
            this.pagination.tab = tab;
            this.selectedKeys = [];
            this.keys = [];
            this.currentGroup = null;
            this.showArchivedKeys = false;
        }
    }

    private reset(): Promise<any> {
        this.loading = true;
        this.quickGuest = null;
        this.loadingAddGuest = false;
        this.uploadedImageSrc = null;
        this.currentKey = {};
        this.restrictKeyCreation(this.currentUser);
        return Promise.all([
            this.countSharedKeys(),
            this.countMyKeys(),
        ]).then((res) => {
            this.sharedKeysCount = res[0];
            this.myKeysCount = res[1];
            if (!this.myKeysCount && this.sharedKeysCount) {
                this.pagination.tab = "sharedKeys";
            }
            return this.getKeys();
        });
    }

    private getKeys(): Promise<any> {
        const query = Object.assign({}, this.pagination, {
            archived: this.showArchivedKeys,
            subscriptions: !this.isB2B && !this.isAdmin,
        });
        const p: Array<Promise<any>> = [
            this.$store.dispatch("users/getMyKeys", {
                id: this.currentUser.id,
                query,
            }),
        ];
        if (this.pagination.tab === "sharedKeys") {
            p.push(this.$store.dispatch("users/getLateKeys", {id: this.currentUser.id}));
        }
        return Promise.all(p).then(([classicKeys, lateKeys]) => {
            // Merge late keys and classic keys, with late keys always at the top of the table
            this.keys = [
                ...lateKeys?.keys || [],
                ...classicKeys?.keys || [],
            ];
            this.totalKeys = (classicKeys?.count || 0) + (lateKeys?.count || 0);
            this.keys.forEach((key: any) => {
                key.relayId = key?.Relays?.find((r) => r.type === "AGENCY")?.id;
                key.newKeyManagers = [];
                key.guests = key?.guests?.map((item: any) => ({...item}));
                key.newGuests = [];
                // Display either current location or reserved location if the key is not in relay
                key.locationDisplayed = this.isKeyB2B(key) ? key.currentLocation :
                    key.currentLocation || key.ReservedLocations?.[0];
                // Display either current relay or main relay of the key (agency for b2b, first else)
                key.relayDisplayed = key?.currentLocation?.Box?.Relay
                    || key.Relays?.find((relay) => relay.type === "AGENCY")
                    || key.Relays?.[0];
                const acsesObject = key.AcsesObjects[0];
                if (acsesObject) {
                    key.connectedBoxLocker = acsesObject.name;
                }
            });
            this.loading = false;
            this.tabHasChanged = false;
        });
    }

    private countSharedKeys(): Promise<any>  {
        return this.$store.dispatch("users/countMySharedKeys", {
            id: this.currentUser.id,
        });
    }

    private countMyKeys(): Promise<any> {
        return this.$store.dispatch("users/countManagedKeys", {
            id: this.currentUser.id,
        });
    }

    private clickRow(item) {
        return this.$router.push({name: "key", params: {id: item.id}});
    }

    private updateIsAddButtonStatus(newVal: boolean): void {
        this.isAddButtonEnabled = newVal;
    }

    private addGuestFunction(): void {
        this.loadingAddGuest = true;
        return (this.$refs.keyGuestsAutocomplete as HTMLFormElement)?.addGuest();
    }

    private displayCodeName(key) {
        if (key.backupId) {
            let codeName;
            try {
                const s = key.locationDisplayed.codeName.split("-");
                codeName = s[s.length - 1];
            } catch {
                codeName = "";
            }
            return codeName;
        } else {
            return key.locationDisplayed.codeName;
        }
    }

    private createKeyGroupFn(keyGroupCreation = this.keyGroupCreation) {
        this.$store
            .dispatch("keys/createGroup", {
                keys: this.selectedKeys,
                keyGroupCreation,
            })
            .then((res) => {
                this.close();
                this.keyGroupCreation = {};
                this.selectedKeys = [];
                this.pagination.tab = "groups";
                this.$store.commit("alerts/displaySuccess", {
                    msg: this.$i18n?.t("actions.created"),
                });
            })
            .catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err,
                });
            });
    }

    private saveKey() {
        const key = this.currentKey;
        delete key.KeyLocation;
        delete key.currentLocation;
        delete key.locationDisplayed;
        delete key.relayDisplayed;
        key.Relays.push({id: key.relayId});
        key.Relays = key.Relays.map((t: any) => {
            return {id: t?.id};
        });

        this.$store
            .dispatch("keys/update", {
                key,
                params: {
                    info: false,
                    newKeyManagers: true,
                    newGuests: true,
                    relays: false,
                },
            })
            .then(() => {
                this.reset();
            });
        this.close();
    }

    private getKeysStatus() {
        return this.$store.dispatch("keys/getStatus").then((res) => {
            this.keysStatus = res.keysStatus;
        });
    }

    private remove(list, item) {
        const pos = list.map((u) => JSON.parse(u).id).indexOf(JSON.parse(item).id);
        list.splice(pos, 1);
    }

    private deleteKey(key) {
        if (confirm(this.$t("key.deleteConfirmation").toString())) {
            this.$store.dispatch("keys/deleteById", {id: key.id}).then((res) => {
                this.reset();
            });
        }
    }

    private deleteMultipleKeys() {
        if (confirm(this.$t("key.deleteMultipleConfirmation").toString())) {
            const promises = this.selectedKeys.map((key: any) =>
                this.$store.dispatch("keys/deleteById", {id: key.id}),
            );
            Promise.all(promises)
                .then((res) => {
                    this.reset();
                    this.deselectAllKeys();
                })
                .catch((err) => {
                    this.$store.commit("alerts/displayError", {
                        msg: err,
                    });
                });
        }
    }

    private displayCreateKeyGroupDialogFn() {
        this.close();
        this.displayCreateKeyGroupDialog = true;
    }

    private selectAllKeys() {
        this.selectedKeys = this.keys;
    }

    private deselectAllKeys() {
        this.selectedKeys = [];
    }

    private openQuickAddGuest(item: any) {
        this.close();
        this.currentKey = JSON.parse(JSON.stringify(item));
        this.quickAddGuestDialog = true;
    }

    private displayUsers(users: object[]) {
        this.usersDialog = true;
        this.usersList = users;
    }

    private close() {
        this.statsDialog = false;
        this.quickAddGuestDialog = false;
        this.quickBookedKeyDialog = false;
        this.usersDialog = false;
        this.displayCreateKeyGroupDialog = false;
    }

    private renderRefRelay(key) {
        if (key.Relays?.length > 1) {
            const refRelay = key.Relays.filter((relay) => relay.type === "AGENCY");
            return refRelay[0]?.name;
        } else {
            return key.Relays?.[0]?.name;
        }
    }

    private selectGroup(currentGroup) {
        if (currentGroup) {
            this.currentGroup = this.currentGroup?.id === currentGroup.id ? null : currentGroup;
        } else {
            this.currentGroup = null;
        }
    }

    private isCompanyKeyBlocked(key: any) {
        return key?.company && !!key.company.blockedAt;
    }

    private isBookedKeyAvailable(key: any) {
        if (!key.currentBooking) {
            return true;
        }
        const hasRights = this.currentUser.id === key.currentBooking.createdBy
            || this.isManager(key, this.currentUser)
            || this.isAdmin;
        return (key.currentBooking && hasRights) || (this.currentUser.id === key.currentBooking.userId);
    }
}
</script>
