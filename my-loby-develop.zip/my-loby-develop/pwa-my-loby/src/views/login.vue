<template>
    <section class="section login-section">
        <v-container>
            <v-card
                class="mx-auto"
                max-width="500px"

            >
                <v-list-item>
                <!--CSS HACK-->
                </v-list-item>
                <v-row justify="center">
                    <img
                        :src="require('@/assets/img/myloby_logo.svg')"
                        alt="uploadedImage"
                        style="object-fit: contain; height: 150px; width: 150px; border-radius: 10px; margin:auto;"
                    />
                </v-row>

                <v-card-text class="text--primary">
                    <v-form
                        ref="form"
                        v-model="valid"
                    >
                        <v-text-field
                            :rules="[rules.email, rules.required]"
                            v-bind:label="$t('user.email')"
                            v-model="form.email"
                        ></v-text-field>

                        <v-text-field
                            v-show="forgottenPasswordState === false"
                            :append-icon="showPassword ? 'visibility' : 'visibility_off'"
                            :rules="[rules.required]"
                            :type="showPassword ? 'text' : 'password'"
                            @click:append="showPassword = !showPassword"
                            v-bind:label="$t('user.password')"
                            v-model="form.password"
                        ></v-text-field>


                    </v-form>
                </v-card-text>

                <v-card-actions  class="justify-center" >
                    <v-btn
                        v-if="forgottenPasswordState === true"
                        :disabled="!form.email"
                        @click="forgottenPasswordFn"
                        color="warning"
                        text

                    >
                        {{ $t('login.forgottenPasswordButton') }}
                    </v-btn>
                    <v-btn
                        v-show="forgottenPasswordState === false"
                        :disabled="!valid"
                        @click="login"
                        color="warning"
                        text

                    >
                        {{ $t('login.btn') }}
                    </v-btn>

                </v-card-actions>
            </v-card>
            <v-row>
                <v-col v-show="forgottenPasswordState === false" align="center"  >
                    <span
                        style="cursor: pointer;
                        font-size: smaller;
                        font-style: italic;
                        text-decoration: underline;"
                        @click="$router.push({name: 'register-classic'})"
                    >
                        {{ $t('login.register') }}
                        <br/>
                    </span>
                    <span
                        style="cursor: pointer;
                        font-size: smaller;
                        font-style: italic;
                        text-decoration: underline;"
                        @click="forgottenPasswordSwitch"
                    >
                        {{ $t('login.forgottenPassword') }}
                        <br/>
                        {{ $t('login.firstConnection') }}
                        <br/>
                    </span>
                </v-col>
                <v-col v-show="forgottenPasswordState === true" align="center"  >
                    <span style="cursor: pointer;font-size: smaller;
    font-style: italic;    text-decoration: underline;" @click="forgottenPasswordSwitch">{{ $t('actions.back') }}</span>
                </v-col>
            </v-row>
        </v-container>
    </section>
</template>

<script lang="ts">
import {Component, Vue} from "vue-property-decorator";
import {formRules} from "@/utils/formRules";

@Component
export default class Login extends Vue {

    private form: any = {
        email: "",
        password: "",
    };
    private rules: object = formRules;
    private valid: boolean = true;
    private showPassword: boolean = false;
    private forgottenPasswordState: boolean = false;

    private mounted() {
        if (this.$route.params.token) {
            this.loginWithToken(this.$route.params.token);
        }
    }

    private login() {
        this.$store.dispatch("auth/login", {
            email: this.form.email,
            password: this.form.password,
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: this.$t(`alerts.error.${err.response.data.error}`),
            });
        });
    }

    private loginWithToken(token: string) {
        this.$store.dispatch("auth/loginWithToken", {token});
            // .catch(() => this.$router.push({name: "login"}) );
    }

    private forgottenPasswordSwitch() {
        this.forgottenPasswordState = !this.forgottenPasswordState;
    }

    private forgottenPasswordFn() {
        this.$store.dispatch("auth/forgottenPasswordFn", {email: this.form.email})
            .then(() => this.$store.commit("alerts/displaySuccess", {
                msg: this.$i18n?.t("login.retrieveMail"),
            }))
            .catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: this.$i18n?.t(`alerts.error.${err?.response?.data?.error || "default"}`),
                });
            });
    }
}
</script>
