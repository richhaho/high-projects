<template>
    <v-container class="m-key-page">
         <div v-if="screenFull" class="fullScreen">
            <img :src="getSrc(key.picturePath)+'?timestamp='+timestampKeyImage || defaultKeyPicture"
                style="object-fit: cover" alt="key picture"/>
            <div class="darkBanner">
                <button class="topRight" v-on:click="screenFull = false"> {{ $t('actions.close') }}</button>
            </div>
        </div>
        <v-row>
            <v-progress-circular
                v-if="isLoading"
                style="margin: 10px auto 0 auto"
                :width="3"
                color="rgba(0,0,0,.06)"
                indeterminate
            ></v-progress-circular>
        </v-row>
        <span v-if="!isLoading">
            <router-link v-if="isAdmin ||  isManager"
                :to="{name: 'keys', params: {tab: 'myKeys'}}" :title="$t('keysList.myKeys')"
                 class="fil_arianne"
            >
                    <i class="icon-picto_retour ml-1"></i>
                        {{ $t('keysList.myKeys') }} | {{ key.name }}
            </router-link>
            <router-link v-else
                :to="{name: 'keys', params: {tab: 'sharedKeys'}}" :title="$t('keysList.sharedKeys')"
                 class="fil_arianne"
            >
                    <i class="icon-picto_retour ml-1"></i>
                        {{ $t('keysList.sharedKeys') }} | {{ key.name }}
            </router-link>
            <v-dialog
                persistent
                v-if="isManager || isMaster()"
                v-model="editKeyInfoDialog"
                width="910px"
            >
                <v-card>
                    <v-form v-model="validEditKeyInfoForm">
                        <v-card-title>
                            <span class="headline">{{ $t('actions.edit') }}</span>
                        </v-card-title>
                        <v-card-text>
                            <v-container>
                                <v-row>
                                      <v-img
                                          v-if="uploadedImageSrc || getSrc(key.picturePath)"
                                          :src="uploadedImageSrc || getSrc(key.picturePath)"
                                          alt="uploadedImage"
                                          style="object-fit: cover; height: 80px; max-width: 80px; border-radius: 50%;"
                                      >
                                        <template v-slot:placeholder>
                                            <v-row align="center" class="fill-height ma-0" justify="center">
                                                <v-progress-circular color="grey" indeterminate></v-progress-circular>
                                            </v-row>
                                        </template>
                                    </v-img>
                                    <v-file-input
                                        class="pa-5"
                                        :label="$t('key.picture')"
                                        :placeholder="$t('user.uploadImage')"
                                        @change="fileChange"
                                        accept="image/png, image/jpeg, image/bmp ,image/heif, image/heic"
                                        prepend-icon="photo"
                                        v-model="avatar"
                                    ></v-file-input>
                                </v-row>
                                <v-row>
                                    <v-text-field
                                        v-bind:label="$t('key.name')"
                                        v-model="key.name"
                                    ></v-text-field>
                                </v-row>
                                <v-row>
                                    <v-text-field
                                        v-bind:label="$t('key.description')"
                                        v-model="key.description"
                                    ></v-text-field>
                                </v-row>
                                <v-row>
                                    <span>Tags</span>
                                    <v-col cols="12 pa-0" v-if="key.newTags && key.newTags.length > 0">
                                        <v-chip-group
                                            active-class="primary--text"
                                            column
                                            multiple
                                        >
                                            <v-chip :key="i"
                                                    @click:close="removeTags(tag)"
                                                    :close="true"
                                                    v-for="(tag, i) in key.newTags"
                                            >
                                                {{ tag[lang] }}
                                            </v-chip>
                                        </v-chip-group>
                                    </v-col>
                                    <v-col cols="12 pa-0">
                                        <v-autocomplete
                                            :search-input.sync="searchTags"
                                            v-model="key.newTags"
                                            :items="removeTagDuplicates(tags, key.newTags)"
                                            multiple
                                            append-icon
                                            hide-no-data
                                            no-filter
                                            chips
                                            prepend-inner-icon="flag"
                                            :label="$t('keysList.addTags')"
                                        >
                                            <template v-slot:selection="data">
                                            </template>
                                            <template v-slot:item="data">
                                                <v-list-item-content>
                                                    <v-list-item-title>{{ data.item[lang] }}</v-list-item-title>
                                                </v-list-item-content>
                                            </template>
                                        </v-autocomplete>
                                    </v-col>
                                </v-row>
                                <v-row cols="12 pa-0">
                                    <v-autocomplete
                                        :item-text="itemStringified"
                                        item-value="id"
                                        :items="isKeyB2B ? agencyRelays : flowRelays"
                                        :search-input.sync="searchAllRelays"
                                        :loading="loadingRelays"
                                        append-icon
                                        flat
                                        :no-data-text="$t('keysList.noRelayFound')"
                                        prepend-icon="near_me"
                                        solo
                                        hide-details
                                        :readonly="currentRelay(key) && currentRelay(key).id === key.relayId"
                                        :clearable="!currentRelay(key) || currentRelay(key).id !== key.relayId"
                                        v-bind:label="$t('actions.search')"
                                        v-model="key.relayId"
                                    >
                                        <template v-slot:selection="data">
                                            <v-list-item-content style="overflow: hidden;">
                                                <v-list-item-title
                                                    v-html="data.item.name">
                                                </v-list-item-title>
                                                <v-list-item-subtitle
                                                    v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city">
                                                </v-list-item-subtitle>
                                            </v-list-item-content>
                                        </template>
                                        <template v-slot:item="data">
                                            <v-list-item-content :aria-disabled="!data.item.available">
                                                <v-list-item-title
                                                    v-html="data.item.name">
                                                </v-list-item-title>
                                                <v-list-item-subtitle
                                                    v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city">
                                                </v-list-item-subtitle>
                                            </v-list-item-content>
                                        </template>
                                    </v-autocomplete>
                                </v-row>
                            </v-container>
                        </v-card-text>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn
                                @click="close"
                                color="white"
                                text
                            >
                                {{ $t('actions.cancel') }}
                            </v-btn>
                            <v-btn
                                v-if="key.Relays && key.name && validEditKeyInfoForm"
                                :disabled="!key.Relays && !key.name"
                                @click="saveKey(key, {info: true, relays: true})"
                                color="warning"
                                :loading="loadingKey"
                            >
                                {{ $t('actions.save') }}
                            </v-btn>
                        </v-card-actions>
                    </v-form>
                </v-card>
            </v-dialog>
            <v-dialog max-width="700px" v-model="replaceReferenceRelay" persistent>
                <v-card>
                    <v-card-title>
                        <span class="headline">{{ $t(isKeyB2B ? 'key.replaceReferenceAgency' : 'key.replaceReferenceRelay') }}</span>
                    </v-card-title>
                    <v-card-text>
                        <v-container>
                            <span>
                                {{$t(isKeyB2B ? 'keysList.chooseAgencyRelay': 'keysList.chooseFlowRelay')}}
                            </span>
                            <v-col cols="12 pa-0">
                                <v-autocomplete
                                    :item-text="itemStringified"
                                    item-value="id"
                                    :items="isKeyB2B ? agencyRelays : flowRelays"
                                    :search-input.sync="searchAllRelays"
                                    :loading="loadingRelays"
                                    append-icon
                                    flat
                                    :no-data-text="$t('keysList.noRelayFound')"
                                    prepend-icon="near_me"
                                    solo
                                    hide-details
                                    :readonly="currentRelay(key) && currentRelay(key).id === key.relayId"
                                    :clearable="!currentRelay(key) || currentRelay(key).id !== key.relayId"
                                    v-bind:label="$t('actions.search')"
                                    v-model="key.relayId"
                                >
                                    <template v-slot:selection="data">
                                        <v-list-item-content style="overflow: hidden;">
                                            <v-list-item-title
                                                v-html="data.item.name">
                                            </v-list-item-title>
                                            <v-list-item-subtitle
                                                v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city">
                                            </v-list-item-subtitle>
                                        </v-list-item-content>
                                    </template>
                                    <template v-slot:item="data">
                                        <v-list-item-content :aria-disabled="!data.item.available">
                                            <v-list-item-title
                                                v-html="data.item.name">
                                            </v-list-item-title>
                                            <v-list-item-subtitle
                                                v-html="data.item.address + ', ' + data.item.zipCode + ', ' + data.item.city">
                                            </v-list-item-subtitle>
                                        </v-list-item-content>
                                    </template>
                                </v-autocomplete>
                            </v-col>
                        </v-container>
                    </v-card-text>
                    <v-card-actions>
                        <v-spacer></v-spacer>
                        <v-btn @click="closeReplaceReferenceRelay" color="white" text>
                            {{ $t("actions.cancel") }}
                        </v-btn>
                        <v-btn
                            v-if="key.relayId && isReferentRelayReplaced"
                            color="warning"
                            :loading="loadingKey"
                            @click="saveKey(key, {relays: true})"
                        >
                            {{ $t("actions.confirm") }}
                        </v-btn>
                        <v-spacer></v-spacer>
                    </v-card-actions>
                </v-card>
            </v-dialog>
            <v-row>
                <div class="onglets_row">
                    <div v-on:click="screenFull = true">
                        <mobile-list-key-item
                            :item="key"
                            :update-data="updateData"
                            :description="true"
                            :location="true"
                            :key="componentKey"
                            :img-update="componentKey"
                        />
                    </div>
                    <button
                        type="button"
                        v-if="isKeyManager(currentUser,key) || isMaster() || isAdmin"
                        class="option open_popup"
                        @click="editKeyInfoDialog = true"
                        :disabled="!isAdmin && isCompanyBlocked"
                    >
                        <i class="icon-picto_editer"></i>
                    </button>
                </div>
            </v-row>
            <v-row v-if="isCompanyBlocked">
                 <v-alert
                     dense
                     text
                     color="error"
                     style="width: 100%;"
                 >
                    {{ $t('key.blocked') }}
                </v-alert>
            </v-row>
            <v-row v-if="isKeyArchived">
                <v-alert
                    dense
                    text
                    color="warning"
                    style="width: 100%;"
                >
                    {{ $t(archivedText) }}
                </v-alert>
            </v-row>
            <v-row v-if="key.hasAllRights">
                <v-alert
                    dense
                    text
                    color="success"
                    style="width: 100%;"
                >
                    {{ $t('key.unblocked') }}
                </v-alert>
            </v-row>
            <v-row v-if="key.currentBooking">
                <div class="onglets_row">
                    <v-row class="owner_row" style="margin-left: 0 !important;margin-right: 0 !important;">
                        <v-col :cols="12" style="background-color: #ffeacc !important;padding-bottom:0 !important;">
                            <div style="padding: 0px 10px !important;">
                                <div class="row no-gutters" style="background-color: #ffeacc !important;">
                                    <div class="col-sm-12">
                                        <relay-booked-key
                                            :current-key="key"
                                            mobile="true"
                                        />
                                    </div>
                                </div>
                            </div>
                        </v-col>
                    </v-row>
                </div>
            </v-row>
            <v-row v-if="key && key.owner && isBookedKeyAvailable">
                <div class="onglets_row">
                    <v-row class="owner_row" style="margin-left: 0 !important;margin-right: 0 !important;">
                        <v-col :cols="12" style="background-color: #ffeacc !important;padding-bottom:0 !important;">
                            <div style="padding: 0px 10px !important;">
                                <div class="row no-gutters" style="background-color: #ffeacc !important;">
                                    <div class="col-sm-12">
                                        <h6 style="color:#fb8c00 !important;">{{ $t('key.actionToDo') }}</h6>
                                        <div v-if="isHandToHandTargetUser">
                                            <button
                                                style="width: inherit"
                                                :disabled="isCompanyBlocked"
                                                type="button"
                                                class="action_button"
                                                @click="goHandToHandScan"
                                            >
                                                <v-list-item-icon class="list_btn_action">
                                                    <p class="with_key action_key">
                                                    <span class="icon-picto_recevoir-main-a-main-2 mobile" style="background: #ffa83b;">
                                                        <i class="path1"></i>
                                                        <i class="path2"></i>
                                                        <i class="path3"></i>
                                                    </span>
                                                        <strong>{{ $t('key.actions.receiveHandToHand') }}</strong>
                                                    </p>
                                                </v-list-item-icon>
                                            </button>
                                        </div>
                                        <key-withdraw
                                            v-if="!isKeyInConnectedBox"
                                            :currentKey="key"
                                            :mobile="true"
                                            :update-data="updateData"
                                        />
                                        <key-withdraw-connected
                                            :currentKey="key"
                                            :mobile="true"
                                            :update-data="updateData"
                                        />
                                        <key-drop-agency
                                            :currentKey="key"
                                            :mobile="true"
                                            :update-data="updateData"
                                        />
                                        <key-drop-connected
                                            :currentKey="key"
                                            :mobile="true"
                                            :update-data="updateData"
                                        />
                                        <hand-to-hand
                                            :currentKey="key"
                                            :mobile="true"
                                            :update-data="updateData"
                                        />
                                        <key-drop-my-loby
                                            v-if="(!isKeyB2B && !isKeyInsurance) || (keyAdditionalRelays && keyAdditionalRelays.length  > 0)"
                                            :currentKey="key"
                                            :mobile="true"
                                            :update-data="updateData"
                                        />
                                        <key-transit
                                            :currentKey="key"
                                            :mobile="true"
                                            :update-data="updateData"
                                        />
                                        <key-retrieve
                                            :currentKey="key"
                                            :mobile="true"
                                            :update-data="updateData"
                                        />
                                    </div>
                                </div>
                            </div>
                        </v-col>
                    </v-row>
                </div>
                <div class="onglets_row">
                    <v-row no-gutters class="owner_row">
                        <v-col :cols="12">
                            <div class="details" style="margin-left: -15px;">
                                <div class="row no-gutters">
                                    <div class="col-sm-12">
                                        <v-row
                                            style="background-color: white"
                                            v-if="(isManager && !isCompanyBlocked) || isAdmin"
                                            justify="center"
                                            class="m-key-card-actions mb-5"
                                        >
                                            <button
                                                @click="openAddGuestModal"
                                                class="option"
                                                type="button"
                                                :disabled="isKeyArchived && !isAdmin"
                                                v-if="isManager || isAdmin"
                                                style="color:#fb8c00 !important;"
                                            >
                                                <i style="color:#fb8c00 !important;" class="icon-picto_ajouter"></i>
                                                {{ $t('key.addGuests') }}
                                            </button>
                                            <v-dialog
                                                persistent
                                                v-model="addGuest"
                                                max-width="500px"
                                                fullscreen
                                                hide-overlay
                                                transition="dialog-bottom-transition"
                                            >
                                                <v-card>
                                                    <v-card-title>
                                                        <span style="color:#fb8c00 !important;"
                                                              class="headline">{{ $t('keysList.addGuest') }}</span>
                                                    </v-card-title>
                                                    <v-card-text>
                                                        <v-container class="pb-0">
                                                            <key-guests-autocomplete
                                                                :currentKey="key"
                                                                :edit="true"
                                                                ref="keyGuestsAutocomplete"
                                                                @invitation-change="updateIsAddButtonStatus"
                                                                @save="saveKey">
                                                            </key-guests-autocomplete>
                                                        </v-container>
                                                    </v-card-text>
                                                    <v-card-actions>
                                                        <v-spacer></v-spacer>
                                                        <v-btn
                                                            @click="addGuest = false"
                                                            color="white"
                                                            text
                                                        >
                                                            {{ $t('actions.cancel') }}
                                                        </v-btn>
                                                        <v-btn
                                                            @click="addGuestFunction()"
                                                            v-if="isAddButtonEnabled || loadingAddGuest"
                                                            :loading="loadingAddGuest"
                                                            color="primary"
                                                        >
                                                            {{ $t('actions.add') }}
                                                        </v-btn>
                                                    </v-card-actions>
                                                </v-card>
                                            </v-dialog>
                                            <over-price-sms
                                                :dialog="acceptOverPrice"
                                                :loading="loadingSmsOverprice"
                                                @accept="saveKey(key,{newGuests:true, acceptOverPrice:true})"
                                                @cancel="closeAddGuest"
                                            ></over-price-sms>
                                        </v-row>
                                    </div>
                                </div>
                            </div>
                        </v-col>
                    </v-row>
                </div>
            </v-row>
            <v-row v-if="key && key.owner">
                <div class="onglets_row">
                    <v-row no-gutters class="owner_row">
                        <v-col :cols="12">
                            <div class="details">
                                <div class="row no-gutters">
                                    <div class="col-sm-12">
                                        <h6>{{ $t('key.owner') }}</h6>
                                        <p class="with_key">
                                            <span>
                                                <i class="icon-picto_mes-contacts"></i>
                                            </span>
                                            <strong>{{ key.owner.displayName }}</strong>
                                            <i v-if="key.owner.Company"> ({{ key.owner.Company.name }})</i>
                                            <br/>
                                            <a :href="`mailto:${key.owner.email}`">{{ key.owner.email }}</a>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </v-col>
                    </v-row>
                </div>
            </v-row>
            <v-row>
                <div class="onglets_row">
                    <v-row no-gutters class="relais_row">
                        <v-col :cols="12" :sm="6" class="first_col d-flex justify-content-between" v-if="isKeyB2B">
                            <div class="details">
                                <key-relays
                                    v-if="keyAgencyRelays && keyAgencyRelays.length  > 0"
                                    :relays="keyAgencyRelays"
                                    :title="$t('key.agencyRelayInfo')"
                                    :mobile="true"
                                >
                                </key-relays>
                                <div class="info_relais_agence text-center" v-else>
                                    <h6>{{ $t('relay.noAssociatedAgency') }}</h6>
                                </div>
                            </div>
                            <div>
                                <button
                                        v-if="isKeyManager(currentUser,key) || isMaster || isAdmin"
                                        type="button"
                                        class="option pr-5 mt-5"
                                        :disabled="isCompanyBlocked || key.status === 'IN_RELAY' || key.status === 'IN_TRANSIT'"
                                        @click.prevent="replaceReferenceRelay = true"
                                    >
                                        <i class="icon-picto_editer"></i>
                                </button>
                            </div>
                        </v-col>
                        <div class="col-md-6" v-if="!isKeyB2B || canAssociateFlowRelay">
                            <div class="details">
                                <key-relays
                                    v-if="keyFlowRelays && keyFlowRelays.length  > 0"
                                    :relays="keyFlowRelays"
                                    :title="$t('key.lobyInfo')"
                                    :mobile="true"
                                ></key-relays>
                                <div class="info_relais_agence text-center" v-else>
                                    <h6>{{ $t('relay.noAssociatedFlow') }}</h6>
                                </div>
                            </div>
                        </div>
                    </v-row>
                </div>
            </v-row>
            <v-row v-if="key.Subscription && key.Subscription.length && (isManager || isAdmin)">
                <div class="onglets_row">
                    <v-row no-gutters class="owner_row">
                        <v-col :cols="12">
                            <div class="details">
                                <div class="row no-gutters">
                                    <div class="col-sm-12">
                                        <h6>{{ $t('key.subscriptions.title') }}</h6>
                                        <div>
                                            <label>{{ $t('key.subscriptions.type') }} :</label>
                                            <p>
                                                <strong>{{
                                                        $t(`subscription.${key.Subscription[0].Plan.name}.title`)
                                                    }}</strong>
                                            </p>
                                        </div>
                                        <div>
                                            <label>{{ $t('key.subscriptions.description') }} :</label>
                                            <p style="margin-bottom: 0">{{
                                                    $t(`subscription.${key.Subscription[0].Plan.name}.description`)
                                                }}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </v-col>
                    </v-row>
                </div>
            </v-row>
        </span>
        <restriction-dialog
            @close="isRestrictedOn = null"
            :type="isRestrictedOn"
            :mobile="true"
        />
    </v-container>
</template>

<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";
import {Getter} from "vuex-class";
import KeyStatus from "@/components/keys/KeyStatus.vue";
import MobileListKeyItem from "@/components/mobile/MobileListKeyItem.vue";
import KeyGuestsAutocomplete from "@/components/keys/KeyGuestsAutocomplete.vue";
import KeyRelays from "@/components/keys/KeyRelays.vue";
import KeyTransit from "@/components/keys/actions/KeyTransit.vue";
import KeyRetrieve from "@/components/keys/actions/KeyRetrieve.vue";
import HandToHand from "@/components/keys/actions/HandToHand.vue";
import KeyWithdraw from "@/components/keys/actions/KeyWithdraw.vue";
import KeyWithdrawConnected from "@/components/keys/actions/KeyWithdrawConnected.vue";
import KeyDropMyLoby from "@/components/keys/actions/KeyDropMyLoby.vue";
import KeyDropAgency from "@/components/keys/actions/KeyDropAgency.vue";
import KeyDropConnected from "@/components/keys/actions/KeyDropConnected.vue";
import RestrictionDialog from "@/components/RestrictionDialog.vue";
import {canUseFlowRelays, canAddMoreUserToKey} from "plan-restrictions";
import OverPriceSms from "@/components/OverPriceSms.vue";
import {getSrc, removeVuetifyFileInputBug} from "@/utils/misc";
import {formRules} from "@/utils/formRules";
import Timeout = NodeJS.Timeout;
import imageCompression from "browser-image-compression";
import heic2any from "heic2any";
import RelayBookedKey from "@/components/relays/RelayBookedKey.vue";

export const DEBOUNCE_TIME_MILLI: number = 500;
export const TYPE_FLOW: string = "FLOW";
export const TYPE_AGENCY: string = "AGENCY";

@Component({
    components: {
        KeyStatus,
        MobileListKeyItem,
        KeyGuestsAutocomplete,
        KeyRelays,
        KeyTransit,
        KeyRetrieve,
        KeyDropMyLoby,
        KeyDropAgency,
        KeyDropConnected,
        KeyWithdraw,
        KeyWithdrawConnected,
        HandToHand,
        RestrictionDialog,
        OverPriceSms,
        RelayBookedKey,
    },
})
export default class KeyMobile extends Vue {
    private componentKey: number = 0;
    private heicFile: any = null;

    get lang(): string {
        return this.$root.$i18n.locale;
    }

    get keyAgencyRelays() {
        return this.key?.Relays?.filter((r) => r.type === "AGENCY");
    }

    get keyFlowRelays() {
        return this.key?.Relays?.filter((r) => r.type === "FLOW");
    }

    get isKeyInsurance(): boolean {
        return this.key?.Relays?.some((r) => r.type === "LONG_TERM");
    }

    get isKeyB2B(): boolean {
        return this.key?.Relays?.some((r) => r.type === "AGENCY");
    }

    get isKeyArchived(): boolean {
        return this.key?.archivedAt && !this.key.hasAllRights;
    }

    get isHandToHandTargetUser(): boolean {
        return this.key?.HandToHand?.some((handToHand) => handToHand?.targetUserId === this.currentUser?.id);
    }

    get archivedText(): string {
        if (this.isAdmin) {
            return "key.archived";
        } else if (!this.isManager) {
            return "key.archivedGuest";
        } else if (this.isKeyB2B) {
            return "key.archived";
        } else if (this.key.Subscription.length) {
            return "key.archivedB2CDefaultPayment";
        } else {
            return "key.archivedB2C";
        }
    }

    get canAssociateFlowRelay(): boolean {
        return this.canUseFlowRelays(this.currentUser?.company);
    }

    get isCompanyBlocked(): boolean {
        return this.key?.company && !!this.key?.company?.blockedAt;
    }

    get disableMoreUsers(): boolean {
        const usersNbrInGroup: (accessGroup: any[]) => number = (accessGroup: any[]) =>
            accessGroup.reduce((a, c) => a + c?.Users?.length || 1, 0) || 0;
        return !this.canAddMoreUserToKey(
            this.currentUser?.company,
            usersNbrInGroup(this.key?.keyManagers) + usersNbrInGroup(this.key?.guests),
            // +1 to prevent manager from selecting more users than authorized
            usersNbrInGroup(this.key?.newKeyManagers) + usersNbrInGroup(this.key?.newGuests) + 1,
        );
    }

    get keyReferenceRelay(): any {
        return this.key?.Relays?.find((relay) => relay.type === "AGENCY") || this.key?.Relays?.[0];
    }

    get keyAdditionalRelays(): any[] {
        return this.key?.Relays?.filter((relay) => relay.type === "FLOW");
    }

    get isReferentRelayReplaced(): boolean {
        return this.key?.relayId?.id !== this.keyReferenceRelay?.id;
    }

    // check if one of the user of one of the management groups match the current user
    get isManager(): boolean {
        return this.key?.keyManagers
            ?.some((g) => g?.Users?.some((u) => u.id === this.currentUser?.id))
            || this.key.ownerId === this.currentUser?.id;
    }

    get isKeyInConnectedBox() {
        return this.key?.status && this.key?.status === "IN_CONNECTED_BOX";
    }
    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isB2B: boolean;

    private key: any = {};
    private keyId: number = null;
    private isLoading: boolean = true;
    private loadingAddGuest: boolean = false;
    private loadingSmsOverprice: boolean = false;
    private isAddButtonEnabled: boolean = false;
    private addGuest: boolean = false;
    private isRestrictedOn: string = null;
    private editKeyInfoDialog: boolean = false;
    private validEditKeyInfoForm: boolean = false;
    private avatar: any = null;
    private uploadedImageSrc: any = null;
    private tags: any = [];
    private searchTags: string = null;
    private rules: object = formRules;
    private replaceReferenceRelay: boolean = false;
    private relayId: number = null;
    private searchAllRelays: string = null;
    private agencyRelays: any[] = [];
    private flowRelays: any[] = [];
    private loadingRelays: boolean = false;
    private loadingKey: boolean = false;
    private additionalRelay: any = null;
    private addManager: boolean = false;
    private editGuestDialog: boolean = false;
    private timerId: Timeout = null;
    private loadingLogs: boolean = false;
    private logs: any = {};
    private lastLogs: any = {};
    private keyManagersHeaders: object[] = [];
    private guestsHeaders: object[] = [];
    private addAdditionalRelay: boolean = false;
    private screenFull: boolean = false;
    private timestampKeyImage: any = "";

    private getSrc: (picturePath: string) => string = getSrc;
    private removeVuetifyFileInputBug: (document: any) => void = removeVuetifyFileInputBug;
    private canUseFlowRelays: (company: any) => boolean = canUseFlowRelays;
    private canAddMoreUserToKey: (
        company: any,
        existingKeyUsersNbr: number,
        newKeyUsersNbr: number,
    ) => boolean = canAddMoreUserToKey;
    private acceptOverPrice: boolean = false;

    @Watch("searchTags")
    public handlerSearchTags(): void {
        this.getTags();
    }
    @Watch("searchAllRelays", {deep: true})
    public handlerSearchRelays(newVal: string): void {
        if (newVal) {
            this.searchRelays();
        }
    }

    private itemStringified = (item) => JSON.stringify(item);
    private currentRelay = (key) => key?.currentLocation?.Box.Relay;
    private isValidAccess = (access: any) => (access.countAccessLeft === -1 || access.countAccessLeft >= 1)
        && (access.startDate === null || new Date(access.startDate) <= new Date())
        && (access.endDate === null || new Date(access.endDate) >= new Date())

    // check if one of the user of one of the management groups match the current user
    private isKeyManager = (user, key) => key?.keyManagers
        ?.some((g) => g?.Users?.some((u) => u.id === user?.id))

    private userHasKey = (user, key) => key?.KeyHolding?.find((kH) => !kH.endDate)?.userId === user?.id;

    private connectedUserHasKeyAccess = (key, user) => this.isManager
        || this.userHasKey(user, key)
        || key.guests
            ?.filter((guestGroup) => guestGroup.Users.map((user) => user.id).includes(user.id))
            ?.filter((guestGroup) => guestGroup.invitations.some((invitation) =>
                this.isValidAccess(invitation.keyAccess)))
            ?.length

    private mounted() {
        this.keyId = Number(this.$route.params.id);
        this.getKeyById();
        this.reset();
    }

    private getKeyById() {
        return this.$store.dispatch("keys/getById", {
            id: this.keyId,
            options: {
                picture: true,
                relays: true,
                reservedLocation: true,
                owner: true,
                holder: true,
                keyManagers: true,
                guests: true,
                logs: true,
                currentLocation: true,
                company: true,
            },
        })
            .then((key) => {
                key.relayId = key?.Relays?.filter((r) => r.type === "AGENCY")?.[0]?.id;
                key.Relays = key?.Relays?.map((relay) => ({
                    value: relay.id,
                    ...relay,
                }));
                key.newKeyManagers = [];
                key.guests.forEach((g) => {
                    g.connectedUserInvitation = g.invitations?.[0];
                });
                key.newGuests = [];
                key.newTags = key.Tags;
                key.transitMode = "";
                key.locationDisplayed = key?.company?.type === "B2B" ? key?.currentLocation :
                    (key?.currentLocation || key?.ReservedLocations?.[0]);
                const acsesObject = key.AcsesObjects[0];
                if (acsesObject) {
                    key.connectedBoxLocker = acsesObject.name;
                }
                this.key = key;
                this.isLoading = false;
            }).catch((err) => {
                this.$store.commit("alerts/displayError", {
                    msg: err,
                });
                this.isLoading = false;
            });
    }

    private goHandToHandScan() {
        this.$router.push({
            name: "key-hand-to-hand-scan",
            params: {
                keyid: this.key.id,
                token: this.key?.HandToHand
                    ?.find((handToHand) => handToHand?.targetUserId === this.currentUser?.id)?.token,
            },
        });
    }

    private openAddGuestModal(): void {
        if (this.disableMoreUsers) {
            this.isRestrictedOn = "maxUsersPerKey";
        } else {
            this.addGuest = true;
        }
    }

    private updateIsAddButtonStatus(newVal: boolean): void {
        this.isAddButtonEnabled = newVal;
    }

    private addGuestFunction(): void {
        this.loadingAddGuest = true;
        return (this.$refs.keyGuestsAutocomplete as HTMLFormElement)?.addGuest();
    }

    private updateData() {
        if (!this.isManager) {
            this.$router.push({name: "keys"});
        } else {
            this.getKeyById();
        }
    }

    private beforeUpdate(): void {
        this.removeVuetifyFileInputBug(document);
    }

    private reset() {
        this.close();
        this.keyManagersHeaders = [
            {value: "name", text: this.$tc("key.user", 1), sortable: true},
            {value: "profile", text: this.$t("key.guest.profile"), sortable: true},
            {value: "keyGroupName", text: this.$t("key.guest.keyGroup"), sortable: true},
            {value: "data-table-expand"},
            {value: "action", sortable: false},
        ];
        this.guestsHeaders = [
            {value: "name", text: this.$tc("key.user", 1), sortable: true},
            {value: "profile", text: this.$t("key.guest.profile"), sortable: true},
            {value: "access", text: this.$t("key.guest.access"), sortable: true},
            {value: "accessCount", text: this.$t("key.guest.accessCount"), sortable: true},
            {value: "keyGroupName", text: this.$t("key.guest.keyGroup"), sortable: true},
            {value: "accessGivedBy", text: this.$t("key.guest.accessGivedBy"), sortable: false},
            {value: "data-table-expand"},
            {value: "action", sortable: false},
        ];
        this.getKeyById();
        this.getLogs();
        this.getRelays();
        this.getTags();
        this.forceImageKeyRender();
    }

    private getLogs(params?: any): void {
        if (this.keyId) {
            if (!params) {
                this.loadingLogs = true;
            }
            this.$store.dispatch("logs/getLogs", {
                query: {
                    currentPage: "key",
                    entityId: this.keyId,
                    entityType: "key",
                    ...params,
                },
            }).then((res) => {
                if (!params) {
                    this.lastLogs = res;
                    this.loadingLogs = false;
                } else {
                    this.logs = res;
                }
            });
        }
    }

    private getRelays(): Promise<void> {
        const p: Array<Promise<any>> = [
            this.$store.dispatch("relays/getAll", {
                query: {
                    search: this.searchAllRelays,
                    type: TYPE_FLOW,
                    available: true,
                    itemsPerPage: 10,
                },
            }),
        ];
        if (this.isB2B || this.isAdmin) {
            p.push(this.$store.dispatch("relays/getList", {
                query: {
                    search: this.searchAllRelays,
                    type: TYPE_AGENCY,
                    available: true,
                    itemsPerPage: 10,
                },
            }));
        }
        return Promise.all(p).then((res) => {
            this.flowRelays = res[0]?.relays || [];
            this.agencyRelays = res[1]?.relays || [];
        });
    }

    private searchRelays(): void {
        this.loadingRelays = true;
        // cancel pending call
        clearTimeout(this.timerId);
        // delay new call
        this.timerId = setTimeout(() => {
            this.getRelays().then(() => {
                this.loadingRelays = false;
            });
        }, DEBOUNCE_TIME_MILLI);
    }

    private closeAddGuest(): void {
        this.acceptOverPrice = false;
        this.addGuest = false;
        this.key.newGuests = [];
        this.loadingSmsOverprice = false;
        this.loadingAddGuest = false;
    }

    private getTags(): void {
        this.$store.dispatch("tags/getAll", {
            query: {
                search: this.searchTags,
                lang: this.lang,
            },
        })
            .then((res) => {
                this.tags = res.tags;
            });
    }

    private removeTags(item): void {
        const index = this.key.newTags.findIndex((i) => i.id === item.id);
        if (index >= 0) {
            this.key.newTags.splice(index, 1);
        }
    }

    private removeTagDuplicates(completeList, duplicates): any[] | null {
        if (!completeList || !duplicates) {
            return null;
        }
        return completeList.filter((item: any) =>
            !duplicates.map((elem: any) => elem?.id)?.includes(item?.id));
    }

    private async fileChange(): Promise<void> {
        this.loadingKey = true;
        this.heicFile = null;
        if (this.avatar) {
            if (this.avatar.type === "image/heif" || this.avatar.type === "image/heic") {
                const blob = this.avatar as Blob;
                this.heicFile = await heic2any({blob});
                const fr = new FileReader();
                fr.readAsDataURL(this.heicFile as Blob);
                fr.addEventListener("load", () => {
                    this.uploadedImageSrc = fr.result;
                });
            } else {
                const fr = new FileReader();
                fr.readAsDataURL(this.avatar);
                fr.addEventListener("load", () => {
                    this.uploadedImageSrc = fr.result;
                });
            }
        } else {
            this.uploadedImageSrc = null;
        }
        this.loadingKey = false;
    }

    private updateTags(): void {
        this.key.tags.push(...this.searchTags.split(","));
        this.searchTags = "";
    }

    private async saveKey(key: any, params?: any): Promise<void> {
        this.loadingKey = true;
        this.loadingAddGuest = true;
        if (this.uploadedImageSrc) {
            const options = {
                maxSizeMB: 1,
                useWebWorker: true,
            };
            let compressedFile: any = null;
            if (!this.heicFile) {
                compressedFile = await imageCompression(this.avatar, options);
            }
            const formData = new FormData();
            formData.append("file", compressedFile ? compressedFile : this.heicFile);
            formData.append("id", this.key.id.toString());
            formData.append("fileType", "key-picture");
            await this.$store.dispatch("files/upload", {formData});
            key.picturePath = `/api/files/keys/${key.id}/pictures/key-picture`;
        }
        key.Tags = key.newTags.map((t) => t?.id);
        if (Number.isInteger(key.relayId)) {
            key?.Relays?.push({id: key.relayId});
        }
        delete key.logs;
        this.$store.dispatch("keys/update", {
            key,
            params: params || {
                info: true,
                newKeyManagers: true,
                newGuests: true,
                relays: true,
                acceptOverPrice: false,
            },
        })
        .then(() => {
            this.reset();
            this.acceptOverPrice = false;
            this.loadingKey = false;
            this.loadingAddGuest = false;
        })
        .catch((err) => {
            switch (err?.response?.data?.error) {
                case "smsLimitReached":
                    this.acceptOverPrice = true;
                    break;
                case "freemium":
                    this.$store.commit("alerts/displayError", {
                        msg: this.$i18n.t("invitation.freemium"),
                    });
                    break;
                default:
                    this.reset();
                    this.$store.commit("alerts/displayError", {
                        msg: this.$t(`alerts.error.${err?.response?.data?.error || "default"}`),
                    });
                    break;
            }
            this.loadingAddGuest = false;
        });
    }

    private close(): void {
        this.addGuest = false;
        this.editGuestDialog = false;
        this.editKeyInfoDialog = false;
        this.key.newTags = this.key.Tags;
        this.addManager = false;
        this.closeReplaceReferenceRelay();
        this.closeAddAdditionalRelay();
    }

    private closeReplaceReferenceRelay(): void {
        this.replaceReferenceRelay = false;
        this.key.relayId = this.keyReferenceRelay;
    }

    private closeAddAdditionalRelay(): void {
        this.addAdditionalRelay = false;
        this.additionalRelay = null;
    }
    private forceImageKeyRender() {
        this.componentKey += 1;
    }

    get isBookedKeyAvailable() {
        if (!this.key.currentBooking) {
            return true;
        }
        const hasRights = this.currentUser.id === this.key.currentBooking.createdBy
            || this.isManager
            || this.isAdmin;
        return (this.key.currentBooking && hasRights) || (this.currentUser.id === this.key.currentBooking.userId);
    }
}
</script>
