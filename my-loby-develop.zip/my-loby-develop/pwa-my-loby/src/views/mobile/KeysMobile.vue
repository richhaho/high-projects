<template>
    <v-container>
        <v-row>
            <v-col cols="10">
                <v-text-field
                    class="mobile-search"
                    :label="$t('keysList.search')"
                    filled
                    rounded
                    dense
                    hide-details
                    single-line
                    append-icon="search"
                    v-model="keysSearch"
                    @input="searchHandler"
                ></v-text-field>
            </v-col>
            <v-col cols="2" class="m-header-btn">
                <button
                    :disabled="isCompanyBlocked"
                    class="m-btn-round"
                    @click="disableKeyCreation ? isRestrictedOn = 'maxKeys' : showCreateDialog = true"
                    v-if="this.pagination.tab === 'myKeys' || this.pagination.tab === 'sharedKeys'"
                >
                    <i style="color: #212529" class="icon-picto_ajouter"></i>
                </button>
            </v-col>
        </v-row>
        <v-row>
        <div class="onglets_row">
            <a
                @click.prevent="pagination.tab = 'myKeys'"
                v-if="!isDemo && (myKeysCount > 0 || sharedKeysCount === 0)"
                :title="$t('keysList.myKeys')"
                :class="{active: pagination.tab === 'myKeys'}"
                :style="displayClass()"
            >
                <div class="onglet">{{$t('keysList.myKeys')}}</div>
            </a>
            <a
                v-if="(sharedKeysCount > 0 || isDemo)"
                @click="pagination.tab = 'sharedKeys'"
                :title="$t('keysList.sharedKeys')"
                :class="{active: pagination.tab === 'sharedKeys'}"
                :style="displayClass()"
            >
                <div class="onglet">{{$t('keysList.sharedKeys')}}</div>
            </a>
        </div>
        </v-row>
        <div>
            <v-row id="key-list" >
                <v-list three-line width="100%" v-if="keys.length">
                    <template v-for="(item, index) in keys" v-if="keys.length">
                        <mobile-list-key-item
                            :item="item"
                            :key="index"
                            :update-data="getKeys"
                        />
                        <v-divider v-if="index < keys.length - 1"/>
                    </template>
                </v-list>
                <v-col v-else-if="!isLoading" align="center">
                    <v-row justify="center" class="mx-0 mt-4">
                        <p class="subtitle-2">
                            {{ $t(`keysList.noData.${pagination.tab}`) }}
                        </p>
                    </v-row>
                </v-col>
            </v-row>
            <v-row>
                <v-progress-circular
                    v-if="isLoading"
                    style="margin: 10px auto 0 auto"
                    :width="3"
                    color="rgba(0,0,0,.06)"
                    indeterminate
                ></v-progress-circular>
            </v-row>
            <key-create
                v-if="canCreateKey"
                :show.sync="showCreateDialog"
                @update-data="getKeys"
                :canUseManagers="canUseManagers"
                :is-mobile="true"
            />
            <restriction-dialog
                v-if="isB2B"
                @close="isRestrictedOn = null"
                :type="isRestrictedOn"
                :mobile="true"
            />
        </div>
    </v-container>
</template>

<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";
import MobileList from "@/components/mobile/MobileListRelayItem.vue";
import MobileListKeyItem from "@/components/mobile/MobileListKeyItem.vue";
import KeyCreate from "@/components/keys/KeyCreate.vue";
import {Getter} from "vuex-class";
import RestrictionDialog from "@/components/RestrictionDialog.vue";
import {canCreateMoreKeys, canUseManagers} from "plan-restrictions";
import Timeout = NodeJS.Timeout;

export const DEBOUNCE_TIME_MILLI: number = 500;

@Component({
    components: {
        MobileListKeyItem,
        MobileList,
        KeyCreate,
        RestrictionDialog,
    },
})
export default class KeysMobile extends Vue {
    @Getter private currentUser: any;
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isB2B: boolean;
    @Getter private isDemo: boolean;
    @Getter private isAdmin: boolean;

    private keys: any = [];
    private isLoading: boolean = true;
    private timerId: Timeout = null;
    private keysSearch: string = null;
    private pagination: any = {
        sortDesc: [true],
        sortBy: ["updatedAt"],
        search: "",
        select: [],
        page: 1,
        itemsPerPage: 10,
        tab: "myKeys",
    };
    private totalKeys: number = 10;
    private showCreateDialog: boolean = false;
    private canCreateMoreKeys: (
        company: any,
        existingKeysNbr: number,
        newKeysNbr: number,
    ) => boolean = canCreateMoreKeys;
    private disableKeyCreation: boolean = true;
    private isRestrictedOn: string = null;
    private canUseManagers: (company: any) => boolean = canUseManagers;
    private sharedKeysCount: number = 0;
    private myKeysCount: number = 0;

    @Watch("pagination", { deep: true })
    public handlerPagination(oldVal, newVal) {
        if (this.pagination.search) {
            this.pagination.page = 1;
            this.pagination.itemsPerPage = 10;
        }
        this.getKeys();
    }

    @Watch("pagination.tab", { deep: true })
    public handlerTab() {
        this.pagination.page = 1;
        this.keysSearch = null;
        this.pagination.search = null;
        this.pagination.itemsPerPage = 10;
    }

    private searchHandler(): void {
        this.isLoading = true;
        // cancel pending call
        clearTimeout(this.timerId);
        // delay new call
        this.timerId = setTimeout(() => {
            this.pagination.search = this.keysSearch || null;
        }, DEBOUNCE_TIME_MILLI);
    }

    get canCreateKey(): boolean {
        return !this.isCompanyBlocked && !this.disableKeyCreation; // && this.canCreateKeyB2B;
    }

    get canCreateKeyB2B(): boolean {
        return !this.isB2B || this.isMaster() || !!this.keys?.length;
    }

    private mounted() {
        if (this.$route.params.tab && !this.isDemo) {
            this.pagination.tab = this.$route.params.tab;
        }
        if (this.isDemo) {
            this.pagination.tab = "sharedKeys";
        }
        this.scroll();
        this.restrictKeyCreation(this.currentUser);
        Promise.all([
            this.countSharedKeys(),
            this.countMyKeys(),
        ]).then((res) => {
            this.sharedKeysCount = res[0];
            this.myKeysCount = res[1];
            if (!this.myKeysCount && this.sharedKeysCount) {
                this.pagination.tab = "sharedKeys";
            }
            return this.getKeys();
        });
    }

    private getKeys() {
        this.isLoading = true;
        const query = Object.assign({}, this.pagination, {
            subscriptions: !this.isB2B && !this.isAdmin,
            mobile: true,
        });
        const p: Array<Promise<any>> = [
            this.$store.dispatch("users/getMyKeys", {
                id: this.currentUser.id,
                query,
            }),
        ];
        if (this.pagination.tab === "sharedKeys") {
            p.push(this.$store.dispatch("users/getLateKeys", { id: this.currentUser.id }));
        }
        return Promise.all(p).then(([classicKeys, lateKeys]) => {
            // Merge late keys and classic keys, with late keys always at the top of the table
            this.keys = [
                ...lateKeys?.keys || [],
                ...classicKeys?.keys || [],
            ];
            this.keys.forEach((key: any) => {
                const acsesObject = key.AcsesObjects[0];
                if (acsesObject) {
                    key.connectedBoxLocker = acsesObject.name;
                }
            });
            this.totalKeys = (classicKeys?.count || 0) + (lateKeys?.count || 0);
            this.isLoading = false;
        });
    }

    private countSharedKeys(): Promise<any>  {
        return this.$store.dispatch("users/countMySharedKeys", {
            id: this.currentUser.id,
        });
    }

    private countMyKeys(): Promise<any> {
        return this.$store.dispatch("users/countManagedKeys", {
            id: this.currentUser.id,
        });
    }

    get isCompanyBlocked() {
        return !!this.currentUser?.company?.blockedAt;
    }

    private restrictKeyCreation(user: any) {
        if (user.companyId) {
            this.$store.dispatch("companies/countKeys", {id: user.companyId}).then((res) => {
                this.disableKeyCreation = !this.canCreateMoreKeys(user.company, res, 1);
            })
                .catch((err) => {
                    this.$store.commit("alerts/displayError", {
                        msg: err,
                    });
                });
        } else {
            this.disableKeyCreation = false;
        }
    }

    private scroll() {
        window.onscroll = () => {
            const listElm = document.querySelector("#key-list");
            if (listElm?.clientHeight <= (document.documentElement.scrollTop + window.innerHeight + 100)
                && !this.isLoading) {
                if (this.pagination.itemsPerPage < this.totalKeys) {
                    this.pagination.itemsPerPage += 10;
                    this.getKeys();
                }
            }
        };
    }
    private displayClass() {
        return this.myKeysCount > 0 && this.sharedKeysCount > 0 ? "flex-basis:50%" : "flex-basis:100%";
    }

}
</script>
