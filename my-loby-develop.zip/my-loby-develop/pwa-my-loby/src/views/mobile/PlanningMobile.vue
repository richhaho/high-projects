<template>
    <div class="main-content-display">
        <div class="middle_part flex-grow-1">
            <div class="mots_cles">{{$t('planning.title')}}</div>
            <div class="tableau">
                <div class="options pb-2">
                    <div class="option_left">
                        <v-row v-if="!isDemo">
                            <div class="icon_filter">
                                <i class="icon-picto_mes-contacts text-md-body-1"></i>
                            </div>
                            <v-autocomplete
                                :items="users"
                                :loading="isSearchingUsers"
                                :search-input.sync="userSearch"
                                class="pa-0 ma-0 ml-4"
                                hide-details
                                hide-selected
                                hide-no-data
                                :label="$t('planning.search.users')"
                                :no-data-text="$t('keysList.noKeyFound')"
                                append-icon
                                prepend-inner-icon="add"
                                chips
                                deletable-chips
                                multiple
                                v-model="selectedUsers"
                                @change="getUserBookings"
                            >
                                <template v-slot:selection="data">
                                    <v-chip
                                        v-bind="data.attrs"
                                        :input-value="data.selected"
                                        close
                                        @click="data.select"
                                        :color="data.item.color"
                                        @click:close="removeItemFromSelectedUser(data.item)"
                                    >
                                        <span class="white--text">{{ data.item.text }}</span>
                                    </v-chip>
                                </template>
                                <template v-slot:item="data">
                                    <div class="mr-2">
                                        <i class="icon-picto_mes-contacts"></i>
                                    </div>
                                    {{ data.item.text }}
                                </template>
                            </v-autocomplete>
                        </v-row>
                        <v-row class="mt-5">
                            <div class="icon_filter">
                                <i class="icon-picto_cle-partagees text-md-body-1"></i>
                            </div>
                            <v-autocomplete
                                :items="formattedKeysValues"
                                :loading="isSearchingKeys"
                                :search-input.sync="keySearch"
                                class="pa-0 ma-0 ml-4"
                                hide-details
                                hide-selected
                                hide-no-data
                                :label="$t('planning.search.keys')"
                                :no-data-text="$t('keysList.noKeyFound')"
                                append-icon
                                prepend-inner-icon="add"
                                chips
                                deletable-chips
                                multiple
                                v-model="selectedKeys"
                                @change="getUserBookings"
                            >
                                <template v-slot:item="data">
                                    <div class="mr-2">
                                        <i class="icon-picto_cle-partagees"></i>
                                    </div>
                                    {{ data.item.text }}
                                </template>
                            </v-autocomplete>
                        </v-row>
                    </div>
                    <div class="option_right">
                        <button
                            type="button"
                            class="option open_popup mt-3"
                            @click="openAddReservationModal"
                            :title="$t('booking.create.button')"
                        >
                            <i class="icon-picto_ajouter"></i>
                            {{ $t('booking.create.button') }}
                        </button>
                    </div>
                </div>
                <v-row class="fill-height">
                    <v-col>
                        <v-sheet height="64">
                            <v-toolbar
                                flat
                            >
                                <v-btn
                                    outlined
                                    class="mr-4"
                                    color="grey darken-2"
                                    @click="setToday"
                                >
                                    {{ $t("common.today") }}
                                </v-btn>
                                <v-menu
                                    bottom
                                    right
                                >
                                    <template v-slot:activator="{ on, attrs }">
                                        <v-btn
                                            outlined
                                            color="grey darken-2"
                                            v-bind="attrs"
                                            v-on="on"
                                        >
                                            <span>{{ typeToLabel[type] }}</span>
                                            <span class="material-icons">
                                                expand_more
                                            </span>
                                        </v-btn>
                                    </template>
                                    <v-list>
                                        <v-list-item @click="setNewRange('day')">
                                            <v-list-item-title>{{ $t("planning.range.day") }}</v-list-item-title>
                                        </v-list-item>
                                        <v-list-item @click="setNewRange('week')">
                                            <v-list-item-title>{{ $t("planning.range.week") }}</v-list-item-title>
                                        </v-list-item>
                                        <v-list-item @click="setNewRange('month')">
                                            <v-list-item-title>{{ $t("planning.range.month") }}</v-list-item-title>
                                        </v-list-item>
                                    </v-list>
                                </v-menu>
                            </v-toolbar>
                        </v-sheet>
                        <v-sheet height="64">
                            <v-toolbar
                                flat
                            >
                                <v-btn
                                    fab
                                    text
                                    small
                                    color="grey darken-2"
                                    @click="prevIteration"
                                >
                                    <span class="material-icons">
                                        chevron_left
                                    </span>
                                </v-btn>
                                <v-btn
                                    fab
                                    text
                                    small
                                    color="grey darken-2"
                                    @click="nextIteration"
                                >
                                    <span class="material-icons">
                                        chevron_right
                                    </span>
                                </v-btn>
                                <v-toolbar-title>
                                    {{ calendarTitle }}
                                </v-toolbar-title>
                                <v-spacer></v-spacer>
                            </v-toolbar>
                        </v-sheet>
                    </v-col>
                </v-row>
                <Calendar
                    ref="calendar"
                    :type="type"
                    :focus="focus"
                    :isMobile="true"
                    :events="formattedCalendarEvents"
                    @update-focus="updateFocus"
                    @update-type="updateType"
                    @addBooking = openAddReservationModal
                    @updateRange = "updateRange"
                    @showEvent = "showEvent"
                />
            </div>
        </div>
        <BookingCreateSelection
            :show.sync="showCreateBookingSelection"
            :keys="keys"
            @closeModal="showCreateBookingSelection = false"
            @nextStep="goToStep2Creation"
        />
        <BookingCreate
            :show.sync="showCreateBooking"
            :activeKey="newBookingKey"
            :user="newBookingUser"
            :editMode="bookingEditMode"
            :activeEvent="activeEvent"
            :bookingStartingDate="newBookingStartingDate"
            @bookingCreated="successCreation"
            @closeModal="closeCreationModal"
            @deleteBooking="deleteBooking"
        />
        <BookingRemoveConfirmation
            :booking="bookingToDelete"
            :confirmBlock="confirmRemoval"
            @closeModal="closeDeleteModal"
            @removeSuccess="removeSuccess"
        />
    </div>
</template>
<script lang="ts">
import {Component, Vue, Watch} from "vue-property-decorator";
import Calendar from "@/components/Calendar.vue";
import {Getter} from "vuex-class";
import BookingCreateSelection from "@/components/booking/BookingCreateSelection.vue";
import BookingCreate from "@/components/booking/BookingCreate.vue";
import BookingRemoveConfirmation from "@/components/booking/BookingRemoveConfirmation.vue";
import moment from "moment";
import { bookingColors } from "@/utils/constants";

@Component({
    components: {
        Calendar,
        BookingCreateSelection,
        BookingCreate,
        BookingRemoveConfirmation,
    },
})

export default class Planning extends Vue {
    public typeToLabel: object = {
        month: "",
        week:  "",
        day:  "",
    };

    public $refs!: {
        calendar: HTMLFormElement,
        calendars: HTMLFormElement[],
    };
    public showCreateBookingSelection: boolean = false;
    public showCreateBooking: boolean = false;

    @Getter private currentUser: any;
    @Getter private isAdmin: boolean;
    @Getter private isB2B: boolean;
    @Getter private isDemo: boolean;

    private keys: any[] = [];
    private isSearchingKeys: boolean = false;
    private keySearch: string = null;
    private selectedKeys: any[] = [];

    private users: any[] = [];
    private isSearchingUsers: boolean = false;
    private userSearch: string = null;
    private selectedUsers: any[] = [];

    private focus: string = "";
    private type: string = "month";

    private newBookingKey: object = null;
    private newBookingUser: object = null;
    private newBookingStartingDate: object = null;
    private startDateResearch: string = "";
    private endDateResearch: string = "";
    private searchRequestSend: boolean = true;
    private bookingEditMode: boolean = false;
    private confirmRemoval: boolean = false;
    private bookingToDelete: object = null;
    private activeEvent: object = null;

    private bookingsList: any[] = [];

    get activeList(): any[] {
        if (this.selectedUsers.length > 0) {
            return this.selectedUsers.map((user) => ({
                id: user.id,
                type: "user",
                value: this.getUserIdentity(user),
            }));
        } else if (this.selectedKeys.length > 0) {
            return this.selectedKeys.map((key) => ({
                id: key.id,
                type: "key",
                value: key.name,
            }));
        }
        return [{
            type: "all",
            value: this.$t("planning.planningAll"),
        }];
    }
    get calendarTitle(): string {
        if (this.type === "month") {
            const date = new Date(this.startDateResearch);
            date.setMonth(date.getMonth() + 1);
            const month = date.toLocaleString("default", { month: "long" });
            const uppercasedMonth = month.charAt(0).toUpperCase() + month.slice(1);
            return `${uppercasedMonth} ${date.getFullYear()}`;
        }
        const startDate = new Date(this.startDateResearch);
        const startMonth = startDate.toLocaleString("default", { month: "long" });
        const endDate = new Date(this.endDateResearch);
        const endMonth = endDate.toLocaleString("default", { month: "long" });

        const uppercasedStartMonth = startMonth.charAt(0).toUpperCase() + startMonth.slice(1);
        const uppercasedEndMonth = endMonth.charAt(0).toUpperCase() + endMonth.slice(1);
        if (uppercasedStartMonth === uppercasedEndMonth) {
            return `${uppercasedStartMonth} ${startDate.getFullYear()}`;
        }
        return `${uppercasedStartMonth} - ${uppercasedEndMonth} ${endDate.getFullYear()}`;
    }

    get formattedKeysValues(): any[] {
        return this.keys.map((key: any) => {
            return { text: key.name, value: key.id, ...key };
        });
    }

    get formattedCalendarEvents(): any[] {
        const events = this.bookingsList.map((booking) => {
            const startDate = moment(booking.startDate).format("YYYY-MM-DD HH:mm:ss");
            const endDate = moment(booking.endDate).format("YYYY-MM-DD HH:mm:ss");
            const relatedKey = this.keys.find((key) => key.id === booking.keyId);
            const relatedUser = this.users.find((user) => user.id === booking.userId) || booking.User;
            return {
                id: booking.id,
                name: `${(this.getUserIdentity(relatedUser))} - ${relatedKey?.name || booking.name || ""}`,
                start: startDate,
                end: endDate,
                color: relatedUser?.color,
                timed: true,
                user: {
                    id: relatedUser?.id,
                    identity: this.getUserIdentity(relatedUser),
                },
                key: {
                    id: relatedKey?.id,
                    name: relatedKey?.name,
                    keyManagers: relatedKey?.keyManagers,
                    keyAccess: relatedKey?.keyAccess,
                    status: relatedKey?.status,
                    guests: relatedKey?.guests,
                },
                bookingName: booking.name,
                createdBy: booking.createdBy,
            };
        });
        return events;
    }

    private mounted(): void {
        this.typeToLabel = {
            month: this.$t("planning.range.month"),
            week:  this.$t("planning.range.week"),
            day:  this.$t("planning.range.day"),
        };
        this.initFilters(this.$route.params.key || null, this.$route.params.userId || null);
        const currentDate = new Date();
        this.startDateResearch = moment(currentDate.setMonth(currentDate.getMonth() - 1)).format();
        this.endDateResearch = moment(currentDate.setMonth(currentDate.getMonth() + 2)).format();
        this.getKeysList();
        if (!this.isDemo) {
            this.getContactAndSubordinateList();
        }
        this.getUserBookings();
    }

    private initFilters(key?, userId?): void {
        this.selectedUsers = userId ? [userId] : (this.isAdmin ? [] : [this.currentUser.id]);
        this.selectedKeys = key ? [key.id] : [];
    }

    private getUserIdentity(user): string {
        return user.displayName || user.phone || user.email || "";
    }

    private getKeysList(): any {
        this.isSearchingKeys = true;
        return this.$store.dispatch("users/getGuestAndManagedKeys", {
            id: this.currentUser.id,
            query: {
                from: this.isAdmin ? null : (this.isB2B ? "B2B" : "B2C"),
            },
        }).then((res) => {
            this.isSearchingKeys = false;
            this.keys = res.keys;
        });
    }

    private async getContactAndSubordinateList(): Promise<any> {
        this.isSearchingUsers = true;
        let res = null;
        if (this.isAdmin) {
            res = await this.$store.dispatch("users/getUsers", {
                id: this.currentUser.id,
            });
        } else {
            res = await this.$store.dispatch("users/getContactsAndSubordinates", {
                id: this.currentUser.id,
            });
        }
        const connectedUser = {
            text: `${this.currentUser.firstName} ${this.currentUser.lastName}`,
            value: this.currentUser.id,
            ...this.currentUser,
        };
        this.isSearchingUsers = false;
        const usersColors = [];
        const usedColors = [];
        return this.users = [...res.users.map((user: any) => {
            const userAlreadyGotColors = usersColors.find((el) => el.itemId === user?.id);
            if (!userAlreadyGotColors) {
                let nextUnusedColor = bookingColors.find((color) => !usedColors.includes(color));
                if (!nextUnusedColor) {
                    nextUnusedColor = bookingColors[Math.floor(Math.random() * bookingColors.length)];
                }
                usersColors.push({
                    itemId: user?.id,
                    color: nextUnusedColor,
                });
                usedColors.push(nextUnusedColor);
                user.color = nextUnusedColor;
            } else {
                user.color = userAlreadyGotColors.color;
            }
            return { text: this.getUserIdentity(user), value: user.id, ...user };
        }), connectedUser];
    }

    private getUserBookings(): any {
        this.userSearch = this.keySearch = "";
        return this.$store.dispatch("users/getUserBookings", {
            id: this.currentUser.id,
            startDate: this.startDateResearch,
            endDate:  this.endDateResearch,
            users: this.selectedUsers,
            keys: this.selectedKeys,
            from: this.isB2B ? "B2B" : "B2C",
        }).then((res) => {
            this.bookingsList = res.bookings;
        });
    }

    private setToday(): void {
        this.searchRequestSend = false;
        this.focus = "";
    }

    private prevIteration(): any {
        return this.$refs.calendar.prev();
    }

    private nextIteration(): any {
        return this.$refs.calendar.next();
    }

    private updateFocus(newVal: string): void {
        this.searchRequestSend = false;
        this.focus = newVal;
    }

    private updateType(newVal: string): void {
        this.type = newVal;
    }

    private openAddReservationModal(item): void {
        this.newBookingStartingDate = item ? item.date : null;
        this.showCreateBookingSelection = true;
    }

    private goToStep2Creation(item): void {
        this.newBookingKey = item.key;
        this.newBookingUser = {
            id: item.user.id,
            identity: this.getUserIdentity(item.user),
            notificationType: item.notificationType,
        };
        this.showCreateBooking = true;
    }

    private updateRange(item): void {
        if (this.searchRequestSend) {
            return;
        }
        const start = item.start?.date;
        const requestStartDate = new Date(start);
        requestStartDate.setHours(0, 0 , 0);
        if (this.type === "month") {
            requestStartDate.setMonth(requestStartDate.getMonth() - 1);
        }
        this.startDateResearch = moment(requestStartDate, "YYYY-MM-DD HH:mm:ss").format("YYYY-MM-DD HH:mm:ss");
        const end = item.end?.date;
        const requestEndDate = new Date(end);
        requestEndDate.setHours(23, 59 , 59);
        if (this.type === "month") {
            requestEndDate.setMonth(requestEndDate.getMonth() + 1);
        }
        this.endDateResearch = moment(requestEndDate, "YYYY-MM-DD HH:mm:ss").format("YYYY-MM-DD HH:mm:ss");
        this.searchRequestSend = true;
        this.getUserBookings();
    }

    private setNewRange(range): void {
        this.type = range;
        this.searchRequestSend = false;
    }

    private successCreation(): void {
        this.getUserBookings();
    }

    private closeCreationModal(): void {
        this.showCreateBooking = false;
        this.bookingEditMode = false;
        this.activeEvent = null;
    }

    private showEvent(event): void {
        this.newBookingStartingDate = null;
        this.bookingEditMode = true;
        this.activeEvent = event;
        this.newBookingKey = event.key;
        this.newBookingUser = event.user;
        this.showCreateBooking = true;
    }

    private deleteBooking(item): void {
        this.bookingToDelete = item?.booking;
        this.confirmRemoval = true;
    }

    private closeDeleteModal(): void {
        this.confirmRemoval = false;
    }

    private removeSuccess(): void {
        this.closeDeleteModal();
        this.getUserBookings();
    }

    private removeItemFromSelectedUser(userToRemove): void {
        this.selectedUsers = this.selectedUsers.filter((userId) => userId !== userToRemove.id);
        this.getUserBookings();
    }
}
</script>