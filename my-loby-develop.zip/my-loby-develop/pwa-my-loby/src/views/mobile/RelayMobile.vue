<template>
    <v-container>
        <v-card
            class="mx-auto mt-10"
            max-width="400"
            v-if="relay"
        >

            <v-card-text class="text--primary">
                <div class="relais_row row no-gutters">
                    <div class="col-md-6 first_col">
                        <div class="details">
                            <div class="row no-gutters">
                                <div class="col-sm-6">
                                    <h6>{{$t('relay.infoLoby.info')}}</h6>
                                    <img
                                        v-if="relay.picturePath"
                                        width="100%"
                                        class="pb-3 pr-5"
                                        style="max-height: 150px; object-fit: contain"
                                        :src="getSrc(relay.picturePath)"
                                    />
                                    <p class="with_key">
                                        <span><i class="icon-picto_relais-agence"></i></span>
                                        <strong>{{relay.name}}</strong>
                                        <br/>{{relay.address}}
                                        <br/>{{relay.zipCode}} {{relay.city}}
                                        <br v-if="relay.phone1"/>
                                        <a v-if="relay.phone1" :href="`tel:${relay.phone1}`" style="color: #0c0733">
                                            <i class="icon-picto_telephone"></i> {{relay.phone1}}
                                        </a>
                                        <br v-if="relay.phone2"/>
                                        <a v-if="relay.phone2" :href="`tel:${relay.phone2}`" style="color: #0c0733">
                                            <i class="icon-picto_telephone"></i> {{relay.phone2}}
                                        </a>
                                        <br v-if="relay.email"/>
                                        <a v-if="relay.email" :href="`mailto:${relay.email}`" style="color: #0c0733">
                                            <i class="icon-picto_courrier"></i> {{relay.email}}
                                        </a>
                                    </p>
                                    <!--                                <span class="reseau"><span><i class="icon-picto_wifi"></i> 4G</span> 3 codes promos en cours</span>-->
                                </div>
                                <div class="col-sm-6">
                                    <relay-schedule
                                        :schedule="relay.companyOpeningHours"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </v-card-text>
            <v-card-actions v-if="relay.itinerary">
                <v-row justify="center">
                    <v-btn
                        :href="relay.itinerary"
                        target="_blank"
                        color="warning"
                        outlined
                    >
                        {{$t('relay.goTo')}}
                    </v-btn>
                </v-row>
            </v-card-actions>
        </v-card>
    </v-container>
</template>
<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";
import router from "@/router";
import RelaySchedule from "@/components/relays/RelaySchedule.vue";
import { Getter } from "vuex-class";
import {getSrc} from "@/utils/misc";

const openingHoursFieldDayFn = () => ({
    isActive: true,
    continuous: {
        isActive: true,
        fromHours: "09:00",
        toHours: "18:00",
    },
    morning: {
        isActive: false,
        fromHours: "00:20",
        toHours: "00:00",
    },
    evening: {
        isActive: false,
        fromHours: "00:20",
        toHours: "00:00",
    },
});

@Component({
    components: {
        RelaySchedule,
    },
})
export default class Relay extends Vue {
    @Getter private currentUser: any;
    private relay: any = null;
    private referents: object[] = [];
    private tab: string = "myRelay";
    private logs: any = [];
    private hasEditRight: boolean = false;
    private insuranceCompanies: any[] = [];
    private searchInsuranceCompanies: string = "";
    private relayKeysStats: any[] = [];
    private getSrc: (string) => string = getSrc;

    get redirection() {
        switch (this.relay?.type) {
            case "AGENCY" :
                return "admin-relays-agency";
            case "FLOW":
                return "admin-relays-flow";
            case "LONG_TERM":
                return "admin-relays-long-term";
        }
    }

    private mounted() {
        this.reset();
    }

    private reset() {
        if (this.$route.params.id) {
            this.getRelay(this.$route.params.id);
        }
    }

    get isAgency(): boolean {
        return this.relay?.type === "AGENCY";
    }

    get isFlow(): boolean {
        return this.relay?.type === "FLOW";
    }

    get isLongTerm(): boolean {
        return this.relay?.type === "LONG_TERM";
    }

    private getRelay(id) {
        if (this.relay) {
            this.relay.picturePath = null;
        }
        this.$store.dispatch("relays/getById", {id})
            .then((relay) => {
                this.relay = relay;
            }).catch(() => router.push({name: "home"}));
    }
}
</script>
