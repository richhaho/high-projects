<template>
    <v-container>
        <v-row>
            <v-col cols="10">
                <address-geo
                    class="mobile-address-input"
                    :mobile="true"
                    :relay-map="true"
                    v-bind:latitude.sync="addressSearch.latitude"
                    v-bind:longitude.sync="addressSearch.longitude"
                    :label="$t('actions.searchAddress')"
                ></address-geo>
            </v-col>
            <v-col cols="2" class="m-header-btn">
                <div class="m-btn-round" @click.prevent="mapDisplayedFn()" >
                    <v-icon v-if="!mapDisplayed">map</v-icon>
                    <v-icon v-if="mapDisplayed">list</v-icon>
                </div>
            </v-col>
        </v-row>
        <v-row v-show="mapDisplayed">
            <v-col class="map-size">
                <!--map here-->
                <l-map  ref="map" :zoom="zoom" :center="center">
                    <l-tile-layer :url="url"></l-tile-layer>
                    <l-marker v-for="(relay) in mapableRelay"
                              :lat-lng="getLatLng(relay.latitude, relay.longitude)">
                        <l-popup>
                            <div>
                                <h4>{{relay.name}}</h4>
                                {{relay.address}}
                            </div>
                        </l-popup>

                    </l-marker>

                </l-map>
            </v-col>
        </v-row>
        <v-row v-show="!mapDisplayed" id="relay-list">
            <v-list three-line width="100%">
                <v-subheader
                    v-text="$t('relay.myRelays')"
                ></v-subheader>
                <template v-for="(relay, index) in displayedRelays">
                    <v-col class="pa-0">
                        <v-list-item>
                            <v-list-item-avatar class="map-item-avatar">
                                <i class="icon-picto_relais-agence"></i>
                            </v-list-item-avatar>

                            <v-list-item-content class="pa-0">
                                <v-list-item-title v-html="relay.name"></v-list-item-title>
                                <v-list-item-subtitle v-if="isB2B">
                                    <v-chip v-if="relay.type === 'AGENCY'"
                                            x-small chip
                                            color="#070a33"
                                            text-color="white"
                                    >
                                        {{$t("relaysMap.agencyRelay")}}
                                    </v-chip>
                                    <v-chip v-if="relay.type === 'FLOW'"
                                            x-small chip
                                            color="#070a33"
                                            outlined
                                    >
                                        {{$t('relaysMap.flowRelay')}}
                                    </v-chip>
                                </v-list-item-subtitle>
                                <v-list-item-subtitle class="map-item-address">
                                    {{relay.address}}
                                    <br/>
                                    {{relay.zipCode}} {{relay.city}}
                                </v-list-item-subtitle>
                                <div class="mt-2">
                                    <v-btn
                                        v-if="relay.distance && hasSearchAddress"
                                        class="v-btn--active text-none mb-2"
                                        color="green"
                                        rounded
                                        text
                                        x-small
                                    >
                                        <v-icon left x-small>near_me</v-icon>
                                        {{displayDistance(relay.distance)}}
                                    </v-btn>
                                </div>
                                <relay-closed
                                    :closures="relay.exceptionalClosures"
                                    messagePath="relay.currentlyClosed"
                                    :mobile="true"
                                ></relay-closed>
                            </v-list-item-content>

                            <v-list-item-icon class="map-item-icon">
                                <router-link
                                    :to="{name: 'relay', params: {id: relay.id}}">
                                    <v-icon class="arrow_forward_ios">arrow_forward_ios</v-icon>
                                </router-link>

                            </v-list-item-icon>
                        </v-list-item>
                    </v-col>
                    <v-divider v-if="index < relays.length - 1"/>
                </template>
            </v-list>
        </v-row>
    </v-container>
</template>
<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";
import {LMap, LMarker, LPopup, LTileLayer} from "vue2-leaflet";
import RelayClosed from "@/components/relays/RelayClosed.vue";
declare var L: any;

/*MAP*/
import { Icon } from "leaflet";
import "leaflet/dist/leaflet.css";
import {Getter} from "vuex-class";
import AddressGeo from "@/components/AddressGeo.vue";

delete (Icon as any).Default.prototype._getIconUrl;
Icon.Default.mergeOptions({
    iconUrl: require("./../../../public/img/marker-icon.png"),
    shadowUrl: require("./../../../public/img/marker-icon.png"),
    iconSize: [20, 20],
    shadowSize: [20, 20],
});
/*END MAP*/

@Component({
    components: {
        LMap,
        LTileLayer,
        LMarker,
        LPopup,
        AddressGeo,
        RelayClosed,
    },
})
export default class RelaysMobileMap extends Vue {
    @Getter private isB2B: boolean;
    private relays: any = [];
    private zoom = 5;
    private search = "";
    private center = L.latLng(46.227638, 2.213749);
    private url = "http://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png";
    private mapDisplayed = true;
    private addressSearch: any = {
        longitude: "",
        latitude: "",
    };
    private hasSearchAddress: boolean = false;
    private isLoading: boolean = true;
    private pagination: any = {
       itemsPerPage: 5,
       totalItems: 0,
    };

    get mapableRelay() {
        return this.relays.filter((r: any) => r.longitude && r.latitude);
    }

    get displayedRelays() {
        return this.relays.slice(0, this.pagination.itemsPerPage);
    }

    @Watch("addressSearch", {deep: true})
    private async searchHandler() {
        if (this.addressSearch.latitude && this.addressSearch.longitude) {
            this.hasSearchAddress = true;
            this.getRelaysDistance();
            await (this.$refs.map as any)?.mapObject.setView(
                this.getLatLng(this.addressSearch.latitude, this.addressSearch.longitude), 13);
        } else {
            this.hasSearchAddress = false;
            this.sortRelays();
        }
    }

    private mounted() {
        this.scroll();
        this.getListRelays();
    }

    private getLatLng(latitude, longitude) {
        return L.latLng(latitude, longitude);
    }

    private  mapDisplayedFn() {
        this.mapDisplayed = ! this.mapDisplayed;
        if (this.mapDisplayed) {
            setTimeout(function() { window.dispatchEvent(new Event("resize")); });
        }
    }

    private getListRelays() {
        return this.$store.dispatch("relays/getForMap", {
            search: this.search,
        }).then((data) => {
            this.relays = data.relays;
            this.pagination.totalItems = data.count;
            this.isLoading = false;
            setTimeout(function() { window.dispatchEvent(new Event("resize")); });

        });
    }

    private getDistance(lat1, lon1, lat2, lon2) {
        const R = 6371;
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180 ) * Math.cos(lat2 * Math.PI / 180 ) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const d = R * c;
        return d;
    }

    private displayDistance(d) {
        if (d > 1) { return Math.round(d) + "km"; } else if (d <= 1) { return Math.round(d * 1000) + "m"; }
        return d;
    }

    private getRelayDistance(relay) {
        if (this.addressSearch.latitude && this.addressSearch.longitude) {
            return this.getDistance(this.addressSearch.latitude, this.addressSearch.longitude,
                relay.latitude, relay.longitude );
        }
        return null;
    }

    private async getRelaysDistance() {
        this.relays = await this.relays.map((r) => {
            r.distance = this.getRelayDistance(r);
            return r;
        });
        this.sortRelays();
    }

    private sortRelays() {
        if (this.hasSearchAddress) {
            this.relays = this.relays.sort(this.compareRelay("distance"));
        } else {
            this.relays = this.relays.sort(this.compareRelay("name"));
        }
    }

    private compareRelay(prop) {
        return (a, b) => {
            if ( a[prop] < b[prop] ) {
                return -1;
            }
            if ( a[prop] > b[prop] ) {
                return 1;
            }
            return 0;
        };
    }

    private scroll() {
        window.onscroll = () => {
            const listElm = document.querySelector("#relay-list");
            if (listElm?.clientHeight <= (document.documentElement.scrollTop + window.innerHeight + 100)
                && !this.isLoading) {
                if (this.pagination.itemsPerPage < this.pagination.totalItems) {
                    this.pagination.itemsPerPage += 5;
                }
            }
        };
    }
}
</script>
