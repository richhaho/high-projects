<template>
    <v-container class="m-user-page pb-0">
        <v-row>
            <v-progress-circular
                v-if="isLoading"
                style="margin: 10px auto 0 auto"
                :width="3"
                color="rgba(0,0,0,.06)"
                indeterminate
            ></v-progress-circular>
        </v-row>
        <v-row v-if="!isLoading" align="center" justify="space-between" class="p-3 font-weight-bold">
            <router-link class="action" :to="{name: 'contacts'}" :title="$t('nav.my_contacts')">
                <i class="icon-picto_retour_orange"></i>
                {{$t('nav.my_contacts')}}
            </router-link>
            <edit-user
                :user="user"
                :can-edit-profile="canEditProfile"
                :is-mobile="true"
                :default-user-avatar="defaultUserAvatar"
                @user-updated="reset"
            ></edit-user>
        </v-row>
        <v-row justify="center" class="bg-white content-height" v-if="!isLoading">
            <div class="text-center">
                <img :src="getSrc(user.picturePath) || defaultUserAvatar" :alt="user.displayName"
                     class="user-profile-image mt-5">
                <h4 class="title font-weight-bold mt-3 title-color">{{user.displayName}}</h4>
                <br>
                <div class="title-color">
                    <p v-if="user.email">
                        <i class="icon-picto_courrier mr-2"></i>
                        {{user.email}}</p>
                    <p v-if="user.phone">
                        <i class="icon-picto_telephone mr-2"></i>
                        {{user.phone}}
                    </p>
                </div>
            </div>
        </v-row>
    </v-container>
</template>
<script lang="ts">
import {Component, Vue} from "vue-property-decorator";
import {Getter} from "vuex-class";
import {defaultUserAvatar} from "@/utils/constants";
import EditUser from "@/components/users/EditUser.vue";
import {getSrc} from "@/utils/misc";

@Component({
    components: {
        EditUser,
    },
})
export default class UserMobile extends Vue {
    @Getter private currentUser: any;
    private user: any = null;
    private userId: number = null;
    private defaultUserAvatar: string = defaultUserAvatar;
    private isLoading: boolean = true;
    private getSrc: (string) => string = getSrc;

    get isMyPage() {
        return this.currentUser.id === this.user.id;
    }

    get canEditProfile() {
        // Only if this is the current user's page, or the current user is Admin
        return this.user.id === this.currentUser.id || this.currentUser.isAdmin;
    }

    private mounted() {
        this.reset();
    }

    private reset() {
        this.userId = Number(this.$route.params.id);
        this.getUserById();
    }

    private getUserById() {
        this.isLoading = true;
        return this.$store.dispatch("users/getUserById", {
            id: this.userId,
            options: {
                logs: true,
                masterOf: true,
                company: true,
            },
        }).then((user) => {
            this.user = user;
            this.isLoading = false;
        }).catch((err) => {
            this.$store.commit("alerts/displayError", {
                msg: err,
            });
            this.isLoading = false;
        });
    }
}
</script>