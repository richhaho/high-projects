<template>
    <v-container class="m-users-page infinite-wrapper">
        <v-row align="center">
            <v-col>
                <v-text-field
                    class="mobile-search"
                    :label="$t('actions.search')"
                    filled
                    rounded
                    dense
                    hide-details
                    single-line
                    append-icon="search"
                    v-model="pagination.search"
                    @input="searchHandler"
                ></v-text-field>
            </v-col>
            <v-col :cols="2" v-if="currentTab === 'contacts'">
                <add-contact
                    :is-mobile="true"
                    @reset="reset()"
                />
            </v-col>
            <v-col :cols="2" v-else-if="currentTab === 'management'">
                <add-subordinate
                    :is-mobile="true"
                    @reset="reset()"
                />
            </v-col>
        </v-row>
        <v-row>
            <div class="onglets_row">
                <a
                    v-if="!isDemo"
                    :style="!isMaster() ? {'flex-basis': '100%'} : ''"
                    @click.prevent="changeTab('contacts')"
                    :title="$t('contacts.contacts')"
                    :class="{active: currentTab === 'contacts'}"
                >
                    <div class="onglet">{{$t('contacts.contacts')}}</div>
                </a>
                <a
                    v-if="isMaster()"
                    :style="isDemo ? {'flex-basis': '100%'} : ''"
                    @click.prevent="changeTab('management')"
                    :class="{active: currentTab === 'management'}"
                    :title="$t('contacts.management')"
                >
                    <div class="onglet">{{$t('contacts.management')}}</div>
                </a>
            </div>
        </v-row>
        <v-row id="users-list">
            <v-list three-line width="100%" v-if="users.length" class="pa-0">
                <template v-for="(user, index) in users">
                    <router-link :to="{name: 'user', params: {id: user.id}}">
                        <v-list-item>
                            <v-list-item-avatar :size="70">
                                <img
                                    :src="getSrc(user.picturePath) || defaultUserAvatar"
                                    alt="userPicture"
                                />
                            </v-list-item-avatar>

                            <v-list-item-content>
                                <v-list-item-title class="font-weight-black title-color"
                                                   v-html="user.displayName"></v-list-item-title>
                                <v-list-item-subtitle class="title-color subtitle"
                                                      v-html="`${user.email || ''}<br>${user.phone || ''}`"></v-list-item-subtitle>
                            </v-list-item-content>
                        </v-list-item>
                    </router-link>
                    <v-divider
                        :inset="false"
                    ></v-divider>
                </template>
            </v-list>
            <v-col class="subtitle-1 font-weight-medium  justify-center" v-if="!users.length && !loading"><p
                class="text-center">
                {{$t('title.noData')}}</p></v-col>
        </v-row>
        <v-row v-if="loading">
            <v-progress-circular
                style="margin: 10px auto 0 auto"
                :width="3"
                color="rgba(0,0,0,.06)"
                indeterminate
            ></v-progress-circular>
        </v-row>
    </v-container>
</template>
<script lang="ts">
import {Component, Vue} from "vue-property-decorator";
import {defaultUserAvatar} from "@/utils/constants";
import {Getter} from "vuex-class";
import AddContact from "@/components/users/AddContact.vue";
import AddSubordinate from "@/components/users/AddSubordinate.vue";
import {getSrc} from "@/utils/misc";
import Timeout = NodeJS.Timeout;

export const DEBOUNCE_TIME_MILLI: number = 500;

@Component({
    components: {
        AddContact,
        AddSubordinate,
    },
})
export default class UsersMobile extends Vue {
    @Getter private isMaster: (type?: string) => boolean;
    @Getter private isDemo: boolean;
    private connectedUser: object = {};
    private defaultUserAvatar: string = defaultUserAvatar;
    private getSrc: (string) => string = getSrc;
    private users: object[] = [];
    private loading: boolean = false;
    private timerId: Timeout = null;
    private pagination: any = {
        sortDesc: [false],
        sortBy: [""],
        search: "",
        page: 1,
        itemsPerPage: 10,
        totalItems: 10,
        loaded: false,
    };
    private currentTab: string = "contacts";

    private mounted() {
        this.reset();
        this.scroll();
        this.connectedUser = this.$store.state.currentUser;
    }

    private changeTab(tab) {
        this.pagination = {
            sortDesc: [false],
            sortBy: [""],
            search: "",
            page: 1,
            itemsPerPage: 10,
            totalItems: 10,
            loaded: false,
        };
        this.users = [];
        this.currentTab = tab;
        this.reset();
    }

    private searchHandler(): void {
        this.loading = true;
        this.users = [];
        // cancel pending call
        clearTimeout(this.timerId);
        // delay new call
        this.timerId = setTimeout(() => {
            this.reset();
        }, DEBOUNCE_TIME_MILLI);
    }

    private reset() {
        this.pagination.page = 1;
        this.pagination.loaded = false;
        this.loading = true;
        this.users = [];
        this.fetchData(this.pagination).then((res) => {
            res.users.forEach((user) => {
                if (typeof user === "object" && user !== null) {
                    this.users.push(user);
                }
            });
            this.pagination.totalItems = res.count;
            this.loading = false;
        });
    }

    private fetchData(query): Promise<any> {
        let action;
        if (this.currentTab === "contacts") {
            action = "users/getContacts";
            return this.executeAction(query, action);
        } else if (this.currentTab === "management") {
            action = "users/getSubordinates";
            return this.executeAction(query, action);
        } else {
            return Promise.reject();
        }
    }

    private executeAction(query, action) {
        return this.$store.dispatch(action, {query}).then((res) => {
            return res;
        });
    }

    private scroll() {
        window.onscroll = () => {
            const listElm = document.querySelector("#users-list");
            if (listElm?.clientHeight <= (document.documentElement.scrollTop + window.innerHeight + 100)
                && !this.loading && !this.pagination.loaded) {
                if (this.pagination.totalItems > this.pagination.itemsPerPage) {
                    this.pagination.page += 1;
                    this.loading = true;
                    this.fetchData(this.pagination).then((res) => {
                        if (res.users.length) {
                            res.users.forEach((user) => {
                                if (typeof user === "object" && user !== null) {
                                    this.users.push(user);
                                }
                            });
                        } else {
                            this.pagination.loaded = true;
                        }
                        this.loading = false;
                    });
                }
            }
        };
    }

}
</script>