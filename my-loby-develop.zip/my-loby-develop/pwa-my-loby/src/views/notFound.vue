<template>
    <section class="section">
        <v-container>
            <v-row justify="center">
                <v-col align="center" xl="2" lg="4" md="5" sm="6">
                    404
                </v-col>
            </v-row>
        </v-container>
    </section>
</template>

<script lang="ts">
  import {Vue, Component} from "vue-property-decorator";

  @Component
  export default class NotFound extends Vue {}
</script>
