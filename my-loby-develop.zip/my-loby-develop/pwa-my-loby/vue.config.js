module.exports = {
  "transpileDependencies": [
    "vuetify"
  ],
  devServer: {
    public: process.env.VUE_APP_URL,
    disableHostCheck: true
  },
  pwa: {
    name: 'MyLoby',
    short_name: "MyLoby",
    themeColor: '#FFFFFF',
    msTileColor : '#ff4119',
    appleMobileWebAppCapable: 'yes',
    appleMobileWebAppStatusBarStyle: 'black',
    workboxOptions: {
      skipWaiting: true
    },
    manifestOptions : {
      name: "MyLoby",
      short_name: "MyLoby",
      themeColor: '#FFFFFF',
      msTileColor : '#ff4119'
    },
    iconPaths : {
      favicon32: 'img/icons/favicon-32x32.png',
      favicon16: 'img/icons/favicon-16x16.png',
      appleTouchIcon: 'img/icons/apple-touch-icon.png',
      maskIcon: 'img/icons/safari-pinned-tab.svg',
      msTileImage: 'img/icons/mstile-150x150.png'
    }
  },
}