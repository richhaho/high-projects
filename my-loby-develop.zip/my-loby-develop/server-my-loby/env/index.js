let dotenv = require('dotenv');
const result2 = dotenv.config(
    {path: `./env/${process.env.ENV_FILE || 'development'}.env`});
if (result2.error) {
  throw result2.error;
}
