'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'companies',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        type: {
          type: DataTypes.ENUM({
            values: ["INSURANCE", "B2B"],
          }),
          allowNull: false,
        },
        activitySector: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        name: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        siret: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        siren: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        color: {
          type: DataTypes.STRING,
          defaultValue: "hsl(360, 50%, 50%)",
        },
        invoicingMail: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        blockedAt: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      }
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('companies')
  },
}