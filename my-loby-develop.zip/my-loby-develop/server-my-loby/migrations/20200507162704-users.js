'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'users',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        companyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'companies',
            key: 'id',
            allowNull: true,
          }
        },
        backupId: {
          type: DataTypes.INTEGER.UNSIGNED,
        },
        firstName: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        lastName: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        username: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        picturePath: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        email: {
          type: DataTypes.STRING,
          allowNull: false,
          unique: true,
        },
        job: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        city: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        phone: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        color: {
          type: DataTypes.STRING,
          defaultValue: 'hsl(180, 50%, 50%)',
        },
        password: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        isAdmin: {
          type: DataTypes.BOOLEAN,
          defaultValue: false,
        },
        isDemo: {
          type: DataTypes.BOOLEAN,
          defaultValue: false,
        },
        activatedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        lastLoginAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        cguAcceptedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      }
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('users')
  },
}