'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'plans',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        type: {
          type: DataTypes.ENUM({
            values: ["INSURANCE", "B2B", "B2C"],
          }),
          allowNull: false,
        },
        name: {
          type: DataTypes.ENUM({
            values: ["FREE", "BASIC", "STANDARD", "PREMIUM", "INSURANCE", "PUNCTUAL"],
          }),
          allowNull: false,
        },
        monthlyPrice: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
        yearlyPrice: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
        details: {
          type: DataTypes.JSON,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      }
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('plans')
  },
}