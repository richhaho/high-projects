'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'payment_method',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        userId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'users',
            key: 'id'
          },
          allowNull: true,
        },
        payzenToken: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        cardNumber: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        expirationDate: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        effectiveBrand: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        status: {
          type: DataTypes.ENUM({
            values: ["CREATED", "SUCCESS", "ERROR"],
          }),
          allowNull: false,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      }
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('payment_method')
  },
}