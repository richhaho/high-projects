'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'users_group',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
        },
        userId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'users',
            key: 'id'
          },
          allowNull: false,
        },
        groupId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'groups',
            key: 'id'
          },
          allowNull: false,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
      }
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('users_group')
  },
}