'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'management',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        managerId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'users',
            key: 'id'
          },
          allowNull: true,
        },
        subordinateId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'users',
            key: 'id'
          },
          allowNull: false,
        },
        companyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'companies',
            key: 'id'
          },
          allowNull: true,
        },
        type: {
          type: DataTypes.ENUM({
            values: ["MASTER"],
          }),
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      }
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('management')
  },
}