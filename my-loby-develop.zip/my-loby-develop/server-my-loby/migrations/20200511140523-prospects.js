'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'prospects',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        type: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        gender: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        lastName: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        firstName: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        company: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        job: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        activitySector: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        address: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        city: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        zipCode: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        country: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        phone: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        email: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        request: {
          type: DataTypes.TEXT,
          allowNull: true,
        },
        legal: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        companyName: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        companyType: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        companyAddress: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        companyPhone1: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        companyPhone2: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        companyEmail: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        companyZipCode: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        companyCity: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        companyCountry: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        companySiret: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        companyOpeningHours: {
          type: DataTypes.JSON,
          allowNull: true,
        },
        validationDate: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        startTestPeriodDate: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        endTestPeriodDate: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        declinationDate: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        rejectionCause: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
      }
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('prospects')
  },
}