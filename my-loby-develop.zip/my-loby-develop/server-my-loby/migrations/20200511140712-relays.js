'use strict';

module.exports = {
  up: (migration, DataTypes) => {
    return migration.createTable(
      'relays',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
        },
        backupId: {
          type: DataTypes.INTEGER.UNSIGNED,
        },
        name: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        type: {
          type: DataTypes.ENUM({
            values: ['FLOW', 'AGENCY', 'LONG_TERM'],
          }),
          allowNull: false,
        },
        address: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        addressdisplayname: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        city: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        country: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        zipCode: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        latitude: {
          type: DataTypes.FLOAT,
          allowNull: true,
        },
        longitude: {
          type: DataTypes.FLOAT,
          allowNull: true,
        },
        siret: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        email: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        phone1: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        phone2: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        keys: {
          type: DataTypes.INTEGER,
          defaultValue: 0,
        },
        keysRange: {
          type: DataTypes.INTEGER,
          defaultValue: 0,
        },
        sealedKeys: {
          type: DataTypes.INTEGER,
          defaultValue: 0,
        },
        dropFee: {
          type: DataTypes.FLOAT,
          defaultValue: 0.5,
        },
        withdrawFee: {
          type: DataTypes.FLOAT,
          defaultValue: 4,
        },
        floorSpaceFee: {
          type: DataTypes.FLOAT,
          defaultValue: 100,
        },
        companyOpeningHours: {
          type: DataTypes.JSON,
          allowNull: true,
        },
        exceptionalClosures: {
          type: DataTypes.JSON,
          allowNull: true,
        },
        isTransitAuthorized: {
          type: DataTypes.BOOLEAN,
          defaultValue: true,
        },
        activatedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        status: {
          type: DataTypes.INTEGER,
          defaultValue: 0,
        },
        iban: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        bankHolder: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        picturePath: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        companyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: true,
          references: {
            model: 'companies',
            key: 'id'
          },
        },
      },
    );
  },

  down: (migration, DataTypes) => {
    return migration.dropTable('relays');
  },
};
