'use strict';

module.exports = {
  up: (migration, DataTypes) => {
    return migration.createTable(
      'boxes',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
        },
        number: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
        sheets: {
          type: DataTypes.INTEGER,
          defaultValue: 0,
        },
        columns: {
          type: DataTypes.INTEGER,
          defaultValue: 0,
        },
        lines: {
          type: DataTypes.INTEGER,
          defaultValue: 0,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        relayId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: true,
          references: {
            model: 'relays',
            key: 'id'
          },
        },
      },
    );
  },

  down: (migration, DataTypes) => {
    return migration.dropTable('boxes');
  },
};
