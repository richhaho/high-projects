'use strict';

module.exports = {
  up: (migration, DataTypes) => {
    return migration.createTable(
      'keys',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
        },
        backupId: {
          type: DataTypes.INTEGER.UNSIGNED,
        },
        name: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        description: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        status: {
          type: DataTypes.ENUM({
            values: ["CREATED", "IN_RELAY", "WITH_SOMEBODY", "LATE", "IN_TRANSIT", "PENDING_CREATION", "ARCHIVED"],
          }),
          allowNull: false,
        },
        picturePath: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        archivedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        hasAllRights: {
          type: DataTypes.BOOLEAN,
          defaultValue: false,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        ownerId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: true,
          references: {
            model: 'users',
            key: 'id'
          },
        },
      },
    );
  },

  down: (migration, DataTypes) => {
    return migration.dropTable('keys');
  },
};
