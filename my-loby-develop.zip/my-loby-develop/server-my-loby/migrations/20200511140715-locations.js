'use strict';

module.exports = {
  up: (migration, DataTypes) => {
    return migration.createTable(
      'locations',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
        },
        boxNumber: {
          type: DataTypes.INTEGER,
          allowNull: true,
        },
        sheet: {
          type: DataTypes.INTEGER,
          allowNull: true,
        },
        column: {
          type: DataTypes.INTEGER,
          allowNull: true,
        },
        line: {
          type: DataTypes.INTEGER,
          allowNull: true,
        },
        codeName: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        qrCode: {
          type: DataTypes.TEXT,
          allowNull: true,
        },
        token: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        reservedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        boxId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: true,
          references: {
            model: 'boxes',
            key: 'id'
          },
        },
        keyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: true,
          references: {
            model: 'keys',
            key: 'id'
          },
        },
        companyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: true,
          references: {
            model: 'companies',
            key: 'id'
          },
        },
      },
    );
  },

  down: (migration, DataTypes) => {
    return migration.dropTable('locations');
  },
};
