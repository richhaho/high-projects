'use strict';

module.exports = {
  up: (migration, DataTypes) => {
    return migration.createTable(
      'tags',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
        },
        en: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        fr: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        pt: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      },
    );
  },

  down: (migration, DataTypes) => {
    return migration.dropTable('tags');
  },
};
