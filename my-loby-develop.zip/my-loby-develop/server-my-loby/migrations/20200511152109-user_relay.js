'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'user_relay',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,

        },
        userId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'users',
            key: 'id'
          },
          allowNull: true,
        },
        relayId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'relays',
            key: 'id'
          },
          allowNull: true,
        },
        isOwner: {
          type: DataTypes.BOOLEAN,
          defaultValue: false,
        },
        pin: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
      }
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('user_relay')
  },
}