'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'subscriptions',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,

        },
        userId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'users',
            key: 'id'
          },
          allowNull: true,
        },
        keyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'keys',
            key: 'id'
          },
          allowNull: true,
        },
        companyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'companies',
            key: 'id'
          },
          allowNull: true,
        },
        planId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'plans',
            key: 'id'
          },
          allowNull: true,
        },
        paymentMethodId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'payment_method',
            key: 'id'
          },
          allowNull: true,
        },
        startDate: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        endDate: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        payzenSubscriptionId: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        anniversaryDate: {
          type: DataTypes.INTEGER,
          allowNull: true,
        },
        paymentPeriodicity: {
          type: DataTypes.ENUM({
            values: ["MONTHLY", "YEARLY"],
          }),
          allowNull: false,
          defaultValue: "MONTHLY",
        },
        status: {
          type: DataTypes.ENUM({
            values: ["CREATED", "SUCCESS"],
          }),
          allowNull: false,
          defaultValue: "CREATED",
        },
        details: {
          type: DataTypes.JSON,
          allowNull: true,
        },
        chargedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      }
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('subscriptions')
  },
}