'use strict';

module.exports = {
  up: (migration, DataTypes) => {
    return migration.createTable(
      'key_access',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
        },
        grantedById: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: false,
        },
        countAccessLeft: {
          type: DataTypes.INTEGER,
          allowNull: false,
          defaultValue: 1,
        },
        startDate: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        endDate: {
          type: DataTypes.DATE,
          defaultValue: null,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        keyGroupId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: true,
          references: {
            model: 'groups',
            key: 'id'
          },
        },
        userGroupId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: true,
          references: {
            model: 'groups',
            key: 'id'
          },
        },
        keyManagementId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: true,
          references: {
            model: 'key_management',
            key: 'id'
          },
        },
      },
    );
  },

  down: (migration, DataTypes) => {
    return migration.dropTable('key_access');
  },
};
