'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'payments',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        subscriptionId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'subscriptions',
            key: 'id'
          },
          allowNull: true,
        },
        amount: {
          type: DataTypes.FLOAT,
          allowNull: true,
        },
        formAction: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        currency: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        orderId: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        status: {
          type: DataTypes.ENUM({
            values: ["CREATED", "PAID", "ERROR"],
          }),
          allowNull: false,
        },
        payzenUuid: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      }
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('payments')
  },
}