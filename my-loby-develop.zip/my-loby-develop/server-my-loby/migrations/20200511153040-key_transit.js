'use strict';

module.exports = {
  up: (migration, DataTypes) => {
    return migration.createTable(
      'key_transit',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
        },
        startDate: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        endDate: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        type: {
          type: DataTypes.ENUM({
            values: ["POSTAL_BOX", "MAILING"],
          }),
          allowNull: false,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        keyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: true,
          references: {
            model: 'keys',
            key: 'id'
          },
        },
        targetRelayId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: true,
          references: {
            model: 'relays',
            key: 'id'
          },
        },
        sourceUserId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: true,
          references: {
            model: 'users',
            key: 'id'
          },
        },
      },
    );
  },

  down: (migration, DataTypes) => {
    return migration.dropTable('key_transit');
  },
};
