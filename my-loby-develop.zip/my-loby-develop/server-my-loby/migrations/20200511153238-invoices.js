'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'invoices',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        relayId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'relays',
            key: 'id'
          },
          allowNull: true,
        },
        companyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'companies',
            key: 'id'
          },
          allowNull: true,
        },
        status: {
          type: DataTypes.ENUM({
            values: ["CREATED", "LATE", "PAID"],
          }),
          allowNull: true,
        },
        invoiceNumber: {
          type: DataTypes.STRING,
          allowNull: true,
          unique: true,
        },
        customerInvoiceNumber: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        label: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        startDate: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        endDate: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        dueDate: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        details: {
          type: DataTypes.JSON,
          allowNull: true,
        },
        tva: {
          type: DataTypes.FLOAT,
          allowNull: true,
        },
        legalNotice: {
          type: DataTypes.TEXT,
          allowNull: true,
        },
        totalPriceHT: {
          type: DataTypes.FLOAT,
          allowNull: true,
        },
        totalPrice: {
          type: DataTypes.FLOAT,
          allowNull: true,
        },
        pdfPath: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      }
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('invoices')
  },
}