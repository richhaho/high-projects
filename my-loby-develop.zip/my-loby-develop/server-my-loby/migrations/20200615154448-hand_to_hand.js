'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.dropTable('hand_to_hand')
  },
  down: function (migration, DataTypes) {
    return migration.createTable(
      'hand_to_hand',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        keyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'keys',
            key: 'id'
          },
          allowNull: true,
        },
        sourceUserId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'users',
            key: 'id'
          },
          allowNull: true,
        },
        targetUserId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'users',
            key: 'id'
          },
          allowNull: true,
        },
        qrCode: {
          type: DataTypes.TEXT,
          allowNull: true,
        },
        pin: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        token: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      }
    )
  },
}