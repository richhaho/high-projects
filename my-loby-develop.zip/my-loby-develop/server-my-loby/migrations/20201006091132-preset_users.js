'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'preset_users',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        groupId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'groups',
            key: 'id'
          },
          allowNull: true,
        },
        relayId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'relays',
            key: 'id'
          },
          allowNull: true,
        },
        role: {
          type: DataTypes.ENUM({
            values: ["GUEST", "MANAGER"],
          }),
          allowNull: false,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
      }
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('preset_users')
  },
}
