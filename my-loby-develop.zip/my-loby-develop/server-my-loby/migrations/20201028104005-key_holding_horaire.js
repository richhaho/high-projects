'use strict';

module.exports = {
  up: (queryInterface, DataTypes) => {
    return Promise.all([
      queryInterface.addColumn('key_holding', 'estimatedEndDate', {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null,
      }),
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn('key_holding', 'estimatedEndDate'),
    ]);
  }
};
