'use strict'
module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'sms',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        mailjetId: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        status: {
          type: DataTypes.ENUM({
            values: ["CREATED", "SENT", "ERROR"],
          }),
          allowNull: false,
        },
        userId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'users',
            key: 'id'
          },
          allowNull: false,
        },
        keyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'keys',
            key: 'id'
          },
          allowNull: false,
        },
        companyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'companies',
            key: 'id'
          },
          allowNull: true,
        },
        subscriptionId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'subscriptions',
            key: 'id'
          },
          allowNull: false,
        },
        price: {
          type: DataTypes.FLOAT,
          allowNull: false,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      },
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('sms')
  },
}