'use strict';

module.exports = {
  up: (migration, DataTypes) => {
    return migration.createTable(
      'short_urls',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        token: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        url: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      },
    );
  },

  down: (migration, DataTypes) => {
    return migration.dropTable('short_urls');
  },
};
