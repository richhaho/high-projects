'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn('sms', 'keyId', {
        type: Sequelize.INTEGER.UNSIGNED,
        allowNull: true,
      }),
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn('sms', 'keyId', {
        type: Sequelize.INTEGER.UNSIGNED,
        references: {
          model: 'keys',
          key: 'id'
        },
        allowNull: false,
      }),
    ]);
  }
};
