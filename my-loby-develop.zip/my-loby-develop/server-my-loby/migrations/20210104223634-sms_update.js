'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn('sms', 'price', {
        type: Sequelize.FLOAT,
        allowNull: true,
      }),
      queryInterface.addColumn('sms', 'mailjetPrice', {
        type: Sequelize.FLOAT,
        allowNull: true,
      }),
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn('sms', 'price', {
        type: Sequelize.FLOAT,
        allowNull: false,
      }),
      queryInterface.removeColumn('sms', 'mailjetPrice'),
    ]);
  }
};
