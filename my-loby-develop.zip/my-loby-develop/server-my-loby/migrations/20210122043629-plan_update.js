'use strict';

module.exports = {
  up: (queryInterface, DataTypes) => {
    return Promise.all([
      queryInterface.changeColumn('plans', 'name', {
        type: DataTypes.ENUM({
          values: ["FREE", "BASIC", "STANDARD", "PREMIUM", "INSURANCE", "PUNCTUAL", "CONNECTED_BOXES"],
        }),
        allowNull: false,
      }),
    ]);
  },

  down: (queryInterface, DataTypes) => {
    return Promise.all([
      queryInterface.changeColumn('plans', 'name', {
        type: DataTypes.ENUM({
          values: ["FREE", "BASIC", "STANDARD", "PREMIUM", "INSURANCE", "PUNCTUAL"],
        }),
        allowNull: false,
      }),
    ]);
  }
};
