'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn('companies', 'blockedAt', {
        type: Sequelize.DATE,
        defaultNull: true,
      }),
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn('companies', 'blockedAt', {
        type: Sequelize.STRING,
        allowNull: true,
      }),
    ]);
  }
};
