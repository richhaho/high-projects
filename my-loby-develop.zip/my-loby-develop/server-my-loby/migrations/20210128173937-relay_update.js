'use strict';

module.exports = {
  up: (queryInterface, DataTypes) => {
    return Promise.all([
      queryInterface.addColumn('relays', 'minimumKeysNeeded', {
        type: DataTypes.INTEGER,
        defaultValue: 0,
      }),
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn('relays', 'minimumKeysNeeded'),
    ]);
  }
};
