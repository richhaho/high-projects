'use strict';

module.exports = {
  up: (migration, DataTypes) => {
    return migration.createTable(
      'boxes_tags',
      {
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        boxId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: false,
          references: {
            model: 'boxes',
            key: 'id'
          },
        },
        tagId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: false,
          references: {
            model: 'tags',
            key: 'id'
          },
        },
      },
    );
  },

  down: (migration, DataTypes) => {
    return migration.dropTable('boxes_tags');
  },
};
