'use strict';

module.exports = {
  up: (queryInterface, DataTypes) => {
    return Promise.all([
      queryInterface.addColumn('keys', 'acsesObjectId', {
        type: DataTypes.STRING,
        defaultValue: null,
        allowNull: true,
      }),
      queryInterface.addColumn('keys', 'acsesAccessId', {
        type: DataTypes.STRING,
        defaultValue: null,
        allowNull: true,
      }),
      queryInterface.addColumn('keys', 'acsesCodes', {
        type: DataTypes.STRING,
        defaultValue: null,
        allowNull: true,
      }),
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn('keys', 'acsesObjectId'),
      queryInterface.removeColumn('keys', 'acsesAccessId'),
      queryInterface.removeColumn('keys', 'acsesCodes'),
    ]);
  }
};
