'use strict';

module.exports = {
  up: function (migration, DataTypes) {
    return migration.createTable(
      'bookings',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        name: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        keyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'keys',
            key: 'id',
            allowNull: false,
          }
        },
        userId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'users',
            key: 'id',
            allowNull: false,
          }
        },
        startDate: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        endDate: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        createdBy: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'users',
            key: 'id',
            allowNull: false,
          }
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        notificationType: {
          type: DataTypes.STRING,
          allowNull: true,
        },
        notificationBooking: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        notificationRecall: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        notificationRetard: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        closed: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      }
    )
  },
  down: function (migration, DataTypes) {
    return migration.dropTable('bookings')
  },
};
