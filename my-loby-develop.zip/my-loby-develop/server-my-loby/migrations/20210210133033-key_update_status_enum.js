'use strict';

module.exports = {
  up: (queryInterface, DataTypes) => {
    return Promise.all([
      queryInterface.changeColumn('keys', 'status', {
        type: DataTypes.ENUM({
          values: ["CREATED", "IN_RELAY", "WITH_SOMEBODY", "LATE", "IN_TRANSIT", "PENDING_CREATION", "ARCHIVED", "UNARCHIVED", "IN_CONNECTED_BOX"],
        }),
        allowNull: false,
      }),
    ]);
  },

  down: (queryInterface, DataTypes) => {
    return Promise.all([
      queryInterface.changeColumn('keys', 'status', {
        type: DataTypes.ENUM({
          values: ["CREATED", "IN_RELAY", "WITH_SOMEBODY", "LATE", "IN_TRANSIT", "PENDING_CREATION", "ARCHIVED", "UNARCHIVED", "IN_CONNECTED_BOX"],
        }),
        allowNull: false,
      }),
    ]);
  }
};
