'use strict';

module.exports = {
  up: (queryInterface, DataTypes) => {
    return Promise.all([
      queryInterface.addColumn('boxes', 'acsesLockesystemId', {
        type: DataTypes.STRING,
        defaultValue: null,
        allowNull: true,
      }),
    ]);
  },

  down: (queryInterface, DataTypes) => {
    return Promise.all([
      queryInterface.removeColumn('boxes', 'acsesLockesystemId'),
    ]);
  }
};