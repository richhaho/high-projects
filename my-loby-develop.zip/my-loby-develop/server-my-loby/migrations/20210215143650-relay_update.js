'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn('relays', 'authorizeReccurence', {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
      }),
      queryInterface.addColumn('relays', 'authorizeBookingRecall', {
        type: Sequelize.BOOLEAN,
        defaultValue: false,
      }),
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn('relays', 'authorizeReccurence'),
      queryInterface.removeColumn('relays', 'authorizeBookingRecall'),
    ]);
  }
};
