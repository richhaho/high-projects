'use strict';

module.exports = {
  up: (migration, DataTypes) => {
    return migration.createTable(
      'acses_objects',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        name: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        tableKey: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: false,
        },
        acsesLockesystemId: {
          type: DataTypes.INTEGER.UNSIGNED,ull: false,
        },
        keyId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'keys',
            key: 'id'
          },
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      }
    )
  },

  down: (migration, DataTypes) => {
    return migration.dropTable('acses_objects');
  }
};
