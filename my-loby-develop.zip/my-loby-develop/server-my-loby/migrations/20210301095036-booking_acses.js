'use strict';

module.exports = {
  up: (migration, DataTypes) => {
    return migration.createTable(
      'acses_bookings',
      {
        id: {
          type: DataTypes.INTEGER.UNSIGNED,
          autoIncrement: true,
          primaryKey: true,
          allowNull: false,
        },
        code: {
          type: DataTypes.STRING,
          allowNull: false,
        },
        tableKey: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
        lockercell: {
          type: DataTypes.INTEGER,
          allowNull: false,
        },
        objectAcsesId: {
          type: DataTypes.INTEGER.UNSIGNED,
          references: {
            model: 'acses_objects',
            key: 'id'
          },
          allowNull: false,
        },
        startDate: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        endDate: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        used: {
          type: DataTypes.DATE,
          allowNull: true,
        },
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        deletedAt: {
          type: DataTypes.DATE,
          allowNull: true,
        },
      }
    )
  },

  down: (migration, DataTypes) => {
    return migration.dropTable('acses_bookings');
  }
};
