'use strict';

module.exports = {
  up: (migration, DataTypes) => {
    return migration.createTable(
      'box_acsesObjects',
      {
        createdAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        updatedAt: {
          type: DataTypes.DATE,
          allowNull: false,
        },
        boxId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: false,
          references: {
            model: 'boxes',
            key: 'id'
          },
        },
        acsesObjectId: {
          type: DataTypes.INTEGER.UNSIGNED,
          allowNull: false,
          references: {
            model: 'acses_objects',
            key: 'id'
          },
        },
      },
    );
  },

  down: (migration, DataTypes) => {
    return migration.dropTable('box_acsesObjects');
  },
};
