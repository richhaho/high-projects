'use strict';

module.exports = {
  up: (queryInterface, DataTypes) => {
    return Promise.all([
      queryInterface.addColumn('boxes', 'extensionsCount', {
        type: DataTypes.INTEGER,
        defaultValue: 0,
        allowNull: true,
      }),
    ]);
  },

  down: (queryInterface, DataTypes) => {
    return Promise.all([
      queryInterface.removeColumn('boxes', 'extensionsCount'),
    ]);
  }
};