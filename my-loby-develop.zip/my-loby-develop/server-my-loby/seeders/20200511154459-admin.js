'use strict';

const bcrypt = require("bcryptjs");

module.exports = {
  up: async (queryInterface, Sequelize) => {
    const email = process.env.ADMIN_EMAIL;
    const salt = await bcrypt.genSalt(10);
    const password = await bcrypt.hash(process.env.ADMIN_PASSWORD, salt);
    const creationDate = new Date();
    return queryInterface.bulkInsert('users', [{
      firstName: "Admin",
      lastName: "MyLoby",
      email,
      password,
      isAdmin: true,
      activatedAt: creationDate,
      createdAt: creationDate,
      updatedAt: creationDate,
    }]);
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('users', {
        email: "admin@gmail.com",
      }, {}
    );
  }
};
