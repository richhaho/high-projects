'use strict';


module.exports = {
  up: async (queryInterface, Sequelize) => {
    var creationDate = new Date();
    return queryInterface.bulkInsert('plans', [
      {
        type: "B2B",
        name: "FREE",
        monthlyPrice: 0,
        yearlyPrice: 0,
        details: JSON.stringify({
          maxKeys: 10,
          maxUsersPerKey: 2,
          maxReferents: 1,
          canUseFlowRelays: false,
          canCreateMoreRelays: false,
          canUseManagers: false,
        }),
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        type: "B2B",
        name: "BASIC",
        monthlyPrice: 49,
        yearlyPrice: (49 * 12) * 0.9,
        details: JSON.stringify({
          maxKeys: 1000000,
          maxUsersPerKey: 2,
          maxReferents: 1,
          canUseFlowRelays: true,
          canCreateMoreRelays: false,
          canUseManagers: false,
        }),
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        type: "B2B",
        name: "STANDARD",
        monthlyPrice: 99,
        yearlyPrice: (99 * 12) * 0.9,
        details: JSON.stringify({
          maxKeys: 1000000,
          maxUsersPerKey: 5,
          maxReferents: 1,
          canUseFlowRelays: true,
          canCreateMoreRelays: true,
          canUseManagers: true,
        }),
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        type: "B2B",
        name: "PREMIUM",
        monthlyPrice: 199,
        yearlyPrice: (199 * 12) * 0.9,
        details: JSON.stringify({
          maxKeys: 1000000,
          maxUsersPerKey: 1000000,
          maxReferents: 1000000,
          canUseFlowRelays: true,
          canCreateMoreRelays: true,
          canUseManagers: true,
        }),
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        type: "INSURANCE",
        name: "BASIC",
        monthlyPrice: 49,
        yearlyPrice: (49 * 12) * 0.9,
        details: JSON.stringify({
          maxKeys: 1000000,
          maxUsersPerKey: 2,
          maxReferents: 0,
          canUseFlowRelays: false,
          canCreateMoreRelays: false,
          canUseManagers: false,
        }),
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        type: "INSURANCE",
        name: "STANDARD",
        monthlyPrice: 99,
        yearlyPrice: (99 * 12) * 0.9,
        details: JSON.stringify({
          maxKeys: 1000000,
          maxUsersPerKey: 6,
          maxReferents: 0,
          maxGroups: 1000000,
          canUseFlowRelays: false,
          canCreateMoreRelays: false,
          canUseManagers: true,
        }),
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        type: "INSURANCE",
        name: "PREMIUM",
        monthlyPrice: 199,
        yearlyPrice: (199 * 12) * 0.9,
        details: JSON.stringify({
          maxKeys: 1000000,
          maxUsersPerKey: 1000000,
          maxReferents: 0,
          canUseFlowRelays: false,
          canCreateMoreRelays: false,
          canUseManagers: true,
        }),
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        type: "B2C",
        name: "PUNCTUAL",
        monthlyPrice: 0,
        yearlyPrice: 0,
        details: JSON.stringify({
          creationPrice: 5,
          withdrawPrice: 0,
          daysDelay: 15,
        }),
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        type: "B2C",
        name: "STANDARD",
        monthlyPrice: 3,
        yearlyPrice: 12 * 3,
        details: JSON.stringify({
          creationPrice: 3,
          withdrawPrice: 4,
        }),
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        type: "B2C",
        name: "PREMIUM",
        monthlyPrice: 20,
        yearlyPrice: 12 * 20,
        details: JSON.stringify({
          creationPrice: 20,
          withdrawPrice: 0,
        }),
        createdAt: creationDate,
        updatedAt: creationDate,
      },
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('plans', {}, {} );
  }
};
