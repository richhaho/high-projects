'use strict';


module.exports = {
  up: async (queryInterface, Sequelize) => {
    const creationDate = new Date();
    return queryInterface.bulkInsert('tags', [
      {
        en: "elevator",
        fr: "ascenseur",
        pt: "ascenseur",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "lot",
        fr: "lot",
        pt: "lot",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "cellars",
        fr: "caves",
        pt: "caves",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "common area",
        fr: "parties communes",
        pt: "parties communes",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "private area",
        fr: "parties privatives",
        pt: "parties privatives",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "machine room",
        fr: "local technique",
        pt: "local technique",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "boiler room",
        fr: "chaufferie",
        pt: "chaufferie",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "floor",
        fr: "étages",
        pt: "étages",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "building",
        fr: "immeuble",
        pt: "immeuble",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "unfurnished rental",
        fr: "location non meublée",
        pt: "location non meublée",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "furnished rental",
        fr: "location meublée",
        pt: "location meublée",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "mailbox",
        fr: "boîtes aux lettres",
        pt: "boîtes aux lettres",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "lodge",
        fr: "loge",
        pt: "loge",
        createdAt: creationDate,
        updatedAt: creationDate,

      },
      {
        en: "rental",
        fr: "re location",
        pt: "re location",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "renovation",
        fr: "rénovation",
        pt: "rénovation",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "penalty",
        fr: "astreinte",
        pt: "astreinte",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "emergency",
        fr: "urgence",
        pt: "urgence",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "double",
        fr: "double",
        pt: "double",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "street",
        fr: "rue",
        pt: "rue",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "courtyard",
        fr: "court",
        pt: "court",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "landlord",
        fr: "propriétaire",
        pt: "propriétaire",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "tenant",
        fr: "locataire",
        pt: "locataire",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "rented",
        fr: "en location",
        pt: "en location",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('tags', {}, {} );
  }
};
