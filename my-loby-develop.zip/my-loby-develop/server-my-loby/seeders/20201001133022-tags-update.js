'use strict';


module.exports = {
  up: async (queryInterface, Sequelize) => {
    const creationDate = new Date();
    return queryInterface.bulkInsert('tags', [
      {
        en: "washing finished",
        fr: "lavage terminé",
        pt: "lavagem terminada",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "repair completed",
        fr: "réparation terminée",
        pt: "reparação concluída",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('tags', {}, {} );
  }
};
