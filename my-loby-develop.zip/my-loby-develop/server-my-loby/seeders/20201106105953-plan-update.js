'use strict';

module.exports = {

  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 10,
            maxUsersPerKey: 2,
            maxReferents: 1,
            canUseFlowRelays: false,
            canCreateMoreRelays: false,
            canUseManagers: false,
            maxSms: 0,
            smsOverPrice: 0.07
          })
        }, {
          type: "B2B",
          name: "FREE",
        },
      ),
      queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 2,
            maxReferents: 1,
            canUseFlowRelays: true,
            canCreateMoreRelays: false,
            canUseManagers: false,
            maxSms: 50,
            smsOverPrice: 0.07
          })
        }, {
          type: "B2B",
          name: "BASIC",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 5,
            maxReferents: 1,
            canUseFlowRelays: true,
            canCreateMoreRelays: true,
            canUseManagers: true,
            maxSms: 100,
            smsOverPrice: 0.07
          })
        }, {
          type: "B2B",
          name: "STANDARD",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 1000000,
            maxReferents: 1000000,
            canUseFlowRelays: true,
            canCreateMoreRelays: true,
            canUseManagers: true,
            maxSms: 500,
            smsOverPrice: 0.07
          })
        }, {
          type: "B2B",
          name: "PREMIUM",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 2,
            maxReferents: 0,
            canUseFlowRelays: false,
            canCreateMoreRelays: false,
            canUseManagers: false,
            maxSms: 0,
            smsOverPrice: 0.07
          })
        }, {
          type: "INSURANCE",
          name: "BASIC",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 6,
            maxReferents: 0,
            maxGroups: 1000000,
            canUseFlowRelays: false,
            canCreateMoreRelays: false,
            canUseManagers: true,
            maxSms: 0,
            smsOverPrice: 0.07
          })
        }, {
          type: "INSURANCE",
          name: "STANDARD",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 1000000,
            maxReferents: 0,
            canUseFlowRelays: false,
            canCreateMoreRelays: false,
            canUseManagers: true,
            maxSms: 0,
            smsOverPrice: 0.07
          })
        }, {
          type: "INSURANCE",
          name: "PREMIUM",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            creationPrice: 5,
            withdrawPrice: 0,
            daysDelay: 15,
            maxSms: 1,
            smsOverPrice: 0.07
          })
        }, {
          type: "B2C",
          name: "PUNCTUAL",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            creationPrice: 3,
            withdrawPrice: 4,
            maxSms: 5,
            smsOverPrice: 0.07
          })
        }, {
          type: "B2C",
          name: "STANDARD",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            creationPrice: 20,
            withdrawPrice: 0,
            maxSms: 10,
            smsOverPrice: 0.07
          })
        }, {
          type: "B2C",
          name: "PREMIUM",
        },
      )

    ])
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('plans', {}, {});
  }
};
