'use strict';


module.exports = {
  up: async (queryInterface, Sequelize) => {
    const creationDate = new Date();
    return queryInterface.bulkInsert('tags', [
      {
        en: "washing finished",
        fr: "lavage terminé",
        pt: "lavagem terminada",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "repair completed",
        fr: "réparation terminée",
        pt: "reparação concluída",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Validated quote",
        fr: "Devis validé",
        pt: "Citação validada",
        //de: "Validiertes Angebot",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Vehicle delivered",
        fr: "Véhicule livré",
        pt: "Veículo entregue",
        //de: "Fahrzeug geliefert",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Validated order",
        fr: "Commande validée",
        pt: "Pedido validado",
        //de: "Validierte Bestellung",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Bill paid",
        fr: "Facture payée",
        pt: "Conta paga",
        //de: "Rechnung bezahlt",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Urgent",
        fr: "Urgent",
        pt: "Urgente",
        //de: "Dringend",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Parking badge",
        fr: "Badge parking",
        pt: "Crachá de estacionamento",
        //de: "Parkausweis",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Intercom badge",
        fr: "Vigik",
        pt: "Emblema do Intercom",
        //de: "Intercom-Abzeichen",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Entrance badge",
        fr: "Badge d’entrée",
        pt: "Crachá de entrada",
        //de: "Eingangsabzeichen",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Release inventory",
        fr: "EDL Sortie",
        pt: "Liberar estoque",
        //de: "Inventar freigeben",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Inventory upon arrival",
        fr: "EDL Entrée",
        pt: "Estoque na chegada",
        //de: "Inventar bei der Ankunft",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Plumbing done",
        fr: "Plomberie effectuée",
        pt: "Encanamento feito",
        //de: "Sanitär fertig",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Painting done",
        fr: "Peinture effectuée",
        pt: "Pintura feita",
        //de: "Malen fertig",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Renovation completed",
        fr: "Rénovation terminée",
        pt: "Renovação concluída",
        //de: "Renovierung abgeschlossen",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
      {
        en: "Housekeeping completed",
        fr: "Ménage terminé",
        pt: "Limpeza concluída",
        //de: "Housekeeping abgeschlossen",
        createdAt: creationDate,
        updatedAt: creationDate,
      },
    ]);
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('tags', {}, {} );
  }
};