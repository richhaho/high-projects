'use strict';
// this must be executed to update old subscriptions .
module.exports = {
  up: async (queryInterface, Sequelize) => {
    return queryInterface.sequelize.query("SELECT subscriptions.id, subscriptions.details, plans.name FROM subscriptions LEFT JOIN plans ON subscriptions.planId = plans.id  WHERE companyId is not null")
    .then((res, metadata) => {
      return Promise.all(res[0].map((e) => {
        if (e.name === "PREMIUM") {
          e.details.options['manageStock'] = {
            initValue: 0,
            isActive: true,
            discount: {
              multiplier: 1,
            },
          }
        } else {
          e.details.options['manageStock'] = {
            initValue: 50,
            isActive: false,
            discount: {
              multiplier: 1,
            },
          }
        }
        return queryInterface.sequelize
        .query({
            query: "UPDATE subscriptions SET details = ? WHERE id= ?",
            values: [JSON.stringify(e.details), (e.id).toString()]
          }
          , {type: 'Update'})
      }));

    })

  },
  down: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.query("SELECT * FROM subscriptions WHERE companyId is not null")
    .then((res, metadata) => {
      return Promise.all(res[0].map((e) => {
        delete e.details.options['manageStock']
        return queryInterface.sequelize
        .query({
            query: "UPDATE subscriptions SET details = ? WHERE id= ?",
            values: [JSON.stringify(e.details), (e.id).toString()]
          }
          , {type: 'Update'})
      }));
    })
  }
};
