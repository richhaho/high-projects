'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    const creationDate = new Date();
    return Promise.all([
      queryInterface.bulkInsert('plans', [
        {
          type: "B2B",
          name: "CONNECTED_BOXES",
          monthlyPrice: 0,
          yearlyPrice: 0,
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 6,
            maxReferents: 6,
            maxGroups: 1000000,
            canUseFlowRelays: false,
            canCreateMoreRelays: false,
            canUseManagers: true,
            canManageStock: true,
            canUseBooking: true,
            firstConnectedBoxPrice: 49,
            connectedBoxPrice: 89,
            maxSms: 0,
            smsOverPriceCoef: 1.75,
          }),
          createdAt: creationDate,
          updatedAt: creationDate,
        },
        {
          type: "INSURANCE",
          name: "CONNECTED_BOXES",
          monthlyPrice: 0,
          yearlyPrice: 0,
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 6,
            maxReferents: 6,
            maxGroups: 1000000,
            canUseFlowRelays: false,
            canCreateMoreRelays: false,
            canUseManagers: true,
            canManageStock: true,
            canUseBooking: true,
            firstConnectedBoxPrice: 49,
            connectedBoxPrice: 89,
            maxSms: 0,
            smsOverPriceCoef: 1.75,
          }),
          createdAt: creationDate,
          updatedAt: creationDate,
        },
      ]),
      queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 10,
            maxUsersPerKey: 2,
            maxReferents: 1,
            canUseFlowRelays: false,
            canCreateMoreRelays: false,
            canUseManagers: false,
            canManageStock:false,
            canUseBooking: false,
            maxSms: 0,
            smsOverPriceCoef: 1.75,
            firstConnectedBoxPrice: 49,
            connectedBoxPrice: 89,
          })
        }, {
          type: "B2B",
          name: "FREE",
        },
      ),
      queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 2,
            maxReferents: 1,
            canUseFlowRelays: true,
            canCreateMoreRelays: false,
            canUseManagers: false,
            canManageStock:false,
            canUseBooking: false,
            maxSms: 50,
            smsOverPriceCoef: 1.75,
            firstConnectedBoxPrice: 49,
            connectedBoxPrice: 89,
          })
        }, {
          type: "B2B",
          name: "BASIC",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 5,
            maxReferents: 1,
            canUseFlowRelays: true,
            canCreateMoreRelays: true,
            canUseManagers: true,
            canManageStock:false,
            canUseBooking: false,
            maxSms: 100,
            smsOverPriceCoef: 1.75,
            firstConnectedBoxPrice: 49,
            connectedBoxPrice: 89,
          })
        }, {
          type: "B2B",
          name: "STANDARD",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 1000000,
            maxReferents: 1000000,
            canUseFlowRelays: true,
            canCreateMoreRelays: true,
            canUseManagers: true,
            canManageStock:true,
            canUseBooking: true,
            maxSms: 500,
            smsOverPriceCoef: 1.75,
            firstConnectedBoxPrice: 49,
            connectedBoxPrice: 89,
          })
        }, {
          type: "B2B",
          name: "PREMIUM",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 2,
            maxReferents: 0,
            canUseFlowRelays: false,
            canCreateMoreRelays: false,
            canUseManagers: false,
            canManageStock:false,
            canUseBooking: false,
            maxSms: 0,
            smsOverPriceCoef: 1.75,
            firstConnectedBoxPrice: 49,
            connectedBoxPrice: 89,
          })
        }, {
          type: "INSURANCE",
          name: "BASIC",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 6,
            maxReferents: 0,
            maxGroups: 1000000,
            canUseFlowRelays: false,
            canCreateMoreRelays: false,
            canUseManagers: true,
            canManageStock:false,
            canUseBooking: true,
            maxSms: 0,
            smsOverPriceCoef: 1.75,
            firstConnectedBoxPrice: 49,
            connectedBoxPrice: 89,
          })
        }, {
          type: "INSURANCE",
          name: "STANDARD",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 1000000,
            maxReferents: 0,
            canUseFlowRelays: false,
            canCreateMoreRelays: false,
            canUseManagers: true,
            canManageStock:false,
            canUseBooking: true,
            maxSms: 0,
            smsOverPriceCoef: 1.75,
            firstConnectedBoxPrice: 49,
            connectedBoxPrice: 89,
          })
        }, {
          type: "INSURANCE",
          name: "PREMIUM",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            creationPrice: 5,
            withdrawPrice: 0,
            daysDelay: 15,
            maxSms: 1,
            smsOverPriceCoef: 1.75
          })
        }, {
          type: "B2C",
          name: "PUNCTUAL",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            creationPrice: 3,
            withdrawPrice: 4,
            maxSms: 5,
            smsOverPriceCoef: 1.75
          })
        }, {
          type: "B2C",
          name: "STANDARD",
        },
      ), queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            creationPrice: 20,
            withdrawPrice: 0,
            maxSms: 10,
            smsOverPriceCoef: 1.75
          })
        }, {
          type: "B2C",
          name: "PREMIUM",
        },
      )

    ])
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('plans', {}, {});
  }
};
