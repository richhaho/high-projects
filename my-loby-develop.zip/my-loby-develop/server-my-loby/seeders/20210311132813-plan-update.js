'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.bulkUpdate('plans', {
          details: JSON.stringify({
            maxKeys: 1000000,
            maxUsersPerKey: 6,
            maxReferents: 6,
            maxGroups: 1000000,
            canUseFlowRelays: false,
            canCreateMoreRelays: false,
            canUseManagers: true,
            canManageStock: true,
            canUseBooking: true,
            firstConnectedBoxPrice: 89,
            connectedBoxPrice: 89,
            maxSms: 50,
            smsOverPriceCoef: 1.75,
          }),
        }, {
          type: "B2B",
          name: "CONNECTED_BOXES",
        },
      ),
    ])
  },

  down: (queryInterface, Sequelize) => {
    return queryInterface.bulkDelete('plans', {}, {});
  }
};
