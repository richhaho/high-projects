'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.sequelize.query("SELECT subscriptions.id, subscriptions.details, plans.name FROM subscriptions LEFT JOIN plans ON subscriptions.planId = plans.id  WHERE companyId is not null")
      .then((res, metadata) => {
        return Promise.all(res[0].map((e) => {
          if (e.details.options['shareConnectedBoxes']) {
            delete e.details.options['shareConnectedBoxes'];
          }
          return queryInterface.sequelize
            .query({
                query: "UPDATE subscriptions SET details = ? WHERE id= ?",
                values: [JSON.stringify(e.details), (e.id).toString()]
              }
              , {type: 'Update'})
        }));
      });
  },

  down: (queryInterface, Sequelize) => {

  }
};
