const canCreateMoreKeys = (company: any, existingKeysNbr: number, newKeysNbr: number) => {
  if (!company) {
    // If the user has no company, he is a B2C user => Can create as many keys as he wants (he pays for each key)
    return true;
  } else {
    // If the user has a company, check plan restrictions
    const {maxKeys} = company?.currentSubscription?.Plan?.details || 0;
    return existingKeysNbr + newKeysNbr <= maxKeys;
  }
};

const canAddMoreUserToKey = (company: any, existingKeyUsersNbr: number, newKeyUsersNbr: number) => {
  if (!company) {
    // If the user has no company, he is a B2C user => Can add as many guest as he wants (he pays monthly or at the withdraw)
    return true;
  } else {
    // If the user has a company, check plan restrictions
    const {maxUsersPerKey} = company?.currentSubscription?.Plan?.details || 0;
    return existingKeyUsersNbr + newKeyUsersNbr <= maxUsersPerKey;
  }
};

const canAddMoreReferents = (company: any, existingReferentsNbr: number, newReferentsNbr: number) => {
  if (!company) {
    // If the user has no company, he is the owner of a long_term / flow relays => no referents
    return false;
  } else {
    // If the user has a company, check plan restrictions
    const {maxReferents} = company?.currentSubscription?.Plan?.details || 0;
    return existingReferentsNbr + newReferentsNbr <= maxReferents;
  }
};

const canCreateMoreRelays = (company: any) => {
  if (!company) {
    // If the user has no company, he is the owner of a longTerm / flow relay => no more relays
    return false;
  } else {
    // If the option is not activated for the current subscription, not authorized
    return company?.currentSubscription?.details?.options?.additionalRelays?.isActive;
  }
};

const canUseManagers = (company: any) => {
  if (!company) {
    // If the user has no company, he is a B2C user => Cannot access the management part
    return false;
  } else {
    // If the user has a company, check plan restrictions
    return company?.currentSubscription?.Plan?.details?.canUseManagers;
  }
};

const canUseFlowRelays = (company: any) => {
  if (!company) {
    // If the user has no company, he is a B2C user => Can use only flow relays
    return true;
  } else {
    // If the user has a company, check plan restrictions
    return company?.currentSubscription?.Plan?.details?.canUseFlowRelays;
  }
};

const canManageStock = (company: any) => {
  if (!company) {
    // If the user has no company, he is a B2C user => he can't manage stock
    return true;
  } else {
    // If the user has a company, check plan restrictions
    return company?.currentSubscription?.Plan?.details?.canManageStock;
  }
};

const canUseBooking = (company: any) => {
  if (!company) {
    // If the user has no company, he is a B2C user => Can use only flow relays
    return true;
  } else {
    // If the user has a company, check plan restrictions
    return company?.currentSubscription?.details?.options?.allowBooking?.isActive;
  }
};

module.exports = {
  canCreateMoreKeys,
  canAddMoreUserToKey,
  canAddMoreReferents,
  canCreateMoreRelays,
  canUseManagers,
  canUseFlowRelays,
  canUseBooking,
  canManageStock,
};