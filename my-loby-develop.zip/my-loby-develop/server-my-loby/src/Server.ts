import cookieParser from "cookie-parser";
import express, {Request, Response} from "express";
import logger from "morgan";
import path from "path";
import session = require("express-session");
import BaseRouter from "./routes";
import passport from "passport";
import "./services/passport";
import * as shared from "@shared";

// Init dataBase

import dotenv = require("dotenv");
dotenv.config({path: `./env/${process.env.ENV_FILE || "development"}.env`});

// Init CRON

import cronManager = require("./services/cron");
cronManager.init();

// Init express
const app = express();

// Add middleware/settings/routes to express.
app.use(logger("combined", {
  skip: (req, res) => res.statusCode < 400,
}));
app.use(express.json({limit: "50mb"}));
app.use(express.urlencoded({extended: true}));
app.use(cookieParser());

if (process.env.SESSION_SECRET) {
    app.use(session({
        secret: process.env.SESSION_SECRET,
        resave: true,
        saveUninitialized: true,
        cookie: { maxAge: 43200000, httpOnly: false},
    }));
} else {
    shared.logger.error("Session secret missing");
}
app.use(passport.initialize());
app.use(passport.session());

app.use("/api", BaseRouter);

/**
 * Point express to the 'views' directory. If you're using a
 * single-page-application framework like react or angular
 * which has its own development server, you might want to
 * configure this to only serve the index file while in
 * production mode.
 */
/*app.use(express.static(path.join(__dirname + "./../../pwa-my-loby/dist/")));
app.get("*", (req: Request, res: Response) => {
    res.sendFile(path.join(__dirname + "./../../pwa-my-loby/dist/index.html"));
});*/

// Export express instance
export default app;
