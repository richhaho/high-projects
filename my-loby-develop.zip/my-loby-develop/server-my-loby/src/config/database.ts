import {logger} from "@shared";
import {Sequelize} from "sequelize";
import {ProspectDao, UserDao, TokenDao, MigrationDao} from "@daos";
import {plansData} from "../data/plans";
import {prospectData} from "../data/prospects";
import {tagData} from "../data/tags";
import {nexityData} from "../data/nexity";
import {b2bTestData} from "../data/b2bTest";
import {lukoData} from "../data/luko";
import {mylobyData} from "../data/myloby";
import {otherData} from "../data/other";

const database = new Sequelize({
    database: process.env.DB_DATABASE,
    host: process.env.DB_HOST,
    username: process.env.DB_USER,
    password: process.env.DB_PASS,
    dialect: "mysql",
    logging:  (str) => {
      // console.log(str)
    },
});

database.authenticate()
    .then(() => {
        logger.info("Connection has been established successfully.");
    })
    .catch((err: any) => {
        logger.error("Unable to connect to the database:", err);
    });
/*
database.query("SET FOREIGN_KEY_CHECKS = 0", { raw: true }).then (  () => {
  database.sync({force: true}).then(async () => {
    await plansData();
    await mylobyData();
    await nexityData();
    await b2bTestData();
    await lukoData();
    await prospectData(new ProspectDao());
    await otherData(new UserDao(), new TokenDao());
    await tagData();
    if (process.env.NODE_ENV === "production") {
      // await MigrationDao.init();
    }
  });
});
 */

export {database, Sequelize};
