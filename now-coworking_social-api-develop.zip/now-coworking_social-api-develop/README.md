<div>
    <p align="center">
        <img src="https://git.thecodingmachine.com/tcm-projects/now-coworking_social-app/raw/develop/images/logo.png" width="200px") />
    </p>
</div>
<div>
    <h1 align="center">Now-Coworking Social API</h1>
    <h4 align="center">Back-end part of project : now-coworking_social-app</h4>
</div>


## Table of Contents

* <a href="#architecture">Architecture</a>
* <a href="#prerequisites">Prerequisites</a>
* <a href="#how-to-use">How to use</a> 
* <a href="#running-app">Running App</a> 
* <a href="#ci">CI</a> 
* <a href="#cd">CD</a> 

## Architecture

This project is part of the [Now-Coworking Social project](https://git.thecodingmachine.com/tcm-projects/now-coworking_social-app), an open-source mobile app featuring social networking functionalities which are meant to encourage interaction among the Now Coworkers.

This repo focuses on the backend, a Laravel API, that lies behind the app.

## Prerequisites

In order to set up this repo correctly, please make sure your workspace meets the following requirements :
* [Docker](https://docs.docker.com/install/) >= 17.12.0 (recommendation: Version 18.03.0-ce-rc1-win54)
* [Docker-Compose](https://docs.docker.com/compose/)

## How to use

### General

```
git clone git@git.thecodingmachine.com:tcm-projects/now-coworking_social-api.git
cd now-coworking_social-api
```

*In staging environment only :*
```
touch docker/traefik/acme.json
chmod 600 docker/traefik/acme.json
```

### Fill environment files

After cloning the repo, some environment variables need to be set to mount the project properly.

```
# From root folder
cp docker-compose.dev.yml docker-compose.yml
cp .env.example .env
cp api/.env.example api/.env
cp api/laravel-echo-server.dev.json api/laravel-echo-server.json
```

Edit each of these files as indicated below :

* `.env` :

Set a value to the `MYSQL_PASSWORD` and `MYSQL_TEST_PASSWORD` variables.

*In development environment only :* If you want to use Blackfire profiling, you need to provide your Blackfire credentials in this file as well in the variables `BLACKFIRE_CLIENT_ID`, `BLACKFIRE_CLIENT_TOKEN`, `BLACKFIRE_SERVER_ID`, `BLACKFIRE_SERVER_TOKEN`.

* `api/.env` :

As this Laravel project integrates third-party service Cosoft API, the URL and API keys should be set in this file.

Set a value to the `DB_PASSWORD` variable as well in this file.

#### Ngrok

[Ngrok](https://ngrok.com/) is secured tunnel for expose localhost to the world.  
You must first create an account and install it.

After the installation of ngrok,

```
cp ngrok.yml.example ngrok.yml
```
Then set `authtoken` in ngrok.yml with your own ngrok token  
You can find it at https://dashboard.ngrok.com/auth

Start ngrok with :

```
cd path/to/ngrok
ngrok start --all -config=path/to/nowco/api/ngrok.yml
```

Copy the tunnel for `echo.nowco.localhost:80` in `.env` file (`ECHO_DOMAIN`) without http or https (just the host)
Copy the tunnel for `api.nowco.localhost:80` in `.env` file (`API_DOMAIN`) without http or https (just the host)
and inside the app configuration file `App/Config/index.js` (with http or https) used into `app/App/Services/ApiClient.js`

Modify your host file adding the following lines
```
127.0.0.1 api.nowco.localhost
127.0.0.1 node.nowco.localhost
```

### Docker

The project uses Docker in its stack for easy set up.

A Docker Compose file is provided to launch the API server and every dependencies it needs. Launch this command from the root directory of the project and you should be ready to go :

```
# from root folder
docker-compose up -d
```

If you need to execute commands from within the container (ex: artisan commands), enter the container first with :

```
docker exec -it now-coworking_social_api_1 bash
```

*In development environment only :*
```
# To enable Blackfire profiling (CLI scripts)
sudo apt-get install wget gnupg2
wget -q -O - https://packagecloud.io/gpg.key | sudo apt-key add - \
    && echo "deb http://packages.blackfire.io/debian any main" | sudo tee /etc/apt/sources.list.d/blackfire.list \
    && sudo apt-get update \
    && sudo apt-get install blackfire-php
```

## COSOFT

You should add the 

## Firebase
In order to setup notifications, you'll need to initialise your firebase admin sdk by running these commands :
```
cd api/
cp firebase-private-key.dev.json firebase-private-key.json
```

and fill it with information available in the Login Machine.

## Artisan commands

Once everything is ready and you got the 404 error from Laravel run the following command into the api container:

- `php artisan db:sync` : Synchronize database with Cosoft API
- `php artisan mix:run` : Run Mix scores evaluation. This process takes a while to finish depending on the number of entries you have in your Users table. If needed, you can manage the local database in phpMyAdmin.

Tips : use your test account and around 20 users to test this part. Don't forget to update `updated_at` column for running the command `php artisan mix:run`

In PhpMyAdmin or in command line:
```
UPDATE `users` SET `updated_at` = NOW() WHERE 1;
```

## CI

Continuous integration (CI) is configured on this repo. Whenever changes are pushed to the repo, the CI launches several scripts :

* `composer phpstan` : phpstan script which analyse the code
* `composer cs-check` : cs-check script which check the cleanliness of the code
* `composer tests` : test script which run the tests
* washing machine script which indicates code coverage

## CD

@todo Fastlane

## Known issues

#### Unable to connect to the database at first install

On the first install it's possible that you get this error:

```bash
 Illuminate\Database\QueryException  : SQLSTATE[HY000] [1045] Access denied for user 'root'@'172.22.0.8' (using password: NO) (SQL: select * from information_schema.tables where table_schema = api and table_name = migrations)

  at /var/www/html/vendor/laravel/framework/src/Illuminate/Database/Connection.php:664
    660|         // If an exception occurs when attempting to run a query, we'll format the error
    661|         // message to include the bindings with SQL, which will make this exception a
    662|         // lot more helpful to the developer instead of just the database's errors.
    663|         catch (Exception $e) {
  > 664|             throw new QueryException(
    665|                 $query, $this->prepareBindings($bindings), $e
    666|             );
    667|         }
    668| 

  Exception trace:

  1   Doctrine\DBAL\Driver\PDOException::("SQLSTATE[HY000] [1045] Access denied for user 'root'@'172.22.0.8' (using password: NO)")
      /var/www/html/vendor/doctrine/dbal/lib/Doctrine/DBAL/Driver/PDOConnection.php:50

  2   PDOException::("SQLSTATE[HY000] [1045] Access denied for user 'root'@'172.22.0.8' (using password: NO)")
      /var/www/html/vendor/doctrine/dbal/lib/Doctrine/DBAL/Driver/PDOConnection.php:46
```

Compose does not wait until a container is “ready” (whatever that means for your particular application) - only until it’s running. There’s a good reason for this.

The problem of waiting for a database (for example) to be ready is really just a subset of a much larger problem of distributed systems. In production, your database could become unavailable or move hosts at any time. Your application needs to be resilient to these types of failures.

So laravel (php artisan migrate) try to connect to the database into the container mysql but this one is not completely setting up.


To fix this issue, there is 2 solutions.

1. Comment a line

    Comment this line into the `docker-compose.yml`
    ```
    ...
    STARTUP_COMMAND_[number]: php artisan migrate
    ...
    ```
    
    Run 
    ```
    $ docker-compose up -d
    ```
    
    Jump into the container to run the line manually
    ```
    $ docker-compose exec api php artisan migrate
    ```
    
    Don't forget to uncomment this line after it

2. Use a script to test the connection

Design your application to attempt to re-establish a connection to the database after a failure. If the application retries the connection, it can eventually connect to the database.

The best solution is to perform this check in your application code, both at startup and whenever a connection is lost for any reason. However, if you don’t need this level of resilience, you can work around the problem with a wrapper script (as wait-for.sh).

You need to add this script into the `docker-compose.yml` please follow the documentation
- [Docker official documentation](https://docs.docker.com/compose/startup-order/)
- [Wait-for script](https://github.com/Eficode/wait-for)