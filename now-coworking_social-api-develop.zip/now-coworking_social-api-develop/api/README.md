# Documentation Now-Social API

L'API Now-Social est disponible sur l'URL https://nowco.thecodingmachine.com/api.


## Endpoints
------------

- <a href="#users">`/users`</a>
    - <a href="#post-users-login">`POST /users/login`</a>
    - <a href="#get-users">`GET /users`</a>
    - <a href="#post-users-logout">`POST /users/logout`</a>
- <a href="#coworkers">`/coworkers`</a>
    - <a href="#get-coworkers">`GET /coworkers`</a>
    - <a href="#get-coworkers-search">`GET /coworkers/search`</a>
    - <a href="#get-coworkers-coworker">`GET /coworkers/{coworker}`</a>

### <a id="users"></a> `USERS`
-----------

#### <a id="post-users-login"></a> `POST /users/login`

Permet d'authentifier un utilisateur avec les identifiants passés en paramètres

- **Paramètres**

| Nom             | Type             | Description                |
| :-------------- | :--------------- | :------------------------- |
| `email`         | `string`         | Email du coworker          |
| `password`      | `string`         | Mot de passe du coworker   |

- **Réponse**

```
{
    "id": 1356,
    "cosoftId": "a8e83b3d-e832-4ed0-aa60-a93100cf2634",
    "firstName": "Utilisateur ",
    "lastName": "Test",
    "email": "test@tcm.fr",
    "phone": null,
    "mobilePhone": "0000000000",
    "description": null,
    "job": "Testeur chez The Coding Machine",
    "society": {
        "id": 334,
        "cosoftId": "39c91b2c-6523-4d02-a31b-a79400815193",
        "name": "The Coding Machine",
        "office": "Bureau 08 (8 pers)",
        "chief": 446
    },
    "coworkingSpace": {
        "id": 2,
        "cosoftId": "99d9e3cf-335f-4760-88c8-a66700937794",
        "name": "Lyon"
    },
    "photoUrl": "https://media.fteledition.fr/Uploads/8f2abbf0-4d82-4d1b-82c8-97e5df9b2170/profile-default.jpg?autorotate=true&crop=0,0,300,300&",
    "joinedAt": "2018-08-03 15:24:13",
    "tags": [
        {
            "id": 1,
            "cosoftId": "ae949b8c-fbdf-46d4-832d-a50c00e984cb",
            "name": "informatique",
            "coworkerId": 1
        },
        {
            "id": 2,
            "cosoftId": "aeb9c498-ffbd-832d-46d4-5ce90acb0084",
            "name": "business development",
            "coworkerId": 1
        }
    ]
}
```


#### <a id="get-users"></a> `GET /users`

Retourne les informations sur l'utilisateur connecté

- **Réponse**

```
{
    "id": 1356,
    "cosoftId": "a8e83b3d-e832-4ed0-aa60-a93100cf2634",
    "firstName": "Utilisateur ",
    "lastName": "Test",
    "email": "test@tcm.fr",
    "phone": null,
    "mobilePhone": "0000000000",
    "description": null,
    "job": "Testeur chez The Coding Machine",
    "society": {
        "id": 334,
        "cosoftId": "39c91b2c-6523-4d02-a31b-a79400815193",
        "name": "The Coding Machine",
        "office": "Bureau 08 (8 pers)",
        "chief": 446
    },
    "coworkingSpace": {
        "id": 2,
        "cosoftId": "99d9e3cf-335f-4760-88c8-a66700937794",
        "name": "Lyon"
    },
    "photoUrl": "https://media.fteledition.fr/Uploads/8f2abbf0-4d82-4d1b-82c8-97e5df9b2170/profile-default.jpg?autorotate=true&crop=0,0,300,300&",
    "joinedAt": "2018-08-03 15:24:13",
    "tags": [
        {
            "id": 1,
            "cosoftId": "ae949b8c-fbdf-46d4-832d-a50c00e984cb",
            "name": "informatique",
            "coworkerId": 1
        },
        {
            "id": 2,
            "cosoftId": "aeb9c498-ffbd-832d-46d4-5ce90acb0084",
            "name": "business development",
            "coworkerId": 1
        }
    ]
}
```

#### <a id="post-users-logout"></a> `POST /users/logout`

Permet de déconnecter l'utilisateur authentifié


###  <a id="coworkers"></a> `COWORKERS`
---------------

#### <a id="get-coworkers"></a> `GET /coworkers`

Retourne la liste des coworkers.

*Requête paginée : 10 entrées max retournées*

- **Paramètres**

| Nom             | Type             | Description                |
| :-------------- | :--------------- | :------------------------- |
| `page`          | `integer`        | Index pagination           |

- **Réponse**

```
{
    "current_page": 2,
    "first_page_url": "http://nowco.thecodingmachine.com/api/coworkers?page=1",
    "from": 1,
    "last_page": 140,
    "last_page_url": "http://nowco.thecodingmachine.com/api/coworkers?page=140",
    "next_page_url": "http://nowco.thecodingmachine.com/api/coworkers?page=2",
    "path": "http://nowco.thecodingmachine.com/api/coworkers",
    "per_page": 10,
    "prev_page_url": null,
    "to": 10,
    "total": 1397,
    "data": [
        {
            "id": 1356,
            "cosoftId": "a8e83b3d-e832-4ed0-aa60-a93100cf2634",
            "firstName": "Utilisateur ",
            "lastName": "Test",
            "email": "test@tcm.fr",
            "phone": null,
            "mobilePhone": "0000000000",
            "description": null,
            "job": "Testeur chez The Coding Machine",
            "society": {
                "id": 334,
                "cosoftId": "39c91b2c-6523-4d02-a31b-a79400815193",
                "name": "The Coding Machine",
                "office": "Bureau 08 (8 pers)",
                "chief": 446
            },
            "coworkingSpace": {
                "id": 2,
                "cosoftId": "99d9e3cf-335f-4760-88c8-a66700937794",
                "name": "Lyon"
            },
            "photoUrl": "https://media.fteledition.fr/Uploads/8f2abbf0-4d82-4d1b-82c8-97e5df9b2170/profile-default.jpg?autorotate=true&crop=0,0,300,300&",
            "joinedAt": "2018-08-03 15:24:13",
            "tags": [
                {
                    "id": 1,
                    "cosoftId": "ae949b8c-fbdf-46d4-832d-a50c00e984cb",
                    "name": "informatique",
                    "coworkerId": 1
                },
                {
                    "id": 2,
                    "cosoftId": "aeb9c498-ffbd-832d-46d4-5ce90acb0084",
                    "name": "business development",
                    "coworkerId": 1
                }
            ]
        },

        // ...
    ]
}
```

#### <a id="get-coworkers-search"></a> `GET /coworkers/search`

Retourne la liste des coworkers dont le nom ou le prénom contient la recherche en paramètre.

*Requête paginée : 10 entrées max retournées*

- **Paramètres**

| Nom             | Type             | Description                |
| :-------------- | :--------------- | :------------------------- |
| `search`        | `string`         | La chaîne recherchée       |
| `page`          | `integer`        | Index pagination           |


- **Réponse**

```
{
    "current_page": 2,
    "first_page_url": "http://nowco.thecodingmachine.com/api/coworkers/search?page=1",
    "from": 11,
    "last_page": 7,
    "last_page_url": "http://nowco.thecodingmachine.com/api/coworkers/search?page=7",
    "next_page_url": "http://nowco.thecodingmachine.com/api/coworkers/search?page=3",
    "path": "http://nowco.thecodingmachine.com/api/coworkers/search",
    "per_page": 10,
    "prev_page_url": "http://nowco.thecodingmachine.com/api/coworkers/search?page=1",
    "to": 20,
    "total": 62,
    "data": [
        {
            "id": 1356,
            "cosoftId": "a8e83b3d-e832-4ed0-aa60-a93100cf2634",
            "firstName": "Utilisateur ",
            "lastName": "Test",
            "email": "test@tcm.fr",
            "phone": null,
            "mobilePhone": "0000000000",
            "description": null,
            "job": "Testeur chez The Coding Machine",
            "society": {
                "id": 334,
                "cosoftId": "39c91b2c-6523-4d02-a31b-a79400815193",
                "name": "The Coding Machine",
                "office": "Bureau 08 (8 pers)",
                "chief": 446
            },
            "coworkingSpace": {
                "id": 2,
                "cosoftId": "99d9e3cf-335f-4760-88c8-a66700937794",
                "name": "Lyon"
            },
            "photoUrl": "https://media.fteledition.fr/Uploads/8f2abbf0-4d82-4d1b-82c8-97e5df9b2170/profile-default.jpg?autorotate=true&crop=0,0,300,300&",
            "joinedAt": "2018-08-03 15:24:13",
            "tags": [
                {
                    "id": 1,
                    "cosoftId": "ae949b8c-fbdf-46d4-832d-a50c00e984cb",
                    "name": "informatique",
                    "coworkerId": 1
                },
                {
                    "id": 2,
                    "cosoftId": "aeb9c498-ffbd-832d-46d4-5ce90acb0084",
                    "name": "business development",
                    "coworkerId": 1
                }
            ]
        },

        // ...
    ]
}
```


#### <a id="get-coworkers-coworker"></a> `GET /coworkers/{coworker}`

Retourne les informations d'un coworker.

- **Paramètres**

| Nom             | Type             | Description                |
| :-------------- | :--------------- | :------------------------- |
| `coworker`      | `integer`        | ID du coworker             |

- **Réponse**

```
{
    "id": 1356,
    "cosoftId": "a8e83b3d-e832-4ed0-aa60-a93100cf2634",
    "firstName": "Utilisateur ",
    "lastName": "Test",
    "email": "test@tcm.fr",
    "phone": null,
    "mobilePhone": "0000000000",
    "description": null,
    "job": "Testeur chez The Coding Machine",
    "society": {
        "id": 334,
        "cosoftId": "39c91b2c-6523-4d02-a31b-a79400815193",
        "name": "The Coding Machine",
        "office": "Bureau 08 (8 pers)",
        "chief": 446
    },
    "coworkingSpace": {
        "id": 2,
        "cosoftId": "99d9e3cf-335f-4760-88c8-a66700937794",
        "name": "Lyon"
    },
    "photoUrl": "https://media.fteledition.fr/Uploads/8f2abbf0-4d82-4d1b-82c8-97e5df9b2170/profile-default.jpg?autorotate=true&crop=0,0,300,300&",
    "joinedAt": "2018-08-03 15:24:13",
    "tags": [
        {
            "id": 1,
            "cosoftId": "ae949b8c-fbdf-46d4-832d-a50c00e984cb",
            "name": "informatique",
            "coworkerId": 1
        },
        {
            "id": 2,
            "cosoftId": "aeb9c498-ffbd-832d-46d4-5ce90acb0084",
            "name": "business development",
            "coworkerId": 1
        }
    ]
}
```
