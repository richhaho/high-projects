<?php

namespace App\Console\Commands;

use App\Services\BadgeService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class Badge extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'badge:run';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create badges for users';

    /**
     * @var BadgeService
     */
    private $service;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(BadgeService $service)
    {
        parent::__construct();

        $this->service = $service;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        DB::transaction(function () {
            $this->service->run();
        });
    }
}
