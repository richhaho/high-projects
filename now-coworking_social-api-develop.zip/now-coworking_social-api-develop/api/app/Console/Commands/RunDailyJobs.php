<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class RunDailyJobs extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cron:daily';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Runs NowSocial API calculations that need to be performed daily at midnight';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->call('db:sync');
        $this->call('mix:run');
        $this->call('badge:run');
    }
}
