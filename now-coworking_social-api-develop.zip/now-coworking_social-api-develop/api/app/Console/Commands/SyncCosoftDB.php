<?php

namespace App\Console\Commands;

use App\Services\CosoftSyncService;
use Illuminate\Console\Command;

class SyncCosoftDB extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'db:sync';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Synchronize database with Cosoft API';

    /**
     * The sync service.
     *
     * @var CosoftSyncService
     */
    protected $cosoftSyncService;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(CosoftSyncService $cosoftSyncService)
    {
        parent::__construct();

        $this->cosoftSyncService = $cosoftSyncService;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->cosoftSyncService->synchronizeDatabase();
    }
}
