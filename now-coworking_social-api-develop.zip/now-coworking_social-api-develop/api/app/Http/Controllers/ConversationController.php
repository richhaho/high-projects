<?php

namespace App\Http\Controllers;

use App\Events\NewMessage;
use App\Http\Requests\GetConversationMessagesRequest;
use App\Http\Requests\NewConversationRequest;
use App\Http\Requests\NewMessageRequest;
use App\Http\Requests\SearchConversationRequest;
use App\Http\Requests\SetFavoriteRequest;
use App\Models\Conversation;
use App\Models\Message;
use App\Models\PredefinedMessages;
use App\Services\NotificationService;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;
use Symfony\Component\HttpKernel\Exception\UnprocessableEntityHttpException;

class ConversationController extends Controller
{
    public function search(SearchConversationRequest $request)
    {
        $user = Auth::user();

        $conversations = Conversation::with([
                'lastMessage' => function ($query) {
                    $query
                        ->with('author:id,lastName,firstName')
                    ;
                },
                'partners:id,lastName,firstName,photoUrl',
                'me:favorite,last_read'
            ])
            ->join('conversation_user', function ($join) use ($user) {
                $join->on('conversation_user.conversation_id', '=', 'conversations.id')
                    ->on('conversation_user.user_id', '=', DB::raw($user->getKey()));
            })
            ->select([
                'id',
            ])
            ->orderBy('updated_at', 'desc')
            ->orderBy('id', 'desc')
            ->paginate(10)
        ;

        $conversations = Conversation::countUnread($conversations);

        return response()->json($conversations);
    }

    /**
     * @param Conversation $conversation
     * @return \Illuminate\Http\JsonResponse
     */
    public function get(Conversation $conversation)
    {
        $user = Auth::user();

        if (!$conversation->users->contains($user)) {
            throw new UnauthorizedHttpException('session');
        }

        $conversation->load([
            'partners:id,lastName,firstName,photoUrl',
            'me:favorite,last_read'
        ]);

        return response()->json($conversation);
    }

  /**
   * @param Conversation $conversation
   * @param GetConversationMessagesRequest $request
   * @return \Illuminate\Http\JsonResponse
   */
    public function getMessages(Conversation $conversation, GetConversationMessagesRequest $request)
    {
        $user = Auth::user();

        if (!$conversation->users->contains($user)) {
            throw new UnauthorizedHttpException('Session');
        }

        $messages = $conversation->messages()
            ->with('author:id,firstname,lastname,photoUrl')
            ->select(['id','content','file','author_id','created_at'])
            ->orderByDesc('created_at')
            ->orderByDesc('id')
            ->limit(10)
            ->when($request->get('filters'), function ($query, $filters) {
                if (isset($filters['before']) && $filters['before']) {
                    $query->where('messages.id', '<', $filters['before']);
                }
            })
            ->get();

        foreach ($messages as $message) {
            if ($message->file !== null) {
                $message->file = asset($message->file, true);
            }
        }

        return response()->json($messages);
    }

    /**
     * @param Conversation $conversation
     * @param NewMessageRequest $request
     * @param NotificationService $notificationService
     * @return \Illuminate\Http\JsonResponse
     */
    public function newMessage(
        Conversation $conversation,
        NewMessageRequest $request,
        NotificationService $notificationService
    ) {
        $user = Auth::user();

        if (!$conversation->users->contains($user)) {
            throw new UnauthorizedHttpException('session');
        }

        $fileURL = null;

        if (array_get($request, 'file', false)) {
            $path = $request->file('file')->store('public/files');
            $fileURL = Storage::url($path);
        }

        $message = Message::create([
            'conversation_id'   => $conversation->id,
            'author_id'         => $user->id,
            'content'           => strip_tags($request->get('content')),
            'file'              => $fileURL,
        ]);

        $conversation->touch();

        event(new NewMessage($message));

        $data = [
            'conversationId' => strval($conversation->id),
        ];

        foreach ($conversation->partners as $partner) {
            $notificationService->sendNotificationWithData(
                $partner,
                $data,
                "Nouveau message de " . $user->firstName . " " . $user->lastName,
                $request->get('content') ?: ''
            );
        }


        return response()->json($message);
    }

    /**
     * @param Conversation $conversation
     * @return \Illuminate\Contracts\Routing\ResponseFactory|\Symfony\Component\HttpFoundation\Response
     */
    public function readMessages(Conversation $conversation)
    {
        $conversation->markAsRead();
        return response(null, 204);
    }

    /**
     * @param Conversation $conversation
     * @param SetFavoriteRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function setFavorite(Conversation $conversation, SetFavoriteRequest $request)
    {
        $user = Auth::user();
        $conversation->users()->updateExistingPivot($user->id, ['favorite' => $request->get('state')]);
        $newState = $conversation->users()->withPivot('favorite')->find($user->id)->pivot->favorite;

        return response()->json(['newState' => $newState]);
    }

    /**
     * @param NewConversationRequest $request
     * @return \Illuminate\Http\JsonResponse|mixed
     */
    public function new(NewConversationRequest $request)
    {
        $users = [$request->get('partner_id'), Auth::id()];

        if (($conversationId = Conversation::existsBetweenUsers($users)) !== false) {
            return response()->json([
                'message'   => 'Une conversation existe déjà avec ce coworker',
                'code'      => 'exists',
                'data'      => [
                    'conversation' => Conversation::find($conversationId)->load([
                        'partners:id,lastName,firstName,photoUrl',
                        'me:favorite,last_read'
                    ]),
                ]
            ], 422);
        }

        if (count(array_unique($users)) === 1) {
            throw new UnprocessableEntityHttpException('Il n\'est jamais simple de se parler à soi-même...');
        }

        return DB::transaction(function () use ($users) {
            $conversation = Conversation::create();
            $conversation->users()->attach($users, ['favorite' => 0]);
            $conversation->save();

            $conversation = $conversation->load([
                'partners:id,lastName,firstName,photoUrl',
                'me:favorite,last_read'
            ]);
            $conversation->favorite = 0;

            return response()->json($conversation);
        });
    }

    /**
     * @param Conversation $conversation
     * @return \Illuminate\Http\JsonResponse
     */
    public function fetchPredefinedMessages(Conversation $conversation)
    {
        $predefinedMessages = PredefinedMessages::all();
        foreach ($predefinedMessages as $message) {
            $message->content = $message->customize($conversation);
        }

        return response()->json($predefinedMessages);
    }

    /**
     * @return \Illuminate\Http\JsonResponse
     */
    public function fetchNbUnreadMessages()
    {
        return response()->json(Conversation::countUnreadMessages());
    }
}
