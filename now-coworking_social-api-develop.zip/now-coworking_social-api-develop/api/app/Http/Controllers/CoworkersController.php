<?php

namespace App\Http\Controllers;

use App\Http\Requests\SearchRequest;
use App\Models\CoworkingSpace;
use App\Models\Society;
use App\Models\User as Coworker;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class CoworkersController extends Controller
{
    /**
     * Get coworkers (searching enabled) (paginated)
     *
     * @param SearchRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function search(SearchRequest $request)
    {
        $coworkers = Coworker::with(['society', 'coworkingSpace', 'tags', 'badges'])
            ->select('users.*')
            ->where('isBanned', '=', 0)
            ->join('societies', 'societies.id', '=', 'users.society')
            ->where(function ($query) {
                $query->whereIn('societies.cosoftId', $this->getSocietiesListId());
                $query->orWhere('credit', '>=', 0);
            })
            ->when($request->get('search'), function ($query) use ($request) {
                return $query->whereIn('users.id', $this->filterSearch(explode(' ', $request->get('search'))));
            })
            ->when($request->get('favorite'), function ($query) {
                return $query->whereIn('users.id', $this->filterFavorite());
            })
            ->when($request->get('staff'), function ($query) {
                return $query->whereIn('users.id', $this->filterStaff());
            })
            ->orderBy('joinedAt', 'desc')
            ->paginate(10);

        return response()->json($coworkers);
    }

    /**
     * @return array
     */
    private function getSocietiesListId(): array
    {
        $societies_cosoft_ids = config('services.cosoft.societies_ids');

        return explode(',', $societies_cosoft_ids);
    }

    /**
     * @param array $keywords
     * @return array
     */
    private function filterSearch(array $keywords = [])
    {
        $where = [];
        $searchKeywords = [];
        foreach ($keywords as $key => $keyword) {
            $where[] =
                "CONCAT(
                    users.firstName, ' ',
                    users.lastName, ' ',
                    coworking_spaces.name, ' ',
                    COALESCE((
                            SELECT GROUP_CONCAT(tags.name)
                            FROM coworker_tags
                            INNER JOIN tags on tags.id = coworker_tags.tagId
                            WHERE coworker_tags.coworkerId = users.id
                            GROUP by coworker_tags.coworkerId
                    ), ' '),
                    COALESCE(societies.name, ' ')
                ) LIKE ?";

            $searchKeywords[] = '%' . $keyword . '%';
        }

        $where = implode(" AND ", $where);

        $queryId = DB::select("
            SELECT users.id
            FROM users  INNER JOIN societies ON societies.id = users.society
                        INNER JOIN coworking_spaces ON coworking_spaces.id = users.coworkingSpace
            WHERE $where
        ", $searchKeywords);

        $results = array();
        foreach ($queryId as $item) {
            array_push($results, (string) $item->id);
        }

        return $results;
    }

    /**
     * @return array
     */
    private function filterFavorite()
    {
        $favoriteConversations = DB::table('conversation_user')
            ->where('user_id', '=', Auth::id())
            ->where('favorite', '=', 1)
            ->pluck('conversation_id')
        ;

        if ($favoriteConversations->count() <= 0) {
            return [];
        }

        $favoriteUsers = DB::table('conversation_user')
            ->where('user_id', '!=', Auth::id())
            ->whereIn('conversation_id', $favoriteConversations->toArray())
            ->pluck('user_id')
        ;

        return $favoriteUsers->toArray();
    }

    /**
     * Load staff users
     * @return array
     */
    private function filterStaff()
    {
        return DB::table('users')
            ->join('societies', function ($join) {
                $join
                   ->on('societies.id', '=', 'users.society')
                   ->on('societies.name', 'like', DB::raw('"%Now Coworking%"'))
                ;
            })->pluck('users.id')
            ->toArray()
        ;
    }

    /**
     * Fetch one coworker
     *
     * @param Coworker $coworker
     * @return \Illuminate\Http\JsonResponse
     */
    public function get(Coworker $coworker)
    {
        $coworker->load(['society', 'coworkingSpace', 'tags', 'badges']);

        return response()->json($coworker);
    }
}
