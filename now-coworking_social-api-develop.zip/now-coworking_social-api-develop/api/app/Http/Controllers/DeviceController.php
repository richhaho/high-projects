<?php

namespace App\Http\Controllers;

use App\Http\Requests\DeviceRequest;
use App\Models\Device;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class DeviceController extends Controller
{

    /**
     * Update or create the device token of a given user
     * @param DeviceRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function createOrUpdate(DeviceRequest $request)
    {
        $device = Device::updateOrCreate(
            ['user_id' => Auth::user()->id],
            ['device_token' => $request->get('token')]
        );

        return response()->json($device);
    }
}
