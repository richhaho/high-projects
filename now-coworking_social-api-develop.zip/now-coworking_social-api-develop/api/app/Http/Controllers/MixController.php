<?php

namespace App\Http\Controllers;

use App\Http\Requests\SwipeRequest;
use App\Models\Conversation;
use App\Models\CoworkerSwipesLeft;
use App\Models\CoworkingSpace;
use App\Models\Mix;
use App\Models\Society;
use App\Models\User as Coworker;
use App\Models\User;
use App\Services\CoworkerService;
use App\Services\NotificationService;
use Illuminate\Support\Facades\DB;
use Symfony\Component\Translation\Exception\NotFoundResourceException;

class MixController extends Controller
{
    /**
     * Fetch mix list of one coworker
     *
     * @param $coworkerId
     * @return \Illuminate\Http\JsonResponse
     */
    public function getCoworkerMixes(Coworker $coworker)
    {
        $coworkerId = $coworker->getKey();
        $swipesLeft = CoworkerSwipesLeft::find($coworkerId)->swipesLeft;

        $mixes = DB::table('mixes')
            ->whereNull('deleted_at')
            ->where(function ($query) use ($coworkerId) {
                $query
                    ->where(function ($query) use ($coworkerId) {
                        $query
                            ->where('coworker1', $coworkerId)
                            ->whereNull('hasSwiped1');
                    })
                    ->orWhere(function ($query) use ($coworkerId) {
                        $query
                            ->where('coworker2', $coworkerId)
                            ->whereNull('hasSwiped2');
                    });
            })
            ->orderBy('score', 'desc')
            ->take($swipesLeft)
            ->get();

        $result = [];
        $ownerTags = Coworker::find($coworkerId)->tags()->get();
        foreach ($mixes as $mix) {
            $swipeId = ($mix->coworker1 === (int) $coworkerId) ? $mix->coworker2 : $mix->coworker1;
            $coworker = Coworker::find($swipeId);
            $coworker->society = Society::find($coworker->society);
            $coworker->coworkingSpace = CoworkingSpace::find($coworker->coworkingSpace);
            $coworker->tags = $coworker->tags()->get();
            $commonTags = [];
            foreach ($coworker->tags as $tag) {
                foreach ($ownerTags as $ownTag) {
                    if ($tag->id === (int) $ownTag->id) {
                        $commonTags[] = $tag;
                    }
                }
            }
            $swipe = [
                'coworker'      => $coworker,
                'commonTags'    => $commonTags,
                'wantMix'       => ($mix->coworker1 === (int) $coworkerId) ? $mix->hasSwiped2 : $mix->hasSwiped1,
            ];
            $result[] = $swipe;
        }

        return response()->json($result);
    }

    /**
     * Request swipe action
     *
     * @param Coworker $coworker
     * @param $swipedCoworkerId
     * @param SwipeRequest $request
     * @param NotificationService $notificationService
     * @return \Illuminate\Http\JsonResponse
     */
    public function swipe(
        Coworker $coworker,
        $swipedCoworkerId,
        SwipeRequest $request,
        NotificationService $notificationService,
        CoworkerService $service
    ) {
        return DB::transaction(
            function () use ($service, $coworker, $swipedCoworkerId, $request, $notificationService) {
                $coworkerId = $coworker->getKey();
                $mix = Mix::where(function ($query) use ($coworkerId, $swipedCoworkerId) {
                    $query
                    ->where('coworker1', $coworkerId)
                    ->where('coworker2', $swipedCoworkerId);
                })->orWhere(function ($query) use ($coworkerId, $swipedCoworkerId) {
                    $query
                    ->where('coworker1', $swipedCoworkerId)
                    ->where('coworker2', $coworkerId);
                })->first();

                if ($mix === null) {
                    throw new NotFoundResourceException('Mix not found');
                }

                if ($mix->coworker1 === (int) $coworkerId) {
                    $mix->hasSwiped1 = (int) $request->get('action');
                } else {
                    $mix->hasSwiped2 = (int) $request->get('action');
                }

            //if both want
                if ((int) $mix->hasSwiped1 === 1 && (int) $mix->hasSwiped2 === 1) {
                    $other = User::find($swipedCoworkerId);

                    $coworker->inside = $service->getCoworkerById($coworker->cosoftId)->IsInsideCoworkingSpace;//current
                    $other->inside = $service->getCoworkerById($other->cosoftId)->IsInsideCoworkingSpace;

                    $this->mixNotification($coworker, $other, $notificationService);
                    $this->mixNotification($other, $coworker, $notificationService);

                    $conversation = Conversation::create();
                    $conversation->users()->attach([$coworkerId, $swipedCoworkerId], ['favorite' => 0]);
                    $conversation->save();
                }

                $coworkerSwipesLeft = CoworkerSwipesLeft::find($coworkerId);
                $coworkerSwipesLeft->swipesLeft--;
                $coworkerSwipesLeft->save();
                $mix->save();

                return response()->json($mix);
            }
        );
    }

    private function mixNotification(User $target, User $other, NotificationService $notificationService)
    {
        $title = $target->firstName . ' veut aussi te rencontrer.';

        if ($target->inside && $other->inside) {
            return $notificationService->sendNotification(
                $target,
                $title,
                'Profitez d’une capsule de Nespresso gratuite. Écrivez-lui !'
            );
        }
        if ($target->inside && !$other->inside) {
            return $notificationService->sendNotification(
                $target,
                $title,
                "A son retour dans l’espace de coworking, n’oubliez pas de lui proposer un café. Écrivez-lui !"
            );
        }
        return $notificationService->sendNotification(
            $target,
            $title,
            "A votre retour dans l’espace de coworking, n’oubliez pas de lui proposer un café. Écrivez-lui !"
        );
    }
}
