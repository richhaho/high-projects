<?php

namespace App\Http\Controllers;

use App\Http\Requests\AddCommentRequest;
use App\Http\Requests\CreatePostRequest;
use App\Http\Requests\PublicationRequest;
use App\Services\PublicationService;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpKernel\Exception\UnprocessableEntityHttpException;

class PublicationController extends Controller
{

    /**
     * Get the list of the groups and channels for a user
     * @param User $user
     * @param PublicationService $client
     * @return \Illuminate\Http\JsonResponse
     */
    public function getUserGroup(PublicationService $client)
    {
        $user = Auth::user();
        $groups = $client->getGroupForUser($user->cosoftId);
        return response()->json($groups);
    }

    /**
     * Get a post by it's Id
     * @param $postId
     * @param PublicationService $client
     * @return \Illuminate\Http\JsonResponse
     */
    public function getPost($postId, PublicationService $client)
    {
        $postApi = $client->getPost($postId);
        $postApi->AuthorAppId = User::firstOrNew(['cosoftId' => $postApi->AuthorId])->getKey();
        $postApi->Content = strip_tags(html_entity_decode($postApi->Content, ENT_QUOTES), '<p><br>');
        $postApi->Content = preg_replace('/<br?[ ]?\\/>/i', "\n", $postApi->Content);
        $postApi->Content = preg_replace('/<p>/i', '', $postApi->Content);
        $postApi->Content = preg_replace('/<\\/p>(?=.+)/i', "\n", $postApi->Content);
        $postApi->Content = preg_replace('/<\\/p>/i', '', $postApi->Content);

        $postApi->AuthorPicture = preg_replace(
            '/\\?.*/',
            '?autorotate=true&width=300&height=300&',
            $postApi->AuthorPicture
        ); // Replace query string

        foreach ($postApi->Answers as $answer) {
            $answer->AuthorAppId = User::firstOrNew(['cosoftId' => $answer->AuthorId])->getKey();
            $answer->Content = strip_tags(html_entity_decode($answer->Content, ENT_QUOTES), '<p><br>');
            $answer->Content = preg_replace('/<br?[ ]?\\/>/i', "\n", $answer->Content);
            $answer->Content = preg_replace('/<p>/i', '', $answer->Content);
            $answer->Content = preg_replace('/<\\/p>(?=.+)/i', "\n", $answer->Content);
            $answer->Content = preg_replace('/<\\/p>/i', '', $answer->Content);
        }

        return response()->json($postApi);
    }

    /**
     * Get a list of publications based on a channel
     * @param String $group
     * @param String $channel
     * @param PublicationRequest $rq
     * @param PublicationService $client
     * @return \Illuminate\Http\JsonResponse
     */
    public function getChannelPublications($group, $channel, PublicationRequest $rq, PublicationService $client)
    {
        $user = Auth::user();
        $publications = $client->getPublications(
            $user->cosoftId,
            $group,
            $channel,
            $rq->get('page'),
            $rq->get('pageSize')
        );
        if (!isset($publications->Publications) || !is_array($publications->Publications)) {
            throw new UnprocessableEntityHttpException();
        }

        $publicationApi=[];

        foreach ($publications->Publications as $publication) {
            $publicationApi[] = [
                "Id"                => $publication->Id,
                "Date"              => $publication->Date,
                "Title"             => $publication->Title,
                "AuthorId"          => $publication->AuthorId,
                "AuthorAppId"       => User::firstOrNew(['cosoftId'=> $publication->AuthorId])->getKey(),
                "AuthorFirstName"   => $publication->AuthorFirstName,
                "AuthorLastName"    => $publication->AuthorLastName,
                "Answers"           => count($publication->Answers),
                "ChannelId"         => $publication->ChannelId,
                "ChannelName"       => $publication->ChannelName,
                "GroupId"           => $publication->GroupId,
                "GroupName"         => $publication->GroupName,
            ];
        }
        return response()->json($publicationApi);
    }

    /**
     * Create a post for the authenticated user
     * @param $group
     * @param $channel
     * @param CreatePostRequest $rq
     * @param PublicationService $client
     * @return \Illuminate\Http\JsonResponse
     */
    public function createPost($group, $channel, CreatePostRequest $rq, PublicationService $client)
    {
        $user = Auth::user();
        $content = nl2br($rq->get('content'));
        $publication = $client->createPost($user->cosoftId, $channel, $rq->get('title'), $content);
        $publicationApi = [
            'Id'                => $publication->Id,
            'Date'              => $publication->Date,
            'Title'             => $publication->Title,
            'Content'           => strip_tags(html_entity_decode($publication->Content, ENT_QUOTES)),
            'AuthorId'          => $publication->AuthorId,
            'AuthorAppId'       => User::firstOrNew(['cosoftId'=> $publication->AuthorId])->getKey(),
            'AuthorFirstName'   => $publication->AuthorFirstName,
            'AuthorLastName'    => $publication->AuthorLastName,
            'AuthorPicture'     => $publication->AuthorPicture,
            'Answers'           => $publication->Answers,
            'ChannelId'         => $publication->ChannelId,
            'ChannelName'       => $publication->ChannelName,
            'GroupId'           => $publication->GroupId,
            'GroupName'         => $publication->GroupName,
        ];
        return response()->json($publicationApi);
    }

    /**
     * Add a comment for the authenticated user in a post
     * @param $post
     * @param AddCommentRequest $rq
     * @param PublicationService $client
     * @return \Illuminate\Http\JsonResponse
     */
    public function createPostComment(string $post, AddCommentRequest $rq, PublicationService $client)
    {
        $user = Auth::user();
        $publication = $client->createComment($user->cosoftId, $post, $rq->get('content'));
        $publicationApi = [
            'Id'                => $publication->Id,
            'Date'              => $publication->Date,
            'Title'             => $publication->Title,
            'Content'           => strip_tags(html_entity_decode($publication->Content, ENT_QUOTES)),
            'AuthorId'          => $publication->AuthorId,
            'AuthorAppId'       => User::firstOrNew(['cosoftId'=> $publication->AuthorId])->getKey(),
            'AuthorFirstName'   => $publication->AuthorFirstName,
            'AuthorLastName'    => $publication->AuthorLastName,
            'AuthorPicture'     => $publication->AuthorPicture,
            'Answers'           => $publication->Answers,
            'ChannelId'         => $publication->ChannelId,
            'ChannelName'       => $publication->ChannelName,
            'GroupId'           => $publication->GroupId,
            'GroupName'         => $publication->GroupName,
        ];
        return response()->json($publicationApi);
    }
}
