<?php

namespace App\Http\Controllers;

use App\Http\Requests\Users\CheckAuthRequest;
use App\Http\Requests\Users\LoginRequest;
use App\Libraries\CosoftClient;
use App\Models\CoworkingSpace;
use App\Models\Society;
use App\Models\User as Coworker;
use App\Services\CosoftSyncService;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpKernel\Exception\UnprocessableEntityHttpException;

class UserController extends Controller
{
    use ThrottlesLogins {
        maxAttempts as protected maxAttemptsTrait;
    }

    protected $maxAttempts;

    protected function maxAttempts()
    {
        $this->maxAttempts = config('auth.max_attempts');
        return $this->maxAttemptsTrait();
    }

    /**
     * Get the login username to be used by the controller.
     *
     * @return string
     */
    protected function username()
    {
        return 'email';
    }

    /**
     * Connect a user with email and password
     *
     * @param LoginRequest $request
     * @param CosoftClient $cosoftClient
     * @return \Illuminate\Http\JsonResponse
     * @throws ValidationException
     */
    public function login(LoginRequest $request, CosoftClient $cosoftClient)
    {
        // Check if too many login with wrong credentials
        if ($this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);
            return $this->sendLockoutResponse($request);
        }

        // First, find user in CoSoft API with given email
        $foundUser = $cosoftClient->get('/Coworkers/GetByEmail', [
            'email'     => $request->get('email'),
        ]);
        if (!$foundUser) {
            throw ValidationException::withMessages([
                'email' => 'Invalid email address',
            ]);
        }

        // Sync user on login attempt
        $cosoftSyncService = resolve(CosoftSyncService::class);
        $foundUser->CoworkingSpaceName = $foundUser->CoworkingSpace;
        $cosoftSyncService->synchronizeCoworker($foundUser);

        $user = Coworker::where('cosoftId', $foundUser->Id)->first();
        if (!$user) {
            throw new UnprocessableEntityHttpException('User not found');
        }

        // Attempt authentication
        $checkAuth = $cosoftClient->post('/Coworkers/CheckAuth', [
            'email'     => $request->get('email'),
            'password'  => $request->get('password'),
        ]);

        // If login failed, increment login attempt
        if ($checkAuth !== "ok") {
            $this->incrementLoginAttempts($request);
            throw new UnprocessableEntityHttpException('Invalid credentials');
        }

        // If everything is ok, log user in (remember if needed)
        Auth::login($user, $request->get('stay_connected'));
        $this->clearLoginAttempts($request);

        $user->society = Society::find($user->society);
        $user->coworkingSpace = CoworkingSpace::find($user->coworkingSpace);
        $user->tags = $user->tags()->get();

        return response()->json($user);
    }

    /**
     * Logout a connected user
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout()
    {
        Auth::logout();
        return response()->json(null, 200);
    }

    /**
     * Get connected user
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function fetch(Request $request)
    {
        $user = Coworker::find($request->user()->getKey());
        $user->society = Society::find($user->society);
        $user->coworkingSpace = CoworkingSpace::find($user->coworkingSpace);
        $user->tags = $user->tags()->get();

        return response()->json($user);
    }
}
