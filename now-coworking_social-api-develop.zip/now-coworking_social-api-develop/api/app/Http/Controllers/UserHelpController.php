<?php

namespace App\Http\Controllers;

use App\Http\Requests\UserHelpSaveRequest;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpKernel\Exception\UnprocessableEntityHttpException;

class UserHelpController extends Controller
{
    public function save(UserHelpSaveRequest $request)
    {
        $user = Auth::user();

        $helper = User::find($request->get('helper'));

        if ($user->society === $helper->society) {
            throw new UnprocessableEntityHttpException('Vous ne pouvez recevoir de coups de main de vos collègues.');
        }

        $hasAlreadyHelpedToday = $user->helps()
            ->where('helper_id', '=', $request->get('helper'))
            ->where(
                DB::raw('DATE_FORMAT(helps.created_at, "%Y-%m-%d")'),
                '=',
                Carbon::now()->toDateString()
            )
            ->count();

        if ($hasAlreadyHelpedToday > 0) {
            throw new UnprocessableEntityHttpException("Ce coworker vous a déjà donné un coup de main aujourd'hui.");
        }

        $newHelp = $user
            ->helps()
            ->save($user, [
                'helper_id' => $request->get('helper'),
                'created_at' => Carbon::now(),
                'updated_at' => Carbon::now()
            ]);

        return response()->json($newHelp);
    }
}
