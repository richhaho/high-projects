<?php

namespace App\Http\Middleware;

use App\Models\User;
use Closure;
use Symfony\Component\HttpKernel\Exception\UnauthorizedHttpException;

class UserCanAccess
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ($parameters = $request->route()->parameters()) {
            foreach ($parameters as $parameter) {
                if ($parameter instanceof User) {
                    if ($parameter->getKey() !== $request->user()->getKey()) {
                        throw new UnauthorizedHttpException('Session');
                    }
                }
            }
        }
        return $next($request);
    }
}
