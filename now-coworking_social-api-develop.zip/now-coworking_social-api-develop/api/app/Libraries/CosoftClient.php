<?php

namespace App\Libraries;

use App\Libraries\CurlApi;
use Psr\Http\Message\ResponseInterface;
use Symfony\Component\HttpKernel\Exception\HttpException;

class CosoftClient
{
    use CurlApi;

    /**
     * Return URL used for API call
     * @return string
     */
    protected function url()
    {
        return config('services.cosoft.api_url');
    }

    /**
     * Return all headers always put in requests
     * @return array
     */
    protected function headers()
    {
        return [
            'App-Secret' => config('services.cosoft.api_secret'),
            'App-Id' => config('services.cosoft.api_id'),
        ];
    }

    /**
     * Return error message from body response
     * @param mixed|ResponseInterface $body
     */
    public function processErrors($response)
    {
        if ($response->getStatusCode() >= 500) {
            throw new HttpException(500, 'generic error');
        }
        if ($response->getStatusCode() >= 300) {
            throw new HttpException(
                $response->getStatusCode(),
                $response->getBody()->getContents()
            );
        }
    }
}
