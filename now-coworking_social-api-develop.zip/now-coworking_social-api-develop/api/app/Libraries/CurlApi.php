<?php

namespace App\Libraries;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\ConnectException;
use GuzzleHttp\Exception\TransferException;
use GuzzleHttp\Handler\MockHandler;
use GuzzleHttp\HandlerStack;
use GuzzleHttp\Middleware;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;
use Psr\Http\Message\ResponseInterface;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Illuminate\Support\Facades\Log;

trait CurlApi
{
    /**
     * @var bool
     */
    protected $debug = false;

    /**
     * @var bool
     */
    protected $log = false;

    /**
     * @var bool
     */
    protected $toArray = false;

    /**
     * @var MockHandler
     */
    protected $mock = null;

    /**
     * @param $resource
     * @param $method
     * @param array $parameters
     * @return mixed|null
     * @throws \HttpException
     */
    private function run($resource, $method, $parameters = [])
    {
        if ($this->isMocked()) {
            $this->processErrors(null); // If client want override processErrors in mocking
            throw new \ErrorException('You can\'t call run() method on mocking'); // If not, throw an exception
        }

        $container = [];
        $history = Middleware::history($container);
        $stack = HandlerStack::create($this->mock);
        $stack->push($history);

        if ($this->log) {
            $logger = new \Monolog\Logger('Logger');
            $logger->pushHandler(new StreamHandler(storage_path('logs/guzzle.log'), Logger::DEBUG));
            $loggermid = Middleware::log(
                $logger,
                new \GuzzleHttp\MessageFormatter(
                    '{method} {uri} HTTP/{version} {req_body} - RESPONSE: {code} - {res_body}'
                )
            );
            $stack->push($loggermid);
        }

        $client = new Client(['handler' => $stack, 'http_errors' => false]);

        try {
            $options = [
                'headers' => $this->headers(),
                'debug' => $this->debug,
            ];

            $options += $parameters;

            $response = $client->request(
                $method,
                (isset($options['multipart']) ? $this->multipartUrl() : $this->url()) . $resource,
                $options
            );
        } catch (TransferException $e) {
            if ($e instanceof ConnectException) {
                throw new HttpException(504, "Could not resolve distant host");
            }
            foreach ($container as $transaction) {
                //TODO IF NEEDED
            }
            throw $e;
        }

        $this->log && $response->getBody()->rewind(); // Rewind when logging because logger is consuming response

        $this->processErrors($response);

        $response->getBody()->rewind(); // Fix missing body
        $body = $response->getBody()->getContents();

        if ($response->getStatusCode() == 204 || !$body) {
            return null;
        }

        return $this->toArray? \GuzzleHttp\json_decode($body, true) : \GuzzleHttp\json_decode($body);
    }

    /**
     * @param $resource
     * @param array $parameters
     * @return mixed|null
     */
    public function get($resource, $parameters = [])
    {
        return $this->run($resource, 'GET', $parameters ? [
            'query' => $parameters,
        ] : []);
    }

    /**
     * @param $resource
     * @param array $parameters
     * @param array $multipart
     * @param array $json
     * @return mixed|null
     */
    public function post($resource, $parameters = [], $multipart = [], $json = [])
    {
        $options = [];

        if ($parameters && $multipart) {
            throw new \InvalidArgumentException('Parameters and multipart not supported, see guzzle multipart doc');
        }

        if ($parameters) {
            $options['form_params'] = $parameters;
        }

        if ($multipart) {
            $options['multipart'] = $multipart;
        }
        if ($json) {
            $options['json'] = $json;
        }

        return $this->run($resource, 'POST', $options);
    }

    /**
     * @param $resource
     * @param array $parameters
     * @return mixed|null
     */
    public function put($resource, $parameters = [])
    {
        return $this->run($resource, 'PUT', $parameters ? [
            'json' => $parameters,
        ] : []);
    }

    /**
     * @param $resource
     * @param array $parameters
     * @return mixed|null
     */
    public function delete($resource, $parameters = [])
    {
        return $this->run($resource, 'DELETE', $parameters ? [
            'query' => $parameters,
        ] : []);
    }

    /**
     * @return string
     */
    protected function multipartUrl() : string
    {
        return $this->url();
    }

    /**
     * Used to avoid mistakes in UnitTest
     * @return bool
     */
    public function isMocked() : bool
    {
        return false;
    }

    /**
     * Set debug mode
     * @param bool $debug
     * @return $this
     */
    public function debug($debug = true) : self
    {
        $this->debug = $debug;
        return $this;
    }

    /**
     * Log request and response in a guzzle log file
     * @param bool $log
     * @return self
     */
    public function log($log = true) : self
    {
        $this->log = $log;
        return $this;
    }
    public function toArray($toArray = true) : self
    {
        $this->toArray = $toArray;
        return $this;
    }
    /**
     * @param MockHandler $mock
     * @return $this
     */
    public function setMock(MockHandler $mock): self
    {
        $this->mock = $mock;
        return $this;
    }

    /**
     * Return URL used for API call
     * @return string
     */
    abstract protected function url();

    /**
     * Return all headers always put in requests
     * @return array
     */
    abstract protected function headers();

    /**
     * Return error message from body response
     * @param mixed|ResponseInterface $body
     */
    abstract public function processErrors($response);
}
