<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Badge extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['user_id', 'type', 'level'];

    /**
     * @var array
     */
    protected $appends = ['image'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * @return string
     */
    public function getImageAttribute()
    {
        $path = 'badges/'.$this->type.'/'.$this->level.'.png';

        if (!file_exists(public_path($path))) {
            return null;
        }

        return asset($path, true);
    }
}
