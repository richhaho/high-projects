<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class Conversation extends Model
{
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = ['pivot'];

    /**
     * Retrieve all users inside the conversation
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function users()
    {
        return $this->belongsToMany(User::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function messages()
    {
        return $this->hasMany(Message::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne|\Illuminate\Database\Query\Builder
     */
    public function lastMessage()
    {
        return $this->hasOne(Message::class)->latest();
    }

    /**
     * Retrieve all users of the conversation except the connected one
     * This method can't be used without connected user
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function partners()
    {
        if (!Auth::check()) {
            throw new \BadMethodCallException();
        }

        return $this->belongsToMany(User::class)->where('users.id', '!=', Auth::user()->getKey());
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function me()
    {
        if (!Auth::check()) {
            throw new \BadMethodCallException();
        }

        return $this->belongsToMany(User::class)
            ->where('users.id', '=', Auth::id())
            ->withPivot(['favorite', 'last_read'])
        ;
    }

    /**
     * Check if a conversation exists between all $users
     *
     * @param array $users user ids
     * @return int|bool existing conversation id or false
     */
    public static function existsBetweenUsers(array $users = [])
    {
        $result = DB::table('conversation_user')
            ->select(['conversation_id', DB::raw('count(user_id) as cnt')])
            ->whereIn('user_id', $users)
            ->groupBy('conversation_id')
            ->having('cnt', '>=', count($users))
            ->first()
        ;

        return $result ? $result->conversation_id : false;
    }

    /**
     * Add the unread field and its value to the list of coversations to show
     *
     * @param $conversations : Collection of conversations
     */
    public static function countUnread($conversations)
    {

        if (count($conversations->items()) <= 0) {
            return $conversations;
        }

        $user = Auth::user();
        $IDs = [];
        foreach ($conversations as $conversation) {
            $IDs[] = $conversation->id;
        }

        $IDs = implode(", ", $IDs);
        $IDs = "(" . $IDs . ")";
        $userID = $user->id;

        $newMessagesNumber = DB::select("
            SELECT conversation_user.conversation_id, count(*) AS unread
            FROM conversation_user INNER JOIN messages ON messages.conversation_id = conversation_user.conversation_id
            WHERE (conversation_user.last_read < messages.created_at
            OR conversation_user.last_read IS NULL)
            AND conversation_user.conversation_id IN $IDs
            AND conversation_user.user_id = $userID
            GROUP BY conversation_user.conversation_id
        ");

        foreach ($newMessagesNumber as $unreadNumber) {
            $unread = $conversations->find($unreadNumber->conversation_id);
            $unread->setattribute('unread', $unreadNumber->unread);
        }

        return $conversations;
    }

    /**
     * Add the unread field and its value to the list of coversations to show
     *
     * @return mixed
     */
    public static function countUnreadMessages()
    {

        $user = Auth::user();

        $userID = $user->id;

        $newMessagesNumber = DB::select("
            SELECT conversation_user.user_id, count(*) AS unread
            FROM conversation_user INNER JOIN messages ON messages.conversation_id = conversation_user.conversation_id
            WHERE (conversation_user.last_read < messages.created_at
            OR conversation_user.last_read IS NULL)
            AND conversation_user.user_id = $userID
            GROUP BY conversation_user.user_id
        ");

        return count($newMessagesNumber) > 0 ? $newMessagesNumber[0]->unread : 0 ;
    }

    /**
     * Update last_read field in conversation_user table
     */
    public function markAsRead()
    {
        $user = Auth::user();
        $this->users()
            ->updateExistingPivot(
                $user,
                ['last_read' => Carbon::now()]
            );
    }
}
