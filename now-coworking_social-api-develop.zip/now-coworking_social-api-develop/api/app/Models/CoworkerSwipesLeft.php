<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CoworkerSwipesLeft extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'coworker_swipes_lefts';

    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    public $timestamps = false;

    public $incrementing = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'id',
        'swipesLeft',
    ];
}
