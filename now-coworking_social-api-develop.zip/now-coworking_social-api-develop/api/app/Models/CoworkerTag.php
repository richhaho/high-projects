<?php

namespace App\Models;

use App\Models\Traits\HasCompositeKeys;
use Illuminate\Database\Eloquent\Model;

class CoworkerTag extends Model
{
    use HasCompositeKeys;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'coworker_tags';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'coworkerId',
        'tagId',
    ];

    public $timestamps = false;

    public $incrementing = false;

    protected $keyType = 'array';

    /**
     * The primary key of the table.
     *
     * @var array
     */
    protected $primaryKey = [ 'coworkerId', 'tagId' ];
}
