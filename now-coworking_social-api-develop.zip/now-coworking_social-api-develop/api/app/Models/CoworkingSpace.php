<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\User as Coworker;

class CoworkingSpace extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'coworking_spaces';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'cosoftId',
        'name',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'created_at', 'updated_at'
    ];

    /**
     * Get the related coworkers
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function coworkers()
    {
        return $this->hasMany(Coworker::class, 'coworkingSpace', 'id');
    }
}
