<?php

namespace App\Models;

use App\Models\Traits\HasCompositeKeys;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Mix extends Model
{
    use SoftDeletes, HasCompositeKeys;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'mixes';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'coworker1',
        'coworker2',
        'hasSwiped1',
        'hasSwiped2',
        'score',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'deleted_at'
    ];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = ['deleted_at'];

    public $timestamps = false;

    public $incrementing = false;

    protected $keyType = 'array';

    /**
     * The primary key of the table.
     *
     * @var array
     */
    protected $primaryKey = [ 'coworker1', 'coworker2' ];
}
