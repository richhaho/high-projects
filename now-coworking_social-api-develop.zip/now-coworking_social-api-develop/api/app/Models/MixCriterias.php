<?php

namespace App\Models;

class MixCriterias
{
    /**
     * Criteria keys class constants
     */
    const NEW_COWORKER      = 0;
    const OFFICE_HEAD       = 1;
    const NOMADS            = 2;
    const ALREADY_MET       = 3;
    const COMMON_TAGS       = 4;
    const COWORKING_SPACE   = 5;

    public static function criteriaKeys()
    {
        return [
            self::NEW_COWORKER,
            self::OFFICE_HEAD,
            self::NOMADS,
            self::ALREADY_MET,
            self::COMMON_TAGS,
            self::COWORKING_SPACE,
        ];
    }

    /**
     * @var array
     */
    protected $criterias = [];

    public function __construct()
    {
        foreach ($this->criteriaKeys() as $criteriaKey) {
            $this->saveCriteriaValue($criteriaKey, null);
        }
    }

    public function saveCriteriaValue($key, $value)
    {
        $this->criterias[$key] = $value;
    }

    public function getCriteriaValue($key)
    {
        return $this->criterias[$key];
    }
}
