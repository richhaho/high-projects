<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PredefinedMessages extends Model
{

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'created_at', 'updated_at'
    ];

    /**
     * Replace variables in predefined messages
     * @param Conversation $conversation
     * @return string
     */
    public function customize(Conversation $conversation)
    {
        $partner = $conversation->partners->first();

        return str_replace_array(':partner_firstname', array($partner->firstName), $this->content);
    }
}
