<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\User as Coworker;

class Society extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'societies';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'cosoftId',
        'name',
        'office',
        'chief',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'created_at', 'updated_at'
    ];

    /**
     * Get the society employees
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function employees()
    {
        return $this->hasMany(Coworker::class, 'society', 'id');
    }

    /**
     * Get the office head
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function chief()
    {
        return $this->hasOne(Coworker::class, 'society', 'id');
    }
}
