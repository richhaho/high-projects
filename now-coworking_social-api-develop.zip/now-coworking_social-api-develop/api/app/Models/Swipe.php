<?php

namespace App\Models;

class Swipe
{
    const SWIPE_STATE_NO = 0;
    const SWIPE_STATE_OK = 1;

    const SWIPE_STATES = [
        self::SWIPE_STATE_NO,
        self::SWIPE_STATE_OK,
    ];
}
