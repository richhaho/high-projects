<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable, SoftDeletes;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'cosoftId',
        'firstName',
        'lastName',
        'email',
        'phone',
        'mobilePhone',
        'description',
        'job',
        'society',
        'coworkingSpace',
        'isBanned',
        'credit',
        'photoUrl',
        'joinedAt',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'pivot', 'remember_token', 'created_at', 'updated_at', 'deleted_at'
    ];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = [
        'deleted_at',
        'joinedAt',
    ];

    /**
     * Get the related coworking space
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function coworkingSpace()
    {
        return $this->belongsTo(
            'App\Models\CoworkingSpace',
            'coworkingSpace',
            'id'
        );
    }

    /**
     * Get the related society
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function society()
    {
        return $this->belongsTo(
            'App\Models\Society',
            'society',
            'id'
        );
    }

    /**
     * Get the related coworkerTags
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function coworkerTags()
    {
        return $this->hasMany(
            'App\Models\CoworkerTag',
            'coworkerId',
            'id'
        );
    }

    /**
     * Get the related tags
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasManyThrough
     */
    public function tags()
    {
        return $this->hasManyThrough(
            'App\Models\Tag',
            'App\Models\CoworkerTag',
            'coworkerId',
            'id',
            'id',
            'tagId'
        );
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function conversations()
    {
        return $this->belongsToMany(Conversation::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function helps()
    {
        return $this->belongsToMany(User::class, 'helps', 'author_id', 'helper_id');
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function device()
    {
        return $this->hasOne(Device::class);
    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function badges()
    {
        return $this->hasMany(Badge::class);
    }
}
