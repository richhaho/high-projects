<?php

namespace App\Providers;

use App\Services\BadgeService;
use Illuminate\Support\ServiceProvider;

class BadgeServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton(BadgeService::class, function () {
            return new BadgeService();
        });
    }
}
