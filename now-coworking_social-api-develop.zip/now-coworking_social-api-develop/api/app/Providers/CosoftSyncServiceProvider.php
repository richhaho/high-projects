<?php

namespace App\Providers;

use App\Services\CosoftSyncService;
use Illuminate\Support\ServiceProvider;

class CosoftSyncServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton(CosoftSyncService::class, function () {
            return new CosoftSyncService();
        });
    }
}
