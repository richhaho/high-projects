<?php

namespace App\Providers;

use App\Services\MixService;
use App\Services\MixServices\CriteriaService;
use App\Services\MixServices\ScoreService;
use Illuminate\Support\ServiceProvider;

class MixServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton(CriteriaService::class, function () {
            return new CriteriaService();
        });
        $this->app->singleton(ScoreService::class, function () {
            return new ScoreService();
        });
        $this->app->singleton(MixService::class, function () {
            return new MixService();
        });
    }
}
