<?php

namespace App\Services;

use App\Models\Badge;
use App\Models\User;
use App\Services\Badges\BadgeInstance;

class BadgeService
{
    /**
     * Crete or update badges for each user in database
     */
    public function run()
    {
        $instances = BadgeInstance::getInstances();

        User::all()->each(function ($user) use ($instances) {
            foreach ($instances as $key => $instance) {
                $instance->setUser($user);

                if (!($level = $instance->getLevel())) {
                    continue;
                }

                Badge::updateOrCreate([
                    'user_id'   => $user->getKey(),
                    'type'      => $key,
                ], [
                    'level'     => $level
                ]);
            }
        });
    }
}
