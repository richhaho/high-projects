<?php

namespace App\Services\Badges;

use App\Models\User;

class BadgeInstance
{
    const LEVEL_GOLD = 'gold';
    const LEVEL_SILVER = 'silver';
    const LEVEL_BRONZE = 'bronze';

    const TYPE_EXISTENCE = 'existence';
    const TYPE_COMMENT = 'comment';
    const TYPE_HELP = 'help';
    const TYPE_CONTRIBUTE = 'contribute';
    const TYPE_PROFILE = 'profile';

    private static $levels = [
        self::TYPE_COMMENT,
        self::TYPE_CONTRIBUTE,
        self::TYPE_EXISTENCE,
        self::TYPE_HELP,
        self::TYPE_PROFILE,
    ];

    protected $user;

    /**
     * @param User $user
     * @return BadgeInstance
     */
    public function setUser(User $user) : BadgeInstance
    {
        $this->user = $user;

        return $this;
    }

    /**
     * @return array
     */
    public static function getInstances()
    {
        $instances = [];
        foreach (self::$levels as $level) {
            $className = 'App\\Services\\Badges\\' . ucfirst($level);
            if (!class_exists($className)) {
                throw new \OutOfBoundsException('Class '.$className.' does not exists');
            }

            $instances[$level] = new $className();
        }

        return $instances;
    }

    /**
     * @return null|string
     */
    public function getLevel()
    {
        return null;
    }
}
