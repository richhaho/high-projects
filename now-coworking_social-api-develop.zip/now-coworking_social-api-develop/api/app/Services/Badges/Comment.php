<?php

namespace App\Services\Badges;

class Comment extends BadgeInstance
{
    public function getLevel()
    {
        // TODO: Implement getLevel() method.
    }
}
