<?php

namespace App\Services\Badges;

class Contribute extends BadgeInstance
{
    public function getLevel()
    {
        return null; // Manual update in database
    }
}
