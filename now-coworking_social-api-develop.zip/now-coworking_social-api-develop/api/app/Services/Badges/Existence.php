<?php

namespace App\Services\Badges;

use Carbon\Carbon;

class Existence extends BadgeInstance
{
    public function getLevel()
    {
        $now = Carbon::now();
        $joined = Carbon::parse($this->user->joinedAt);
        $diff = $now->diffInYears($joined);

        if ($diff >= 3) {
            return self::LEVEL_GOLD;
        } elseif ($diff >= 2) {
            return self::LEVEL_SILVER;
        } elseif ($diff >= 1) {
            return self::LEVEL_BRONZE;
        }

        return null;
    }
}
