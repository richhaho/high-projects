<?php

namespace App\Services\Badges;

use Illuminate\Support\Facades\DB;

class Help extends BadgeInstance
{
    public function getLevel()
    {
        $help = DB::table('helps')
            ->where('helper_id', '=', $this->user->getKey())
            ->count();

        if ($help >= 50) {
            return self::LEVEL_GOLD;
        } elseif ($help >= 25) {
            return self::LEVEL_SILVER;
        } elseif ($help >= 10) {
            return self::LEVEL_BRONZE;
        }

        return null;
    }
}
