<?php

namespace App\Services\Badges;

class Profile extends BadgeInstance
{
    public function getLevel()
    {
        if (!$this->user->photoUrl) {
            return null;
        }

        if (!$this->user->mobilePhone && !$this->user->phone) {
            return null;
        }

        if (!$this->user->description || (strlen($this->user->description) < 30)) {
            return null;
        }

        if ($this->user->tags->count() <= 0) {
            return null;
        }

        return self::LEVEL_GOLD;
    }
}
