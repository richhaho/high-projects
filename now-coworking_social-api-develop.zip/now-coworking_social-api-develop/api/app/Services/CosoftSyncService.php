<?php

namespace App\Services;

use App\Libraries\CosoftClient;
use App\Models\CoworkerTag;
use App\Models\CoworkingSpace;
use App\Models\Society;
use App\Models\Tag;
use App\Models\User as Coworker;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * Class CosoftSyncService
 * @package App\Services
 */
class CosoftSyncService
{
    /**
     * @var CosoftClient
     */
    protected $client;

    /**
     * @var array
     */
    protected $coworkers = [];

    /**
     * CosoftService constructor.
     */
    public function __construct()
    {
        $this->client = resolve(CosoftClient::class);
    }

    /**
     * Launches database synchronization with Cosoft API
     */
    public function synchronizeDatabase()
    {
        Log::info('Database synchronization started at '.Carbon::now());
        Log::info('================================================');
        Log::info('');

        // Setting max_time_limit on database sync to 1 hour
        set_time_limit(3600);

        DB::transaction(function () {
            $this->flushDatabase();
            $this->synchronizeCoworkingSpaces();

            $page = 0;
            while (count($this->coworkers = $this->fetchCoworkers($page))) {
                $this->synchronizeSocieties();
                $this->synchronizeTags();
                foreach ($this->coworkers as $coworker) {
                    $this->synchronizeCoworker($coworker);
                    $this->synchronizeCoworkerTags($coworker);
                }
                $page++;
            }
            $this->fillSocietiesInfo();
        });

        Log::info('');
        Log::info('================================================');
        Log::info('Database synchronization finished at '.Carbon::now());
    }

    /**
     * @param int $page
     * @param int $take
     * @return array|mixed|null
     * @throws \Exception
     */
    protected function fetchCoworkers(int $page = 0, int $take = 100)
    {
        $skip = $page * $take;
        $coworkers = $this->client->get(
            '/Coworkers/GetAll',
            [
                'skip'  => $skip,
                'take'  => $take,
            ]
        );

        return $coworkers;
    }

    protected function flushDatabase()
    {
        $this->flushCoworkers();
        $this->flushSocieties();
    }

    protected function flushCoworkerTags()
    {
        Log::info('Dropping entries from CoworkerTags...');
        DB::table('coworker_tags')->truncate();
    }

    protected function flushCoworkers()
    {
        Log::info('Dropping deleted entries from Users table...');
        DB::update('update users set deleted_at = NOW() where deleted_at is null');
    }

    protected function flushSocieties()
    {
        Log::info('Dropping entries from Society...');
        DB::raw(
            'Delete societies from societies 
                    where societies.id not in ( select society from users where users.deleted_at is null)'
        );
    }

    /**
     * @throws \Exception
     */
    protected function synchronizeCoworkingSpaces()
    {
        Log::info('Starting coworking spaces sync...');

        $coworkingSpacesIds = $this->client->get('/CoworkingSpaces/Get');
        foreach ($coworkingSpacesIds as $coworkingSpaceId) {
            $coworkingSpaceInfo = [
                'cosoftId'  => $coworkingSpaceId->Id,
                'name'      => $coworkingSpaceId->Name,
            ];
            CoworkingSpace::updateOrCreate(
                [ 'cosoftId' => $coworkingSpaceInfo['cosoftId'] ],
                $coworkingSpaceInfo
            );
        }
    }

    /**
     * @throws \Exception
     */
    protected function synchronizeSocieties()
    {
        foreach ($this->coworkers as $coworker) {
            $societyInfo = [
                'cosoftId'  => $coworker->Society->Id,
                'name'      => $coworker->Society->Name,
            ];
            Society::updateOrCreate(
                [ 'cosoftId' => $societyInfo['cosoftId'] ],
                $societyInfo
            );
        }
    }

    /**
     * @throws \Exception
     */
    protected function synchronizeTags()
    {
        foreach ($this->coworkers as $coworker) {
            foreach ($coworker->Tags as $tag) {
                $tagInfo = [
                    'cosoftId'  => $tag->Id,
                    'name'      => $tag->Name,
                ];
                Tag::updateOrCreate(
                    [ 'cosoftId' => $tagInfo['cosoftId'] ],
                    $tagInfo
                );
            }
        }
    }

    /**
     * @param $coworker
     * @throws \Exception
     */
    public function synchronizeCoworker($coworker)
    {
        $now = Carbon::now();
        $coworkingSpace = CoworkingSpace::where([ 'cosoftId' => $coworker->CoworkingSpaceName->Id ])->firstOrFail();
        $society = Society::where([ 'cosoftId' => $coworker->Society->Id ])->firstOrFail();

        $coworkerInfo = [
            'cosoftId'          => $coworker->Id,
            'firstName'         => $coworker->FirstName,
            'lastName'          => $coworker->LastName,
            'email'             => $coworker->Email,
            'phone'             => $coworker->Phone,
            'mobilePhone'       => $coworker->MobilePhone,
            'description'       => $coworker->Description,
            'job'               => $coworker->Society->Job,
            'society'           => $society->id,
            'coworkingSpace'    => $coworkingSpace->id,
            'credit'            => $coworker->Credit,
            'isBanned'          => $coworker->IsBanned,
            'photoUrl'          => str_replace('http://', 'https://', $coworker->PhotoUrl),
            'joinedAt'          => Carbon::parse($coworker->CreationDate)->toDateTimeString(),
        ];

        $coworker = Coworker::withTrashed()->where([ 'cosoftId' => $coworkerInfo['cosoftId'] ])->first();
        if ($coworker === null) {
            Coworker::create($coworkerInfo);
        } else {
            $hasChanged = false;
            foreach ($coworkerInfo as $key => $value) {
                if ($coworker[$key] != $value) {
                    $hasChanged = true;
                    $coworker[$key] = $value;
                }
            }
            if ($hasChanged) {
                Log::info('coworker #'.$coworker->getKey().' hasChanged');
                $coworker->updated_at = $now;
                $coworker->save();
            }
            DB::update(
                'update users set deleted_at = null where cosoftId = :cosoftId',
                [ 'cosoftId' => $coworkerInfo['cosoftId'] ]
            );
        }
    }

    /**
     * @param $coworker
     * @throws \Exception
     */
    protected function synchronizeCoworkerTags($coworker)
    {
        $localCoworker = Coworker::where([ 'cosoftId' => $coworker->Id ])->firstOrFail();
        $localCoworkerTags = $localCoworker->tags->pluck('id')->toArray();

        $hasChanged = false;

        foreach ($coworker->Tags as $tag) {
            // First check if Tag exists in database
            $localTag = Tag::where([ 'cosoftId' => $tag->Id ])->firstOrFail();

            // Check if coworker-tag relation already exists, if not create it
            $coworkerTag = CoworkerTag::firstOrCreate([
                'coworkerId'    => $localCoworker->getKey(),
                'tagId'         => $localTag->getKey(),
            ]);

            // Consider changes if association is just created
            $hasChanged |= $coworkerTag->wasRecentlyCreated;

            // Remove item from coworker tags, used after foreach for deletion
            if (($key = array_search($localTag->getKey(), $localCoworkerTags)) !== false) {
                unset($localCoworkerTags[$key]);
            }
        }

        // Delete extra tags
        if ($localCoworkerTags) {
            foreach ($localCoworkerTags as $localCoworkerTag) {
                DB::table('coworker_tags')
                    ->where('coworkerId', $localCoworker->getKey())
                    ->where('tagId', $localCoworkerTag)
                    ->delete()
                ;
            }

            // Consider changes append
            $hasChanged = true;
        }

        // Update updated_at field to process mixes
        if ($hasChanged) {
            $localCoworker->touch();
        }
    }

    /**
     * @throws \Exception
     */
    protected function fillSocietiesInfo()
    {
        Society::chunk(100, function ($societies) {
            foreach ($societies as $society) {
                $societyInfo = $this->client->get(
                    '/Society/GetById',
                    [ 'societyId' => $society->cosoftId ]
                );
                if (count($societyInfo->CurrentRents) > 0) {
                    $renter = Coworker::where(
                        [ 'cosoftId' => $societyInfo->CurrentRents[0]->Coworker->Id ]
                    )->firstOrFail();
                    $rentPlan = $societyInfo->CurrentRents[0]->Name;
                    $society->office = (strpos(Str::lower($rentPlan), 'nomade') !== false)
                        ? null
                        : $rentPlan;
                    $society->chief = $renter->id;
                    $society->save();
                }
            }
        });
    }
}
