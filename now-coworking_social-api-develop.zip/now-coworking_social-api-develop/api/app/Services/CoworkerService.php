<?php

namespace App\Services;

use App\Libraries\CosoftClient;

class CoworkerService
{
    public $client = null;

    /**
     * CosoftService constructor.
     */
    public function __construct()
    {
        $this->client = resolve(CosoftClient::class);
    }

    /**
     * get a coworker by his id
     * @param $idUser
     * @return mixed
     */
    public function getCoworkerById($idUser)
    {
        return $this->client->get('/Coworkers/GetById', [
            'coworkerId' => $idUser,
        ]);
    }
}
