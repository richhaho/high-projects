<?php

namespace App\Services;

use App\Models\CoworkerSwipesLeft;
use App\Models\CoworkingSpace;
use App\Models\Mix;
use App\Models\Society;
use App\Models\User as Coworker;
use App\Services\MixServices\CriteriaService;
use App\Services\MixServices\ScoreService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

class MixService
{
    /**
     * The mix criteria service.
     *
     * @var CriteriaService
     */
    protected $criteriaService;

    /**
     * The mix score service.
     *
     * @var ScoreService
     */
    protected $scoreService;

    /**
     * MixService constructor.
     */
    public function __construct()
    {
        $this->criteriaService  = resolve(CriteriaService::class);
        $this->scoreService     = resolve(ScoreService::class);
    }

    /**
     * Run Mix matchmaking
     */
    public function runMixEvaluation()
    {
        Log::info('Starting mix score evaluation at '.Carbon::now());
        Log::info('================================================');
        Log::info('');

        // Setting max_time_limit on mix evaluation to 6 hours
        set_time_limit(21600);

        $this->setMixesToUpdate();
        $this->updateScores();
        $this->restoreUnchangedMixes();
        $this->resetSwipesNumber();

        Log::info('');
        Log::info('================================================');
        Log::info('Mix score evaluation finished at '.Carbon::now());
    }

    /**
     * Insert new mixes or restores existing mixes from soft deleted state
     */
    protected function setMixesToUpdate()
    {
        Log::info('Setting active mixes');

        // Setting all mixes to deleted state
        Mix::where('deleted_at', null)->update(['deleted_at' => Carbon::now()]);

        DB::statement(
            'INSERT INTO mixes (coworker1, coworker2)
            SELECT u1.id AS coworker1, u2.id AS coworker2
            FROM users u1 JOIN users u2 ON u1.id < u2.id
            WHERE u1.deleted_at IS NULL
            AND u2.deleted_at IS NULL
            AND u1.isBanned = 0 
            AND u1.credit >= 0
            AND u2.isBanned = 0 
            AND u2.credit >= 0
            AND DATEDIFF(NOW(), u1.updated_at) < 1
            ON DUPLICATE KEY UPDATE deleted_at = null;'
        );
    }

    /**
     * Reset swipes left number to 10 for all coworkers
     */
    protected function resetSwipesNumber()
    {
        Log::info('Resetting swipes number');
        DB::table('coworker_swipes_lefts')->truncate();
        DB::insert(
            'INSERT INTO coworker_swipes_lefts (id)
            SELECT id FROM users'
        );
    }

    /**
     * Run calculation on mix scores that need to be updated
     */
    protected function updateScores()
    {
        Log::info('Updating mix scores');
        $coworkers = [];
        DB::table('mixes')
            ->where('hasSwiped1', null)
            ->orWhere('hasSwiped2', null)
            ->orderBy('coworker1')
            ->chunk(100, function ($mixes) use ($coworkers) {
                foreach ($mixes as $mix) {
                    if (!isset($coworkers[$mix->coworker1])) {
                        $coworkers[$mix->coworker1] = Coworker::find($mix->coworker1);
                    }
                    if (!isset($coworkers[$mix->coworker2])) {
                        $coworkers[$mix->coworker2] = Coworker::find($mix->coworker2);
                    }

                    // If a user is deleted, we can remove all mixes for this user
                    if (!$coworkers[$mix->coworker1]) {
                        DB::table('mixes')
                            ->where('coworker1', '=', $mix->coworker1)
                            ->orWhere('coworker2', '=', $mix->coworker1)
                            ->delete();
                        continue;
                    }
                    if (!$coworkers[$mix->coworker2]) {
                        DB::table('mixes')
                            ->where('coworker1', '=', $mix->coworker2)
                            ->orWhere('coworker2', '=', $mix->coworker2)
                            ->delete();
                        continue;
                    }

                    // Calculate score between users
                    $mixCriterias = $this->criteriaService->evalMixCriterias(
                        $coworkers[$mix->coworker1],
                        $coworkers[$mix->coworker2]
                    );

                    $mixScore = $this->scoreService->calculateScore($mixCriterias);
                    $mix->score = $mixScore;
                    DB::insert(
                        'insert into mixes (coworker1, coworker2)
                        values (:coworker1, :coworker2)
                        on duplicate key update score = :score',
                        [
                            'coworker1' => $mix->coworker1,
                            'coworker2' => $mix->coworker2,
                            'score'     => $mix->score,
                        ]
                    );
                }
            });
    }

    /**
     * Restore unchanged mixes after score update
     */
    protected function restoreUnchangedMixes()
    {
        Log::info('Restoring unchanged mixes');
        DB::update(
            'UPDATE mixes
            SET deleted_at = null
            WHERE (coworker1, coworker2) IN (
              SELECT u1.id AS coworker1, u2.id AS coworker2
                FROM users u1 JOIN users u2 ON u1.id < u2.id
                WHERE u1.deleted_at IS NULL
                AND u2.deleted_at IS NULL
            )
            AND deleted_at IS NOT null'
        );
    }
}
