<?php

namespace App\Services\MixServices;

use App\Models\CoworkerTag;
use App\Models\CoworkingSpace;
use App\Models\MixCriterias;
use App\Models\Society;
use App\Models\User as Coworker;
use Carbon\Carbon;

/**
 * Class CriteriaService
 * @package App\Services\MixServices
 */
class CriteriaService
{
    /**
     * @var array
     */
    protected $coworkingSpaces = [];

    /**
     * @var array
     */
    protected $coworkerTags = [];

    /**
     * @var array
     */
    protected $societies = [];

    /**
     * Evaluate mix criterias for given coworkers
     *
     * @param Coworker $coworker1
     * @param Coworker $coworker2
     * @return MixCriterias
     */
    public function evalMixCriterias(Coworker $coworker1, Coworker $coworker2) : MixCriterias
    {
        $mixCriterias = new MixCriterias();

        foreach (MixCriterias::criteriaKeys() as $criteriaKey) {
            switch ($criteriaKey) {
                case MixCriterias::NEW_COWORKER:
                    $criteriaValue = $this->evalNewCoworkerCriteria($coworker1, $coworker2);
                    break;

                case MixCriterias::OFFICE_HEAD:
                    $criteriaValue = $this->evalOfficeHeadCriteria($coworker1, $coworker2);
                    break;

                case MixCriterias::NOMADS:
                    $criteriaValue = $this->evalNomadCriteria($coworker1, $coworker2);
                    break;

                case MixCriterias::ALREADY_MET:
                    // TODO Chat model
                    $criteriaValue = $this->evalAlreadyMet($coworker1, $coworker2);
                    break;

                case MixCriterias::COMMON_TAGS:
                    $criteriaValue = $this->evalCommonTags($coworker1, $coworker2);
                    break;

                case MixCriterias::COWORKING_SPACE:
                    $criteriaValue = $this->evalCoworkingSpaceCriteria($coworker1, $coworker2);
                    break;

                default:
                    $criteriaValue = null;
                    break;
            }

            $mixCriterias->saveCriteriaValue($criteriaKey, $criteriaValue);
        }

        return $mixCriterias;
    }

    /**
     * Evaluate NEW_COWORKER criteria
     *
     * @param Coworker $coworker1
     * @param Coworker $coworker2
     * @return int
     */
    protected function evalNewCoworkerCriteria(Coworker $coworker1, Coworker $coworker2) : int
    {
        $coworker1_join_date = new Carbon($coworker1->joinedAt);
        $coworker2_join_date = new Carbon($coworker2->joinedAt);
        $isNew1 = ($coworker1_join_date->diffInWeeks(Carbon::now()) < 3);
        $isNew2 = ($coworker2_join_date->diffInWeeks(Carbon::now()) < 3);
        return ($isNew1 || $isNew2) ? 1 : 0;
    }

    /**
     * Evaluate OFFICE_HEAD criteria
     *
     * @param Coworker $coworker1
     * @param Coworker $coworker2
     * @return int
     */
    protected function evalOfficeHeadCriteria(Coworker $coworker1, Coworker $coworker2) : int
    {
        if (!isset($this->societies[$coworker1->society])) {
            $this->societies[$coworker1->society] = Society::find($coworker1->society);
        }
        if (!isset($this->societies[$coworker2->society])) {
            $this->societies[$coworker2->society] = Society::find($coworker2->society);
        }
        $society1 = $this->societies[$coworker1->society];
        $society2 = $this->societies[$coworker2->society];

        $isOfficeHead1 = ($coworker1->id === $society1->chief);
        $isOfficeHead2 = ($coworker2->id === $society2->chief);

        return ($isOfficeHead1 && $isOfficeHead2) ? 1 : 0;
    }

    /**
     * Evaluate NOMADS criteria
     *
     * @param Coworker $coworker1
     * @param Coworker $coworker2
     * @return int
     */
    protected function evalNomadCriteria(Coworker $coworker1, Coworker $coworker2) : int
    {
        if (!isset($this->societies[$coworker1->society])) {
            $this->societies[$coworker1->society] = Society::find($coworker1->society);
        }
        if (!isset($this->societies[$coworker2->society])) {
            $this->societies[$coworker2->society] = Society::find($coworker2->society);
        }
        $society1 = $this->societies[$coworker1->society];
        $society2 = $this->societies[$coworker2->society];
        $isNomad1 = ($society1->office === null);
        $isNomad2 = ($society2->office === null);
        return ($isNomad1 && $isNomad2) ? 1 : 0;
    }

    /**
     * Evaluate ALREADY_MET criteria
     *
     * @param Coworker $coworker1
     * @param Coworker $coworker2
     * @return int
     */
    protected function evalAlreadyMet(Coworker $coworker1, Coworker $coworker2) : int
    {
        // TODO Chat model
        return 0;
    }

    /**
     * Evaluate COMMON_TAGS criteria
     *
     * @param Coworker $coworker1
     * @param Coworker $coworker2
     * @return int
     */
    protected function evalCommonTags(Coworker $coworker1, Coworker $coworker2) : int
    {
        if (!isset($this->coworkerTags[$coworker1->id])) {
            $this->coworkerTags[$coworker1->id] = [];
            $coworkerTags1 = CoworkerTag::where('coworkerId', $coworker1->id)->get();
            foreach ($coworkerTags1 as $coworkerTag) {
                $this->coworkerTags[$coworker1->id][] = $coworkerTag->tagId;
            }
        }
        if (!isset($this->coworkerTags[$coworker2->id])) {
            $this->coworkerTags[$coworker2->id] = [];
            $coworkerTags2 = CoworkerTag::where('coworkerId', $coworker2->id)->get();
            foreach ($coworkerTags2 as $coworkerTag) {
                $this->coworkerTags[$coworker2->id][] = $coworkerTag->tagId;
            }
        }

        $commonTags = 0;
        foreach ($this->coworkerTags[$coworker1->id] as $tag1) {
            if (in_array($tag1, $this->coworkerTags[$coworker2->id])) {
                $commonTags++;
            }
        }

        return $commonTags;
    }

    /**
     * Evaluate COWORKING_SPACE criteria
     *
     * @param Coworker $coworker1
     * @param Coworker $coworker2
     * @return int
     */
    protected function evalCoworkingSpaceCriteria(Coworker $coworker1, Coworker $coworker2) : int
    {
        if (!isset($this->coworkingSpaces[$coworker1->coworkingSpace])) {
            $this->coworkingSpaces[$coworker1->coworkingSpace] = CoworkingSpace::find($coworker1->coworkingSpace);
        }
        if (!isset($this->coworkingSpaces[$coworker2->coworkingSpace])) {
            $this->coworkingSpaces[$coworker2->coworkingSpace] = CoworkingSpace::find($coworker2->coworkingSpace);
        }
        $coworkingSpace1 = $this->coworkingSpaces[$coworker1->coworkingSpace];
        $coworkingSpace2 = $this->coworkingSpaces[$coworker2->coworkingSpace];
        return ($coworkingSpace1->is($coworkingSpace2)) ? 1 : 0;
    }
}
