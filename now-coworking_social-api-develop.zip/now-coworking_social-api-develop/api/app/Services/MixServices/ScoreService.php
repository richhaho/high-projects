<?php

namespace App\Services\MixServices;

use App\Models\MixCriterias;

class ScoreService
{
    /**
     * @var array
     */
    private $scoreOperators;

    public function __construct()
    {
        $this->scoreOperators = [
            MixCriterias::NEW_COWORKER      => function ($criteriaValue, $currentScore) {
                return $currentScore + (20 * $criteriaValue);
            },
            MixCriterias::OFFICE_HEAD       => function ($criteriaValue, $currentScore) {
                return $currentScore * (($criteriaValue === 1) ? 1.2 : 1);
            },
            MixCriterias::NOMADS            => function ($criteriaValue, $currentScore) {
                return $currentScore * (($criteriaValue === 1) ? 1.2 : 1);
            },
            MixCriterias::ALREADY_MET       => function ($criteriaValue, $currentScore) {
                return $currentScore * (($criteriaValue === 0) ? 1.2 : 0.1);
            },
            MixCriterias::COMMON_TAGS       => function ($criteriaValue, $currentScore) {
                return $currentScore + (5 * $criteriaValue);
            },
            MixCriterias::COWORKING_SPACE   => function ($criteriaValue, $currentScore) {
                return $currentScore * (($criteriaValue === 1) ? 1.2 : 0.2);
            },
        ];
    }

    public function calculateScore(MixCriterias $mixCriterias)
    {
        $score = 10;
        foreach (MixCriterias::criteriaKeys() as $criteriaKey) {
            $criteriaValue = $mixCriterias->getCriteriaValue($criteriaKey);
            $score = $this->scoreOperators[$criteriaKey]($criteriaValue, $score);
        }
        return $score;
    }
}
