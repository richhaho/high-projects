<?php

namespace App\Services;

use App\Models\User;
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;
use Kreait\Firebase\Messaging\CloudMessage;
use Kreait\Firebase\Messaging\Notification;

class NotificationService
{
    private $messaging = null;

    /**
     * NotificationService constructor.
     */
    public function __construct()
    {
        //Load adminsdk firebase
        $serviceAccount = ServiceAccount::fromJsonFile(base_path('firebase-private-key.json'));
        $firebase = (new Factory)
            ->withServiceAccount($serviceAccount)
            ->create();
        $this->messaging = $firebase->getMessaging();
    }

    /**
     * send simple notification to specific user
     * @param String $title
     * @param String $body
     * @param User $user
     * @return array
     */
    public function sendNotification(User $user, String $title, String $body)
    {
        if ($user->device) {
            $notification = Notification::create($title, $body);
            $message = CloudMessage::withTarget('token', $user->device->device_token)
                ->withNotification($notification)
            ;
            return $this->messaging->send($message);
        }
    }

    /**
     * send simple notification
     * @param User $user
     * @param array $data
     * @param String $title
     * @param String $body
     * @return array
     */
    public function sendNotificationWithData(User $user, array $data, String $title, String $body)
    {
        if ($user->device) {
            $notification = Notification::create($title, $body);
            $message = CloudMessage::withTarget('token', $user->device->device_token)
                ->withNotification($notification)
                ->withData($data)
            ;
            return $this->messaging->send($message);
        }
    }
}
