<?php

namespace App\Services;

use App\Libraries\CosoftClient;

class PublicationService
{
    public $client = null;


    /**
     * CosoftService constructor.
     */
    public function __construct()
    {
        $this->client = resolve(CosoftClient::class);
    }

    /**
     * Get groups and their channels for a given user
     * @param $idUser
     * @return mixed
     */
    public function getGroupForUser($idUser)
    {
        return $this->client->get('/UserGroup/GetByCoworker', [
            'coworkerId' => $idUser,
        ]);
    }

    /**
     * Create a comment for a user in a post
     * @param $idUser
     * @param $idPost
     * @param $content
     * @return mixed
     */
    public function createComment($idUser, $idPost, $content)
    {
        return $this->client->post('/Post/AddAnswer', [
            'AuthorId' => $idUser,
            'PostId' => $idPost,
            'Content' => $content,
        ]);
    }

    /**
     * Get a post by it's Id
     * @param $idPost
     * @return mixed
     */
    public function getPost(String $idPost)
    {
        return $this->client->get('/Post/Get', [
            'Id' => $idPost,
        ]);
    }

    /**
     * Get publications based on multiple criteria
     * @param String $idUser
     * @param String $idGroup
     * @param String $idChannel
     * @param Int $page
     * @param Int $nbItem
     * @return mixed
     */
    public function getPublications(string $idUser, string $idGroup, string $idChannel, int $page = 1, int $nbItem = 10)
    {
        return $this->client->get('/Post/GetAll', [
            'coworkerId'    => $idUser,
            'groupId'       => $idGroup,
            'channelId'     => $idChannel,
            'skip'          => ($page-1)*$nbItem,
            'take'          => $nbItem,
        ]);
    }

    /**
     * Create a post for a user
     * @param $idUser
     * @param $idChannel
     * @param $title
     * @param $content
     * @return mixed
     */
    public function createPost(String $idUser, String $idChannel, String $title, String $content)
    {
        return $this->client->post('/Post/Create', [
            'AuthorId' => $idUser,
            'ChannelId' => $idChannel,
            'Title' => $title,
            'Content' => $content,
        ]);
    }
}
