#!/usr/bin/env bash

mkdir -p /tmp/blackfire \
    && curl -A "Docker" -L https://blackfire.io/api/v1/releases/client/linux_static/amd64 | tar zxp -C /tmp/blackfire \
    && mv /tmp/blackfire/blackfire /usr/bin/blackfire \
    && rm -Rf /tmp/blackfire

# sudo apt-get install wget gnupg2

# wget -q -O - https://packagecloud.io/gpg.key | sudo apt-key add - \
#     && echo "deb http://packages.blackfire.io/debian any main" | sudo tee /etc/apt/sources.list.d/blackfire.list \
#     && sudo apt-get update \
#     && sudo apt-get install blackfire-php
