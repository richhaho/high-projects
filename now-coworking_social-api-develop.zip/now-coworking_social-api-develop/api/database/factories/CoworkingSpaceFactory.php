<?php

use Faker\Generator as Faker;
use App\Models\CoworkingSpace;

$factory->define(CoworkingSpace::class, function (Faker $faker) {
    return [
        'cosoftId'  => $faker->unique()->uuid,
        'name'      => $faker->word,
    ];
});
