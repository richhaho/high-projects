<?php

use Faker\Generator as Faker;
use App\Models\Society;

$factory->define(Society::class, function (Faker $faker) {
    return [
        'cosoftId'  => $faker->unique()->uuid,
        'name'      => $faker->unique()->company,
        'office'    => ($faker->boolean(25)) ? $faker->words(3, true) : null,
    ];
});
