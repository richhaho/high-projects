<?php

use Faker\Generator as Faker;
use App\Models\User as Coworker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(Coworker::class, function (Faker $faker) {
    return [
        'cosoftId'          => $faker->unique()->uuid,
        'firstName'         => $faker->firstName,
        'lastName'          => $faker->lastName,
        'email'             => $faker->unique()->email,
        'phone'             => $faker->unique()->phoneNumber,
        'mobilePhone'       => $faker->unique()->phoneNumber,
        'description'       => $faker->text(),
        'job'               => $faker->jobTitle,
        'photoUrl'          => $faker->imageUrl(),
        'joinedAt'          => $faker->dateTimeBetween('-4 years'),
        'remember_token'    => ($faker->boolean(15)) ? str_random(10) : null,
    ];
});
