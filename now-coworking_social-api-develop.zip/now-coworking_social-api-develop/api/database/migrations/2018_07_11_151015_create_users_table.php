<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('cosoftId')->unique();
            $table->string('firstName')->nullable();
            $table->string('lastName')->nullable();
            $table->string('email');
            $table->string('phone')->nullable();
            $table->string('mobilePhone')->nullable();
            $table->longText('description')->nullable();
            $table->string('job')->nullable();
            $table->integer('society')->unsigned()->nullable();
            $table->integer('coworkingSpace')->unsigned()->nullable();
            $table->string('photoUrl')->nullable();
            $table->dateTime('joinedAt')->useCurrent();
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('society')
                ->references('id')
                ->on('societies')
                ->onDelete('set null');
            $table->foreign('coworkingSpace')
                ->references('id')
                ->on('coworking_spaces')
                ->onDelete('set null');
        });

        Schema::table('societies', function (Blueprint $table) {
            $table->foreign('chief')
                ->references('id')
                ->on('users')
                ->onDelete('set null');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
