<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCoworkerTagsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('coworker_tags', function (Blueprint $table) {
            $table->integer('coworkerId')->unsigned();
            $table->integer('tagId')->unsigned();

            $table->foreign('coworkerId')
                ->references('id')
                ->on('users')
                ->onDelete('cascade');
            $table->foreign('tagId')
                ->references('id')
                ->on('tags')
                ->onDelete('cascade');

            $table->primary([ 'coworkerId', 'tagId' ]);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('coworker_tags');
    }
}
