<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMixesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('mixes', function (Blueprint $table) {
            $table->integer('coworker1')->unsigned();
            $table->integer('coworker2')->unsigned();
            $table->integer('hasSwiped1')->nullable();
            $table->integer('hasSwiped2')->nullable();
            $table->double('score')->nullable();
            $table->softDeletes();

            $table->foreign('coworker1')
                ->references('id')
                ->on('users');
            $table->foreign('coworker2')
                ->references('id')
                ->on('users');

            $table->primary([ 'coworker1', 'coworker2' ]);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('mixes');
    }
}
