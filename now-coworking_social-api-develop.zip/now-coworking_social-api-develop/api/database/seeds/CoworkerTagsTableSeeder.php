<?php

use Illuminate\Database\Seeder;
use App\Models\CoworkerTag;
use App\Models\User as Coworker;
use App\Models\Tag;
use Faker\Generator as Faker;
use Illuminate\Support\Facades\DB;

class CoworkerTagsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(Faker $faker)
    {
        DB::table('coworker_tags')->truncate();
        $coworkers = Coworker::all();
        $tags = Tag::all();
        foreach ($coworkers as $coworker) {
            // Randomly set from 0 to 20 tags to each coworker
            $tagsNumber = $faker->numberBetween(0, 20);
            for ($i = 0; $i < $tagsNumber; $i++) {
                CoworkerTag::firstOrCreate([
                    'coworkerId'    => $coworker->getKey(),
                    'tagId'         => $tags[$faker->numberBetween(0, count($tags) - 1)]->getKey(),
                ]);
            }
        }
    }
}
