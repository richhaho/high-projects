<?php

use Illuminate\Database\Seeder;
use App\Models\User as Coworker;
use Faker\Generator as Faker;
use App\Models\Society;

class CoworkersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(Faker $faker)
    {
        $countSocieties = count(Society::all());
        factory(Coworker::class, 100)->create([
            'society'           => $faker->numberBetween(1, $countSocieties),
            'coworkingSpace'    => $faker->numberBetween(1, 4),
        ]);
    }
}
