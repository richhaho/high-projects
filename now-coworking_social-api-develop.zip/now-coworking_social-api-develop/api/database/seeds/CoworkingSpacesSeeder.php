<?php

use Illuminate\Database\Seeder;
use App\Models\CoworkingSpace;

class CoworkingSpacesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $coworkingSpaces = [
            'Lille',
            'Lyon',
            'Rouen',
            'Marseille',
        ];

        foreach ($coworkingSpaces as $coworkingSpace) {
            if (CoworkingSpace::where('name', $coworkingSpace)->first() === null) {
                factory(CoworkingSpace::class)->create([
                    'name' => $coworkingSpace,
                ]);
            }
        }
    }
}
