<?php

use Illuminate\Database\Seeder;
use App\Models\Society;
use App\Models\User as Coworker;
use Faker\Generator as Faker;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @param Faker $faker
     * @return void
     */
    public function run(Faker $faker)
    {
        $this->call(CoworkingSpacesSeeder::class);

        $this->call(TagsTableSeeder::class);

        $this->call(SocietiesTableSeeder::class);

        $this->call(CoworkersTableSeeder::class);

        // Set society chiefs after seeding coworkers table
        $societies = Society::all();
        foreach ($societies as $society) {
            $employees = Coworker::where('society', $society->id)->get();
            if (count($employees) !== 0) {
                $society->chief = $employees[$faker->numberBetween(0, count($employees) - 1)]->getKey();
                $society->save();
            }
        }

        $this->call(CoworkerTagsTableSeeder::class);
    }
}
