<?php

use Illuminate\Database\Seeder;
use App\Models\Tag;

class TagsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $tags = [
            'big data',
            'business intelligence',
            'webmarketing',
            'immobilier',
            'apéro',
            'art',
            'écologie',
            'communication',
            'community management',
            'css',
            'html',
            'js',
            'laravel',
            'react',
            'react-native',
            'symfony',
            'infrastructure réseau',
            'ressources humaines',
            'sport',
            'cinéma',
            'cuisine',
            'saine',
            'design',
            'machine learning',
            'voyages',
            'web',
        ];

        foreach ($tags as $tag) {
            if (Tag::where('name', $tag)->first() === null) {
                factory(Tag::class)->create([
                    'name' => $tag,
                ]);
            }
        }
    }
}
