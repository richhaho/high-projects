<?php

use Illuminate\Support\Facades\Route;

/**
 * Guest routes
 * No authentication required
 * Be sure of routes you put inside Guest middleware
 */
Route::group(['middleware' => 'guest:api'], function () {

    // Users
    /**
     * @package Users
     * @description Connect a user with email and password
     */
    Route::post('/users/login', 'UserController@login');
    /**
     * @package Users
     * @description Get connected user
     */
    Route::get('/user', 'UserController@fetch');
});

/**
 * Authenticated routes
 * User must be connected with /users/login and obtain a session cookie
 */
Route::middleware(['auth:web'])->group(function () {
    /**
     * @package Coworkers
     * @description Fetch one coworker
     */
    Route::get('/coworkers/{coworker}', 'CoworkersController@get');
});

/**
 * Authenticated routes
 * User must be connected with /users/login and obtain a session cookie
 */
Route::middleware(['auth:web', 'usercanaccess'])->group(function () {

    // Users
    /**
     * @package Users
     * @description Logout a connected user
     */
    Route::post('/users/logout', 'UserController@logout');

    // Coworkers
    /**
     * @package Coworkers
     * @description Fetch all coworkers (paginated)
     */
    Route::get('/coworkers', 'CoworkersController@search');

    //Devices
    /**
     * @package Devices
     * @description create or update device token
     */
    Route::post('/user/device', 'DeviceController@createOrUpdate');

    // Mixes
    /**
     * @package Mixes
     * @description Fetch mix list of one coworker
     */
    Route::get('/coworkers/{coworker}/mixes', 'MixController@getCoworkerMixes');
    /**
     * @package Mixes
     * @description Request swipe action
     */
    Route::post('/coworkers/{coworker}/mixes/{swiped}', 'MixController@swipe');

    /**
     * @package Publications
     * @description Get groups and their channel subscribed by a user
     */
    Route::get('/user/groups', 'PublicationController@getUserGroup');

    /**
     * @package Publications
     * @description Get a publication
     */
    Route::get('/user/posts/{post}', 'PublicationController@getPost');

    /**
     * @package Publications
     * @description Add a comment in a post
     */
    Route::post('/user/posts/{post}/comments', 'PublicationController@createPostComment');

    /**
     * @package Publications
     * @description Get publications list for a channel of a user
     */
    Route::get('/user/groups/{group}/channels/{channel}/posts', 'PublicationController@getChannelPublications');

    /**
     * @package Publications
     * @description Create a publication in a channel
     */
    Route::post('/user/groups/{group}/channels/{channel}/posts', 'PublicationController@createPost');

    /**
     * @package Conversations
     * @description List all conversations of a given user
     */
    Route::get('/user/conversations', 'ConversationController@search');

    /**
     * @package Conversations
     * @description get a given conversation of a given user
     */
    Route::get('/user/conversations/{conversation}', 'ConversationController@get');

    /**
     * @package Conversations
     * @description Get messages list from a given conversation
     */
    Route::get('/user/conversations/{conversation}/messages', 'ConversationController@getMessages');

    /**
     * @package Conversations
     * @description Create a new message in a given conversation
     */
    Route::post('/user/conversations/{conversation}/messages', 'ConversationController@newMessage');

    /**
     * @package Conversations
     * @description Update the last_read property of converation_user table
     */
    Route::put('user/conversations/{conversation}/readmessages', 'ConversationController@readMessages');

    /**
     * @package Conversations
     * @description Create a conversation with a given user
     */
    Route::post('/user/conversations', 'ConversationController@new');

    /**
     * @package Conversations
     * @description Fetch predefined messages existing in db
     */
    Route::get('user/conversations/{conversation}/predefined', 'ConversationController@fetchPredefinedMessages');

    /**
     * @package Conversations
     * @description Set favorite state of conversation
     */
    Route::put('/user/conversations/{conversation}/favorite', 'ConversationController@setFavorite');

    /**
     * @package Help
     * @description Save that the given user helped the current user
     */
    Route::post('user/help', 'UserHelpController@save');

    /**
     * @package Badges
     * @description Get all badges of connected user
     */
    Route::get('user/badges', 'UserBadgeController@get');

    /**
     * @package Badge
     * @description Fetch nb badges
     */
    Route::get('/notificationbadges', 'NotificationBadgeController@index');

    /**
     * @package Badge
     * @description Fetch nb badges
     */
    Route::get('/unread', 'ConversationController@fetchNbUnreadMessages');
});
