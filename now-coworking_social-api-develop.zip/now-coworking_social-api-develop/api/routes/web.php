<?php

/**
 * No web routes, it's an API :)
 *
 * @see routes/api.php
 *
**/
