import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

export default {
  commentWrapper: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  thumbWrapper: {
    width: 52,
    height: 52,
    borderRadius: 52,
    marginBottom: 5,
    backgroundColor: Colors.green200,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  thumb: {
    width: 60,
    height: 60,
    resizeMode: 'cover',
  },
  thumbInner: {
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: Colors.white,
    overflow: 'hidden',
    borderRadius: 46,
    width: 46,
    height: 46,
  },
  card: {
    flex: 1,
    borderRadius: 10,
    borderTopLeftRadius: 0,
  },
  cardItem: {
    alignItems: 'flex-start',
    flexDirection: 'column',
    borderRadius: 10,
    borderTopLeftRadius: 0,
  },
  date: {
    color: Colors.green200,
    fontSize: Metrics.fontSizeXs,
  },
}
