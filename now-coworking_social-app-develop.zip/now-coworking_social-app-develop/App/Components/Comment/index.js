import React, { Component } from 'react'
import { View, Text, Image, TouchableOpacity } from 'react-native'
import { Card, CardItem } from 'native-base'

import Styles from './Styles'
import moment from 'moment'
import 'moment/locale/fr'
import NavigationService from 'App/Services/NavigationService'

class Comment extends Component {
  _parseAuthorPicture(picture) {
    let pictureFormated = picture.replace(/\?.*/, '?autorotate=true&width=300&height=300&') // Replace query string
    return pictureFormated
  }

  _parseHtmlToString(html) {
    html = html.replace(/<br?[ ]?\/>/gi, '\n')
    html = html.replace(/<p>/gi, '')
    html = html.replace(/<\/p>(?=.+)/gi, '\n')
    html = html.replace(/<\/p>/gi, '')
    return html
  }

  _getTimeFromString(strTime) {
    moment.locale('fr')
    return moment(strTime).fromNow()
  }

  redirectToProfile(userId) {
    NavigationService.navigate('Profile', { userId: userId })
  }

  render() {
    const { data } = this.props
    let authorPicture = this._parseAuthorPicture(data.AuthorPicture)
    return (
      <View style={Styles.commentWrapper}>
        <View style={Styles.thumbWrapper}>
          <View style={Styles.thumbInner}>
            <TouchableOpacity onPress={() => this.redirectToProfile(data.AuthorAppId)}>
              <Image style={Styles.thumb} source={{ uri: authorPicture }} />
            </TouchableOpacity>
          </View>
        </View>
        <Card style={Styles.card}>
          <CardItem style={Styles.cardItem}>
            <Text>{this._parseHtmlToString(data.Content)}</Text>
            <Text style={Styles.date}>{this._getTimeFromString(data.Date)}</Text>
          </CardItem>
        </Card>
      </View>
    )
  }
}

export default Comment
