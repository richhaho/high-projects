import { createIconSetFromIcoMoon } from 'react-native-vector-icons'
import IconConfig from 'App/Theme/Fonts/selection.json'

export default createIconSetFromIcoMoon(IconConfig)
