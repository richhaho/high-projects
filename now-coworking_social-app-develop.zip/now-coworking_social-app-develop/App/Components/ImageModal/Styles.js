import Colors from 'App/Theme/Colors'

export default {
  imageView: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: Colors.black,
  },
  image: {
    flex: 1,
  },
  buttonContainer: {
    width: '100%',
    height: '100%',
    paddingBottom: 15,
    justifyContent: 'flex-end',
    alignItems: 'center',
    position: 'absolute',
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  button: {
    backgroundColor: Colors.white,
    borderColor: Colors.brandPrimary,
    borderRadius: 25,
    paddingVertical: 15,
    paddingHorizontal: 30,
    elevation: 2,
  },
  buttonText: { color: Colors.brandPrimary },
}
