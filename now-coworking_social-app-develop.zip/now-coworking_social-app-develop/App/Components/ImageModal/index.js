import React, { Component } from 'react'
import {
  View,
  Text,
  Image,
  TouchableWithoutFeedback,
  TouchableHighlight,
  Modal,
} from 'react-native'

import Styles from './Styles'
import 'moment/locale/fr'
import PropTypes from 'prop-types'

class ImageModal extends Component {
  state = {
    showButton: false,
  }

  setShowButton(show) {
    this.setState({ showButton: show })
  }

  render() {
    const { image, onClose, modalVisible } = this.props
    return (
      <View>
        <Modal
          animationType="slide"
          transparent={false}
          onRequestClose={() => {
            onClose(!modalVisible)
          }}
        >
          <TouchableWithoutFeedback
            style={Styles.imageView}
            onPress={() => this.setShowButton(!this.state.showButton)}
          >
            <View style={Styles.imageView}>
              <Image resizeMode={'contain'} source={{ uri: image }} style={Styles.image} />
              {this.state.showButton ? (
                <View style={Styles.buttonContainer}>
                  <TouchableHighlight
                    bordered
                    style={Styles.button}
                    onPress={() => {
                      onClose(false)
                    }}
                  >
                    <Text style={Styles.buttonText}>{'RETOUR'}</Text>
                  </TouchableHighlight>
                </View>
              ) : null}
            </View>
          </TouchableWithoutFeedback>
        </Modal>
      </View>
    )
  }
}

ImageModal.propTypes = {
  image: PropTypes.string.isRequired,
  onClose: PropTypes.func.isRequired,
  modalVisible: PropTypes.bool.isRequired,
}

export default ImageModal
