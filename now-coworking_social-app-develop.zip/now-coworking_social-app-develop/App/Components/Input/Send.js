import React, { Component } from 'react'
import { TouchableOpacity, Platform, View } from 'react-native'
import { Input, Spinner } from 'native-base'

import Styles from './SendStyle'
import Colors from 'App/Theme/Colors'
import Icon from 'react-native-vector-icons/EvilIcons'
import PropTypes from 'prop-types'

class InputSend extends Component {
  constructor(props) {
    super(props)
    this.state = {
      height: 50,
    }
  }

  render() {
    let { send, maxHeight, loading, showButton, ...inputProps } = this.props
    return (
      <View style={Styles.wrapper}>
        <Input
          {...inputProps}
          placeholderTextColor={Colors.brandPrimaryLight}
          style={[Styles.input, { height: Math.min(maxHeight, this.state.height) }]}
          onContentSizeChange={(event) => {
            this.setState({ height: event.nativeEvent.contentSize.height })
          }}
        />
        {showButton ? (
          <TouchableOpacity style={Styles.button} onPress={send}>
            {loading ? (
              <Spinner color={Colors.white} />
            ) : (
              <Icon
                style={Styles.inputIcon}
                active
                size={Platform.OS === 'ios' ? 32 : 40}
                name="sc-telegram"
              />
            )}
          </TouchableOpacity>
        ) : null}
      </View>
    )
  }
}

InputSend.defaultProps = {
  maxHeight: 100,
  loading: false,
  showButton: false,
}

InputSend.propTypes = {
  send: PropTypes.func.isRequired,
  maxHeight: PropTypes.number,
  loading: PropTypes.bool,
  showButton: PropTypes.bool,
}

export default InputSend
