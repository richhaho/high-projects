import { StyleSheet, Platform } from 'react-native'
import Colors from 'App/Theme/Colors'

export default StyleSheet.create({
  wrapper: {
    borderColor: Colors.brandPrimaryMedium,
    borderWidth: 0.7,
    backgroundColor: 'transparent',
    paddingHorizontal: 5,
    marginRight: 15,
    marginLeft: 15,
    marginBottom: 10,
    borderRadius: 30,
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  input: {
    marginBottom: Platform.OS === 'ios' ? 12 : 0,
    marginTop: Platform.OS === 'ios' ? 7 : 0,
  },
  button: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: Platform.OS === 'ios' ? 32 : 40,
    height: Platform.OS === 'ios' ? 32 : 40,
    borderRadius: Platform.OS === 'ios' ? 32 : 40,
    backgroundColor: Colors.brandSecondary,
  },
  inputIcon: {
    color: Colors.white,
  },
})
