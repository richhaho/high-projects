import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

export default {
  search: {
    paddingHorizontal: 24,
    borderBottomColor: Colors.searchBorder,
  },
  searchInput: {
    color: Colors.searchInput,
    fontSize: Metrics.fontSizeSm,
  },
}
