import React, { Component } from 'react'
import { View, TouchableWithoutFeedback } from 'react-native'
import { Item, Input } from 'native-base'

import Styles from './Styles'

import AppIcon from 'App/Components/Icon'
import Icon from 'react-native-vector-icons/EvilIcons'
import PropTypes from 'prop-types'

class Search extends Component {
  constructor(props) {
    super(props)
    this.state = {
      value: '',
    }
  }

  generateIcon() {
    return (
      <View>
        <TouchableWithoutFeedback
          onPress={() => {
            this.setState({ value: '' })
            this.props.onChange('')
          }}
        >
          <Icon name="close" size={27} />
        </TouchableWithoutFeedback>
      </View>
    )
  }

  render() {
    return (
      <Item style={Styles.search}>
        <AppIcon name="search" size={24} />

        <Input
          style={Styles.searchInput}
          value={this.state.value}
          onChangeText={(text) => {
            this.setState({ value: text })
            this.props.onChange(text)
          }}
          placeholder={this.props.placeholder}
        />
        {this.state.value ? this.generateIcon() : null}
      </Item>
    )
  }
}

Search.defaultProps = {
  placeholder: 'Rechercher une personne ou un groupe...',
}

Search.propTypes = {
  placeholder: PropTypes.string,
  onChange: PropTypes.func.isRequired,
}

export default Search
