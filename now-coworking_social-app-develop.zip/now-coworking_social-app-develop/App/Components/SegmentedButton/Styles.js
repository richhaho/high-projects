import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

export default {
  container: {
    flexDirection: 'row',
    backgroundColor: 'transparent',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
    borderRadius: 30,
  },
  leftButton: {
    borderBottomLeftRadius: 30,
    borderTopLeftRadius: 30,
    backgroundColor: Colors.white,
    justifyContent: 'center',
    flex: 1,
  },
  leftButtonText: {
    fontSize: Metrics.fontSizeSm,
    color: Colors.brandPrimary,
  },
  rightButton: {
    borderBottomRightRadius: 30,
    borderTopRightRadius: 30,
    backgroundColor: Colors.brandPrimary,
    justifyContent: 'center',
    flex: 1,
  },
  rightButtonText: {
    fontSize: Metrics.fontSizeSm,
    color: Colors.white,
  },
  button: {
    justifyContent: 'center',
    flex: 1,
  },
}
