import React, { Component } from 'react'
import { View } from 'react-native'
import { Button, Text } from 'native-base'
import Styles from 'App/Components/SegmentedButton/Styles'
import PropTypes from 'prop-types'

class SegmentedButton extends Component {
  render() {
    return (
      <View style={Styles.container}>
        <Button large full style={Styles.leftButton} onPress={this.props.onPressLeftButton}>
          <Text style={Styles.leftButtonText}>{this.props.leftButtonText}</Text>
        </Button>
        <Button
          large
          full
          danger
          style={Styles.rightButton}
          onPress={this.props.onPressRightButton}
        >
          <Text style={Styles.rightButtonText}>{this.props.rightButtonText}</Text>
        </Button>
      </View>
    )
  }
}

SegmentedButton.propTypes = {
  leftButtonText: PropTypes.string,
  rightButtonText: PropTypes.string,
  onPressLeftButton: PropTypes.func,
  onPressRightButton: PropTypes.func,
}
export default SegmentedButton
