import React, { Component } from 'react'
import { StatusBar } from 'react-native'

import StyleBase from 'App/Theme/Base'

class StatusBarApp extends Component {
  render() {
    let backgroundColor = this.props.statusBarColor
      ? this.props.statusBarColor
      : StyleBase.statusBar.backgroundColor
    let contentStyle = this.props.statusBarContentStyle
      ? this.props.statusBarContentStyle
      : StyleBase.statusBar.content
    return <StatusBar backgroundColor={backgroundColor} barStyle={contentStyle} />
  }
}

export default StatusBarApp
