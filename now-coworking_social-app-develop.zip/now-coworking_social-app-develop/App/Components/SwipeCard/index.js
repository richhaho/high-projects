import React, { Component } from 'react'
import { View } from 'react-native'
import { Text, H3, Card, CardItem, Badge } from 'native-base'
import Styles from 'App/Components/SwipeCard/Styles'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import FastImage from 'react-native-fast-image'
import { createImageProgress } from 'react-native-image-progress'
import Progress from 'react-native-progress/Pie'

const Image = createImageProgress(FastImage)

class SwipeCard extends Component {
  _renderHeader() {
    const { photoUrl } = this.props.user
    return (
      <CardItem cardBody style={Styles.profileTop}>
        <Image
          source={{
            uri: photoUrl,
          }}
          indicator={Progress}
          imageStyle={Styles.thumb}
          style={Styles.thumb}
        />
      </CardItem>
    )
  }

  _renderContent() {
    const { firstName, lastName, job, society, coworkingSpace } = this.props.user
    return (
      <View>
        <H3 style={Styles.title}>{firstName + ' ' + lastName}</H3>
        {this.props.wantMix === 1 ? (
          <View style={Styles.want}>
            <Badge success>
              <Text>Veut te rencontrer !</Text>
            </Badge>
          </View>
        ) : null}

        <View style={Styles.jobWrapper}>
          <Text style={Styles.centerText}>
            <Text style={Styles.job}>{job}</Text>
            <Text style={Styles.jobSep}> chez </Text>
            <Text style={Styles.job}>{society.name}</Text>
          </Text>
          <Text style={Styles.jobSpace}>
            {'Now '}
            {coworkingSpace.name}
          </Text>
        </View>
      </View>
    )
  }

  _renderTags(tags) {
    const { authUser } = this.props
    let authTags = authUser.tags.map((i) => i.id)

    if (tags.length === 0) {
      return
    }
    if (tags.length > 5) {
      tags = tags.slice(0, 5)
      tags.push({ name: '...' })
    }
    return (
      <View>
        <View style={Styles.tagList}>
          {tags.map((tag, i) => {
            return (
              <View
                key={i}
                style={[
                  Styles.tagItem,
                  i === 5 ? Styles.tagItemLast : {},
                  authTags.indexOf(tag.id) >= 0 ? Styles.tagItemSelected : {},
                ]}
              >
                <Text style={Styles.tagItemText}>{tag.name}</Text>
              </View>
            )
          })}
        </View>
      </View>
    )
  }

  _renderDescription(description) {
    if (description) {
      return (
        <View style={Styles.descriptionWrapper}>
          <Text numberOfLines={3} style={Styles.description}>
            {description}
          </Text>
        </View>
      )
    }
  }

  render() {
    const { user } = this.props
    return (
      <Card style={Styles.innerContent}>
        {this._renderHeader()}
        {this._renderContent(this.props)}
        {this._renderTags(user.tags)}
        {this._renderDescription(user.description)}
      </Card>
    )
  }
}

SwipeCard.propTypes = {
  user: PropTypes.object,
  authUser: PropTypes.object,
  wantMix: PropTypes.any,
}

const mapStateToProps = (state) => {
  return {
    authUser: state.auth.get('user').toJS(),
  }
}

const mapDispatchToProps = (dispatch) => ({})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(SwipeCard)
