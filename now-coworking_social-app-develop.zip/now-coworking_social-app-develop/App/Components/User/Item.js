import React, { Component } from 'react'
import { View, Image, TouchableOpacity, Linking } from 'react-native'
import { ListItem, Text, Button, H3, Body, Toast } from 'native-base'
import NavigationService from 'App/Services/NavigationService'

import Styles from 'App/Components/User/ItemStyles'
import Icon from 'App/Components/Icon'
import { connect } from 'react-redux'
import ConversationActions from 'App/Stores/Conversation/Actions'

class UserItem extends Component {
  constructor(props) {
    super(props)
    this.state = {}
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (
      nextProps.newConversationError &&
      prevState.newConversationError !== nextProps.newConversationError
    ) {
      Toast.show({
        text: nextProps.newConversationError,
        buttonText: 'Fermer',
        type: 'danger',
        duration: 4000,
        position: 'top',
      })
    }
    return nextProps
  }
  goToProfile = (user) => {
    NavigationService.navigate('Profile', { user })
  }

  openLink(url) {
    Linking.openURL(url)
  }

  _newConversation(partnerId) {
    const { newConversationRequest, newConversationLoading } = this.props
    if (newConversationLoading) return
    newConversationRequest(partnerId)
  }

  render() {
    const { user } = this.props
    const photoUrl = this.props.user.photoUrl
    const firstName = this.props.user.firstName
    const lastName = this.props.user.lastName
    const job = this.props.user.job
    const society = this.props.user.society && this.props.user.society.name
    const mobilePhone = this.props.user.mobilePhone

    return (
      <ListItem style={Styles.listItem}>
        <Body style={Styles.listWrapper}>
          <View style={Styles.thumbWrapper}>
            <View style={Styles.thumbInner}>
              <TouchableOpacity onPress={() => this.goToProfile(this.props.user)}>
                <Image style={Styles.thumb} source={{ uri: photoUrl }} />
              </TouchableOpacity>
            </View>
          </View>

          <View style={Styles.contentWrapper}>
            <TouchableOpacity onPress={() => this.goToProfile(this.props.user)}>
              <H3 style={Styles.title}>{firstName + ' ' + lastName}</H3>
              <Text style={Styles.job}>{job}</Text>
              <Text style={Styles.society}>{society}</Text>
            </TouchableOpacity>
          </View>

          <View style={Styles.buttonWrapper}>
            <Button
              transparent
              style={[Styles.button, Styles.buttonLeft]}
              onPress={() => this._newConversation(user.id)}
            >
              <Icon name={'messages'} size={24} />
            </Button>

            <Button
              transparent
              style={Styles.button}
              onPress={() => this.openLink('tel:' + mobilePhone)}
            >
              <Icon name={'phone'} size={24} />
            </Button>
          </View>
        </Body>
      </ListItem>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    newConversationError: state.conversation.get('newError'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  newConversationRequest: (partnerId) => dispatch(ConversationActions.newRequest(partnerId)),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(UserItem)
