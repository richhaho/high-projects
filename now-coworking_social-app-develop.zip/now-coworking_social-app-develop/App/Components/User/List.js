import React, { Component } from 'react'
import { FlatList, View } from 'react-native'
import { Spinner } from 'native-base'

import UserItem from 'App/Components/User/Item'
import Styles from 'App/Components/User/ListStyles'
import StyleBase from 'App/Theme/Base'

import PropTypes from 'prop-types'
import Colors from 'App/Theme/Colors'

class UserList extends Component {
  _renderItem({ item }, index) {
    return <UserItem key={index} navigation={this.props.navigation} user={item} />
  }

  render() {
    const { list, loading, numColumns, renderItem } = this.props
    return (
      <View style={StyleBase.flex}>
        <FlatList
          contentContainerStyle={Styles.flatList}
          removeClippedSubviews={true}
          refreshing={loading}
          keyExtractor={(item) => item.id.toString()}
          data={list}
          numColumns={numColumns}
          ListFooterComponent={() => (loading ? <Spinner color={Colors.brandPrimary} /> : <View />)}
          onEndReachedThreshold={0.2}
          onEndReached={() => {
            if (!this.onEndReachedCalledDuringMomentum) {
              this.props.onEndReached()
              this.onEndReachedCalledDuringMomentum = true
            }
          }}
          onScrollBeginDrag={() => {
            this.onEndReachedCalledDuringMomentum = false
          }}
          onScrollEndDrag={() => {
            this.onEndReachedCalledDuringMomentum = true
          }}
          onMomentumScrollBegin={() => {
            this.onEndReachedCalledDuringMomentum = false
          }}
          onMomentumScrollEnd={() => {
            this.onEndReachedCalledDuringMomentum = true
          }}
          renderItem={renderItem ? renderItem.bind(this) : this._renderItem.bind(this)}
        />
      </View>
    )
  }
}

UserList.defaultProps = {
  numColumns: 2,
}

UserList.propTypes = {
  numColumns: PropTypes.number,
  onEndReached: PropTypes.func.isRequired,
  list: PropTypes.any,
  loading: PropTypes.bool.isRequired,
  navigation: PropTypes.any,
  renderItem: PropTypes.func,
}

export default UserList
