export default {
  flatList: {
    paddingTop: 20,
  },
}
