import React, { Component } from 'react'
import { View, Image, Linking } from 'react-native'
import { Container, Content, Text, Button, H3, Toast, Spinner } from 'native-base'
import Styles from 'App/Components/User/ProfileStyles'
import Icon from 'App/Components/Icon'
import StatusBarApp from 'App/Components/StatusBarApp'
import { connect } from 'react-redux'
import Colors from 'App/Theme/Colors'
import ConversationActions from 'App/Stores/Conversation/Actions'
import UserActions from 'App/Stores/User/Actions'

class UserProfile extends Component {
  constructor(props) {
    super(props)
    this.state = {
      viewRef: null,
      showHelpButton: true,
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (
      nextProps.newConversationError &&
      prevState.newConversationError !== nextProps.newConversationError
    ) {
      Toast.show({
        text: nextProps.newConversationError,
        buttonText: 'Fermer',
        type: 'danger',
        duration: 4000,
        position: 'top',
      })
    }

    if (
      nextProps.addHelpFail &&
      prevState.addHelpFail !== nextProps.addHelpFail &&
      typeof prevState.addHelpFail !== 'undefined'
    ) {
      Toast.show({
        text: nextProps.addHelpFail,
        buttonText: 'Fermer',
        type: 'warning',
        duration: 4000,
        position: 'top',
      })
    }

    if (
      nextProps.addHelpSuccess &&
      prevState.addHelpSuccess !== nextProps.addHelpSuccess &&
      typeof prevState.addHelpSuccess !== 'undefined'
    ) {
      Toast.show({
        text: 'Coup de main enregsitré !',
        buttonText: 'Fermer',
        type: 'success',
        duration: 4000,
        position: 'top',
      })
    }
    return nextProps
  }

  componentDidUpdate(prevProps, prevState) {
    if (
      this.props.addHelpSuccess &&
      prevState.addHelpSuccess !== this.props.addHelpSuccess &&
      typeof prevState.addHelpSuccess !== 'undefined'
    ) {
      this.setState({ showHelpButton: false })
    }
  }

  openLink(url) {
    Linking.openURL(url)
  }

  goBack() {
    this.props.goBack()
  }

  saveHelp(helperId) {
    const { helperRequest, addHelpLoading } = this.props
    if (addHelpLoading) {
      return
    }
    helperRequest(helperId)
  }

  _renderHeader() {
    const photoUrl = this.props.user.photoUrl
    return (
      <View style={Styles.profileTop}>
        <Button transparent style={Styles.backButton} onPress={() => this.goBack()}>
          <Icon name="arrow-left" size={24} />
        </Button>

        <View style={Styles.thumbWrapper}>
          <Image
            style={Styles.thumb}
            source={{
              uri: photoUrl,
            }}
          />
        </View>
      </View>
    )
  }

  _renderContent(props) {
    const firstName = props.user.firstName
    const lastName = props.user.lastName
    const job = props.user.job
    const society = props.user.society && props.user.society.name
    const coworkingSpace = props.user.coworking_space && props.user.coworking_space.name

    return (
      <View style={Styles.contentWrapper}>
        <H3 style={Styles.title}>{firstName + ' ' + lastName}</H3>

        <View style={Styles.jobWrapper}>
          <Text style={Styles.job}>{job}</Text>
          <Text style={Styles.jobSep}> chez </Text>
          <Text style={Styles.job}>{society}</Text>
        </View>

        <Text style={Styles.society}>{coworkingSpace}</Text>
      </View>
    )
  }

  _newConversation(partnerId) {
    const { newConversationRequest, newConversationLoading } = this.props
    if (newConversationLoading) return
    newConversationRequest(partnerId)
  }

  _renderActionsButtons() {
    const { newConversationLoading, user } = this.props
    return (
      <View style={Styles.actionButtons}>
        <View style={Styles.buttonWrapper}>
          <Button
            transparent
            style={[Styles.button, Styles.buttonLeft]}
            onPress={() => this._newConversation(user.id)}
          >
            {newConversationLoading ? (
              <Spinner color={Colors.brandPrimary} />
            ) : (
              <Icon name={'messages'} size={24} />
            )}
          </Button>

          <Button
            transparent
            style={Styles.button}
            onPress={() => this.openLink('tel:' + user.mobilePhone)}
          >
            <Icon name={'phone'} size={24} />
          </Button>
        </View>
      </View>
    )
  }

  _renderTags(tags) {
    if (tags.size === 0) {
      return null
    }
    return (
      <View>
        <View style={Styles.tagList}>
          {tags.map((tag, i) => {
            return (
              <View key={i} style={Styles.tagItem}>
                <Text style={Styles.tagItemText}>{tag.name}</Text>
              </View>
            )
          })}
        </View>
      </View>
    )
  }

  _renderDescription(description) {
    return (
      <View style={Styles.descriptionWrapper}>
        <Text style={Styles.description}>{description}</Text>
      </View>
    )
  }

  _renderBadges(badges) {
    return (
      <View style={Styles.badgeWrap}>
        {badges.map((badge) => {
          return (
            <View key={badge.id} style={Styles.badgeItem}>
              <Image
                source={{ uri: badge.image }}
                style={Styles.badgeImage}
                resizeMode={'contain'}
              />
            </View>
          )
        })}
      </View>
    )
  }

  _renderFooter(name, partnerId) {
    const buttonText = name.toUpperCase() + ' M’A DONNÉ \n UN COUP DE MAIN'
    const { addHelpLoading } = this.props
    if (this.state.showHelpButton) {
      return (
        <View style={Styles.footer}>
          <View style={Styles.submitButtonShadow}>
            <Button bordered style={Styles.submitButton} onPress={() => this.saveHelp(partnerId)}>
              {addHelpLoading ? (
                <Spinner color={Colors.brandPrimary} />
              ) : (
                <Text style={Styles.submitButtonText}>{buttonText}</Text>
              )}
            </Button>
          </View>
        </View>
      )
    }
  }

  render() {
    const tags = this.props.user.tags
    const description = this.props.user.description
    const firstName = this.props.user.firstName
    const partnerId = this.props.user.id
    const badges = this.props.user.badges

    return (
      <Container>
        <StatusBarApp statusBarColor={'transparent'} statusBarContentStyle={'dark-content'} />
        <Content>
          <View style={Styles.innerContent}>
            {this._renderHeader()}
            {this._renderContent(this.props)}
            {this._renderActionsButtons()}
            {this._renderTags(tags)}
            {this._renderDescription(description)}
            {this._renderBadges(badges)}
            {this._renderFooter(firstName, partnerId)}
          </View>
        </Content>
      </Container>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    newConversationLoading: state.conversation.get('newLoading'),
    newConversationError: state.conversation.get('newError'),
    addHelpSuccess: state.user.get('addHelpSuccess'),
    addHelpFail: state.user.get('addHelpFail'),
    addHelpLoading: state.user.get('addHelpLoading'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  newConversationRequest: (partnerId) => dispatch(ConversationActions.newRequest(partnerId)),
  helperRequest: (helperId) => dispatch(UserActions.addHelpRequest(helperId)),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(UserProfile)
