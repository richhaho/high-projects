import React, { Component } from 'react'
import { View } from 'react-native'
import { ListItem, Text, Thumbnail } from 'native-base'

import Styles from 'App/Components/User/SimpleItemStyles'
import PropTypes from 'prop-types'

class UserSimpleItem extends Component {
  render() {
    const userId = this.props.user.id
    const photoUrl = this.props.user.photoUrl
    const firstName = this.props.user.firstName
    const lastName = this.props.user.lastName
    const society = this.props.user.society && this.props.user.society.name

    return (
      <ListItem noBorder onPress={() => this.props.onPress(userId)}>
        <View>
          <Thumbnail small source={{ uri: photoUrl }} />
        </View>
        <View style={Styles.panel}>
          <Text style={Styles.leftPart}>{firstName + ' ' + lastName}</Text>
          <Text style={Styles.rightPart}> {' / ' + society}</Text>
        </View>
      </ListItem>
    )
  }
}

UserSimpleItem.defaultProps = {}

UserSimpleItem.propTypes = {
  onPress: PropTypes.func,
  user: PropTypes.object.isRequired,
}

export default UserSimpleItem
