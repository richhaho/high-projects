export default {
  panel: {
    flexDirection: 'row',
    marginLeft: 20,
  },
  leftPart: {
    fontWeight: 'bold',
  },
  rightPart: {},
}
