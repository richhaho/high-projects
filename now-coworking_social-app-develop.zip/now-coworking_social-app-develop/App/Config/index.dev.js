export const Config = {
  API_URL: 'https://0123456.ngrok.io/api',
  ECHO_URL: 'http://654321.ngrok.io:80',
  FB_URL: 'https://facebook.com/NowCoworking',
  TW_URL: 'https://twitter.com/NowCoworking',
  IN_URL: 'https://www.linkedin.com/company/now-coworking/',
  INST_URL: 'https://www.instagram.com/nowcoworking/',
  NOW_URL: 'https://coworker.now-coworking.com',
  FORGOT_PASSWORD_URL: 'https://coworker.now-coworking.com/ForgotPassword',
  CONTRIBUTE_URL: 'https://github.com/thecodingmachine',
}
