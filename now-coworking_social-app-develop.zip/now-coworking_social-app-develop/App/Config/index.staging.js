export const Config = {
  API_URL: 'https://nowco.thecodingmachine.com/api',
  ECHO_URL: 'http://nowchat.thecodingmachine.com:80',
  FB_URL: 'https://facebook.com/NowCoworking',
  TW_URL: 'https://twitter.com/NowCoworking',
  IN_URL: 'https://www.linkedin.com/company/now-coworking/',
  INST_URL: 'https://www.instagram.com/nowcoworking/',
  NOW_URL: 'https://coworker.now-coworking.com',
  FORGOT_PASSWORD_URL: 'https://coworker.now-coworking.com/ForgotPassword',
  CONTRIBUTE_URL: 'https://github.com/thecodingmachine',
}
