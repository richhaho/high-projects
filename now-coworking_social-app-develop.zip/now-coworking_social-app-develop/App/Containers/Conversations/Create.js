import React, { Component } from 'react'
import { View } from 'react-native'
import { Container, Toast, Header, Title, Button, Spinner, Right, Left } from 'native-base'
import StatusBarApp from 'App/Components/StatusBarApp'
import Icon from 'react-native-vector-icons/EvilIcons'
import CreateList from './CreateList'

import BaseStyles from 'App/Theme/Base'
import Colors from 'App/Theme/Colors'
import Styles from './CreateStyles'

import { connect } from 'react-redux'
import NavigationService from 'App/Services/NavigationService'

class ConversationCreate extends Component {
  constructor(props) {
    super(props)
    this.state = {}
  }

  static navigationOptions = {
    header: null,
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.error && prevState.error !== nextProps.error) {
      Toast.show({
        text: nextProps.error,
        buttonText: 'Fermer',
        type: 'danger',
        duration: 4000,
        position: 'top',
      })
    }
    return nextProps
  }

  render() {
    const { loading } = this.props
    return (
      <Container>
        <Header style={Styles.header}>
          <StatusBarApp />
          <Left style={Styles.headerLeft}>
            <Button transparent onPress={() => NavigationService.navigate('List')}>
              <Icon size={45} name="chevron-left" />
            </Button>
          </Left>
          <View style={Styles.body}>
            <Title style={BaseStyles.headerTitle}>Nouvelle discussion</Title>
          </View>
          <Right style={Styles.rightHeader}>
            {loading ? <Spinner color={Colors.brandPrimary} /> : null}
          </Right>
        </Header>

        <CreateList />
      </Container>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    loading: state.conversation.get('newLoading'),
    error: state.conversation.get('newError'),
  }
}

const mapDispatchToProps = (dispatch) => ({})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ConversationCreate)
