import React, { Component } from 'react'
import { View, Image } from 'react-native'
import { Accordion, Text, Spinner } from 'native-base'
import AppIcon from 'App/Components/Icon'
import UserList from 'App/Components/User/List'
import SimpleUserItem from 'App/Components/User/SimpleItem'
import Search from 'App/Components/Search'

import Styles from './CreateListStyles'
import BaseStyles from 'App/Theme/Base'
import Colors from 'App/Theme/Colors'
import Images from 'App/Theme/Images'

import { connect } from 'react-redux'
import UserActions from 'App/Stores/User/Actions'
import ConversationActions from 'App/Stores/Conversation/Actions'

class ConversationCreateList extends Component {
  constructor(props) {
    super(props)

    this.state = {
      search: '',
    }
  }

  componentDidMount() {
    const { listUsers, resetUsers, listFavoriteUsers, listStaffUsers } = this.props
    resetUsers()
    // All users
    listUsers()
    // Favorite users
    listFavoriteUsers()
    // Staff users
    listStaffUsers()
  }

  _renderHeader(item, expanded) {
    return (
      <View style={Styles.header}>
        <View style={Styles.leftPanel}>
          {item.icon}
          <Text style={Styles.headerTitle}> {item.title}</Text>
        </View>
        {expanded ? (
          <AppIcon size={14} name="arrow-top" />
        ) : (
          <AppIcon size={14} name="arrow-down" />
        )}
      </View>
    )
  }
  _renderContent(item) {
    return <View style={Styles.content}>{item.content}</View>
  }

  _renderAllUsers() {
    const { users, usersLoading } = this.props

    if (usersLoading && users && users.size < 1) {
      return <Spinner color={Colors.brandPrimary} />
    }

    if (users && users.size < 1) {
      return <Text style={Styles.noData}>Aucun coworker ne correspond à votre recherche</Text>
    }

    return (
      <UserList
        onEndReached={this._loadUsers.bind(this)}
        list={users.toJS()}
        loading={usersLoading}
        numColumns={1}
        renderItem={this._renderUserItem.bind(this)}
      />
    )
  }

  _renderFavoriteUsers() {
    const { favoriteUsers, favoriteUsersLoading } = this.props

    if (favoriteUsersLoading && favoriteUsers && favoriteUsers.size < 1) {
      return <Spinner color={Colors.brandPrimary} />
    }

    if (favoriteUsers && favoriteUsers.size < 1) {
      return (
        <Text style={Styles.noData}>{"Vous n'avez ajouté aucune conversation en favoris"}</Text>
      )
    }

    return (
      <UserList
        onEndReached={this._loadFavoriteUsers.bind(this)}
        list={favoriteUsers.toJS()}
        loading={favoriteUsersLoading}
        numColumns={1}
        renderItem={this._renderUserItem.bind(this)}
      />
    )
  }

  _renderStaffUsers() {
    const { staffUsers, staffUsersLoading } = this.props

    if (staffUsersLoading && staffUsers && staffUsers.size < 1) {
      return <Spinner color={Colors.brandPrimary} />
    }

    if (staffUsers && staffUsers.size < 1) {
      return <Text style={Styles.noData}>{"Aucun membre de l'équipe trouvé"}</Text>
    }

    return (
      <UserList
        onEndReached={this._loadStaffUsers.bind(this)}
        list={staffUsers.toJS()}
        loading={staffUsersLoading}
        numColumns={1}
        renderItem={this._renderUserItem.bind(this)}
      />
    )
  }

  _loadUsers() {
    const { listUsers, currentPage, nextPage } = this.props

    if (nextPage) {
      listUsers(currentPage + 1, this.state.search)
    }
  }

  _loadFavoriteUsers() {
    const { listFavoriteUsers, favoriteCurrentPage, favoriteNextPage } = this.props

    if (favoriteNextPage) {
      listFavoriteUsers(favoriteCurrentPage + 1)
    }
  }

  _loadStaffUsers() {
    const { listStaffUsers, staffCurrentPage, staffNextPage } = this.props

    if (staffNextPage) {
      listStaffUsers(staffCurrentPage + 1)
    }
  }

  _renderUserItem({ item }) {
    return <SimpleUserItem key={item.id} user={item} onPress={this._newConversation.bind(this)} />
  }

  _newConversation(userId) {
    const { newConversationRequest } = this.props
    newConversationRequest(userId)
  }

  _handleChangeText(text) {
    const { currentPage, listUsers, resetUsers, listFavoriteUsers, listStaffUsers } = this.props
    resetUsers()
    this.setState({ search: text })
    if (text) {
      listUsers(currentPage, text)
    } else {
      listUsers()
      listFavoriteUsers()
      listStaffUsers()
    }
  }

  render() {
    const items = [
      {
        icon: <AppIcon name={'star'} size={25} />,
        title: 'Favoris',
        content: this._renderFavoriteUsers(),
      },
      {
        icon: <AppIcon name={'user-full'} size={25} />,
        title: 'Tous les coworkers',
        content: this._renderAllUsers(),
      },
      {
        icon: <Image source={Images.logo} style={Styles.teamIcon} />,
        title: "L'équipe Now",
        content: this._renderStaffUsers(),
      },
    ]
    return (
      <View style={BaseStyles.flex}>
        <Search
          onChange={(text) => this._handleChangeText(text)}
          placeholder={'Rechercher une personne, une entreprise, etc.'}
        />
        {this.state.search ? (
          this._renderAllUsers()
        ) : (
          <Accordion
            dataArray={items}
            renderHeader={this._renderHeader}
            renderContent={this._renderContent}
          />
        )}
      </View>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    // All users
    users: state.user.get('users'),
    usersLoading: state.user.get('loading'),
    currentPage: state.user.get('currentPage'),
    nextPage: state.user.get('nextPage'),
    // Favorite users
    favoriteUsers: state.user.get('favoriteUsers'),
    favoriteUsersLoading: state.user.get('favoriteLoading'),
    favoriteCurrentPage: state.user.get('favoriteCurrentPage'),
    favoriteNextPage: state.user.get('favoriteNextPage'),
    // Staff users
    staffUsers: state.user.get('staffUsers'),
    staffUsersLoading: state.user.get('staffLoading'),
    staffCurrentPage: state.user.get('staffCurrentPage'),
    staffNextPage: state.user.get('staffNextPage'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  listUsers: (index, search) => dispatch(UserActions.fetchCoworkers(index, search)),
  listFavoriteUsers: (index) => dispatch(UserActions.fetchFavoriteCoworkers(index)),
  listStaffUsers: (index) => dispatch(UserActions.fetchStaffCoworkers(index)),
  resetUsers: () => dispatch(UserActions.resetCoworkers()),
  newConversationRequest: (partnerId) => dispatch(ConversationActions.newRequest(partnerId)),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ConversationCreateList)
