import Colors from 'App/Theme/Colors'

export default {
  header: {
    flexDirection: 'row',
    padding: 20,
    justifyContent: 'space-between',
    backgroundColor: Colors.white,
  },
  leftPanel: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  headerTitle: {
    fontWeight: 'bold',
    marginLeft: 20,
  },
  content: {
    backgroundColor: Colors.white,
  },
  teamIcon: {
    width: 30,
    height: 30,
  },
}
