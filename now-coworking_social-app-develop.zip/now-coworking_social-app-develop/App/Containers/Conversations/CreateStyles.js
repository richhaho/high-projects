import Metrics from 'App/Theme/Metrics'
import Colors from 'App/Theme/Colors'

export default {
  rightHeader: {},
  headerLeft: {},
  header: {
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.searchBorder,
    alignItems: 'flex-end',
    justifyContent: 'center',
    position: 'relative',
  },
  body: {
    position: 'absolute',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingBottom: 10,
  },
  title: {
    color: Colors.heading,
    fontSize: Metrics.fontSizeXl,
  },
}
