import React, { Component } from 'react'
import { FlatList, View, Image } from 'react-native'
import {
  Container,
  Text,
  Card,
  CardItem,
  Spinner,
  Toast,
  Title,
  Header,
  Fab,
  Icon,
} from 'native-base'

import Styles from './ListStyles'
import BaseStyles from 'App/Theme/Base'
import Colors from 'App/Theme/Colors'
import ConversationActions from 'App/Stores/Conversation/Actions'
import { connect } from 'react-redux'
import NavigationService from 'App/Services/NavigationService'
import StatusBarApp from 'App/Components/StatusBarApp'

class ConversationList extends Component {
  constructor(props) {
    super(props)
    this.state = {}
  }

  componentDidMount() {
    const { currentPage, listRequest } = this.props
    listRequest(currentPage)
  }

  static navigationOptions = {
    header: null,
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.error && prevState.error !== nextProps.error) {
      Toast.show({
        text: nextProps.error,
        buttonText: 'Fermer',
        type: 'danger',
        duration: 4000,
        position: 'top',
      })
    }
    return nextProps
  }

  lazyLoad() {
    const { currentPage, listRequest } = this.props
    listRequest(currentPage + 1)
  }

  _pullToRefresh() {
    const { listRequest, listReset } = this.props
    listReset()
    listRequest(1)
  }

  _renderList(conversations) {
    const { loading } = this.props
    return (
      <FlatList
        contentContainerStyle={Styles.list}
        // Keep this value to false, this is a bug fix for white screen on FlatList due to react-navigation issue
        // https://github.com/facebook/react-native/issues/13202
        // https://github.com/react-navigation/react-navigation/issues/1338
        removeClippedSubviews={false}
        // For information please read: https://facebook.github.io/react-native/docs/flatlist#removeclippedsubviews
        ListFooterComponent={() => (loading ? <Spinner color={Colors.brandPrimary} /> : <View />)}
        onEndReachedThreshold={0.01}
        onEndReached={() => {
          if (!this.onEndReachedCalledDuringMomentum && !loading) {
            this.lazyLoad()
            this.onEndReachedCalledDuringMomentum = true
          }
        }}
        onMomentumScrollBegin={() => {
          this.onEndReachedCalledDuringMomentum = false
        }}
        keyExtractor={(item) => item.id.toString()}
        onRefresh={() => this._pullToRefresh()}
        refreshing={false} // atribute is required for onRefresh but we manage loader with loading
        renderItem={({ item }) =>
          item.partners && 0 in item.partners ? (
            <View style={Styles.cardWrapper}>
              <Card transparent>
                <CardItem
                  button
                  style={Styles.cardItem}
                  onPress={() => NavigationService.navigate('Messages', { conversation: item })}
                >
                  <View>
                    <View style={Styles.thumbWrapper}>
                      <Image
                        style={Styles.thumb}
                        source={{
                          uri: item.partners[0].photoUrl,
                        }}
                      />
                    </View>
                    {item.unread > 0 ? (
                      <View style={Styles.badge}>
                        <Text style={Styles.badgeText}>{item.unread}</Text>
                      </View>
                    ) : null}
                  </View>
                  <View style={Styles.cardItemBody}>
                    <Text
                      style={item.unread ? Styles.cardItemBodyTitleBold : Styles.cardItemBodyTitle}
                    >
                      {item.partners[0].firstName} {item.partners[0].lastName}
                    </Text>
                    <Text
                      ellipsizeMode={'tail'}
                      numberOfLines={1}
                      style={item.unread ? Styles.lastMessageBold : Styles.lastMessage}
                    >
                      {item.last_message ? item.last_message.content : null}
                    </Text>
                  </View>
                </CardItem>
              </Card>
            </View>
          ) : null
        }
        data={conversations}
      />
    )
  }
  render() {
    const { list, loading } = this.props

    return (
      <Container>
        <Header style={Styles.header}>
          <StatusBarApp />
          <Title style={Styles.title}>Chat</Title>
        </Header>

        {list.length > 0 ? (
          this._renderList(list)
        ) : loading ? (
          <Spinner color={Colors.brandPrimary} />
        ) : (
          <View style={Styles.noConversation}>
            <Text style={Styles.title}>
              {"Il semblerait que vous n'ayez pas encore de conversation."}
            </Text>
            <Text style={Styles.noConversationHint}>
              {"Cliquez sur l'icône "}
              <Icon style={Styles.noConversationHint} name="ios-create" />
              {' en bas à droite pour en lancer une !'}
            </Text>
          </View>
        )}

        <Fab
          active={false}
          direction="up"
          containerStyle={{}}
          style={BaseStyles.fab}
          position="bottomRight"
          onPress={() => NavigationService.navigate('CreateConversation')}
        >
          <Icon name="ios-create" />
        </Fab>
      </Container>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    list: state.conversation.get('list').toJS(),
    loading: state.conversation.get('listLoading'),
    currentPage: state.conversation.get('listCurrentPage'),
    error: state.conversation.get('listError'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  listRequest: (page) => {
    dispatch(ConversationActions.listRequest(page))
  },
  listReset: () => {
    dispatch(ConversationActions.listReset())
  },
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ConversationList)
