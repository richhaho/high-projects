import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

export default {
  header: {
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.searchBorder,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    color: Colors.heading,
    fontSize: Metrics.fontSizeXl,
    paddingTop: 0,
    textAlign: 'center',
  },
  list: {
    paddingTop: 10,
  },
  cardWrapper: {
    flex: 1,
    paddingHorizontal: 5,
  },
  cardItem: {
    flex: 1,
    paddingBottom: 0,
    paddingLeft: 5,
    paddingTop: 0,
    marginBottom: 5,
  },
  cardItemBody: {
    flex: 1,
    marginLeft: 15,
  },
  cardItemBodyTitleBold: {
    fontWeight: 'bold',
  },
  cardItemBodyTitle: {
    fontWeight: 'normal',
  },
  thumb: {
    width: 60,
    height: 60,
    resizeMode: 'cover',
  },
  thumbWrapper: {
    width: 60,
    height: 60,
    borderRadius: 60,
    backgroundColor: Colors.white,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: Colors.white,
  },
  lastMessage: {
    fontSize: Metrics.fontSizeSmXs,
    color: Colors.green300,
  },
  lastMessageBold: {
    fontWeight: 'bold',
    fontSize: Metrics.fontSizeSmXs,
    color: Colors.green300,
  },
  noConversation: {
    display: 'flex',
    flex: 1,
    flexDirection: 'column',
    backgroundColor: Colors.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  noConversationHint: {
    fontSize: Metrics.fontSizeSmXs,
    color: Colors.green300,
    padding: 20,
  },
  badge: {
    position: 'absolute',
    height: 21,
    width: 21,
    backgroundColor: 'red',
    borderRadius: 50,
    zIndex: 10,
    right: 0,
    top: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    color: 'white',
    margin: 0,
    fontSize: 11,
    padding: 0,
  },
}
