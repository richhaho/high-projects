import React, { Component } from 'react'
import { View, Image } from 'react-native'
import { Text, Card, CardItem } from 'native-base'

import moment from 'moment'

import Styles from './MessagesStyles'
import PropTypes from 'prop-types'

class ConversationMessageItem extends Component {
  render() {
    const { item, inverse, displayDate } = this.props
    let createdAt = moment(item.created_at)
    return (
      <View style={[Styles.cardWrapper, inverse ? '' : Styles.cardWrapperInverse]}>
        <View style={Styles.thumbWrapper}>
          <Image
            style={Styles.thumb}
            source={{
              uri: item.author.photoUrl,
            }}
          />
        </View>
        <Card transparent style={[Styles.card, inverse ? '' : Styles.cardInverse]}>
          <CardItem style={[Styles.cardItem, inverse ? '' : Styles.cardItemInverse]}>
            <View style={[Styles.cardItemBody, inverse ? '' : Styles.cardItemBodyInverse]}>
              {item.file ? (
                <View>
                  <Image
                    resizeMode={'cover'}
                    source={{
                      uri: item.file,
                    }}
                    style={Styles.image}
                  />
                </View>
              ) : null}
              <Text style={inverse ? {} : Styles.textInverse}>{item.content}</Text>
              <Text style={[Styles.cardFooter, inverse ? '' : Styles.textInverse]}>
                {displayDate(createdAt)}
              </Text>
            </View>
          </CardItem>
        </Card>
      </View>
    )
  }
}

ConversationMessageItem.defaultProps = {
  inverse: false,
}

ConversationMessageItem.propTypes = {
  item: PropTypes.object.isRequired,
  displayDate: PropTypes.func.isRequired,
  inverse: PropTypes.bool,
}

export default ConversationMessageItem
