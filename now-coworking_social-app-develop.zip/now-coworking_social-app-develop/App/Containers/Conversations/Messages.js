import React, { Component } from 'react'
import { FlatList, View, Platform, TouchableOpacity, KeyboardAvoidingView } from 'react-native'
import {
  Container,
  Text,
  Spinner,
  Toast,
  Title,
  Header,
  Button,
  Right,
  Left,
  Subtitle,
} from 'native-base'
import ImageModal from 'App/Components/ImageModal'
import ImagePicker from 'react-native-image-picker'
import Swiper from 'react-native-swiper'

import { connect } from 'react-redux'
import moment from 'moment'
import io from 'socket.io-client'
import Echo from 'laravel-echo'

import Styles from './MessagesStyles'
import BaseStyles from 'App/Theme/Base'
import Colors from 'App/Theme/Colors'
import Icon from 'react-native-vector-icons/EvilIcons'
import AppIcon from 'App/Components/Icon'

import UserActions from 'App/Stores/User/Actions'
import ConversationActions from 'App/Stores/Conversation/Actions'
import NavigationService from 'App/Services/NavigationService'
import { Config } from 'App/Config'

import StatusBarApp from 'App/Components/StatusBarApp'
import InputSend from 'App/Components/Input/Send'
import ConversationMessageItem from './MessageItem'
import FastImage from 'react-native-fast-image'

class ConversationMessages extends Component {
  constructor(props) {
    super(props)
    this.state = {
      newMessageText: '',
      channel: null,
      echoClient: null,
      modalVisible: false,
      currentImage: null,
    }
  }

  setModalVisible(visible) {
    this.setState({ modalVisible: visible })
  }

  componentDidMount() {
    this.init()
  }

  init() {
    const {
      navigation,
      messagesRequest,
      readConversationRequest,
      initFavoriteRequest,
      setConversationId,
      predefinedRequest,
    } = this.props
    let conversation = navigation.getParam('conversation')

    // First we read the conversation
    readConversationRequest(conversation.id)

    // Set the default favorite state
    initFavoriteRequest(conversation.me[0].favorite)

    messagesRequest(conversation.id, {}, true)

    const echoClient = new Echo({
      broadcaster: 'socket.io',
      client: io,
      host: Config.ECHO_URL,
    })

    const channel = 'conversation.' + conversation.id

    echoClient.channel(channel).listen('NewMessage', (data) => {
      this.realTimeMessage(data)
    })

    setConversationId(conversation.id)

    this.setState({
      echoClient: echoClient,
      channel: channel,
    })

    // Load predefined messages
    predefinedRequest(conversation.id)
  }

  componentWillUnmount() {
    this.state.echoClient.leave(this.state.channel)
    this.props.setConversationId(null) // reset opened conversation
  }

  static navigationOptions = {
    header: null,
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.error && prevState.error !== nextProps.error) {
      Toast.show({
        text: nextProps.error,
        buttonText: 'Fermer',
        type: 'danger',
        duration: 4000,
        position: 'top',
      })
    }

    if (
      nextProps.newMessageError &&
      prevState.newMessageError !== nextProps.newMessageError &&
      typeof prevState.newMessageError !== 'undefined'
    ) {
      Toast.show({
        text: nextProps.newMessageError,
        buttonText: 'Fermer',
        type: 'danger',
        duration: 4000,
        position: 'top',
      })
    }

    if (
      prevState.messages &&
      nextProps.messages &&
      prevState.messages.length !== nextProps.messages.length &&
      nextProps.conversationId &&
      prevState.conversationId &&
      nextProps.conversationId === prevState.conversationId
    ) {
      nextProps.readConversationRequest(prevState.conversationId)
    }

    return nextProps
  }

  componentDidUpdate() {
    if (this.props.navigation.getParam('conversation').id !== this.props.conversationId) {
      this.init()
    }
  }

  displayDate(date) {
    let moreThanOneDay = moment().diff(date, 'days') > 1
    return moreThanOneDay ? date.format('D MMMM YYYY [à] HH[h]mm') : date.fromNow()
  }

  lazyLoad() {
    const { messagesRequest, conversationId, oldestId } = this.props
    if (oldestId > 0) {
      messagesRequest(conversationId, { before: oldestId }, false)
    }
  }

  sendMessage() {
    const { conversationId, newMessage, newMessageLoading } = this.props
    if (newMessageLoading) return
    newMessage(conversationId, this.state.newMessageText, this.state.image)
    this.setState({ newMessageText: '' })
  }

  realTimeMessage(message) {
    const { appendMessage } = this.props
    appendMessage(message)
  }

  setFavorite() {
    const { conversationId, setFavoriteRequest } = this.props
    setFavoriteRequest(conversationId, !this.props.setFavoriteState)
  }

  pickImage() {
    const options = {
      title: 'Sélectionner une image',
      storageOptions: {
        skipBackup: true,
      },
      maxWidth: 700,
      maxHeight: 700,
      quality: 0.5,
      videoQuality: 'low',
      noData: true,
    }
    ImagePicker.showImagePicker(options, (response) => {
      let mimes = {
        gif: 'image/gif',
        jpeg: 'image/jpeg',
        jpg: 'image/jpeg',
        png: 'image/png',
        svg: 'image/svg+xml',
        bmp: 'image/bmp',
      }
      if (!response.didCancel) {
        if (response.error) {
          this.setState({ image: null, imagePicked: false, imagePickedError: response.error })
        } else {
          // fix fileType when spaces in filename
          // @see https://github.com/react-community/react-native-image-picker/issues/557
          let extension
          if (response.fileName) {
            extension = response.fileName.split('.').pop()
          } else {
            extension = response.uri.split('.').pop()
          }
          if (!response.type && !(extension in mimes)) {
            this.setState({ image: null, imagePicked: false, imagePickedError: response.error })
          }
          const image = {
            uri: response.uri,
            type: response.type ? response.type : mimes[extension],
            name: response.fileName ? response.fileName : 'NowSocialImg',
          }

          this.setState({ image: image, imagePicked: true, imagePickedError: null })
        }
      }
    })
  }

  _renderList() {
    const { loading, user, messages } = this.props
    return (
      <FlatList
        contentContainerStyle={Styles.list}
        removeClippedSubviews={true}
        ListFooterComponent={() => (loading ? <Spinner color={Colors.brandPrimary} /> : <View />)}
        onEndReachedThreshold={0.01}
        inverted={true}
        onEndReached={() => {
          if (!this.onEndReachedCalledDuringMomentum && !loading) {
            this.lazyLoad()
            this.onEndReachedCalledDuringMomentum = true
          }
        }}
        onMomentumScrollBegin={() => {
          this.onEndReachedCalledDuringMomentum = false
        }}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => {
          return (
            <TouchableOpacity
              onPress={() => {
                if (item.file) {
                  this.setModalVisible(!this.modalVisible)
                  this.setState({ currentImage: item.file })
                }
              }}
            >
              <ConversationMessageItem
                displayDate={this.displayDate}
                item={item}
                inverse={item.author.id !== user.id}
              />
            </TouchableOpacity>
          )
        }}
        data={messages}
      />
    )
  }

  _setPredefinedText(text) {
    this.setState({
      newMessageText: text,
    })
  }

  render() {
    const {
      messages,
      loading,
      navigation,
      newMessageLoading,
      predefined,
      predefinedLoading,
    } = this.props
    const conversation = navigation.getParam('conversation')
    const partner = conversation ? conversation.partners[0] : null
    const partnerName = partner ? partner.firstName + ' ' + partner.lastName : '...'

    const lastMessage = conversation ? conversation.last_message : null
    const lastDate = lastMessage ? this.displayDate(moment(lastMessage.created_at)) : null

    return this.state.modalVisible ? (
      <ImageModal
        onClose={this.setModalVisible.bind(this)}
        image={this.state.currentImage}
        modalVisible={this.state.modalVisible}
      />
    ) : (
      <Container>
        <KeyboardAvoidingView
          style={BaseStyles.flex}
          behavior={'padding'}
          enabled={Platform.OS === 'ios'}
        >
          <Header style={Styles.header}>
            <StatusBarApp />
            <Left style={Styles.leftHeader}>
              <Button transparent onPress={() => NavigationService.navigate('List')}>
                <Icon size={45} name="chevron-left" />
              </Button>
            </Left>
            <View style={Styles.centerHeader}>
              <Title style={Styles.title}>{partnerName}</Title>
              {lastDate ? <Subtitle style={Styles.subtitle}>{lastDate}</Subtitle> : null}
            </View>
            <Right style={Styles.rightHeader}>
              <Button transparent onPress={() => this.setFavorite()}>
                {this.props.setFavoriteLoading ? (
                  <Spinner color={Colors.brandPrimary} />
                ) : (
                  <AppIcon
                    style={Styles.favoriteStar}
                    size={35}
                    name={this.props.setFavoriteState ? 'star-full' : 'star'}
                  />
                )}
              </Button>
            </Right>
          </Header>

          <View style={BaseStyles.flex} contentContainerStyle={BaseStyles.flex}>
            {messages.length > 0 ? (
              this._renderList()
            ) : loading ? (
              <View style={BaseStyles.columnCenter}>
                <Spinner color={Colors.brandPrimary} />
              </View>
            ) : predefinedLoading || predefined.size > 0 ? (
              <View style={Styles.swiperWrapper}>
                {predefinedLoading ? (
                  <Spinner color={Colors.brandPrimary} />
                ) : (
                  <Swiper
                    containerStyle={Styles.swiper}
                    dotColor={Colors.white}
                    activeDotColor={Colors.brandPrimary}
                  >
                    {predefined.toJS().map((item) => {
                      return (
                        <View key={'predefined-' + item.id.toString()} style={Styles.swiperItem}>
                          <TouchableOpacity onPress={() => this._setPredefinedText(item.content)}>
                            <Text style={Styles.swiperText}>{item.content}</Text>
                          </TouchableOpacity>
                          <View style={Styles.swiperSeparator} />
                          <Text style={Styles.swiperHint}>
                            Touchez pour écrire un message prédéfini.
                          </Text>
                        </View>
                      )
                    })}
                  </Swiper>
                )}
              </View>
            ) : null}
            <View style={Styles.input}>
              {this.state.imagePicked ? (
                <FastImage
                  style={Styles.imgPreview}
                  source={{
                    uri: this.state.image.uri,
                    priority: FastImage.priority.high,
                  }}
                />
              ) : (
                <TouchableOpacity onPress={() => this.pickImage()}>
                  <AppIcon
                    style={Styles.plusIcon}
                    color={Colors.middleGrey}
                    size={25}
                    name="plus"
                  />
                </TouchableOpacity>
              )}
              <View style={Styles.inputText}>
                <InputSend
                  placeholder={
                    (messages.length > 0 ? 'Répondre à ' : 'Écrire à ') + partner.firstName + '...'
                  }
                  returnKeyType={Platform.OS === 'android' ? 'previous' : 'default'}
                  enablesReturnKeyAutomatically={true}
                  multiline={true}
                  loading={newMessageLoading}
                  onChangeText={(newMessageText) => this.setState({ newMessageText })}
                  send={this.sendMessage.bind(this)}
                  value={this.state.newMessageText}
                  showButton={
                    !!(
                      this.state.newMessageText.trim().length > 0 ||
                      newMessageLoading ||
                      this.state.image
                    )
                  }
                />
              </View>
            </View>
          </View>
        </KeyboardAvoidingView>
      </Container>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    messages: state.conversation.get('messages').toJS(),
    loading: state.conversation.get('messagesLoading'),
    error: state.conversation.get('messagesError'),
    conversationId: state.conversation.get('messagesConversationId'),
    oldestId: state.conversation.get('messagesOldestId'),
    newMessageLoading: state.conversation.get('newMessageLoading'),
    newMessageError: state.conversation.get('newMessageError'),
    user: state.auth.get('user').toJS(),
    setFavoriteState: state.conversation.get('setFavoriteState'),
    setFavoriteLoading: state.conversation.get('setFavoriteLoading'),
    imagePicked: state.conversation.get('imagePicked'),
    imagePickedError: state.conversation.get('imagePickedError'),
    image: state.conversation.get('image'),
    predefinedLoading: state.conversation.get('predefinedLoading'),
    predefined: state.conversation.get('predefined'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  messagesRequest: (conversationId, filters, reset) => {
    dispatch(ConversationActions.messagesRequest(conversationId, filters, reset))
  },
  newMessage: (conversationId, content, image) => {
    dispatch(ConversationActions.newMessageRequest(conversationId, content, image))
  },
  appendMessage: (message) => {
    dispatch(ConversationActions.appendMessage(message))
  },
  initFavoriteRequest: (initState) => {
    dispatch(ConversationActions.initFavoriteRequest(initState))
  },
  setFavoriteRequest: (conversationId, newState) => {
    dispatch(ConversationActions.setFavoriteRequest(conversationId, newState))
  },
  readConversationRequest: (conversationId) => {
    dispatch(ConversationActions.readRequest(conversationId))
  },
  setConversationId: (conversationId) => {
    dispatch(UserActions.fetchCurrentConversationId(conversationId))
  },
  predefinedRequest: (conversationId) => {
    dispatch(ConversationActions.predefinedRequest(conversationId))
  },
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ConversationMessages)
