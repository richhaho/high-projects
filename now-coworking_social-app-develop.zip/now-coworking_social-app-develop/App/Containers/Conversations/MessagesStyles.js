import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

const imageSize = 40

export default {
  header: {
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.searchBorder,
    alignItems: 'flex-end',
    justifyContent: 'center',
    position: 'relative',
  },
  leftHeader: {},
  centerHeader: {
    position: 'absolute',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingBottom: 0,
  },
  rightHeader: {},
  title: {
    color: Colors.heading,
    fontSize: Metrics.fontSizeXl,
    paddingTop: 0,
    textAlign: 'center',
  },
  subtitle: {
    color: Colors.brandSecondary,
    fontSize: Metrics.fontSizeSm,
    paddingTop: 0,
    marginBottom: 5,
    textAlign: 'center',
  },
  spinner: {
    display: 'flex',
    flexDirection: 'column',
    flex: 1,
  },
  list: {
    paddingTop: 10,
  },
  cardWrapper: {
    flex: 1,
    paddingHorizontal: 5,
    marginVertical: 0,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardWrapperInverse: {
    flexDirection: 'row-reverse',
  },
  card: {
    flex: 1,
    marginLeft: 10,
    borderRadius: 10,
    paddingVertical: 5,
    backgroundColor: Colors.lightGrey,
  },
  cardInverse: {
    backgroundColor: Colors.brandPrimaryLight,
  },
  cardItem: {
    flex: 1,
    paddingBottom: 0,
    paddingLeft: 5,
    paddingTop: 0,
    marginBottom: 5,
    borderRadius: 10,
    backgroundColor: Colors.lightGrey,
  },
  cardItemInverse: {
    backgroundColor: Colors.brandPrimaryLight,
  },
  cardItemBody: {
    flex: 1,
    justifyContent: 'center',
    marginLeft: 15,
  },
  cardItemBodyInverse: {},
  textInverse: {
    color: Colors.white,
  },
  image: {
    height: 400,
    width: '100%',
  },
  thumb: {
    width: imageSize,
    height: imageSize,
    resizeMode: 'cover',
  },
  thumbWrapper: {
    width: imageSize,
    height: imageSize,
    borderRadius: imageSize,
    backgroundColor: Colors.white,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: Colors.white,
  },
  cardFooter: {
    fontSize: Metrics.fontSizeXs,
    color: Colors.green300,
  },
  favoriteStar: {
    color: Colors.brandPrimary,
  },
  input: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
  },
  inputText: {
    flex: 1,
  },
  plusIcon: {
    marginBottom: 10,
    marginLeft: 15,
  },
  imgPreview: {
    marginLeft: 15,
    marginBottom: 10,
    width: 70,
    height: 70,
  },
  swiperWrapper: {
    flex: 1,
    justifyContent: 'flex-end',
    marginBottom: 10,
  },
  swiper: {
    flex: 0.4,
    backgroundColor: Colors.lightGrey,
  },
  swiperItem: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-start',
    paddingHorizontal: 20,
  },
  swiperText: {
    color: Colors.darkGrey,
  },
  swiperSeparator: {
    borderWidth: 1,
    borderColor: Colors.brandPrimary,
    marginVertical: 10,
    width: '20%',
  },
  swiperHint: {
    fontStyle: 'italic',
    fontSize: Metrics.fontSizeXs,
    color: Colors.darkGrey,
    marginBottom: 40,
  },
}
