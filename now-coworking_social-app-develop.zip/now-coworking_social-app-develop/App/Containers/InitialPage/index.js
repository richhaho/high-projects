import React from 'react'
import { connect } from 'react-redux'
import AuthActions from 'App/Stores/Auth/Actions'
import StatusBarApp from 'App/Components/StatusBarApp'

class InitialPage extends React.Component {
  componentDidMount() {
    this.props.checkAuth()
  }

  render() {
    return <StatusBarApp />
  }
}

const mapStateToProps = (state) => {
  return {
    loading: state.auth.get('loading'),
    errorCheckAuth: state.auth.get('errorCheckAuth'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  checkAuth: () => dispatch(AuthActions.checkAuthRequest()),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(InitialPage)
