import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

export default {
  container: {
    flex: 1,
    justifyContent: 'center',
    flexDirection: 'column',
  },
  scrollView: {
    flex: 1,
    justifyContent: 'center',
  },
  logo: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: 30,
    marginTop: 30,
  },
  logoImage: {
    width: 256,
    height: 141,
    resizeMode: 'contain',
    marginBottom: 10,
  },
  form: {
    paddingHorizontal: 30,
    marginBottom: 20,
    position: 'relative',
  },
  formInputWrapper: {
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 16,
    borderColor: Colors.inputBorder,
    backgroundColor: Colors.white,
    shadowColor: Colors.black,
    shadowOpacity: 0.05,
    shadowRadius: 3,
    shadowOffset: {
      height: 3,
      width: 0,
    },
  },
  formInputWrapperError: {
    borderColor: Colors.inputBorderError,
  },
  formInput: {
    paddingLeft: 0,
    color: Colors.brandSecondary,
    fontSize: Metrics.fontSizeXl,
    lineHeight: 21,
    height: 63,
  },
  formInputError: {
    color: Colors.brandRed,
  },
  toggleWrapper: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 30,
  },
  toggleLabel: {
    color: Colors.brandSecondary,
    fontSize: Metrics.fontSizeMd,
    lineHeight: 19,
    marginLeft: 15,
  },
  footer: {
    paddingHorizontal: 0,
    marginBottom: 30,
  },
  submitSpinner: {
    position: 'absolute',
  },
  submitButtonShadow: {
    backgroundColor: Colors.white,
    borderRadius: 30,
    overflow: 'hidden',
    shadowColor: Colors.black,
    shadowOpacity: 0.12,
    shadowRadius: 25,
    shadowOffset: {
      height: 13,
      width: 0,
    },
    marginHorizontal: 30,
    position: 'relative',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  submitButton: {
    display: 'flex',
    width: '100%',
    height: 61,
    borderColor: Colors.green100,
    borderRadius: 30,
    justifyContent: 'center',
  },
  submitButtonText: {
    textAlign: 'center',
    color: Colors.green100,
    fontSize: Metrics.fontSizeMd,
  },
  resetButton: {
    width: '100%',
    marginTop: 10,
    paddingTop: 0,
    paddingBottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  resetButtonText: {
    color: Colors.brandPrimary,
    fontSize: Metrics.fontSizeSm,
    textAlign: 'center',
  },
  errorMessage: {
    color: Colors.brandRed,
    fontSize: Metrics.fontSizeSm,
    fontWeight: 'bold',
    textAlign: 'center',
    position: 'absolute',
    top: -28,
    left: 30,
    width: '100%',
  },
}
