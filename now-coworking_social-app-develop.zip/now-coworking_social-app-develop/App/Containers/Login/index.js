import React, { Component } from 'react'
import { ScrollView, View, Image, Linking } from 'react-native'
import { connect } from 'react-redux'
import ToggleSwitch from 'toggle-switch-react-native'
import { Container, Text, Spinner, Button, Item, Input, Toast } from 'native-base'

import Styles from './Styles'
import BaseStyle from 'App/Theme/Base'
import Images from 'App/Theme/Images'
import Colors from 'App/Theme/Colors'
import { Config } from 'App/Config'
import AuthActions from 'App/Stores/Auth/Actions'
import Icon from 'App/Components/Icon'
import StatusBarApp from 'App/Components/StatusBarApp'

class Login extends Component {
  constructor(props) {
    super(props)
    this.state = {
      email: '',
      password: '',
      stayConnected: false,
      submitted: false,
    }
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.error && prevState.error !== nextProps.error) {
      Toast.show({
        text: nextProps.error,
        buttonText: 'Fermer',
        type: 'danger',
        duration: 4000,
        position: 'top',
      })
    }
    return nextProps
  }

  openLink(url) {
    Linking.openURL(url)
  }

  handleSubmit() {
    const { loginUser } = this.props
    const { email, password, stayConnected } = this.state

    this.setState({ submitted: true })

    if (email && password) {
      loginUser(email, password, stayConnected)
    }
  }

  _renderLogo() {
    return (
      <View style={Styles.logo}>
        <Image style={Styles.logoImage} source={Images.logo} />
      </View>
    )
  }

  _renderForm() {
    const { error } = this.props
    const { submitted, email, password } = this.state
    const errorMessage = 'Email ou mot de passe invalide...'

    return (
      <View style={Styles.form}>
        {error ? <Text style={Styles.errorMessage}>{errorMessage}</Text> : null}

        <View>
          <Item
            rounded
            style={
              error || (submitted && !email)
                ? [Styles.formInputWrapper, Styles.formInputWrapperError]
                : Styles.formInputWrapper
            }
          >
            <Icon
              name="email"
              style={[
                BaseStyle.iconInput,
                error || (submitted && !email) ? BaseStyle.iconInputError : null,
              ]}
            />

            <Input
              style={
                error || (submitted && !email)
                  ? [Styles.formInput, Styles.formInputError]
                  : Styles.formInput
              }
              autoCapitalize={'none'}
              placeholder="email@email.com"
              onChangeText={(email) => this.setState({ email })}
              value={email}
            />
          </Item>

          <Item
            rounded
            style={
              error || (submitted && !email)
                ? [Styles.formInputWrapper, Styles.formInputWrapperError]
                : Styles.formInputWrapper
            }
          >
            <Icon
              name="lock"
              style={[
                BaseStyle.iconInput,
                BaseStyle.iconInputLock,
                error || (submitted && !email) ? BaseStyle.iconInputError : null,
              ]}
              size={18}
            />

            <Input
              style={
                error || (submitted && !email)
                  ? [Styles.formInput, Styles.formInputError]
                  : Styles.formInput
              }
              placeholder="password"
              secureTextEntry={true}
              onChangeText={(password) => this.setState({ password })}
              value={password}
            />
          </Item>
        </View>
      </View>
    )
  }

  _renderSwitch() {
    return (
      <View style={Styles.toggleWrapper}>
        <ToggleSwitch
          isOn={this.state.stayConnected}
          onColor="#8A7D5C"
          offColor="#E9EDF1"
          onToggle={(stayConnected) => this.setState({ stayConnected })}
        />
        <Text style={Styles.toggleLabel}>Rester connecté</Text>
      </View>
    )
  }

  _renderFooter() {
    const { loading } = this.props
    return (
      <View style={Styles.footer}>
        <View style={Styles.submitButtonShadow}>
          <Button
            bordered
            disabled={loading}
            style={Styles.submitButton}
            onPress={() => this.handleSubmit()}
          >
            {!loading ? <Text style={Styles.submitButtonText}>SE CONNECTER</Text> : null}
          </Button>

          {loading ? <Spinner color={Colors.brandPrimary} style={Styles.submitSpinner} /> : null}
        </View>

        <Button
          transparent
          style={Styles.resetButton}
          onPress={() => this.openLink(Config.FORGOT_PASSWORD_URL)}
        >
          <Text style={Styles.resetButtonText}>Mot de passe oublié ?</Text>
        </Button>
      </View>
    )
  }

  render() {
    return (
      <Container style={Styles.container}>
        <StatusBarApp />
        <ScrollView contentContainerStyle={Styles.scrollView}>
          {this._renderLogo()}
          {this._renderForm()}
          {this._renderSwitch()}
          {this._renderFooter()}
        </ScrollView>
      </Container>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    user: state.auth.get('user'),
    loading: state.auth.get('loading'),
    error: state.auth.get('error'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  loginUser: (email, password, stayConnected) =>
    dispatch(AuthActions.loginRequest(email, password, stayConnected)),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Login)
