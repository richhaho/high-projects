import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'
const React = require('react-native')
const { Dimensions } = React

export default {
  header: {
    backgroundColor: '#fff',
    borderBottomWidth: 0,
    height: 70,
    paddingTop: 40,
  },
  title: {
    color: '#444A53',
    fontSize: 18,
    paddingTop: 0,
  },
  content: {
    flex: 1,
    paddingRight: 0,
    paddingLeft: 0,
    marginLeft: 0,
    marginRight: 0,
  },
  swipeContainer: {
    flex: 1,
    backgroundColor: Colors.white,
    paddingTop: 50,
    paddingHorizontal: 20,
  },
  noData: {
    fontSize: 15,
    color: '#000',
    textAlign: 'center',
  },
  footer: {
    backgroundColor: 'white',
    padding: 15,
    justifyContent: 'center',
  },
  contentFlex: {
    flex: 1,
  },
  spinner: {
    marginTop: Dimensions.get('window').height / 3,
    position: 'absolute',
    alignSelf: 'center',
  },
  emptyContainer: {
    flexDirection: 'column',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainerMessage: {
    textAlign: 'center',
    fontSize: 22,
    marginBottom: 10,
    color: Colors.black,
  },
  emptyContainerSmall: {
    textAlign: 'center',
    fontSize: Metrics.fontSizeSm,
    color: Colors.brandSecondary,
    fontStyle: 'italic',
  },
}
