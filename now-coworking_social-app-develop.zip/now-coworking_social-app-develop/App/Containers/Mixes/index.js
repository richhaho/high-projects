import React, { Component } from 'react'
import { View } from 'react-native'
import { connect } from 'react-redux'
import Colors from 'App/Theme/Colors'
import { Container, Spinner, Text } from 'native-base'
import MixesActions from 'App/Stores/Mixes/Actions'
import SwipeCards from 'react-native-swipe-cards'

import SegmentedButton from 'App/Components/SegmentedButton'
import Styles from './Styles'
import SwipeCard from 'App/Components/SwipeCard'
import { NOPE_MIX, YUP_MIX } from 'App/Sagas/MixesSaga'

class Mixes extends Component {
  constructor(props) {
    super(props)
    this.state = {
      nbMixesDone: 0,
    }
  }

  componentDidMount() {
    const { fetchMixes } = this.props
    fetchMixes()
  }
  handleLeftButton() {
    const { nopeMixes } = this.props
    if (this._deckSwiper.state.card) {
      nopeMixes(this._deckSwiper.state.card.coworker.id)
      this._deckSwiper._forceLeftSwipe()
      this.setState({ nbMixesDone: this.state.nbMixesDone + 1 })
    }
  }
  handleRightButton() {
    const { yupMixes } = this.props
    if (this._deckSwiper.state.card) {
      this._deckSwiper._forceRightSwipe()
      yupMixes(this._deckSwiper.state.card.coworker.id)
      this.setState({ nbMixesDone: this.state.nbMixesDone + 1 })
    }
  }

  render() {
    const { loading, yupMixes, nopeMixes, mixes } = this.props
    if (loading) {
      return <Spinner color={Colors.brandPrimary} style={Styles.spinner} />
    }

    return (
      <Container>
        <View style={Styles.swipeContainer}>
          <SwipeCards
            ref={(c) => (this._deckSwiper = c)}
            showNope={false}
            showYup={false}
            cards={mixes}
            renderCard={(cardData) => (
              <SwipeCard user={cardData.coworker} wantMix={cardData.wantMix} />
            )}
            renderNoMoreCards={() => (
              <View style={Styles.emptyContainer}>
                <Text style={Styles.emptyContainerMessage}>
                  {'Votre limite de rencontre est épuisée, vous pourrez recommencer demain matin !'}
                </Text>
                <Text style={Styles.emptyContainerSmall}>
                  {
                    "Envie de découvrir encore plus de monde, n'hésitez pas à rentrer en contact avec les coworkers dans la partie trombinoscope."
                  }
                </Text>
              </View>
            )}
            handleYup={(cardData) => {
              this.setState({ nbMixesDone: this.state.nbMixesDone + 1 })
              yupMixes(cardData.coworker.id)
            }}
            handleNope={(cardData) => {
              this.setState({ nbMixesDone: this.state.nbMixesDone + 1 })
              nopeMixes(cardData.coworker.id)
            }}
          />
        </View>
        {/* If the user swipe all mixes */}
        {!(this.state.nbMixesDone === this.props.mixes.length) ? (
          <View style={Styles.footer}>
            <SegmentedButton
              leftButtonText={'PASSER'}
              onPressLeftButton={this.handleLeftButton.bind(this)}
              rightButtonText={'RENCONTRER'}
              onPressRightButton={this.handleRightButton.bind(this)}
            />
          </View>
        ) : null}
      </Container>
    )
  }
}
const mapStateToProps = (state) => {
  return {
    mixes: state.mixes.get('mixes').toJS(),
    loading: state.mixes.get('loading'),
    error: state.mixes.get('error'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  fetchMixes: () => dispatch(MixesActions.fetchMixes()),
  yupMixes: (idCoworker) => dispatch(MixesActions.swipeMixes(idCoworker, YUP_MIX)),
  nopeMixes: (idCoworker) => dispatch(MixesActions.swipeMixes(idCoworker, NOPE_MIX)),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Mixes)
