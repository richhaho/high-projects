import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

export default {
  container: {
    paddingLeft: 0,
    paddingRight: 0,
  },
  header: {
    backgroundColor: Colors.white,
    borderBottomWidth: 0,
    height: 70,
    paddingTop: 40,
  },
  title: {
    color: Colors.heading,
    fontSize: Metrics.fontSizeXl,
    paddingTop: 0,
  },
  content: {
    paddingTop: 20,
    paddingRight: 0,
    paddingLeft: 0,
    marginLeft: 0,
    marginRight: 0,
  },
}
