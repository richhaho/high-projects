import React, { Component } from 'react'

import { Container, Header, Content, Title, Text, Left, Button, Body, Right } from 'native-base'

import Styles from './Styles'
import StyleBase from 'App/Theme/Base'
import NavigationService from 'App/Services/NavigationService'
import Icon from 'react-native-vector-icons/EvilIcons'

class NotImplemented extends Component {
  render() {
    return (
      <Container style={Styles.container}>
        <Header style={Styles.header}>
          <Left style={StyleBase.flex}>
            <Button transparent onPress={() => NavigationService.navigate('TabNavigation')}>
              <Icon style={Styles.icon} size={45} name="chevron-left" />
            </Button>
          </Left>
          <Body style={StyleBase.flex}>
            <Title style={Styles.title}>{'Page vide'}</Title>
          </Body>
          <Right style={StyleBase.flex} />
        </Header>

        <Content>
          <Text>
            {
              "Il semblerait que vous essayez d'atteindre une page qui ne soit pas encore implémentée"
            }
          </Text>
        </Content>
      </Container>
    )
  }
}

export default NotImplemented
