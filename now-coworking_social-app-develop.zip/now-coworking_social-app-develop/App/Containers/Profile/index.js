import React, { Component } from 'react'
import { Spinner } from 'native-base'

import UserProfile from 'App/Components/User/Profile'
import { connect } from 'react-redux'
import UserActions from 'App/Stores/User/Actions'
import Colors from 'App/Theme/Colors'

class Profile extends Component {
  constructor(props) {
    super(props)

    this.state = {
      user: null,
      loading: true,
    }
  }

  componentDidMount() {
    const { navigation, fetchProfileUser } = this.props

    if (navigation.getParam('userId')) {
      fetchProfileUser(navigation.getParam('userId'))
    } else {
      this.setState({
        user: navigation.getParam('user'),
      })
    }

    this.setState({
      loading: false,
    })
  }

  goBack() {
    const { navigation } = this.props
    navigation.goBack()
  }

  render() {
    if (this.props.loading || this.state.loading) {
      return <Spinner color={Colors.brandPrimary} />
    }

    return (
      <UserProfile
        user={this.state.user ? this.state.user : this.props.profileUser.toJS()}
        goBack={() => this.goBack()}
      />
    )
  }
}

const mapStateToProps = (state) => {
  return {
    loading: state.user.get('profileUserLoading'),
    profileUser: state.user.get('profileUser'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  fetchProfileUser: (userId) => dispatch(UserActions.fetchProfileUser(userId)),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Profile)
