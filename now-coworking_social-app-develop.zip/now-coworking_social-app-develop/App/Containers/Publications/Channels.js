import React, { Component } from 'react'
import { SectionList } from 'react-native'
import { Container, Header, Title, Text, ListItem, Left, Body, Spinner } from 'native-base'
import StatusBarApp from 'App/Components/StatusBarApp'
import Styles from './ChannelsStyles'
import PublicationActions from 'App/Stores/Publication/Actions'
import { connect } from 'react-redux'
import Colors from 'App/Theme/Colors'
import NavigationService from 'App/Services/NavigationService'

class Channels extends Component {
  componentDidMount() {
    this.props.getGroups()
  }

  static navigationOptions = {
    header: null,
  }

  _renderList(groups) {
    const sections = groups.map((item) => {
      return { title: item.Name, data: item.Channels, key: item.Id }
    })
    return (
      <SectionList
        stickySectionHeadersEnabled={false}
        keyExtractor={(item) => item.Id}
        renderItem={({ item, section: { key } }) => (
          <ListItem
            icon
            style={Styles.listItem}
            button
            onPress={() =>
              NavigationService.navigate('PublicationList', {
                title: item.Name,
                channelId: item.Id,
                channelName: item.Name,
                groupId: key,
              })
            }
          >
            <Left>
              <Text style={Styles.listItemHashTag}>#</Text>
            </Left>
            <Body>
              <Text style={Styles.listItemText}>{item.Name}</Text>
            </Body>
          </ListItem>
        )}
        renderSectionHeader={({ section: { title } }) => (
          <Text style={Styles.section}>{title}</Text>
        )}
        sections={sections}
      />
    )
  }

  render() {
    const { groups, loading } = this.props
    return (
      <Container>
        <Header style={Styles.header}>
          <StatusBarApp />
          <Title style={Styles.title}>Publications</Title>
        </Header>

        {groups.length > 0 ? (
          this._renderList(groups)
        ) : loading ? (
          <Spinner color={Colors.brandPrimary} />
        ) : (
          <Text>{'Aucun groupe de publication trouvé'}</Text>
        )}
      </Container>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    groups: state.publication.get('groups').toJS(),
    loading: state.publication.get('loading'),
    error: state.publication.get('error'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  getGroups: () => dispatch(PublicationActions.getGroupsRequest()),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Channels)
