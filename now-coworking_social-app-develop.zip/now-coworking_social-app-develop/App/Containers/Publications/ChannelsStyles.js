import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

export default {
  header: {
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.searchBorder,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    color: Colors.heading,
    fontSize: Metrics.fontSizeXl,
  },
  content: {
    paddingTop: 10,
  },
  textCenter: {
    textAlign: 'center',
  },
  listItem: {
    paddingVertical: 30,
  },
  listItemHashTag: {
    color: Colors.green300,
  },
  listItemText: {
    color: Colors.green300,
  },
  section: {
    color: Colors.black,
    fontWeight: 'bold',
    textAlign: 'center',
    paddingTop: 20,
    paddingBottom: 15,
    borderBottomColor: Colors.brandGrey,
    borderBottomWidth: 2,
    marginHorizontal: 10,
  },
}
