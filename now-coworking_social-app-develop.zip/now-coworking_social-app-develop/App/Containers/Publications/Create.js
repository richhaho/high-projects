import React, { Component } from 'react'
import { View } from 'react-native'
import {
  Container,
  Content,
  Form,
  Label,
  Input,
  Textarea,
  Button,
  Title,
  Header,
  Text,
  Spinner,
  Toast,
  Subtitle,
} from 'native-base'

import Styles from './CreateStyles'
import Colors from 'App/Theme/Colors'
import PublicationActions from 'App/Stores/Publication/Actions'
import connect from 'react-redux/es/connect/connect'
import NavigationService from 'App/Services/NavigationService'
import AppIcon from 'react-native-vector-icons/EvilIcons'
import StatusBarApp from 'App/Components/StatusBarApp'

class Create extends Component {
  constructor(props) {
    super(props)
    const { navigation } = this.props
    this.state = {
      channelName: navigation.getParam('channelName', 'Non défini'),
      channelId: navigation.getParam('channelId', ''),
      groupId: navigation.getParam('groupId', ''),
      title: '',
      content: '',
    }
  }
  static navigationOptions = {
    header: null,
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.error && prevState.error !== nextProps.error) {
      Toast.show({
        text: nextProps.error,
        buttonText: 'Fermer',
        type: 'danger',
        duration: 4000,
        position: 'top',
      })
    }
    return nextProps
  }
  handleSubmit() {
    let { groupId, channelId, title, content } = this.state
    this.props.createPublication(groupId, channelId, title, content)
  }
  render() {
    const { loading } = this.props
    let { channelName, channelId, groupId, title, content } = this.state
    return (
      <Container>
        <Header style={Styles.header}>
          <View style={Styles.headerLeft}>
            <StatusBarApp />
            <Button
              transparent
              onPress={() =>
                NavigationService.navigate('PublicationList', {
                  title: channelName,
                  channelId: channelId,
                  channelName: channelName,
                  groupId: groupId,
                })
              }
            >
              <AppIcon style={Styles.icon} size={45} name="chevron-left" />
            </Button>
          </View>
          <View style={Styles.bodyHeader}>
            <Title style={Styles.title}>{"Création d'une publication"}</Title>
            <Subtitle style={Styles.subtitle}>{this.state.channelName}</Subtitle>
          </View>
        </Header>
        <Content style={Styles.content}>
          <Form>
            <View>
              <Label style={Styles.label}>TITRE* :</Label>
              <Input
                value={title}
                onChangeText={(title) => this.setState({ title })}
                placeholderTextColor={Colors.green300}
                placeholder={'Le titre de votre publication'}
              />
            </View>
            <View>
              <Label style={Styles.label}>CONTENU* :</Label>
              <Textarea
                value={content}
                onChangeText={(content) => this.setState({ content })}
                placeholderTextColor={Colors.green300}
                placeholder={'Le contenu de votre publication'}
                rowSpan={8}
              />
            </View>
          </Form>
          <View style={Styles.submitButtonShadow}>
            <Button
              bordered
              disabled={loading}
              style={Styles.submitButton}
              onPress={() => this.handleSubmit()}
            >
              {!loading ? <Text style={Styles.submitButtonText}>PUBLIER</Text> : null}
            </Button>

            {loading ? <Spinner color={Colors.brandPrimary} style={Styles.submitSpinner} /> : null}
          </View>
        </Content>
      </Container>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    loading: state.publication.get('loading'),
    error: state.publication.get('errorCreation'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  createPublication: (groupId, channelId, title, content) => {
    dispatch(PublicationActions.createPublicationRequest(groupId, channelId, title, content))
  },
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Create)
