import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

export default {
  header: {
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.searchBorder,
    alignItems: 'flex-end',
    justifyContent: 'center',
    position: 'relative',
  },
  headerLeft: {
    position: 'absolute',
    left: 0,
  },
  bodyHeader: {
    position: 'absolute',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingBottom: 10,
  },
  title: {
    color: Colors.heading,
    fontSize: Metrics.fontSizeXl,
  },
  subtitle: {
    color: Colors.heading,
    fontSize: Metrics.fontSizeXs,
  },
  content: {
    paddingTop: 10,
    paddingHorizontal: 15,
  },
  label: {
    color: Colors.black,
    paddingTop: 20,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: Colors.green100,
  },
  input: {
    fontSize: Metrics.fontSizeMd,
  },
  submitButtonShadow: {
    backgroundColor: Colors.white,
    borderRadius: 30,
    flex: 1,
    overflow: 'hidden',
    shadowColor: Colors.black,
    shadowOpacity: 0.12,
    shadowRadius: 25,
    shadowOffset: {
      height: 13,
      width: 0,
    },
    justifyContent: 'center',
    alignItems: 'center',
  },
  submitButton: {
    display: 'flex',
    width: '100%',
    height: 61,
    borderColor: Colors.green100,
    borderRadius: 30,
    justifyContent: 'center',
  },
  submitButtonText: {
    textAlign: 'center',
    color: Colors.green100,
    fontSize: Metrics.fontSizeMd,
  },
  submitSpinner: {
    position: 'absolute',
  },
}
