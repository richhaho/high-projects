import React, { Component } from 'react'
import {
  Platform,
  Image,
  View,
  Keyboard,
  TouchableOpacity,
  KeyboardAvoidingView,
  ScrollView,
} from 'react-native'
import {
  Container,
  Header,
  Content,
  Title,
  Subtitle,
  Button,
  Text,
  Spinner,
  Toast,
} from 'native-base'
import PublicationActions from 'App/Stores/Publication/Actions'
import connect from 'react-redux/es/connect/connect'
import Styles from './PublicationStyles'
import StyleBase from 'App/Theme/Base'
import Colors from 'App/Theme/Colors'
import moment from 'moment'
import ReadMoreText from './ReadMoreText'
import NavigationService from 'App/Services/NavigationService'
import Icon from 'react-native-vector-icons/EvilIcons'
import Comment from 'App/Components/Comment'
import StatusBarApp from 'App/Components/StatusBarApp'
import InputSend from 'App/Components/Input/Send'

class Publication extends Component {
  constructor(props) {
    super(props)

    this.state = {
      inputText: '',
    }
  }
  static navigationOptions = {
    header: null,
  }
  componentDidMount() {
    const { getPublication, resetPublication, navigation } = this.props
    const publicationId = navigation.getParam('publicationId')
    resetPublication()
    getPublication(publicationId)
  }

  componentDidUpdate(prevProps, prevState) {
    if (prevState.sending && prevProps.publication !== this.props.publication) {
      this.setState({ sent: true })
    }
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (prevState.sending && !nextProps.sending && !nextProps.errorComment) {
      prevState.inputText = ''
    }
    if (nextProps.errorComment && prevState.errorComment !== nextProps.errorComment) {
      Toast.show({
        text: nextProps.errorComment,
        buttonText: 'Fermer',
        type: 'danger',
        duration: 4000,
        position: 'top',
      })
    }
    return nextProps
  }

  redirectToProfile(userId) {
    NavigationService.navigate('Profile', { userId: userId })
  }

  _getTimeFromString(strTime) {
    return moment(strTime).format('[Le] DD/MM/YYYY [à] HH:MM')
  }

  _renderComments(comments) {
    let commentsReversed = comments.slice(0)
    commentsReversed = commentsReversed.reverse()
    return (
      <View style={Styles.commentWrapper}>
        {commentsReversed.map((data) => {
          return <Comment key={data.Id} data={data} />
        })}
      </View>
    )
  }

  _renderTruncatedFooter = (handlePress) => {
    return (
      <View style={Styles.buttonWrapper}>
        <View style={Styles.buttonRadius}>
          <Button bordered style={Styles.button} onPress={handlePress}>
            <Text style={Styles.buttonText}>{'LIRE LA SUITE'}</Text>
          </Button>
        </View>
      </View>
    )
  }

  _renderRevealedFooter = (handlePress) => {
    return (
      <View style={Styles.buttonWrapper}>
        <View style={Styles.buttonRadius}>
          <Button bordered style={Styles.button} onPress={handlePress}>
            <Text style={Styles.buttonText}>{'RÉDUIRE'}</Text>
          </Button>
        </View>
      </View>
    )
  }

  newComment() {
    const { navigation, sendComment, sending } = this.props
    if (sending) {
      return
    }
    const publicationId = navigation.getParam('publicationId')
    sendComment(publicationId, this.state.inputText)
    this.setState({ inputText: '' })
    Keyboard.dismiss()
  }

  scrollToEnd() {
    if (this.state.sent) {
      this.scrollView.scrollToEnd()
    }
  }

  render() {
    const { loading, publication, sending } = this.props
    if (loading) {
      return (
        <View style={Styles.spinnerWrapper}>
          <Spinner color={Colors.brandPrimary} />
        </View>
      )
    }
    let authorPicture = publication.AuthorPicture
    if (this.readMoreText && publication.Answers && publication.Answers.length > 0) {
      this.readMoreText.setShouldShowReadMore()
    }
    return (
      <Container>
        <KeyboardAvoidingView
          style={StyleBase.flex}
          behavior={'padding'}
          enabled={Platform.OS === 'ios'}
        >
          <Header style={Styles.header}>
            <View style={Styles.headerLeft}>
              <StatusBarApp />
              <Button transparent onPress={() => NavigationService.goBack()}>
                <Icon style={Styles.icon} size={45} name="chevron-left" />
              </Button>
            </View>
            <View style={Styles.bodyHeader}>
              <Title style={Styles.title}>{publication.ChannelName}</Title>
              <Subtitle style={Styles.subtitle}>
                {this._getTimeFromString(publication.Date)}
              </Subtitle>
            </View>
          </Header>
          <ScrollView
            ref={(ref) => (this.scrollView = ref)}
            onContentSizeChange={(width, height) => this.scrollToEnd()}
          >
            <Content style={Styles.content}>
              <View style={Styles.authorWrapper}>
                <View style={Styles.thumbWrapper}>
                  <View style={Styles.thumbInner}>
                    <TouchableOpacity
                      onPress={() => this.redirectToProfile(publication.AuthorAppId)}
                    >
                      <Image
                        style={Styles.thumb}
                        source={{
                          uri: authorPicture,
                        }}
                      />
                    </TouchableOpacity>
                  </View>
                </View>
                <View style={Styles.authorName}>
                  <Text>
                    {publication.AuthorFirstName} {publication.AuthorLastName}
                  </Text>
                </View>
              </View>
              <View>
                <Text style={Styles.titlePost}>{publication.Title}</Text>
              </View>
              <View style={StyleBase.flex}>
                <ReadMoreText
                  ref={(c) => (this.readMoreText = c)}
                  style={StyleBase.flex}
                  numberOfLines={publication.Answers && publication.Answers.length > 0 ? 5 : 0}
                  renderTruncatedFooter={this._renderTruncatedFooter}
                  renderRevealedFooter={this._renderRevealedFooter}
                >
                  <Text>{publication.Content}</Text>
                </ReadMoreText>
              </View>
              {publication.Answers ? this._renderComments(publication.Answers) : null}
            </Content>
          </ScrollView>
          <View style={Styles.commentInputWrapper}>
            <InputSend
              value={this.state.inputText}
              onChangeText={(inputText) => this.setState({ inputText })}
              multiline={true}
              numberOfLines={2}
              returnKeyType={Platform.OS === 'android' ? 'previous' : 'default'}
              enablesReturnKeyAutomatically={true}
              placeholderTextColor={Colors.green200}
              placeholder={'Commenter la publication...'}
              style={Styles.commentInput}
              onFocus={() => this.scrollView.scrollToEnd()}
              loading={sending}
              send={this.newComment.bind(this)}
              showButton={this.state.inputText.trim().length > 0 || sending}
            />
          </View>
        </KeyboardAvoidingView>
      </Container>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    publication: state.publication.get('publication').toJS(),
    loading: state.publication.get('loading'),
    error: state.publication.get('errorSinglePublication'),
    sending: state.publication.get('sending'),
    errorComment: state.publication.get('errorComment'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  getPublication: (publicationId) =>
    dispatch(PublicationActions.getSinglePublicationRequest(publicationId)),
  resetPublication: () => dispatch(PublicationActions.resetSinglePublications()),
  sendComment: (publicationId, content) =>
    dispatch(PublicationActions.sendCommentRequest(publicationId, content)),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Publication)
