import React, { Component } from 'react'
import { FlatList, View, TouchableOpacity } from 'react-native'
import StatusBarApp from 'App/Components/StatusBarApp'
import moment from 'moment'
import {
  Container,
  Text,
  Card,
  CardItem,
  Left,
  Body,
  Right,
  Spinner,
  Toast,
  Button,
  Title,
  Header,
  Fab,
  Icon,
} from 'native-base'

import Styles from './PublicationListStyles'
import StyleBase from 'App/Theme/Base'
import Colors from 'App/Theme/Colors'
import PublicationActions from 'App/Stores/Publication/Actions'
import connect from 'react-redux/es/connect/connect'
import NavigationService from 'App/Services/NavigationService'
import AppIcon from 'react-native-vector-icons/EvilIcons'

class PublicationList extends Component {
  constructor(props) {
    super(props)
    const { navigation } = this.props
    this.state = {
      channelName: navigation.getParam('channelName', 'Non défini'),
      channelId: navigation.getParam('channelId', ''),
      groupId: navigation.getParam('groupId', ''),
    }
  }

  static navigationOptions = {
    header: null,
  }

  componentDidMount() {
    const { resetPublications, getPublications } = this.props
    resetPublications()
    getPublications(this.state.groupId, this.state.channelId, 1)
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    const { currentPage, resetPublications, getPublications } = nextProps
    if (nextProps.error && prevState.error !== nextProps.error) {
      Toast.show({
        text: nextProps.error,
        buttonText: 'Fermer',
        type: 'danger',
        duration: 4000,
        position: 'top',
      })
    }
    if (nextProps.needReload && prevState.needReload !== nextProps.needReload) {
      resetPublications()
      getPublications(prevState.groupId, prevState.channelId, currentPage)
    }
    return nextProps
  }

  lazyLoad() {
    const { currentPage, getPublications } = this.props
    getPublications(this.state.groupId, this.state.channelId, currentPage + 1)
  }

  _pullToRefresh() {
    const { getPublications, resetPublications } = this.props
    resetPublications()
    getPublications(this.state.groupId, this.state.channelId, 1)
  }

  _getTimeFromString(strTime) {
    return moment(strTime).format('[Le] DD/MM/YYYY [à] HH:MM')
  }
  _renderList(publications) {
    const { loading } = this.props
    return (
      <FlatList
        contentContainerStyle={Styles.list}
        removeClippedSubviews={true}
        ListFooterComponent={() => (loading ? <Spinner color={Colors.brandPrimary} /> : <View />)}
        onEndReachedThreshold={0.7}
        onEndReached={() => {
          if (!this.onEndReachedCalledDuringMomentum) {
            this.lazyLoad()
            this.onEndReachedCalledDuringMomentum = true
          }
        }}
        onMomentumScrollBegin={() => {
          this.onEndReachedCalledDuringMomentum = false
        }}
        keyExtractor={(item) => item.Id}
        onRefresh={() => this._pullToRefresh()}
        refreshing={false} // atribute is required for onRefresh but we manage loader with loading
        renderItem={({ item }) => (
          <View style={Styles.cardWrapper}>
            <TouchableOpacity
              style={Styles.buttonCard}
              onPress={() => {
                NavigationService.navigate('Publication', { publicationId: item.Id })
              }}
            >
              <Card transparent style={Styles.card} pointerEvents="none">
                <CardItem style={Styles.firstItem}>
                  <Text>
                    <Text style={Styles.group}>{item.GroupName + ' / '}</Text>
                    <Text style={Styles.groupAccent}>{item.ChannelName}</Text>
                    <Text style={Styles.group}>{' par '}</Text>
                    <Text style={Styles.groupAccent}>
                      {item.AuthorFirstName} {item.AuthorLastName}
                    </Text>
                  </Text>
                </CardItem>
                <CardItem>
                  <Body>
                    <Text numberOfLines={2}>{item.Title}</Text>
                  </Body>
                </CardItem>
                <CardItem style={Styles.lastItem}>
                  <Left>
                    <Text style={Styles.time}>{this._getTimeFromString(item.Date)}</Text>
                  </Left>

                  <Right style={StyleBase.flex}>
                    <Text style={Styles.commentaries}>
                      {item.Answers} {'commentaires'}
                    </Text>
                  </Right>
                </CardItem>
              </Card>
            </TouchableOpacity>
          </View>
        )}
        data={publications}
      />
    )
  }
  render() {
    const { publications, loading } = this.props

    return (
      <Container>
        <Header style={Styles.header}>
          <View style={Styles.headerLeft}>
            <StatusBarApp />
            <Button transparent onPress={() => NavigationService.navigate('Channels')}>
              <AppIcon style={Styles.icon} size={45} name="chevron-left" />
            </Button>
          </View>
          <View style={Styles.body}>
            <Title style={Styles.title}>{this.state.channelName}</Title>
          </View>
        </Header>

        {publications.length > 0 ? (
          this._renderList(publications)
        ) : loading ? (
          <Spinner color={Colors.brandPrimary} />
        ) : (
          <Text>{"Il n'y a pas de publications sur ce channel"}</Text>
        )}
        <View style={StyleBase.flex}>
          <Fab
            active={false}
            direction="up"
            containerStyle={{}}
            style={Styles.fab}
            position="bottomRight"
            onPress={() =>
              NavigationService.navigate('Create', {
                channelName: this.state.channelName,
                channelId: this.state.channelId,
                groupId: this.state.groupId,
              })
            }
          >
            <Icon name="ios-create" />
          </Fab>
        </View>
      </Container>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    publications: state.publication.get('publications').toJS(),
    loading: state.publication.get('loading'),
    currentPage: state.publication.get('currentPage'),
    error: state.publication.get('errorPublication'),
    needReload: state.publication.get('needReload'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  getPublications: (groupId, channelId, page) => {
    dispatch(PublicationActions.getPublicationsRequest(groupId, channelId, page))
  },
  resetPublications: () => dispatch(PublicationActions.resetPublications()),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(PublicationList)
