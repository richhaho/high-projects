import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

export default {
  header: {
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.searchBorder,
    alignItems: 'flex-end',
    justifyContent: 'center',
    position: 'relative',
  },
  headerLeft: {
    position: 'absolute',
    left: 0,
  },
  body: {
    position: 'absolute',
    flex: 1,
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
    paddingBottom: 10,
  },
  title: {
    color: Colors.heading,
    fontSize: Metrics.fontSizeXl,
  },
  list: {
    paddingTop: 10,
  },
  cardWrapper: {
    flex: 1,
    paddingVertical: 15,
    paddingHorizontal: 15,
  },
  buttonCard: {
    backgroundColor: Colors.white,
    borderRadius: 20,
    padding: 0,
    margin: 0,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 13 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 9,
  },
  card: {
    borderRadius: 20,
  },
  group: {
    fontSize: Metrics.fontSizeXs,
    color: Colors.green200,
  },
  groupAccent: {
    fontSize: Metrics.fontSizeXs,
    color: Colors.brandSecondary,
  },
  mainText: {
    color: Colors.brandSecondary,
  },
  time: {
    fontSize: Metrics.fontSizeSm,
    marginLeft: 0,
    color: Colors.searchInput,
  },
  commentaries: {
    fontSize: Metrics.fontSizeXs,
    color: Colors.brandPrimary,
  },
  textCenter: {
    textAlign: 'center',
  },
  listItem: {
    paddingVertical: 30,
  },
  listItemHashTag: {
    color: Colors.green300,
  },
  listItemText: {
    color: Colors.green300,
  },
  firstItem: {
    paddingBottom: 0,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
  },
  lastItem: {
    paddingTop: 0,
    borderBottomLeftRadius: 15,
    borderBottomRightRadius: 15,
  },
  section: {
    color: Colors.black,
    fontWeight: 'bold',
    textAlign: 'center',
    paddingTop: 20,
    paddingBottom: 15,
    borderBottomColor: Colors.brandGrey,
    borderBottomWidth: 2,
    marginHorizontal: 10,
  },
  fab: { backgroundColor: Colors.green200 },
}
