import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

export default {
  spinnerWrapper: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: Colors.white,
  },
  header: {
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.searchBorder,
    alignItems: 'flex-end',
    justifyContent: 'center',
    position: 'relative',
  },
  headerLeft: {
    position: 'absolute',
    left: 0,
  },
  bodyHeader: {
    position: 'absolute',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingBottom: 10,
  },
  padding: {
    paddingHorizontal: 30,
  },
  content: {
    flex: 1,
    paddingVertical: 10,
    paddingHorizontal: 30,
  },
  title: {
    color: Colors.heading,
    fontSize: Metrics.fontSizeXl,
  },
  subtitle: {
    color: Colors.heading,
    fontSize: Metrics.fontSizeXs,
  },
  buttonWrapper: {
    paddingVertical: 50,
    justifyContent: 'center',
    flex: 1,
  },
  buttonRadius: {
    flex: 1,
    borderRadius: 25,
    position: 'absolute',
    alignSelf: 'center',
    zIndex: 5,
    overflow: 'hidden',
  },
  button: {
    flex: 1,
    backgroundColor: Colors.white,
    borderColor: Colors.brandPrimary,
    borderRadius: 25,
    paddingVertical: 15,
    elevation: 2,
  },
  buttonText: { color: Colors.brandPrimary },
  authorWrapper: {
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  thumbWrapper: {
    width: 52,
    height: 52,
    borderRadius: 52,
    marginBottom: 5,
    backgroundColor: Colors.green200,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  thumb: {
    width: 60,
    height: 60,
    resizeMode: 'cover',
  },
  thumbInner: {
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: Colors.white,
    overflow: 'hidden',
    borderRadius: 46,
    width: 46,
    height: 46,
  },
  authorName: { paddingLeft: 10 },
  titlePost: {
    fontSize: Metrics.fontSizeXl,
    fontWeight: 'bold',
    color: Colors.brandPrimary,
    marginBottom: 20,
  },
  separator: {
    borderBottomColor: Colors.inputBorder,
    borderBottomWidth: 3,
    zIndex: 1,
  },
  commentWrapper: {
    paddingBottom: 15,
  },
  commentInputWrapper: {
    backgroundColor: 'transparent',
    paddingHorizontal: 15,
    paddingBottom: 10,
  },
  commentInputItem: {
    borderColor: Colors.green200,
    borderWidth: 2,
    paddingHorizontal: 5,
  },
  commentInput: {
    height: 60,
  },
  commentInputIcon: {
    color: Colors.white,
  },
  commentButton: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: 40,
    height: 40,
    borderRadius: 40,
    backgroundColor: Colors.brandSecondary,
  },
}
