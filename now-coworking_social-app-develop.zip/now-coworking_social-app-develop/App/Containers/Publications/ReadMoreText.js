import ReadMore from 'react-native-read-more-text'

export default class ReadMoreText extends ReadMore {
  async setShouldShowReadMore() {
    const fullHeight = await measureHeightAsync(this._text)
    this.setState({ measured: true })
    await nextFrameAsync()
    const limitedHeight = await measureHeightAsync(this._text)
    if (fullHeight > limitedHeight) {
      this.setState({ shouldShowReadMore: true })
    }
  }
}

function measureHeightAsync(component) {
  return new Promise((resolve) => {
    component.measure((x, y, w, h) => {
      resolve(h)
    })
  })
}

function nextFrameAsync() {
  return new Promise((resolve) => requestAnimationFrame(() => resolve()))
}
