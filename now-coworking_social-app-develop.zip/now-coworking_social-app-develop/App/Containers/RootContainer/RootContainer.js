import React, { Component } from 'react'
import { Root } from 'native-base'
import { createStackNavigator } from 'react-navigation'
import InitialPage from 'App/Containers/InitialPage'
import Login from 'App/Containers/Login'
import TabNavigation from 'App/Containers/Tabs/TabNavigation'
import Profile from 'App/Containers/Profile'
import Users from 'App/Containers/Users'
import Colors from 'App/Theme/Colors'
import NotImplemented from 'App/Containers/NotImplemented'
import NavigationService from 'App/Services/NavigationService'
import styles from './RootContainerStyle'
import firebase from 'react-native-firebase'
import { connect } from 'react-redux'
import UserActions from 'App/Stores/User/Actions'
import ConversationActions from 'App/Stores/Conversation/Actions'
import NotificationBadgeAction from 'App/Stores/NotificationBadge/Actions'

const AppNav = createStackNavigator(
  {
    InitialPage: { screen: InitialPage },
    Login: { screen: Login },
    TabNavigation: { screen: TabNavigation },
    Profile: { screen: Profile },
    Users: { screen: Users },
    NotImplemented: { screen: NotImplemented },
  },
  {
    initialRouteName: 'InitialPage',
    headerMode: 'none',
  }
)

class RootContainer extends Component {
  componentDidMount() {
    this.onTokenRefreshListener = firebase.messaging().onTokenRefresh((fcmToken) => {
      this.props.fetchDeviceToken(fcmToken)
    })

    // Build a channel
    const channel = new firebase.notifications.Android.Channel(
      'nowco-channel',
      'NowCo Channel',
      firebase.notifications.Android.Importance.Max
    ).setDescription('Now Social channel')

    // Create the channel
    firebase.notifications().android.createChannel(channel)

    firebase
      .messaging()
      .hasPermission()
      .then((enabled) => {
        if (enabled) {
          this.notificationListener = firebase.notifications().onNotification((notification) => {
            this.receiveNotification(notification, channel)
          })
          this.notificationOpenedListener = firebase
            .notifications()
            .onNotificationOpened((notificationOpen) => {
              const notification = notificationOpen.notification
              if (notification.data && notification.data.conversationId) {
                this.props.redirectToConversation(notification.data.conversationId)
              }
            })
        } else {
          firebase
            .messaging()
            .requestPermission()
            .then(() => {
              this.notificationListener = firebase
                .notifications()
                .onNotification((notification) => {
                  this.receiveNotification(notification, channel)
                })
            })
        }
      })
  }

  receiveNotification(notification, channel) {
    const { resetList, getAllConversations, getNbBadges } = this.props
    resetList()
    getAllConversations(0)
    getNbBadges(this.props.nbBadges + 1)
    const myNotification = new firebase.notifications.Notification()
      .setNotificationId(notification.notificationId)
      .setTitle(notification.title)
      .setBody(notification.body)
      .setData(notification.data)
      .android.setSmallIcon('ic_stat_nowco_notification')
      .android.setColor(Colors.brandPrimary)

    myNotification.android.setChannelId(channel.channelId).ios.setBadge(this.props.nbBadges)

    if (
      !notification.data ||
      !notification.data.conversationId ||
      (this.props.conversationId !== null
        ? notification.data.conversationId.toString() !== this.props.conversationId.toString()
        : true)
    ) {
      firebase.notifications().displayNotification(myNotification)
    }
  }

  componentWillUnmount() {
    this.onTokenRefreshListener()
    this.notificationListener()
    this.notificationOpenedListener()
  }

  render() {
    return (
      <Root style={styles.rootContainer}>
        <AppNav
          ref={(navigatorRef) => {
            NavigationService.setTopLevelNavigator(navigatorRef)
          }}
        />
      </Root>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    conversationId: state.user.get('currentConversationId'),
    nbBadges: state.notification.get('nbBadges'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  fetchDeviceToken: (token) => dispatch(UserActions.fetchDeviceToken(token)),
  redirectToConversation: (conversationId) => {
    dispatch(ConversationActions.getRequest(conversationId))
  },
  getNbBadges: (nbBadges) => dispatch(NotificationBadgeAction.success(nbBadges)),
  getAllConversations: (page) => dispatch(ConversationActions.listRequest(page)),
  resetList: () => dispatch(ConversationActions.listReset()),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(RootContainer)
