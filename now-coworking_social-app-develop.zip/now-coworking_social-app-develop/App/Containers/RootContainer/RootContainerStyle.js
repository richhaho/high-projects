export default {
  rootContainer: {
    flex: 1,
  },
}
