import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

export default {
  header: {
    backgroundColor: Colors.white,
    borderBottomWidth: 0,
    height: 70,
    paddingTop: 40,
  },
  title: {
    color: Colors.heading,
    fontSize: Metrics.fontSizeXl,
    paddingTop: 0,
  },
  content: {
    paddingTop: 50,
  },
  contentContainer: {
    justifyContent: 'space-between',
    flex: 1,
  },
  listItem: {
    justifyContent: 'center',
    borderBottomWidth: 2,
    borderBottomColor: Colors.border,
    paddingTop: 35,
    paddingBottom: 35,
  },
  listItemText: {
    color: Colors.heading,
  },
  first: {
    borderTopWidth: 2,
    borderTopColor: Colors.border,
  },
  textCenter: {
    textAlign: 'center',
  },
  listItemRight: {
    alignSelf: 'center',
  },
  icon: { color: Colors.black },
  socialLinks: {
    display: 'flex',
    flexDirection: 'row',
    marginBottom: 49,
    justifyContent: 'center',
    alignItems: 'center',
  },
  socialLinkButton: {
    width: 40,
    height: 41,
    marginHorizontal: 12.5,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.12,
    shadowRadius: 5,
  },
  socialLinkImage: {
    width: 40,
    height: 41,
    resizeMode: 'contain',
  },
}
