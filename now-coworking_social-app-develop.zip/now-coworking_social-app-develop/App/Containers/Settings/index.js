import React, { Component } from 'react'
import { Image, Linking, View, Platform } from 'react-native'
import AuthActions from 'App/Stores/Auth/Actions'
import { connect } from 'react-redux'
import {
  Container,
  Header,
  Spinner,
  Content,
  Title,
  Text,
  List,
  ListItem,
  Left,
  Body,
  Right,
  Toast,
  Button,
} from 'native-base'
import Icon from 'App/Components/Icon'
import { Config } from 'App/Config'
import NavigationService from 'App/Services/NavigationService'
import Styles from './Styles'
import Images from 'App/Theme/Images'
import StatusBarApp from 'App/Components/StatusBarApp'
import Colors from 'App/Theme/Colors'

class Settings extends Component {
  constructor(props) {
    super(props)
    this.state = {}
  }
  openLink(url) {
    Linking.openURL(url)
  }

  static getDerivedStateFromProps(nextProps, prevState) {
    if (nextProps.errorLogout && prevState.errorLogout !== nextProps.errorLogout) {
      Toast.show({
        text: nextProps.errorLogout,
        buttonText: 'Fermer',
        type: 'danger',
        duration: 4000,
        position: 'top',
      })
    }
    return nextProps
  }

  _renderSocialLinks() {
    return (
      <View style={Styles.socialLinks}>
        <Button
          transparent
          style={Styles.socialLinkButton}
          onPress={() => this.openLink(Config.FB_URL)}
        >
          <Image source={Images.iconFacebook} style={Styles.socialLinkImage} />
        </Button>

        <Button
          transparent
          style={Styles.socialLinkButton}
          onPress={() => this.openLink(Config.IN_URL)}
        >
          <Image source={Images.iconLinkedin} style={Styles.socialLinkImage} />
        </Button>

        <Button
          transparent
          style={Styles.socialLinkButton}
          onPress={() => this.openLink(Config.TW_URL)}
        >
          <Image source={Images.iconTwitter} style={Styles.socialLinkImage} />
        </Button>

        <Button
          transparent
          style={Styles.socialLinkButton}
          onPress={() => this.openLink(Config.INST_URL)}
        >
          <Image source={Images.iconInstagram} style={Styles.socialLinkImage} />
        </Button>
      </View>
    )
  }

  render() {
    const { loading, logoutUser } = this.props
    return (
      <Container>
        <Header style={Styles.header}>
          <StatusBarApp />
          <Title style={Styles.title}>Autres</Title>
        </Header>

        <Content style={Styles.content} contentContainerStyle={Styles.contentContainer}>
          <List>
            <ListItem
              style={[Styles.listItem, Styles.first]}
              noBorder
              noIndent
              icon
              button
              onPress={() => {
                const link =
                  Platform.OS === 'ios'
                    ? 'itms-apps://itunes.apple.com/fr/app/now-coworking/id1114792074?mt=8'
                    : 'market://details?id=fr.edition.ftel.now'
                Linking.openURL(link)
              }}
              androidRippleColor={'black'}
            >
              <Left>
                <Icon name="web-page" size={24} />
              </Left>
              <Body>
                <Text style={Styles.listItemText}>{'Espace Coworker'}</Text>
              </Body>
            </ListItem>

            <ListItem
              style={Styles.listItem}
              noBorder
              noIndent
              icon
              button
              onPress={() => {
                Linking.openURL(Config.CONTRIBUTE_URL)
              }}
              androidRippleColor={'black'}
            >
              <Left>
                <Icon name="cli" size={24} />
              </Left>
              <Body>
                <Text style={Styles.listItemText}>{"Contribuer à l'application "}</Text>
              </Body>
            </ListItem>

            <ListItem
              style={Styles.listItem}
              noBorder
              noIndent
              icon
              button
              onPress={() => {
                NavigationService.navigate('Users')
              }}
              androidRippleColor={'black'}
            >
              <Left>
                <Icon name="user" size={24} />
              </Left>
              <Body>
                <Text style={Styles.listItemText}>{'Trombinoscope'}</Text>
              </Body>
            </ListItem>
            <ListItem
              style={Styles.listItem}
              noBorder
              noIndent
              icon
              button
              onPress={() => {
                if (loading) {
                  return
                }
                logoutUser()
              }}
              androidRippleColor={'black'}
            >
              <Left>
                <Icon name="exit" size={24} />
              </Left>
              <Body>
                <Text style={Styles.listItemText}>{'Déconnexion'}</Text>
              </Body>
              <Right style={Styles.listItemRight}>
                {loading ? <Spinner color={Colors.brandPrimary} /> : null}
              </Right>
            </ListItem>
          </List>
          {this._renderSocialLinks()}
        </Content>
      </Container>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    user: state.auth.get('user'),
    loading: state.auth.get('loading'),
    errorLogout: state.auth.get('errorLogout'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  logoutUser: () => dispatch(AuthActions.logoutRequest()),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Settings)
