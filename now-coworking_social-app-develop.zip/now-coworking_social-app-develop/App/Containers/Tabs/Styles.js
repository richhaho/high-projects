import Colors from 'App/Theme/Colors'

export default {
  navBar: {
    height: 60,
    borderTopColor: Colors.border,
    borderTopWidth: 0.5,
    padding: 0,
    backgroundColor: Colors.white,
  },
  navBarTab: {
    backgroundColor: Colors.white,
  },
  navBarButton: {
    borderRadius: 0,
    borderTopColor: Colors.white,
    borderTopWidth: 2,
    height: 58,
  },
  navBarButtonActive: {
    borderTopColor: Colors.brandPrimary,
  },
  separator: {
    backgroundColor: Colors.border,
    width: 2,
    height: 30,
    marginTop: 15,
  },
  icon: {
    color: Colors.green300,
  },
  iconSelected: {
    color: Colors.brandPrimary,
  },
  badge: {
    position: 'absolute',
    height: 15,
    width: 15,
    backgroundColor: 'red',
    borderRadius: 50,
    zIndex: 9,
    right: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    color: 'white',
    margin: 0,
    fontSize: 10,
    padding: 0,
  },
}
