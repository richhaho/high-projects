import React from 'react'
import { Text, View } from 'react-native'
import { Footer, FooterTab, Button } from 'native-base'
import StatusBarApp from 'App/Components/StatusBarApp'
import { createBottomTabNavigator, createStackNavigator } from 'react-navigation'

import Mixes from 'App/Containers/Mixes/'
import Settings from 'App/Containers/Settings'
import Publication from 'App/Containers/Publications/Publication'
import PublicationList from 'App/Containers/Publications/PublicationList'
import Channels from 'App/Containers/Publications/Channels'
import Create from 'App/Containers/Publications/Create'
import Styles from './Styles'
import Icon from 'App/Components/Icon'
import NavigationService from 'App/Services/NavigationService'
import ConversationList from 'App/Containers/Conversations/List'
import ConversationCreate from 'App/Containers/Conversations/Create'
import Messages from 'App/Containers/Conversations/Messages'
import { connect } from 'react-redux'

const PublicationStack = createStackNavigator({
  Channels: { screen: Channels },
  PublicationList: { screen: PublicationList },
  Publication: { screen: Publication },
  Create: { screen: Create },
})

const ConversationNavigator = createStackNavigator({
  List: { screen: ConversationList },
  Messages: { screen: Messages },
  CreateConversation: { screen: ConversationCreate },
})

const TabNavigation = createBottomTabNavigator(
  {
    PublicationStack: { screen: PublicationStack },
    Mixes: { screen: Mixes },
    Conversations: { screen: ConversationNavigator },
    Settings: { screen: Settings },
  },
  {
    tabBarPosition: 'bottom',
    tabBarComponent: (props) => {
      return (
        <Footer style={Styles.navBar}>
          <StatusBarApp />
          <FooterTab style={Styles.navBarTab}>
            <Button
              transparent
              style={
                props.navigation.state.index === 0
                  ? [Styles.navBarButton, Styles.navBarButtonActive]
                  : Styles.navBarButton
              }
              onPress={() => NavigationService.navigate('PublicationStack')}
            >
              <Icon
                name="write"
                style={[props.navigation.state.index === 0 ? Styles.iconSelected : Styles.icon]}
                size={28}
              />
            </Button>

            <View style={Styles.separator} />

            <Button
              transparent
              style={
                props.navigation.state.index === 1
                  ? [Styles.navBarButton, Styles.navBarButtonActive]
                  : Styles.navBarButton
              }
              onPress={() => NavigationService.navigate('Mixes')}
            >
              <Icon
                name="user-list"
                style={[props.navigation.state.index === 1 ? Styles.iconSelected : Styles.icon]}
                size={28}
              />
            </Button>

            <View style={Styles.separator} />
            <Button
              transparent
              style={
                props.navigation.state.index === 2
                  ? [Styles.navBarButton, Styles.navBarButtonActive]
                  : Styles.navBarButton
              }
              onPress={() => NavigationService.navigate('Conversations')}
            >
              <View>
                {props.screenProps.nbBadges > 0 ? (
                  <View style={Styles.badge}>
                    <Text style={Styles.badgeText}>{props.screenProps.nbBadges}</Text>
                  </View>
                ) : null}
                <Icon
                  name="messages"
                  style={[props.navigation.state.index === 2 ? Styles.iconSelected : Styles.icon]}
                  size={28}
                />
              </View>
            </Button>

            <View style={Styles.separator} />

            <Button
              transparent
              style={
                props.navigation.state.index === 3
                  ? [Styles.navBarButton, Styles.navBarButtonActive]
                  : Styles.navBarButton
              }
              onPress={() => NavigationService.navigate('Settings')}
            >
              <Icon
                name="more"
                style={[props.navigation.state.index === 3 ? Styles.iconSelected : Styles.icon]}
                size={12}
              />
            </Button>
          </FooterTab>
        </Footer>
      )
    },
  }
)

const mapStateToProps = (state) => {
  return {
    nbUnread: state.conversation.get('nbUnread'),
    nbBadges: state.notification.get('nbBadges'),
  }
}

const mapDispatchToProps = (dispatch) => ({})

const mergeProps = (state, dispatch, ownProps) => {
  return {
    ...ownProps,
    screenProps: {
      ...ownProps.screenProps,
      ...state,
      ...dispatch,
    },
  }
}

export default connect(
  mapStateToProps,
  mapDispatchToProps,
  mergeProps
)(TabNavigation)
