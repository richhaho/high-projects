import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

export default {
  container: {
    paddingLeft: 0,
    paddingRight: 0,
  },
  header: {
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.searchBorder,
    alignItems: 'flex-end',
    justifyContent: 'center',
    position: 'relative',
  },
  body: {
    position: 'absolute',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingBottom: 10,
  },
  title: {
    color: Colors.heading,
    fontSize: Metrics.fontSizeXl,
    paddingTop: 0,
  },
  content: {
    paddingTop: 20,
    paddingRight: 0,
    paddingLeft: 0,
    marginLeft: 0,
    marginRight: 0,
  },
  noData: {
    fontSize: Metrics.fontSizeMd,
    color: Colors.black,
    textAlign: 'center',
  },
}
