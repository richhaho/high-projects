import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Container, Title, Spinner, Text, Header, Left, Button, Right, Toast } from 'native-base'

import UserActions from 'App/Stores/User/Actions'
import UserList from 'App/Components/User/List'
import Search from 'App/Components/Search'
import Icon from 'react-native-vector-icons/EvilIcons'
import Styles from './Styles'
import Colors from 'App/Theme/Colors'
import NavigationService from 'App/Services/NavigationService'
import StatusBarApp from 'App/Components/StatusBarApp'
import { View } from 'react-native'
import _ from 'lodash'

class Users extends Component {
  constructor(props) {
    super(props)
    this.state = {
      search: '',
    }
  }
  static getDerivedStateFromProps(nextProps, prevState) {
    const { fetchCoworkers } = nextProps

    if (nextProps.error && prevState.error !== nextProps.error) {
      Toast.show({
        text: nextProps.error,
        buttonText: 'Recharger',
        type: 'danger',
        duration: 4000,
        position: 'top',
        onClose: (reason) => {
          if (reason === 'user') {
            fetchCoworkers()
          }
        },
      })
    }
    return nextProps
  }
  componentDidMount() {
    const { fetchCoworkers, resetCoworkers } = this.props
    resetCoworkers()
    fetchCoworkers()
  }
  handleChangeText(text) {
    const { fetchCoworkers, resetCoworkers } = this.props
    resetCoworkers()
    this.setState({ search: text })
    if (text) {
      fetchCoworkers(1, text)
    } else {
      fetchCoworkers()
    }
  }
  lazyLoad() {
    const { fetchCoworkers, currentPage, nextPage } = this.props

    if (nextPage) {
      fetchCoworkers(currentPage + 1, this.state.search)
    }
  }

  renderItems() {
    const { users, loading } = this.props
    const jsUsers = users.toJS()

    if (loading && users && users.size < 1) {
      return <Spinner color={Colors.brandPrimary} />
    }

    if (users && users.size < 1) {
      return <Text style={Styles.noData}>Aucun coworker ne correspond à votre recherche</Text>
    }

    return (
      <UserList
        onEndReached={this.lazyLoad.bind(this)}
        navigation={this.props.navigation}
        list={jsUsers}
        loading={loading}
      />
    )
  }

  render() {
    const { newConversationLoading } = this.props
    return (
      <Container style={Styles.container}>
        <Header style={Styles.header}>
          <StatusBarApp />
          <Left>
            <Button transparent onPress={() => NavigationService.navigate('Settings')}>
              <Icon style={Styles.icon} size={45} name="chevron-left" />
            </Button>
          </Left>
          <View style={Styles.body}>
            <Title style={Styles.title}>Trombinoscope</Title>
          </View>
          <Right>{newConversationLoading ? <Spinner color={Colors.brandPrimary} /> : null}</Right>
        </Header>

        <Search onChange={_.debounce((text) => this.handleChangeText(text), 500, false)} />
        {this.renderItems()}
      </Container>
    )
  }
}

const mapStateToProps = (state) => {
  return {
    users: state.user.get('users'),
    loading: state.user.get('loading'),
    error: state.user.get('error'),
    currentPage: state.user.get('currentPage'),
    nextPage: state.user.get('nextPage'),
    newConversationLoading: state.conversation.get('newLoading'),
  }
}

const mapDispatchToProps = (dispatch) => ({
  fetchCoworkers: (index, search) => dispatch(UserActions.fetchCoworkers(index, search)),
  resetCoworkers: () => dispatch(UserActions.resetCoworkers()),
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Users)
