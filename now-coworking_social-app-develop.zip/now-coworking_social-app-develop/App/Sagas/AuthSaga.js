import { put, call } from 'redux-saga/effects'
import { AuthService } from 'App/Services/AuthService'
import AuthActions from 'App/Stores/Auth/Actions'
import NotificationBadgeActions from 'App/Stores/NotificationBadge/Actions'
import ConversationActions from 'App/Stores/Conversation/Actions'
import MixesActions from 'App/Stores/Mixes/Actions'
import PublicationActions from 'App/Stores/Publication/Actions'
import UserActions from 'App/Stores/User/Actions'
import NavigationService from 'App/Services/NavigationService'
import { DeviceTokenService } from 'App/Services/DeviceTokenService'

export function* loginUser() {
  const response = yield call(
    AuthService.login,
    arguments[0].email,
    arguments[0].password,
    arguments[0].stayConnected
  )
  if (response && response.ok) {
    yield put(AuthActions.loginRequestSuccess(response.data))
    yield call(DeviceTokenService.sendDeviceToken) // Update device token
    yield put(NotificationBadgeActions.fetch())
    yield put(ConversationActions.saveUnreadRequest())
    NavigationService.navigateReset('TabNavigation')
  } else {
    yield put(AuthActions.loginRequestFail(response.data.message))
  }
}

export function* logoutUser() {
  const response = yield call(AuthService.logout)
  if (response && response.ok) {
    // Reset all states
    yield put(AuthActions.resetState())
    yield put(ConversationActions.resetState())
    yield put(MixesActions.resetState())
    yield put(PublicationActions.resetState())
    yield put(UserActions.resetState())

    yield put(AuthActions.logoutRequestSuccess(response.data))
    NavigationService.navigateReset('Login')
  } else {
    yield put(AuthActions.logoutRequestFail(response.data.message))
  }
}

export function* checkAuth() {
  const response = yield call(AuthService.checkAuth)
  yield put(UserActions.fetchCurrentConversationId(null)) // reset opened conversation
  if (response && response.ok) {
    yield put(AuthActions.checkAuthRequestSuccess(response.data))
    yield call(DeviceTokenService.sendDeviceToken) // Update device token
    yield put(NotificationBadgeActions.fetch())
    yield put(ConversationActions.saveUnreadRequest())
    NavigationService.navigateReset('TabNavigation')
  } else {
    yield put(AuthActions.checkAuthRequestFail(response.error))
    NavigationService.navigateReset('Login')
  }
}
