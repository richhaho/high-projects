import { put, call } from 'redux-saga/effects'
import { ConversationService } from 'App/Services/ConversationService'
import ConversationActions from 'App/Stores/Conversation/Actions'
import NavigationService from 'App/Services/NavigationService'
import NotificationBadgeActions from '../Stores/NotificationBadge/Actions'

/**
 * @param partnerId
 * @returns {IterableIterator<*>}
 */
export function* newConversation({ partnerId }) {
  const response = yield call(ConversationService.newConversation, partnerId)

  if (response && response.ok) {
    // Reset conversation list
    yield put(ConversationActions.listReset())
    yield call(getList, { page: 1 })
    // Navigate to created conversation
    NavigationService.navigate('Messages', {
      conversation: response.data,
    })
    // Trigger success
    yield put(ConversationActions.newSuccess(response.data))
  } else {
    if (response.data.code !== undefined && response.data.code === 'exists') {
      NavigationService.navigate('Messages', {
        conversation: response.data.data.conversation,
      })
      yield put(ConversationActions.newExists())
    } else {
      yield put(ConversationActions.newFail(response.data.message))
    }
  }
}

/**
 * @param page
 * @returns {IterableIterator<*>}
 */
export function* getList({ page }) {
  const response = yield call(ConversationService.getList, page)

  if (response && response.ok) {
    yield put(ConversationActions.listSuccess(response.data))
    yield call(getNbUnread)
    yield put(NotificationBadgeActions.fetch())
  } else {
    yield put(ConversationActions.listFail(response.data.message))
  }
}

/**
 * @param page
 * @returns {IterableIterator<*>}
 */
export function* getNbUnread() {
  const response = yield call(ConversationService.getNbUnread)
  if (response && response.ok) {
    yield put(ConversationActions.saveUnread(response.data))
  }
}

/**
 * @param conversationId
 * @param page
 * @returns {IterableIterator<*>}
 */
export function* getMessages({ conversationId, filters }) {
  const response = yield call(ConversationService.getMessages, conversationId, filters)

  if (response && response.ok) {
    yield put(ConversationActions.messagesSuccess(conversationId, response.data))
  } else {
    yield put(ConversationActions.messagesFail(response.data.message))
  }
}

/**
 * @param conversationId
 * @returns {IterableIterator<*>}
 */
export function* redirectToConversation({ conversationId }) {
  const response = yield call(ConversationService.get, conversationId)

  if (response && response.ok) {
    yield put(ConversationActions.getSuccess(response.data))
    NavigationService.navigate('Messages', {
      conversation: response.data,
    })
  } else {
    yield put(ConversationActions.getFail(response.data.message))
  }
}

/**
 * @param conversationId
 * @param content
 * @returns {IterableIterator<*>}
 */
export function* newMessage({ conversationId, content, image }) {
  const response = yield call(ConversationService.newMessage, conversationId, content, image)

  if (response && response.ok) {
    yield put(ConversationActions.newMessageSuccess(conversationId, response.data))
  } else {
    yield put(ConversationActions.newMessageFail(response.data.message))
  }
}

/**
 * @param conversationId
 * @param newState
 * @returns {IterableIterator<*>}
 */
export function* setFavorite({ conversationId, newState }) {
  const response = yield call(ConversationService.setFavorite, conversationId, newState)

  if (response && response.ok) {
    yield put(ConversationActions.setFavoriteSuccess(response.data.newState))
    // Reset conversation list
    yield put(ConversationActions.listReset())
    yield call(getList, { page: 1 })
  } else {
    yield put(ConversationActions.setFavoriteFail(response.data.message))
  }
}

/**
 * @param conversationId
 * @returns {IterableIterator<*>}
 */
export function* readConversation({ conversationId }) {
  const response = yield call(ConversationService.readConversation, conversationId)

  if (response && response.ok) {
    yield put(ConversationActions.readSuccess())
    // Reset conversation list
    yield put(ConversationActions.listReset())
    yield call(getList, { page: 1 })
  } else {
    yield put(ConversationActions.readFail(response.data.message))
  }
}

/**
 * @param conversationId
 * @returns {IterableIterator<*>}
 */
export function* predefined({ conversationId }) {
  const response = yield call(ConversationService.predefined, conversationId)

  if (response && response.ok) {
    yield put(ConversationActions.predefinedSuccess(response.data))
  } else {
    yield put(ConversationActions.predefinedFail(response.data.message))
  }
}
