import { call } from 'redux-saga/effects'
import { DeviceTokenService } from 'App/Services/DeviceTokenService'

export function* sendDeviceToken({ token = null }) {
  yield call(DeviceTokenService.sendDeviceToken, token)
}
