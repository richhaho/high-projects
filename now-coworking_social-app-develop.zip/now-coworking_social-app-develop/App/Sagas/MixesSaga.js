import { put, call, select } from 'redux-saga/effects'
import { MixesService } from 'App/Services/MixesService'
import MixesActions from 'App/Stores/Mixes/Actions'

const getAuthId = (state) => state.auth.get('user').get('id')
export const YUP_MIX = 1
export const NOPE_MIX = 0

export function* fetchMixes() {
  const id = yield select(getAuthId)
  const response = yield call(MixesService.fetchMixes, id)

  if (response && response.ok) {
    yield put(MixesActions.fetchMixesSuccess(response.data))
  } else {
    yield put(MixesActions.fetchMixesFail(response.data.message))
  }
}

export function* swipe({ idCoworker, action }) {
  const id = yield select(getAuthId)
  yield call(MixesService.swipe, id, idCoworker, action)
}
