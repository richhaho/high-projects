import { call, put } from 'redux-saga/effects'
import { NotificationBadgeService } from 'App/Services/NotificationBadgeService'
import NotificationsBadgeAction from 'App/Stores/NotificationBadge/Actions'
import firebase from 'react-native-firebase'

export function* getNbBadges() {
  const response = yield call(NotificationBadgeService.getNbBadges)
  if (response && response.ok) {
    firebase.notifications().setBadge(Number(response.data))
    yield put(NotificationsBadgeAction.success(response.data))
  }
}
