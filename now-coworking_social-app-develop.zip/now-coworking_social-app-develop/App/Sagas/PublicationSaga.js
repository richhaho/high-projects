import { put, call } from 'redux-saga/effects'
import { PublicationService } from 'App/Services/PublicationService'
import PublicationActions from 'App/Stores/Publication/Actions'
import NavigationService from 'App/Services/NavigationService'

export function* getGroups() {
  const response = yield call(PublicationService.getGroupsByUser)
  if (response && response.ok) {
    yield put(PublicationActions.getGroupsSuccess(response.data))
  } else {
    yield put(PublicationActions.getGroupsFail(response.data.message))
  }
}

export function* getPublications({ groupId, channelId, page }) {
  const response = yield call(PublicationService.getPublicationsByChannel, groupId, channelId, page)
  if (response && response.ok) {
    yield put(PublicationActions.getPublicationsSuccess(response.data, page))
  } else {
    yield put(PublicationActions.getPublicationsFail(response.data.message))
  }
}

export function* createPublication({ groupId, channelId, title, content }) {
  const response = yield call(
    PublicationService.createPublication,
    groupId,
    channelId,
    title,
    content
  )
  if (response && response.ok) {
    yield put(PublicationActions.createPublicationSuccess())
    NavigationService.navigate('PublicationList')
  } else {
    yield put(PublicationActions.createPublicationFail(response.data.message))
  }
}

export function* getPublication({ postId }) {
  const response = yield call(PublicationService.getPublication, postId)
  if (response && response.ok) {
    yield put(PublicationActions.getSinglePublicationSuccess(response.data))
  } else {
    yield put(PublicationActions.getSinglePublicationFail(response.data.message))
  }
}

export function* sendComment({ postId, content }) {
  const response = yield call(PublicationService.sendPublicationComment, postId, content)
  if (response && response.ok) {
    yield put(PublicationActions.sendCommentSuccess(response.data))
  } else {
    yield put(PublicationActions.sendCommentFail(response.data.message))
  }
}
