import { put, call } from 'redux-saga/effects'
import { UserService } from 'App/Services/UserService'
import UserTypes from 'App/Stores/User/Actions'

export function* fetchCoworkers({ page, search }) {
  const response = yield call(UserService.fetchCoworkers, page, search)
  if (response && response.ok) {
    yield put(UserTypes.fetchCoworkersSuccess(response.data))
  } else {
    yield put(UserTypes.fetchCoworkersFail(response.data.message))
  }
}

export function* fetchFavoriteCoworkers({ page }) {
  const response = yield call(UserService.fetchCoworkers, page, null, 1)
  if (response && response.ok) {
    yield put(UserTypes.fetchFavoriteCoworkersSuccess(response.data))
  } else {
    yield put(UserTypes.fetchFavoriteCoworkersFail(response.data.message))
  }
}

export function* fetchStaffCoworkers({ page }) {
  const response = yield call(UserService.fetchCoworkers, page, null, null, 1)
  if (response && response.ok) {
    yield put(UserTypes.fetchStaffCoworkersSuccess(response.data))
  } else {
    yield put(UserTypes.fetchStaffCoworkersFail(response.data.message))
  }
}

export function* addHelp({ helperId }) {
  const response = yield call(UserService.addHelp, helperId)
  if (response && response.ok) {
    yield put(UserTypes.addHelpSuccess(response.data))
  } else {
    yield put(UserTypes.addHelpFail(response.data.message))
  }
}

/**
 * @param userId
 * @returns {IterableIterator<*>}
 */
export function* fetchProfileUser({ userId }) {
  const response = yield call(UserService.fetchOne, userId)
  if (response && response.ok) {
    yield put(UserTypes.fetchProfileUserSuccess(response.data))
  } else {
    yield put(UserTypes.fetchProfileUserFail(response.data.message))
  }
}
