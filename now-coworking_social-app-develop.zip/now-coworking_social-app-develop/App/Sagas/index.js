import { takeLatest } from 'redux-saga/effects'
import { loginUser, logoutUser, checkAuth } from './AuthSaga'
import { fetchMixes, swipe } from './MixesSaga'
import {
  fetchCoworkers,
  addHelp,
  fetchFavoriteCoworkers,
  fetchStaffCoworkers,
  fetchProfileUser,
} from './UserSaga'

import {
  redirectToConversation,
  getList,
  getMessages,
  newMessage,
  newConversation,
  readConversation,
  setFavorite,
  predefined,
  getNbUnread,
} from './ConversationSaga'
import {
  getGroups,
  getPublications,
  createPublication,
  getPublication,
  sendComment,
} from './PublicationSaga'
import { getNbBadges } from './NotificationBadgeSaga'
import { sendDeviceToken } from './DeviceTokenSaga'
import { AuthTypes } from 'App/Stores/Auth/Actions'
import { UserTypes } from 'App/Stores/User/Actions'
import { PublicationTypes } from 'App/Stores/Publication/Actions'
import { MixesTypes } from 'App/Stores/Mixes/Actions'
import { ConversationTypes } from 'App/Stores/Conversation/Actions'
import { NotificationBadgeTypes } from '../Stores/NotificationBadge/Actions'

export default function* rootSaga() {
  yield [
    takeLatest(AuthTypes.LOGIN_REQUEST, loginUser),
    takeLatest(AuthTypes.LOGOUT_REQUEST, logoutUser),
    takeLatest(AuthTypes.CHECK_AUTH_REQUEST, checkAuth),
    takeLatest(UserTypes.FETCH_COWORKERS, fetchCoworkers),
    takeLatest(UserTypes.FETCH_FAVORITE_COWORKERS, fetchFavoriteCoworkers),
    takeLatest(UserTypes.FETCH_STAFF_COWORKERS, fetchStaffCoworkers),
    takeLatest(UserTypes.ADD_HELP_REQUEST, addHelp),
    takeLatest(UserTypes.FETCH_PROFILE_USER, fetchProfileUser),
    takeLatest(MixesTypes.FETCH_MIXES, fetchMixes),
    takeLatest(MixesTypes.SWIPE_MIXES, swipe),
    takeLatest(PublicationTypes.GET_GROUPS_REQUEST, getGroups),
    takeLatest(PublicationTypes.GET_PUBLICATIONS_REQUEST, getPublications),
    takeLatest(PublicationTypes.CREATE_PUBLICATION_REQUEST, createPublication),
    takeLatest(PublicationTypes.GET_SINGLE_PUBLICATION_REQUEST, getPublication),
    takeLatest(PublicationTypes.SEND_COMMENT_REQUEST, sendComment),
    takeLatest(ConversationTypes.GET_REQUEST, redirectToConversation),
    takeLatest(ConversationTypes.LIST_REQUEST, getList),
    takeLatest(ConversationTypes.MESSAGES_REQUEST, getMessages),
    takeLatest(ConversationTypes.NEW_MESSAGE_REQUEST, newMessage),
    takeLatest(ConversationTypes.SET_FAVORITE_REQUEST, setFavorite),
    takeLatest(ConversationTypes.NEW_REQUEST, newConversation),
    takeLatest(ConversationTypes.READ_REQUEST, readConversation),
    takeLatest(ConversationTypes.PREDEFINED_REQUEST, predefined),
    takeLatest(UserTypes.FETCH_DEVICE_TOKEN, sendDeviceToken),
    takeLatest(NotificationBadgeTypes.FETCH, getNbBadges),
    takeLatest(ConversationTypes.SAVE_UNREAD_REQUEST, getNbUnread),
  ]
}
