import { create } from 'apisauce'
import { Config } from 'App/Config'

export const apiClient = create({
  baseURL: Config.API_URL,
  headers: {
    Accept: 'application/json',
    'Content-Type': 'application/json',
  },
  timeout: 50000,
})
