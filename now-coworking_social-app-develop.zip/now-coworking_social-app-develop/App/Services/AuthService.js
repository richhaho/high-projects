import { apiClient } from './ApiClient'

function login(email, password, stayConnected = false) {
  return apiClient.post('users/login', {
    email: email,
    password: password,
    stay_connected: stayConnected,
  })
}

function logout() {
  return apiClient.post('users/logout')
}

function checkAuth() {
  return apiClient.get('user')
}

export const AuthService = {
  login,
  logout,
  checkAuth,
}
