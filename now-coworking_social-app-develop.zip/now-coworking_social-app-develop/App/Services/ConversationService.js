import { apiClient } from './ApiClient'
import qs from 'qs'

/**
 * @param partnerId
 * @returns {*}
 */
function newConversation(partnerId) {
  return apiClient.post('user/conversations', {
    partner_id: partnerId,
  })
}

/**
 * @param page
 * @returns {*}
 */
function getList(page) {
  return apiClient.get('user/conversations', {
    page: page,
  })
}

/**
 * @returns {*}
 */
function getNbUnread() {
  return apiClient.get('/unread')
}

/**
 * @returns {*}
 * @param conversationId
 */
function get(conversationId) {
  return apiClient.get('user/conversations/' + conversationId)
}

/**
 * @param conversationId
 * @param page
 * @returns {*}
 */
function getMessages(conversationId, filters) {
  return apiClient.get(
    'user/conversations/' + conversationId + '/messages',
    {
      filters: filters,
    },
    {
      paramsSerializer: function(params) {
        return qs.stringify(params, { encode: false })
      },
    }
  )
}

/**
 * @param conversationId
 * @param content
 * @returns {*}
 */
function newMessage(conversationId, content, image) {
  const form = new FormData()
  if (content) {
    form.append('content', content)
  }
  if (image) {
    form.append('file', image)
  }

  const options = {
    headers: {
      Accept: 'application/json',
      'Content-Type': 'multipart/form-data',
    },
    timeout: 20000,
  }

  return apiClient.post('user/conversations/' + conversationId + '/messages', form, options)
}

/**
 * @param conversationId
 * @param newState
 * @returns {*}
 */
function setFavorite(conversationId, newState) {
  return apiClient.put('/user/conversations/' + conversationId + '/favorite', {
    state: newState,
  })
}

/**
 * @param conversationId
 * @returns {*}
 */
function readConversation(conversationId) {
  return apiClient.put('user/conversations/' + conversationId + '/readmessages')
}

/**
 * @param conversationId
 * @returns {*}
 */
function predefined(conversationId) {
  return apiClient.get('user/conversations/' + conversationId + '/predefined')
}

export const ConversationService = {
  get,
  getList,
  getNbUnread,
  getMessages,
  newMessage,
  setFavorite,
  newConversation,
  readConversation,
  predefined,
}
