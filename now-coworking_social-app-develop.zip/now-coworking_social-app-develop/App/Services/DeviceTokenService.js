import { apiClient } from './ApiClient'
import firebase from 'react-native-firebase'

function sendDeviceToken(token = null) {
  if (!token) {
    firebase
      .messaging()
      .getToken()
      .then((fcmToken) => {
        if (fcmToken) {
          return sendApiDeviceToken(fcmToken)
        }
      })
  } else {
    return sendApiDeviceToken(token)
  }
}

function sendApiDeviceToken(token) {
  return apiClient.post('user/device', {
    token: token,
  })
}

export const DeviceTokenService = {
  sendDeviceToken,
}
