import { apiClient } from './ApiClient'

function fetchMixes(id) {
  return apiClient.get('coworkers/' + id + '/mixes')
}
function swipe(idUser, idCoworker, action) {
  return apiClient.post('/coworkers/' + idUser + '/mixes/' + idCoworker, {
    action: action,
  })
}

export const MixesService = {
  fetchMixes,
  swipe,
}
