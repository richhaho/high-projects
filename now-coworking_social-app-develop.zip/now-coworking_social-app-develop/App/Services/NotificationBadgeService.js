import { apiClient } from './ApiClient'

function getNbBadges() {
  return apiClient.get('/notificationbadges')
}

export const NotificationBadgeService = {
  getNbBadges,
}
