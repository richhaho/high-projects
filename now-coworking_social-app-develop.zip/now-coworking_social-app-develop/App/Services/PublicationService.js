import { apiClient } from './ApiClient'

function getGroupsByUser() {
  return apiClient.get('user/groups')
}

function getPublication(postId) {
  return apiClient.get('user/posts/' + postId)
}

function getPublicationsByChannel(idGroup, idChannel, page) {
  return apiClient.get('user/groups/' + idGroup + '/channels/' + idChannel + '/posts', {
    page: page,
    pageSize: 10,
  })
}
function createPublication(idGroup, idChannel, title, content) {
  return apiClient.post('user/groups/' + idGroup + '/channels/' + idChannel + '/posts', {
    title: title,
    content: content,
  })
}

function sendPublicationComment(postId, content) {
  return apiClient.post('user/posts/' + postId + '/comments', {
    content: content,
  })
}
export const PublicationService = {
  getGroupsByUser,
  getPublicationsByChannel,
  createPublication,
  getPublication,
  sendPublicationComment,
}
