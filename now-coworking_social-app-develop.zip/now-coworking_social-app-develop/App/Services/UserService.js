import { apiClient } from './ApiClient'

function fetchOne(userId) {
  return apiClient.get('coworkers/' + userId)
}

function fetchCoworkers(page = 1, search = '', favorite = null, staff = null) {
  return apiClient.get('coworkers', {
    search: search,
    page: page,
    favorite: favorite,
    staff: staff,
  })
}

function paginateCoworkers(page) {
  return apiClient.get('coworkers', {
    page: page,
  })
}

function addHelp(helperId) {
  return apiClient.post('user/help', {
    helper: helperId,
  })
}

export const UserService = {
  fetchCoworkers,
  paginateCoworkers,
  addHelp,
  fetchOne,
}
