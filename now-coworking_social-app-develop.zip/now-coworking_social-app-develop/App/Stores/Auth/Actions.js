import { createActions } from 'reduxsauce'

const { Types, Creators } = createActions({
  resetState: null,

  loginRequest: ['email', 'password', 'stayConnected'],
  loginRequestSuccess: ['payload'],
  loginRequestFail: ['errorMessage'],

  logoutRequest: null,
  logoutRequestSuccess: null,
  logoutRequestFail: ['errorLogout'],

  checkAuthRequest: null,
  checkAuthRequestSuccess: ['user'],
  checkAuthRequestFail: ['payload'],
})

export const AuthTypes = Types
export default Creators
