import { Map } from 'immutable'

/**
 * The initial values for the redux state.
 */
export const INITIAL_STATE = Map({
  loading: false,
  error: null,
  errorLogout: null,
  errorCheckAuth: null,
  user: null,
})
