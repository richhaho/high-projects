import { createReducer } from 'reduxsauce'
import { AuthTypes } from './Actions'
import { INITIAL_STATE } from './InitialState'

/**
 * @param state
 */
export const resetState = (state) => INITIAL_STATE

export const login = (state = INITIAL_STATE) =>
  state.merge({ loading: true, error: null, errorLogout: null })

export const success = (state = INITIAL_STATE, action) =>
  state.merge({ loading: false, user: action.payload })

export const fail = (state = INITIAL_STATE, { errorMessage }) =>
  state.merge({ loading: false, error: errorMessage })

export const logoutRequest = (state) => state.merge({ loading: true, errorLogout: null })

export const logoutSuccess = (state) => INITIAL_STATE

export const logoutFailure = (state, { errorLogout }) =>
  state.merge({ loading: false, errorLogout: errorLogout })

export const checkAuthRequest = (state = INITIAL_STATE) => state.merge({ loading: true })

export const checkAuthRequestSuccess = (state = INITIAL_STATE, { user }) =>
  state.merge({ loading: false, user: user })

export const checkAuthRequestFailure = (state = INITIAL_STATE, { errorCheckAuth }) =>
  state.merge({ loading: false, errorCheckAuth: errorCheckAuth })

export const saveUser = (state = INITIAL_STATE, { user }) => state.merge({ user: user })

export const reducer = createReducer(INITIAL_STATE, {
  // Reset
  [AuthTypes.RESET_STATE]: resetState,
  [AuthTypes.LOGIN_REQUEST]: login,
  [AuthTypes.LOGIN_REQUEST_SUCCESS]: success,
  [AuthTypes.LOGIN_REQUEST_FAIL]: fail,

  [AuthTypes.LOGOUT_REQUEST]: logoutRequest,
  [AuthTypes.LOGOUT_REQUEST_SUCCESS]: logoutSuccess,
  [AuthTypes.LOGOUT_REQUEST_FAIL]: logoutFailure,

  [AuthTypes.CHECK_AUTH_REQUEST]: checkAuthRequest,
  [AuthTypes.CHECK_AUTH_REQUEST_SUCCESS]: checkAuthRequestSuccess,
  [AuthTypes.CHECK_AUTH_REQUEST_FAIL]: checkAuthRequestFailure,
})
