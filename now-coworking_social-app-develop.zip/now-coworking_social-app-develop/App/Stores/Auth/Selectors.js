export const getUserId = (state) => state.auth.get('user').get('id')
