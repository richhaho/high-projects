import { createActions } from 'reduxsauce'

const { Types, Creators } = createActions({
  resetState: null,

  newRequest: ['partnerId'],
  newSuccess: ['conversation'],
  newFail: ['error'],
  newExists: null,
  listRequest: ['page'],
  listSuccess: ['payload'],
  listFail: ['error'],
  listReset: null,
  messagesRequest: ['conversationId', 'filters', 'reset'],
  messagesSuccess: ['conversationId', 'messages'],
  messagesFail: ['error'],
  newMessageRequest: ['conversationId', 'content', 'image'],
  newMessageSuccess: ['payload'],
  newMessageFail: ['error'],
  appendMessage: ['message'],
  setFavoriteRequest: ['conversationId', 'newState'],
  initFavoriteRequest: ['initState'],
  setFavoriteSuccess: ['newState'],
  setFavoriteFail: ['error'],
  readRequest: ['conversationId'],
  readSuccess: null,
  readFail: ['error'],
  getRequest: ['conversationId'],
  getSuccess: ['conversation'],
  getFail: ['error'],
  predefinedRequest: ['conversationId'],
  predefinedSuccess: ['messages'],
  predefinedFail: ['error'],

  saveUnreadRequest: null,
  saveUnread: ['nbUnread'],
})

export const ConversationTypes = Types
export default Creators
