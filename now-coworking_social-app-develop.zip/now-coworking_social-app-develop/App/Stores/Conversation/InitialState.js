import { Map, List } from 'immutable'

/**
 * The initial values for the redux state.
 */
export const INITIAL_STATE = Map({
  // New conversation
  newLoading: false,
  newError: null,
  newConversation: null,
  // Conversation list
  list: List(),
  listLoading: false,
  listError: null,
  listCurrentPage: 1,
  listNextPage: null,
  // Conversation's messages list
  messagesConversationId: null,
  messages: List(),
  messagesLoading: false,
  messagesError: null,
  messagesOldestId: null,
  // New message
  newMessageLoading: false,
  newMessageError: null,
  // Set favorite
  setFavoriteError: null,
  setFavoriteState: false,
  setFavoriteLoading: false,
  // Read
  readFailError: null,
  // Image Picker
  imagePicked: false,
  imagePickedError: null,
  image: null,
  // Conversation
  conversation: null,
  getLoading: null,
  getError: null,
  // Predefined messages
  predefined: List(),
  predefinedLoading: null,
  predefinedError: null,

  nbUnread: 0,
})
