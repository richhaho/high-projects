import { createReducer } from 'reduxsauce'
import { ConversationTypes } from './Actions'
import { INITIAL_STATE } from './InitialState'

/**
 * @param state
 */
export const resetState = (state) => INITIAL_STATE

/**
 * @param state
 * @returns {*}
 */
export const newConversation = (state) => state.merge({ newLoading: true, newError: null })

/**
 * @param state
 * @param conversation
 * @returns {*}
 */
export const newConversationSuccess = (state, { conversation }) =>
  state.merge({ newLoading: false, newError: null, newConversation: conversation })

/**
 * @param state
 * @param error
 * @returns {*}
 */
export const newConversationFail = (state, { error }) =>
  state.merge({ newLoading: false, newError: error })

/**
 * @param state
 * @returns {*}
 */
export const newConversationExists = (state) => state.merge({ newLoading: false, newError: null })

/**
 * @param state
 * @returns {*}
 */
export const getList = (state) => state.merge({ listLoading: true, listError: null })

/**
 * @param state
 * @param action
 * @returns {*}
 */
export const getListSuccess = (state, action) =>
  state.merge({
    list:
      state.get('list').size > 0
        ? state
            .get('list')
            .toJS()
            .concat(action.payload.data)
        : action.payload.data,
    listLoading: false,
    listCurrentPage: action.payload.current_page,
    listNextPage: action.payload.next_page_url,
    listError: null,
  })

/**
 * @param state
 * @param error
 * @returns {*}
 */
export const getListFail = (state) => state.merge({ list: [], listLoading: false })

/**
 * @param state
 * @returns {*}
 */
export const listReset = (state) => state.merge({ list: [], listError: null, listLoading: false })

/**
 * @param state
 * @param conversationId
 * @param page
 * @param reset
 * @returns {*}
 */
export const getMessages = (state, { conversationId, page, reset }) =>
  state.merge({
    messages:
      state.get('messagesConversationId') !== conversationId || reset ? [] : state.get('messages'),
    messagesLoading: true,
    messagesError: null,
    messagesConversationId: conversationId,
  })

/**
 * @param state
 * @param conversationId
 * @param payload
 * @returns {*}
 */
export const getMessagesSuccess = (state, { conversationId, messages }) =>
  state.merge({
    messages:
      state.get('messages').size > 0
        ? state
            .get('messages')
            .toJS()
            .concat(messages)
        : messages,
    messagesConversationId: conversationId,
    messagesLoading: false,
    messagesError: null,
    messagesOldestId: messages.length > 0 ? messages[messages.length - 1].id : 0,
  })

/**
 * @param state
 * @param error
 * @returns {*}
 */
export const getMessagesFail = (state, { error }) =>
  state.merge({ messagesError: error, messagesLoading: false })

/**
 * @param state
 * @returns {*}
 */
export const newMessage = (state) => state.merge({ newMessageLoading: true, newMessageError: null })

/**
 * @param state
 * @returns {*}
 */
export const newMessageSuccess = (state) =>
  state.merge({ newMessageLoading: false, newMessageError: null })

/**
 * @param state
 * @param error
 * @returns {*}
 */
export const newMessageFail = (state, { error }) =>
  state.merge({ newMessageLoading: false, newMessageError: error })

/**
 * @param state
 * @param message
 * @returns {*}
 */
export const appendMessage = (state, { message }) =>
  state.merge({
    messages: state.get('messages').size > 0 ? state.get('messages').unshift(message) : [message],
  })

/**
 * @param state
 * @returns {*}
 */
export const setFavoriteRequest = (state) =>
  state.merge({ setFavoriteLoading: true, setFavoriteError: null })

/**
 * @param state
 * @returns {*}
 */
export const initFavoriteRequest = (state, { initState }) =>
  state.merge({ setFavoriteState: initState })

/**
 * @param state
 * @param newState
 * @returns {*}
 */
export const setFavoriteSuccess = (state, { newState }) =>
  state.merge({ setFavoriteLoading: false, setFavoriteState: newState, setFavoriteError: null })

/**
 * @param state
 * @returns {*}
 */
export const readRequest = (state) => state.merge({ readFailError: null })

/**
 * @param state
 * @returns {*}
 */
export const readSuccess = (state) => state.merge({ readFailError: null })

/**
 * @param state
 * @param error
 * @returns {*}
 */
export const setFavoriteFail = (state, { error }) =>
  state.merge({ setFavoriteLoading: false, setFavoriteError: error })

export const readFail = (state, { error }) => state.merge({ readFailError: error })

/**
 * @param state
 * @returns {*}
 */
export const getRequest = (state) =>
  state.merge({ getError: null, getLoading: true, conversation: null })

/**
 * @param state
 * @param conversation
 * @returns {*}
 */
export const getSuccess = (state, { conversation }) =>
  state.merge({ getLoading: false, conversation: conversation })

/**
 * @param state
 * @param error
 * @returns {*}
 */
export const getFail = (state, { error }) =>
  state.merge({ getError: error, getLoading: false, conversation: null })

/**
 * @param state
 * @returns {*}
 */
export const predefinedRequest = (state) =>
  state.merge({ predefined: [], predefinedLoading: true, predefinedError: null })

/**
 * @param state
 * @param conversation
 * @returns {*}
 */
export const predefinedSuccess = (state, { messages }) =>
  state.merge({ predefined: messages, predefinedLoading: false, predefinedError: false })

/**
 * @param state
 * @param error
 * @returns {*}
 */
export const predefinedFail = (state, { error }) =>
  state.merge({ predefined: null, predefinedLoading: false, predefinedError: error })

/**
 * @param state
 * @returns {*}
 */
export const saveUnreadRequest = (state) => state.merge({ nbUnread: 0 })

/**
 * @param state
 * @returns {*}
 */
export const saveUnread = (state, { nbUnread }) => state.merge({ nbUnread: nbUnread })

export const reducer = createReducer(INITIAL_STATE, {
  // Reset
  [ConversationTypes.RESET_STATE]: resetState,
  // New conversation
  [ConversationTypes.NEW_REQUEST]: newConversation,
  [ConversationTypes.NEW_SUCCESS]: newConversationSuccess,
  [ConversationTypes.NEW_FAIL]: newConversationFail,
  [ConversationTypes.NEW_EXISTS]: newConversationExists,
  // Conversations list
  [ConversationTypes.LIST_REQUEST]: getList,
  [ConversationTypes.LIST_SUCCESS]: getListSuccess,
  [ConversationTypes.LIST_FAIL]: getListFail,
  [ConversationTypes.LIST_RESET]: listReset,
  // Conversation's messages
  [ConversationTypes.MESSAGES_REQUEST]: getMessages,
  [ConversationTypes.MESSAGES_SUCCESS]: getMessagesSuccess,
  [ConversationTypes.MESSAGES_FAIL]: getMessagesFail,
  // New message
  [ConversationTypes.NEW_MESSAGE_REQUEST]: newMessage,
  [ConversationTypes.NEW_MESSAGE_SUCCESS]: newMessageSuccess,
  [ConversationTypes.NEW_MESSAGE_FAIL]: newMessageFail,
  // Real time message
  [ConversationTypes.APPEND_MESSAGE]: appendMessage,
  // Set favorite
  [ConversationTypes.SET_FAVORITE_REQUEST]: setFavoriteRequest,
  [ConversationTypes.INIT_FAVORITE_REQUEST]: initFavoriteRequest,
  [ConversationTypes.SET_FAVORITE_SUCCESS]: setFavoriteSuccess,
  [ConversationTypes.SET_FAVORITE_FAIL]: setFavoriteFail,
  // Read conversation
  [ConversationTypes.READ_REQUEST]: readRequest,
  [ConversationTypes.READ_SUCCESS]: readSuccess,
  [ConversationTypes.READ_FAIL]: readFail,
  // Get conversation
  [ConversationTypes.GET_REQUEST]: getRequest,
  [ConversationTypes.GET_SUCCESS]: getSuccess,
  [ConversationTypes.GET_FAIL]: getFail,
  // Get predefined messages
  [ConversationTypes.PREDEFINED_REQUEST]: predefinedRequest,
  [ConversationTypes.PREDEFINED_SUCCESS]: predefinedSuccess,
  [ConversationTypes.PREDEFINED_FAIL]: predefinedFail,

  [ConversationTypes.SAVE_UNREAD_REQUEST]: saveUnreadRequest,
  [ConversationTypes.SAVE_UNREAD]: saveUnread,
})
