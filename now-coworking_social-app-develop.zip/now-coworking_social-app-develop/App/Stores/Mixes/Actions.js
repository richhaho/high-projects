import { createActions } from 'reduxsauce'

const { Types, Creators } = createActions({
  resetState: null,

  fetchMixes: null,
  fetchMixesSuccess: ['mixes'],
  fetchMixesFail: ['error'],
  swipeMixes: ['idCoworker', 'action'],
})

export const MixesTypes = Types
export default Creators
