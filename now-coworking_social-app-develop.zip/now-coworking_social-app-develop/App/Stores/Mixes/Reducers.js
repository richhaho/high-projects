import { createReducer } from 'reduxsauce'
import { MixesTypes } from './Actions'
import { INITIAL_STATE } from './InitialState'

/**
 * @param state
 */
export const resetState = (state) => INITIAL_STATE

const getMixes = (state = INITIAL_STATE) => state.merge({ loading: true })

const getMixesSuccess = (state = INITIAL_STATE, { mixes }) =>
  state.merge({
    loading: false,
    mixes: mixes,
  })

const getMixesFail = (state = INITIAL_STATE, { error }) =>
  state.merge({ error: error, loading: false })

const HANDLERS = {
  // Reset
  [MixesTypes.RESET_STATE]: resetState,
  [MixesTypes.FETCH_MIXES]: getMixes,
  [MixesTypes.FETCH_MIXES_SUCCESS]: getMixesSuccess,
  [MixesTypes.FETCH_MIXES_FAIL]: getMixesFail,
}

export const reducer = createReducer(INITIAL_STATE, HANDLERS)
