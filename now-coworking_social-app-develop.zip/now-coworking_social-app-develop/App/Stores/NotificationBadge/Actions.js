import { createActions } from 'reduxsauce'

const { Types, Creators } = createActions({
  fetch: null,
  success: ['nbBadges'],
})

export const NotificationBadgeTypes = Types
export default Creators
