import { createReducer } from 'reduxsauce'
import { NotificationBadgeTypes } from './Actions'
import { INITIAL_STATE } from './InitialState'

export const get = (state) => state.merge({ nbBadges: 0 })

export const success = (state, { nbBadges }) => state.merge({ nbBadges: nbBadges })

export const reducer = createReducer(INITIAL_STATE, {
  [NotificationBadgeTypes.FETCH]: get,
  [NotificationBadgeTypes.SUCCESS]: success,
})
