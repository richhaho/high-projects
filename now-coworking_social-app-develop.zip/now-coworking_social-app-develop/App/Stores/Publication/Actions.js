import { createActions } from 'reduxsauce'

const { Types, Creators } = createActions({
  resetState: null,

  getGroupsRequest: null,
  getGroupsSuccess: ['groups'],
  getGroupsFail: ['payload'],
  getSinglePublicationRequest: ['postId'],
  getSinglePublicationSuccess: ['publication'],
  getSinglePublicationFail: ['error'],
  getPublicationsRequest: ['groupId', 'channelId', 'page'],
  getPublicationsSuccess: ['publications', 'page'],
  getPublicationsFail: ['error'],
  createPublicationRequest: ['groupId', 'channelId', 'title', 'content'],
  createPublicationSuccess: null,
  createPublicationFail: ['error'],
  sendCommentRequest: ['postId', 'content'],
  sendCommentSuccess: ['publication'],
  sendCommentFail: ['error'],
  resetPublications: null,
  resetSinglePublications: null,
})

export const PublicationTypes = Types
export default Creators
