import { Map, List } from 'immutable'

/**
 * The initial values for the redux state.
 */
export const INITIAL_STATE = Map({
  loading: false,
  needReload: false,
  error: null,
  errorPublication: null,
  groups: List(),
  publication: Map(),
  errorSinglePublication: null,
  publications: List(),
  errorCreation: null,
  sending: false,
  errorComment: null,
  currentPage: 1,
})
