import { createReducer } from 'reduxsauce'
import { PublicationTypes } from './Actions'
import { INITIAL_STATE } from './InitialState'
import { List, Map } from 'immutable'

/**
 * @param state
 */
export const resetState = (state) => INITIAL_STATE

export const getGroup = (state = INITIAL_STATE) => state.merge({ loading: true, error: null })

export const getGroupSuccess = (state = INITIAL_STATE, { groups }) =>
  state.merge({ loading: false, groups: groups })

export const getGroupFail = (state = INITIAL_STATE, { error }) =>
  state.merge({ loading: false, error: error })

export const getSinglePublication = (state = INITIAL_STATE) =>
  state.merge({ loading: true, error: null })

export const resetPublications = (state) =>
  state.merge({
    loading: false,
    publications: List(),
    errorPublication: null,
    needReload: false,
    currentPage: 1,
  })

export const getSinglePublicationSuccess = (state = INITIAL_STATE, { publication }) =>
  state.merge({ loading: false, publication: publication })

export const getSinglePublicationFail = (state = INITIAL_STATE, { error }) =>
  state.merge({ loading: false, errorSinglePublication: error })

export const getPublications = (state) => state.merge({ loading: true, error: null })

export const getPublicationsSuccess = (state, { publications, page }) =>
  state.merge({
    loading: false,
    publications:
      state.get('publications').size > 0
        ? state
            .get('publications')
            .toJS()
            .concat(publications)
        : publications,
    currentPage: page,
  })

export const getPublicationsFail = (state, { error }) =>
  state.merge({ errorPublication: error, loading: false })

export const createPublication = (state = INITIAL_STATE) =>
  state.merge({ loading: true, errorCreation: null })

export const createPublicationSuccess = (state = INITIAL_STATE) =>
  state.merge({ loading: false, needReload: true })

export const createPublicationFail = (state = INITIAL_STATE, { error }) =>
  state.merge({ loading: false, errorCreation: error })

export const sendComment = (state) => state.merge({ sending: true, errorComment: null })

export const sendCommentSuccess = (state, { publication }) =>
  state.merge({ publication: publication, sending: false })

export const sendCommentFail = (state, { error }) =>
  state.merge({ errorComment: error, loading: false })

export const resetSinglePublications = (state) =>
  state.merge({ loading: false, publication: Map(), errorSinglePublication: null })

export const reducer = createReducer(INITIAL_STATE, {
  // Reset
  [PublicationTypes.RESET_STATE]: resetState,
  [PublicationTypes.GET_GROUPS_REQUEST]: getGroup,
  [PublicationTypes.GET_GROUPS_SUCCESS]: getGroupSuccess,
  [PublicationTypes.GET_GROUPS_FAIL]: getGroupFail,

  [PublicationTypes.GET_SINGLE_PUBLICATION_REQUEST]: getSinglePublication,
  [PublicationTypes.GET_SINGLE_PUBLICATION_SUCCESS]: getSinglePublicationSuccess,
  [PublicationTypes.GET_SINGLE_PUBLICATION_FAIL]: getSinglePublicationFail,

  [PublicationTypes.GET_PUBLICATIONS_REQUEST]: getPublications,
  [PublicationTypes.GET_PUBLICATIONS_SUCCESS]: getPublicationsSuccess,
  [PublicationTypes.GET_PUBLICATIONS_FAIL]: getPublicationsFail,

  [PublicationTypes.CREATE_PUBLICATION_REQUEST]: createPublication,
  [PublicationTypes.CREATE_PUBLICATION_SUCCESS]: createPublicationSuccess,
  [PublicationTypes.CREATE_PUBLICATION_FAIL]: createPublicationFail,

  [PublicationTypes.SEND_COMMENT_REQUEST]: sendComment,
  [PublicationTypes.SEND_COMMENT_SUCCESS]: sendCommentSuccess,
  [PublicationTypes.SEND_COMMENT_FAIL]: sendCommentFail,

  [PublicationTypes.RESET_PUBLICATIONS]: resetPublications,
  [PublicationTypes.RESET_SINGLE_PUBLICATIONS]: resetSinglePublications,
})
