import { createActions } from 'reduxsauce'

const { Types, Creators } = createActions({
  resetState: null,
  // fetch all users
  fetchCoworkers: ['page', 'search'],
  fetchCoworkersSuccess: ['payload'],
  fetchCoworkersFail: ['error'],
  // fetch favorite users
  fetchFavoriteCoworkers: ['page'],
  fetchFavoriteCoworkersSuccess: ['payload'],
  fetchFavoriteCoworkersFail: ['error'],
  // fetch staff users
  fetchStaffCoworkers: ['page'],
  fetchStaffCoworkersSuccess: ['payload'],
  fetchStaffCoworkersFail: ['error'],
  // fetch profile user
  fetchProfileUser: ['userId'],
  fetchProfileUserSuccess: ['payload'],
  fetchProfileUserFail: ['error'],

  resetCoworkers: null,
  addHelpRequest: ['helperId'],
  addHelpSuccess: ['payload'],
  addHelpFail: ['error'],
  fetchDeviceToken: ['token'],
  fetchCurrentConversationId: ['conversationId'],
})

export const UserTypes = Types
export default Creators
