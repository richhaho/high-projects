import { Map, List } from 'immutable'

/**
 * The initial values for the redux state.
 */
export const INITIAL_STATE = Map({
  users: List(),
  loading: false,
  error: null,
  currentPage: 1,
  nextPage: null,
  // favorite users
  favoriteUsers: List(),
  favoriteLoading: false,
  favoriteError: null,
  favoriteCurrentPage: 1,
  // staff users
  staffUsers: List(),
  staffLoading: false,
  staffError: null,
  staffCurrentPage: 1,
  favoriteNextPage: null,
  addHelpLoading: false,
  addHelpSuccess: null,
  addHelpFail: null,
  deviceToken: null,
  currentConversationId: null,
  // profile users
  profileUser: Map(),
  profileUserLoading: false,
  profileUserError: null,
})
