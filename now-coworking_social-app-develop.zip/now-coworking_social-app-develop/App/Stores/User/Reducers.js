import { createReducer } from 'reduxsauce'
import { UserTypes } from './Actions'
import { INITIAL_STATE } from './InitialState'

/**
 * @param state
 */
export const resetState = (state) => INITIAL_STATE

export const getCoworkers = (state) => state.merge({ loading: true, error: null })

export const getDeviceToken = (state, { token }) => state.merge({ deviceToken: token })

export const setConversationId = (state, { conversationId }) =>
  state.merge({ currentConversationId: conversationId })

export const getCoworkersSuccess = (state, action) =>
  state.merge({
    loading: false,
    users:
      state.get('users').size > 0
        ? state
            .get('users')
            .toJS()
            .concat(action.payload.data)
        : action.payload.data,
    currentPage: action.payload.current_page,
    nextPage: action.payload.next_page_url,
  })

export const getCoworkersFail = (state, { error }) => state.merge({ error: error, loading: false })

export const resetCoworkers = (state) => state.merge(INITIAL_STATE)

export const addHelpRequest = (state) => state.merge({ addHelpFail: null, addHelpLoading: true })

export const addHelpSuccess = (state, action) =>
  state.merge({ addHelpFail: null, addHelpSuccess: action.payload, addHelpLoading: false })

export const addHelpFail = (state, action) =>
  state.merge({ addHelpFail: action.error, addHelpLoading: false })

export const getFavoriteCoworkers = (state) =>
  state.merge({ favoriteLoading: true, favoriteError: null })

export const getFavoriteCoworkersSuccess = (state, action) =>
  state.merge({
    favoriteLoading: false,
    favoriteUsers:
      state.get('favoriteUsers').size > 0
        ? state
            .get('favoriteUsers')
            .toJS()
            .concat(action.payload.data)
        : action.payload.data,
    favoriteCurrentPage: action.payload.current_page,
    favoriteNextPage: action.payload.next_page_url,
  })

export const getFavoriteCoworkersFail = (state, { error }) =>
  state.merge({ favoriteError: error, favoriteLoading: false })

export const getStaffCoworkers = (state) => state.merge({ staffLoading: true, staffError: null })

export const getStaffCoworkersSuccess = (state, action) =>
  state.merge({
    staffLoading: false,
    staffUsers:
      state.get('staffUsers').size > 0
        ? state
            .get('staffUsers')
            .toJS()
            .concat(action.payload.data)
        : action.payload.data,
    staffCurrentPage: action.payload.current_page,
    staffNextPage: action.payload.next_page_url,
  })

export const getStaffCoworkersFail = (state, { error }) =>
  state.merge({ staffError: error, staffLoading: false })

/**
 * @param state
 * @returns {*}
 */
export const fetchProfileUser = (state) =>
  state.merge({ profileUser: null, profileUserLoading: true, profileUserError: null })

/**
 * @param state
 * @param payload
 * @returns {*}
 */
export const fetchProfileUserSuccess = (state, { payload }) =>
  state.merge({
    profileUserLoading: false,
    profileUserError: null,
    profileUser: payload,
  })

/**
 * @param state
 * @param error
 * @returns {*}
 */
export const fetchProfileUserFail = (state, { error }) =>
  state.merge({ profileUserError: error, profileUserLoading: false, profileUser: null })

export const reducer = createReducer(INITIAL_STATE, {
  // Reset
  [UserTypes.RESET_STATE]: resetState,
  [UserTypes.FETCH_COWORKERS]: getCoworkers,
  [UserTypes.FETCH_COWORKERS_SUCCESS]: getCoworkersSuccess,
  [UserTypes.FETCH_COWORKERS_FAIL]: getCoworkersFail,
  [UserTypes.RESET_COWORKERS]: resetCoworkers,
  [UserTypes.ADD_HELP_REQUEST]: addHelpRequest,
  [UserTypes.ADD_HELP_FAIL]: addHelpFail,
  [UserTypes.ADD_HELP_SUCCESS]: addHelpSuccess,
  [UserTypes.FETCH_DEVICE_TOKEN]: getDeviceToken,
  // Favorite users
  [UserTypes.FETCH_FAVORITE_COWORKERS]: getFavoriteCoworkers,
  [UserTypes.FETCH_FAVORITE_COWORKERS_SUCCESS]: getFavoriteCoworkersSuccess,
  [UserTypes.FETCH_FAVORITE_COWORKERS_FAIL]: getFavoriteCoworkersFail,
  // Staff users
  [UserTypes.FETCH_STAFF_COWORKERS]: getStaffCoworkers,
  [UserTypes.FETCH_STAFF_COWORKERS_SUCCESS]: getStaffCoworkersSuccess,
  [UserTypes.FETCH_STAFF_COWORKERS_FAIL]: getStaffCoworkersFail,
  // Set conversation id for notification status
  [UserTypes.FETCH_CURRENT_CONVERSATION_ID]: setConversationId,
  // Profile user
  [UserTypes.FETCH_PROFILE_USER]: fetchProfileUser,
  [UserTypes.FETCH_PROFILE_USER_SUCCESS]: fetchProfileUserSuccess,
  [UserTypes.FETCH_PROFILE_USER_FAIL]: fetchProfileUserFail,
})
