import { combineReducers } from 'redux'
import configureStore from './CreateStore'
import rootSaga from 'App/Sagas'
import { reducer as AuthReducer } from './Auth/Reducers'
import { reducer as UserReducer } from './User/Reducers'
import { reducer as PublicationReducer } from './Publication/Reducers'
import { reducer as MixesReducer } from './Mixes/Reducers'
import { reducer as ConversationReducer } from './Conversation/Reducers'
import { reducer as NotificationReducer } from './NotificationBadge/Reducers'

export default () => {
  const rootReducer = combineReducers({
    auth: AuthReducer,
    user: UserReducer,
    publication: PublicationReducer,
    mixes: MixesReducer,
    conversation: ConversationReducer,
    notification: NotificationReducer,
  })

  return configureStore(rootReducer, rootSaga)
}
