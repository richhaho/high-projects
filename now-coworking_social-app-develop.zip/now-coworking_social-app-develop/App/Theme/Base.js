import Colors from 'App/Theme/Colors'
import Metrics from 'App/Theme/Metrics'

export default {
  iconInput: {
    marginHorizontal: 20,
    color: Colors.iconInput,
  },
  iconInputError: {
    color: Colors.iconInputError,
  },
  flex: {
    flex: 1,
  },
  columnCenter: {
    display: 'flex',
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  statusBar: {
    backgroundColor: Colors.white,
    content: 'dark-content',
  },
  fab: {
    backgroundColor: Colors.brandPrimaryLight,
  },
  header: {
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.searchBorder,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  headerTitle: {
    color: Colors.heading,
    fontSize: Metrics.fontSizeXl,
    textAlign: 'center',
    paddingTop: 10,
  },
}
