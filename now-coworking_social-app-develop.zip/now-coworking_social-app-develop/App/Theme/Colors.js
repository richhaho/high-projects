module.exports = {
  // Color
  brandPrimary: '#8A7D5C',
  brandSecondary: '#4F4F4F',
  brandDark: '#2D2D2D',
  brandGrey: '#E5E5E5',
  lightGrey: '#F5F5F5',
  middleGrey: '#a9a9a9',
  brandRed: '#A34848',
  green100: '#94896C',
  brandPrimaryMedium: '#94896C', // proper alias for green100
  green200: '#A89F86',
  brandPrimaryLight: '#A89F86', // proper alias for green200
  green300: '#848484',
  darkGrey: '#848484', // proper alias for green300

  black: '#000000',
  white: '#ffffff',

  border: '#F0F0F0',
  inputBorder: '#E9E9E9',
  inputBorderError: '#DA8989',
  searchBorder: '#D6D6D6',
  searchInput: '#A9A9A9',

  heading: '#444A53',

  iconInput: '#A9A9A9',
  iconInputError: '#DA8989',
}
