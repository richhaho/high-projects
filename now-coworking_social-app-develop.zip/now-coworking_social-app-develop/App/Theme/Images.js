/**
 * Images should be stored in the `App/Images` directory and referenced using variables defined here.
 */

export default {
  iconFacebook: require('App/Images/icon-social-fb.png'),
  iconLinkedin: require('App/Images/icon-social-in.png'),
  iconInstagram: require('App/Images/icon-social-inst.png'),
  iconTwitter: require('App/Images/icon-social-tw.png'),
  logo: require('App/Images/logo.jpg'),
}
