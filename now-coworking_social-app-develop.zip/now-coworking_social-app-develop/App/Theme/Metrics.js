module.exports = {
  fontSizeXXs: 11,
  fontSizeXs: 12,
  fontSizeSmXs: 13,
  fontSizeSm: 14,
  fontSizeMd: 16,
  fontSizeXl: 18,
  fontSizeLarge: 24,
}
