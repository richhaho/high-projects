# Now Coworking social app

This project is the Now Coworking Social app built using [React Native](https://facebook.github.io/react-native/).

## Content

The project contains:

- a [React Native](https://facebook.github.io/react-native/) (v0.57.1) application (in "[ejected](https://github.com/react-community/create-react-native-app/blob/master/EJECTING.md)" mode to allow using dependencies that rely on native code)
- a [clear directory layout](#directory-layout) to provide a base architecture for your application
- [Redux](https://redux.js.org/) (v3.7) to help manage state
- [Redux Persist](https://github.com/rt2zz/redux-persist) (v5.9) to persist the Redux state
- [Redux Sagas](https://redux-saga.js.org) (v5.0) to separate side-effects and logic from state and UI logic
- [React Navigation](https://reactnavigation.org/) (v2.12) with a [`NavigationService`](App/Services/NavigationService.js) to handle routing and navigation in the app, with a splash screen setup by default
- [reduxsauce](https://github.com/infinitered/reduxsauce) (v0.7) to facilitate using Redux
- [apisauce](https://github.com/infinitered/apisauce) (v0.15) to make [axios](https://github.com/axios/axios) even better
- [prettier](https://prettier.io/) and [eslint](https://eslint.org/) preconfigured for React Native

## Directory layout

- [`App/Components`](App/Components): presentational components
- [`App/Config`](App/Config): configuration of the application
- [`App/Containers`](App/Containers): container components, i.e. the application's screens
- [`App/Images`](App/Images): images used by the application
- [`App/Sagas`](App/Sagas): redux sagas
- [`App/Services`](App/Services): application services, e.g. API clients
- [`App/Stores`](App/Stores): redux [actions, reducers and stores](https://redux.js.org/basics)
- [`App/Theme`](App/Theme): base styles for the application

For more information on each directory, click the link and read the directory's README.

## Requirements

Node 8 or greater is required. Development for iOS requires a Mac and Xcode 9 or up, and will target iOS 9 and up.

You also need to install the dependencies required by React Native

##### For OSX developer:

You need to install [Homebrew for Mac OSX](https://brew.sh/index_fr)

Install yarn
```
$ brew install yarn
```

```
$ sudo gem install cocoapods
```

Then run:
```
$ pod update
```

and read this documentation for [installing dependencies (iOS)](https://facebook.github.io/react-native/docs/getting-started.html#installing-dependencies) 

##### For Android developer:

Read this documentation for [installing dependencies (Android)](https://facebook.github.io/react-native/docs/getting-started.html#installing-dependencies-3)

## Running the project as external developer

Assuming you have all the requirements installed, you can setup and run the project by running:

You need to add your SSH key and be added to the project on Gitlab server before running this command
```
$ git clone git@git.thecodingmachine.com:tcm-projects/now-coworking_social-app.git
```

Then, run the following command:
- `yarn install` to install the dependencies


- create this file `App/Config/index.js` from `index.staging.js` template
- create this file `android/app/google-services.json` from `google-services.staging.json` template
- create this file `ios/app/GoogleService-Info.plist` from `GoogleService-Info.staging.plist` template


- `react-native run-android` to run the Android application (remember to start a simulator or connect an Android phone)
- `react-native run-ios` to run the iOS application (remember to start a simulator or connect an iPhone phone)
