<h3 align="center">Priips</h3>
<p align="center">MC2I project - DOCKER project - Manage contracts for life insurance products</p>

---

This document will help you setting up the Priips project. Please read it carefully.

If you have any issue, please contact Quentin Dubes (q.dubes@thecodinmachine.com) or Sonia Mnif (s.mnif@thecodingmachine.com).

# Modules

* [Traefik](https://traefik.io/) as a reverse-proxy
* NGINX as web server
* PHP-FPM 5.6 for executing the PHP code
* MySQL 5.7 as a DBMS (with phpMyAdmin on "local" environment) + session storage
* Graylog for centralizing the Docker's logs

# Code

This project uses the following stack:

* Symfony 3.3.9
* VueJS 2.4

**Note:** the backend is developed as a SPA (single application page). And the frontend is not developed as a SPA.

# Menu

* [Install](#install)
* [Setup](#setup)
* [Working with git](#working-with-git)
* [Orbit commands](#orbit-commands)
* [Documentation](#documentation)

## Install

Download and install [Docker](https://docs.docker.com/engine/installation/) (**>= 17.06**) for your platform.

On Linux, you also have to install [Docker compose](https://docs.docker.com/compose/install/) (**>= 1.14.0**) as it does not
come with by default. Also add your current user to the `docker` group and don't forget to logout/login from your current 
session.

Then download and install [Orbit](https://github.com/gulien/orbit) (**>= 2.0.0**), a tool for generating files from templates and 
running commands.

You may now clone this project using:

```
git clone --recursive git@git.thecodingmachine.com:tcm-projects/priips-docker.git priips
```

### Optional install for performance gains with Docker Sync (Mac and Windows)

Download and install the latest release of [Docker Sync](http://docker-sync.io/).

**Note:** On Windows, it only works with *Windows Subsystem for Linux*.

## Setup

Once you've downloaded this project, move to the config folder of this project and copy the file `.env.blueprint` and paste it to a file
named `.env`.

| Linux/Mac                	| Windows                    	|
|--------------------------	|----------------------------	|
| `cp .env.blueprint .env` 	| `copy .env.blueprint .env` 	|


**Note:** If you wish to enable *Docker Sync*, don't forget to set `ENABLE_DOCKER_SYNC` to `true` in your `.env` file.

Last but not least, **shutdown your local Apache or anything which could use your 80 and 443 ports**, and run:

```
orbit run kickoff
```

The installation might take some time, so go for a coffee break! :coffee: 


### Code dependencies

Enter the PHP-FPM container by running:

```
orbit run workspace
```

You may now run...

```
composer install
```

...to download and install the PHP dependencies.

Then, run...

```
yarn install
```

// TODO frontend dependecies installation procedure

Then you need to run databases migrations to create all tables:

```
php bin/console doctrine:migrations:migrate
```

Finally, populate this database with testing data:

```
php bin/console doctrine:fixtures:load
```

**Caution:** This command purges the database to insert all fixtures data again.

The default credentials for `/admin` are:

* *Login:* admin@admin.com
* *Password:* admin

## Working with git

This project is actually separated into two git's repositories:

* This current repository
* [The source code repository](https://git.thecodingmachine.com/tcm-projects/priips)

You should only work on the latest, which is a git submodule of the first.

In order to view your local changes, go to the `app` folder:

```
cd app
```

This is where you will run your git commands! :smiley:

Before going further, install git flow (see the [official documentation](https://github.com/nvie/gitflow/wiki/Installation)).

Once done, run:
 
```
git flow init
```

### Starting a new feature

First, update your local `develop` branch (status should be clean):

```
git pull origin develop
```

Then run:

```
git flow feature start yourfeaturename
```

### Pushing your local changes

**Note:** Always run `composer run php-cs-fixer` in the PHP-FPM container before 
pushing your branch!

```
git push origin feature/yourfeaturename
```

Once you think that your code is ready for review, open a new merge request to `develop` branch.

### Updating the Docker environment

Go to the root directory of this project and run:

```
orbit run shutdown
git pull origin master
orbit run kickoff
```

## Orbit commands

| Command                | Description                                                                                                                                              |
|------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|
| `orbit run`            | Displays available Orbit commands.                                                                                                                       |
| `orbit run kickoff`    | Generates all configuration files, builds the NGINX and PHP-FPM images and starts the containers. It's a combo of `build`, `proxy-up` and `up` commands. |
| `orbit run shutdown`   | Stops all containers. It's a combo of  `down` and `proxy-down` commands.                                                                                 |
| `orbit run build`      | Generates all configuration files and builds the NGINX and PHP-FPM images.                                                                               |
| `orbit run proxy-up`   | Starts the Traefik container.                                                                                                                            |
| `orbit run up`         | Starts all containers without the Traefik container.                                                                                                     |
| `orbit run proxy-down` | Stops the Traefik container.                                                                                                                             |
| `orbit run down`       | Stops all containers without the Traefik container.                                                                                                      |
| `orbit run workspace`  | Connects through ash to the PHP-FPM container. This is where you're able to run useful commands like `composer` and `yarn`.                              |
| `orbit run mysql-cli`  | Opens the MySQL cli as `root`. On environments <> `local`, it will ask you the MySQL `root` password.                                                    |

**Note:** You can use the `-d` flag to have a more detailed output.

## Documentation

* [Docker kickoff framework](https://github.com/thecodingmachine/kickoff-docker-php/tree/v2.2.0)