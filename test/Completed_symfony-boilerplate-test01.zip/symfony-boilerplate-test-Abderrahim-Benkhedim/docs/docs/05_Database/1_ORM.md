---
title: ORM
slug: /database/ORM
---

The boilerplate uses [TDBM](https://github.com/thecodingmachine/tdbm) as ORM. 
It is an alternative to Doctrine or Eloquent, yet it is pretty close.

The main difference is that with [TDBM](https://github.com/thecodingmachine/tdbm), 
you write your database's tables first before generating your models.
