---
title: LogRocket
slug: /deployments/logrocket
---

[LogRocket](https://logrocket.com/) is a great tool for your testing environments.

It allows you to replay what users do on the web application.

In order to enable it, you may add the `LOGROCKET_ID` environment variable 
to the content of your testing environments `.env` files.

:::note

📣&nbsp;&nbsp;[LogRocket](https://logrocket.com/) requires an account.

::: 