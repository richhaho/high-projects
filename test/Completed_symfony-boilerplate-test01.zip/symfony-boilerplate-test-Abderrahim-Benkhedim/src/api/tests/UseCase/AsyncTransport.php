<?php

declare(strict_types=1);

namespace App\Tests\UseCase;

final class AsyncTransport
{
    public const KEY = 'messenger.transport.async';
}
