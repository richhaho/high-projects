<?php

declare(strict_types=1);

namespace App\Tests\UseCase;

final class DummyValues
{
    public const BLANK   = '';
    public const CHAR256 = 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis,.';
}
