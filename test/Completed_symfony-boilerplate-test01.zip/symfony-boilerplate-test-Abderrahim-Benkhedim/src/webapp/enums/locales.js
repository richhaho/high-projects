export const FR = 'FR'
export const EN = 'EN'
