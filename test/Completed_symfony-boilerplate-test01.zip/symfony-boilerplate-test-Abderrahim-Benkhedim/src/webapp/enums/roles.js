export const ADMINISTRATOR = 'ADMINISTRATOR'
export const USER = 'USER'
