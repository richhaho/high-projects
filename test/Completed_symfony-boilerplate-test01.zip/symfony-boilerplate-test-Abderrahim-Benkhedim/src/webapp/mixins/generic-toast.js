export const GenericToast = {
  methods: {
    genericSuccessToast() {
      this.$toast.show(this.$t('mixins.generic_toast.success_message'))
    },
    genericCreateSuccessToast() {
      this.$toast.success(
        this.$t('mixins.generic_toast.create_success_message')
      )
    },
    genericUpdateSuccessToast() {
      this.$toast.success(
        this.$t('mixins.generic_toast.update_success_message')
      )
    },
  },
}
