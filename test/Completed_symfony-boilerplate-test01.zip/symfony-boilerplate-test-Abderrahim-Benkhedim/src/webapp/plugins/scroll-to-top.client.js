import Vue from 'vue'

Vue.prototype.$scrollToTop = () => window.scrollTo(0, 0)
