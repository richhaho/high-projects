export default {
  isGlobalOverlayActive(state) {
    return state.display
  },
}
