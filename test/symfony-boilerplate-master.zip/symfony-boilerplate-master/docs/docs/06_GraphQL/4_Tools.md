---
title: Tools
slug: /graphql/tools
---

The API provides the endpoint `/graphiql` (in development) so that you may quickly test a query or a mutation.

You may also use the [Altair GraphQL Client](https://altair.sirmuel.design/).