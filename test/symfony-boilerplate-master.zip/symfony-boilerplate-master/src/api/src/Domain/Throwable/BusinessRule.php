<?php

declare(strict_types=1);

namespace App\Domain\Throwable;

use Throwable;

interface BusinessRule extends Throwable
{
}
