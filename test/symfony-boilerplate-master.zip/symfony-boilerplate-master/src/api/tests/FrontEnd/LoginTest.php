<?php

declare(strict_types=1);

namespace App\Tests\FrontEnd;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class LoginTest extends WebTestCase
{
}
