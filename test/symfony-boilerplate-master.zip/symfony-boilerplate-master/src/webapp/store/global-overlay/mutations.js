export default {
  displayGlobalOverlay(state) {
    state.display = true
  },
  hideGlobalOverlay(state) {
    state.display = false
  },
}
