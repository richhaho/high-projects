export default () => ({
  display: false,
})
